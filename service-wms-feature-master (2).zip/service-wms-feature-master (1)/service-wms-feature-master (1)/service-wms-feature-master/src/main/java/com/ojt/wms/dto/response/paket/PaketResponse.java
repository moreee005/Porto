package com.ojt.wms.dto.response.paket;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaketResponse {

    @JsonProperty("kode_paket")
    private String kodePaket;

    @JsonProperty("nama_paket")
    private String namaPaket;

    @JsonProperty("tipe_service")
    private TipeServiceResponse tipeService;

    @JsonProperty("total_harga")
    private BigDecimal totalHarga;
}
