package com.ojt.wms.dto.response.paket;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaketDetailResponse {

    private PaketResponse informasiUmum;
    private List<PartPaketResponse> dataPart;
    private List<JasaPaketResponse> dataJasa;
}
