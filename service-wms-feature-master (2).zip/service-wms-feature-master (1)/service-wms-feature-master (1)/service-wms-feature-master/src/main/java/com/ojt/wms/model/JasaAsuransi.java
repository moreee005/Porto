package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "JasaAsuransi")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JasaAsuransi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_jasa_asuransi", nullable = false, unique = true, updatable = false)
    private Integer idJasaAsuransi;

    @ManyToOne
    @JoinColumn(name = "id_organisasi", referencedColumnName = "id_organisasi")
    private Organization organization;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "kode_jasa_asuransi", nullable = true)
    private String kodeJasaAsuransi;

    @Column(name = "nama_jasa_asuransi", nullable = true)
    private String namaJasaAsuransi;

    @Column(name = "bid", nullable = true)
    private BigDecimal bid;

    @Column(name = "i", nullable = true)
    private BigDecimal i;

    @Column(name = "ii", nullable = true)
    private BigDecimal ii;

    @Column(name = "iii", nullable = true)
    private BigDecimal iii;

    @Column(name = "iv", nullable = true)
    private BigDecimal iv;

    @Column(name = "v", nullable = true)
    private BigDecimal v;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
