package com.ojt.wms.dto.response.part;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartResponseGet {

    private List<PartData> data; // List of parts
    private Long totalItems;     // Total items
    private Integer totalPages;  // Total pages
    private Integer currentPage; // Current page

    // Nested class for Part data
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartData {
        private String kodePart;         // Part code
        private String partName;         // Part name
        private String partDivision;     // Part division
        private Short partOnHand;      // Quantity on hand
        private BigDecimal partBuyPrice; // Buying price
        private BigDecimal partSellPrice;// Selling price
        private String partBrand;        // Part brand
    }
}
