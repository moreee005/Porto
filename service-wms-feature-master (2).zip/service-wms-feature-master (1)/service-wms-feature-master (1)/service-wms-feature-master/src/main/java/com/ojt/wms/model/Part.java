package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Part")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Part {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_part", nullable = false, unique = true, updatable = false)
    private Long idPart;

    @ManyToOne
    @JoinColumn(name = "id_karyawan", referencedColumnName = "id_karyawan")
    private Karyawan karyawan;

    @ManyToOne
    @JoinColumn(name = "id_kendaraan", referencedColumnName = "id_kendaraan")
    private Kendaraan kendaraan;

    @Column(name = "kode_part", nullable = true)
    private String kodePart;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "nama_part", nullable = true)
    private String namaPart;

    @Column(name = "harga_part", nullable = true)
    private BigDecimal hargaPart;

    @Column(name = "part_barcode", nullable = true)
    private String partBarcode;

    @Column(name = "part_brand", nullable = true)
    private String partBrand;

    @Column(name = "part_buy_price", nullable = true)
    private BigDecimal partBuyPrice;

    @Column(name = "part_code2", nullable = true)
    private String partCode2;

    @Column(name = "part_division", nullable = true)
    private String partDivision;

    @Column(name = "part_group", nullable = true)
    private String partGroup;

    @Column(name = "part_lokasi1", nullable = true)
    private String partLokasi1;

    @Column(name = "part_lokasi2", nullable = true)
    private String partLokasi2;

    @Column(name = "part_max_qty", nullable = true)
    private Short partMaxQty;

    @Column(name = "part_min_qty", nullable = true)
    private Short partMinQty;

    @Column(name = "part_nomor_stock", nullable = true)
    private Short partNomorStock;

    @Column(name = "note", nullable = true)
    private String note;

    @Column(name = "part_opb", nullable = true)
    private Boolean partOpb;

    @Column(name = "part_opsck", nullable = true)
    private Boolean partOpsck;

    @Column(name = "part_on_hand", nullable = true)
    private Short partOnHand;

    @Column(name = "part_satuan", nullable = true)
    private String partSatuan;

    @Column(name = "part_sell_price_ag", nullable = true)
    private BigDecimal partSellPriceAg;

    @Column(name = "part_sell_price_bp", nullable = true)
    private BigDecimal partSellPriceBp;

    @Column(name = "part_sell_price_d", nullable = true)
    private BigDecimal partSellPriceD;

    @Column(name = "part_sell_price_r", nullable = true)
    private BigDecimal partSellPriceR;

    @Column(name = "part_status", nullable = true)
    private String partStatus;

    @Column(name = "part_sub_division", nullable = true)
    private String partSubDivision;

    @Column(name = "part_ukuran", nullable = true)
    private BigDecimal partUkuran;

    @Column(name = "part_expired", nullable = true)
    private Boolean partExpired;

    @Column(name = "part_photo", nullable = true)
    private String partPhoto;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "created_by", nullable = true)
    private String createdBy;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
