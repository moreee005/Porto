package com.ojt.wms.dto.response.part;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartResponse {

    private String kodePart;
    private String partCode2;
    private String partName;
    private PartDivision partDivision;
    private String partSubDivision;
    private String partBrand;
    private PartGroup partGroup;
    private BigDecimal partBuyPrice;
    private BigDecimal partSellPriceR;
    private BigDecimal partSellPriceBP;
    private BigDecimal partSellPriceAG;
    private BigDecimal partSellPriceD;
    private Short partOnHand;
    private Short partMinQty;
    private Short partMaxQty;
    private String partBarcode;
    private PartSatuan partSatuan;
    private BigDecimal partUkuran;
    private Short partNomorStock;
    private PartStatus partStatus;
    private String partLocation1;
    private String partLocation2;
    private String partNote;
    private List<PartPhoto> partPhoto;
    private Boolean partExpired;
    private Boolean partOPSCK;
    private Boolean partOPB;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartDivision {
        private Integer idDivisi;

        private String namaDivisi;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartGroup {
        private Integer idGroup;

        private String namaGroup;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartSatuan {
        private Integer idSatuan;

        private String namaSatuan;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartStatus {
        private Integer idStatus;

        private String namaStatus;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartPhoto {
        private String filename;
        private String fileLink;
    }
}
