package com.ojt.wms.model;
import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ProgressWo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProgressWo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_progress_wo", nullable = true)
    private Long idProgressWo;

    @ManyToOne
    @JoinColumn(name = "id_borongan")
    private Borongan borongan;

    @ManyToOne
    @JoinColumn(name = "id_status_pekerjaan")
    private StatusPekerjaan statusPekerjaan;

    @ManyToOne
    @JoinColumn(name = "id_wo")
    private WorkOrder workOrder;
    
    @Column(name = "nama_mekanik", nullable = true)
    private String namaMekanik;

    @Column(name = "tgl_mulai_kerja", nullable = true)
    private LocalDate tglMulaiKerja;

    @Column(name = "tgl_selesai_kerja", nullable = true)
    private LocalDate tglSelesaiKerja;

    @Column(name = "status_pengerjaan", nullable = true)
    private String statusPengerjaan;

    @Column(name = "urutan_pekerjaan", nullable = true)
    private Short urutanPekerjaan;

    @Column(name = "proses", nullable = true)
    private String proses;

    @Column(name = "foto_progress", nullable = true)
    private String fotoProgress;

    @Column(name = "is_submitted")
    private Boolean isSubmitted;

    @Column(name = "is_rework")
    private Boolean isRework;

    @Column(name = "is_riwayat")
    private Boolean isRiwayat;

    @Column(name = "alasan_rework")
    private String alasanRework;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}