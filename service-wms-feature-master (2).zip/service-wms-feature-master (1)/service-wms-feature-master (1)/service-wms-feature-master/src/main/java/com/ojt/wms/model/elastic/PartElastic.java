package com.ojt.wms.model.elastic;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(indexName = "parts")
public class PartElastic {

    @Id
    private String idPart;  // Di Elasticsearch, ID biasanya adalah String

    @Field(type = FieldType.Keyword)
    private String kodePart;

    @Field(type = FieldType.Integer)
    private Integer idBengkel;

    @Field(type = FieldType.Text, analyzer = "standard")
    private String namaPart;

    @Field(type = FieldType.Double)
    private BigDecimal hargaPart;

    @Field(type = FieldType.Keyword)  // Exact match, tidak dianalisis
    private String partBarcode;

    @Field(type = FieldType.Keyword)  // Exact match, tidak dianalisis
    private String partBrand;

    @Field(type = FieldType.Double)
    private BigDecimal partBuyPrice;

    @Field(type = FieldType.Keyword)  // Exact match, tidak dianalisis
    private String partCode2;

    @Field(type = FieldType.Keyword)
    private String partDivision;

    @Field(type = FieldType.Keyword)
    private String partGroup;

    @Field(type = FieldType.Keyword)
    private String partLokasi1;

    @Field(type = FieldType.Keyword)
    private String partLokasi2;

    @Field(type = FieldType.Short)
    private Short partMaxQty;

    @Field(type = FieldType.Short)
    private Short partMinQty;

    @Field(type = FieldType.Short)
    private Short partNomorStock;

    @Field(type = FieldType.Text)
    private String note;

    @Field(type = FieldType.Boolean)
    private Boolean partOpb;

    @Field(type = FieldType.Boolean)
    private Boolean partOpsck;

    @Field(type = FieldType.Short)
    private Short partOnHand;

    @Field(type = FieldType.Keyword)
    private String partSatuan;

    @Field(type = FieldType.Double)
    private BigDecimal partSellPriceAg;

    @Field(type = FieldType.Double)
    private BigDecimal partSellPriceBp;

    @Field(type = FieldType.Double)
    private BigDecimal partSellPriceD;

    @Field(type = FieldType.Double)
    private BigDecimal partSellPriceR;

    @Field(type = FieldType.Keyword)
    private String partStatus;

    @Field(type = FieldType.Keyword)
    private String partSubDivision;

    @Field(type = FieldType.Double)
    private BigDecimal partUkuran;

    @Field(type = FieldType.Boolean)
    private Boolean partExpired;

    @Field(type = FieldType.Keyword)
    private String partPhoto;

    @Field(type = FieldType.Date, format = DateFormat.date_time)  // Menggunakan LocalDateTime
    private LocalDateTime createdDate;

    @Field(type = FieldType.Keyword)
    private String createdBy;

    @Field(type = FieldType.Keyword)
    private String modifiedBy;

    @Field(type = FieldType.Date, format = DateFormat.date_time)  // Menggunakan LocalDateTime
    private LocalDateTime modifiedDate;

    @Field(type = FieldType.Boolean)
    @Builder.Default
    private Boolean isDeleted = false;
}
