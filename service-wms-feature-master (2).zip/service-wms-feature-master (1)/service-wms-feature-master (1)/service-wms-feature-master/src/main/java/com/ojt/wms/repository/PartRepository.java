package com.ojt.wms.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ojt.wms.model.Part;
import java.util.*;

@Repository
public interface PartRepository extends JpaRepository<Part, Long> {
    @Query("SELECT p FROM Part p WHERE p.kodePart LIKE %:search% OR p.namaPart LIKE %:search%")
    List<Part> findBySearchCriteria(@Param("search") String search);

    Optional<Part> findByKodePart(String kodePart);

    @Query("SELECT p FROM Part p WHERE LOWER(p.namaPart) LIKE LOWER(CONCAT('%', :namaPart, '%'))")
    Page<Part> findByNamaPartContaining(@Param("namaPart") String namaPart, Pageable pageable);

    @Query(value = "SELECT * FROM part WHERE LOWER(kode_part) = LOWER(:kodePart)", nativeQuery = true)
    List<Part> findByIdPart(@Param("kodePart") String kodePart);

    @Query(value = "SELECT * FROM part ORDER BY id_part DESC LIMIT 1", nativeQuery = true)
    Optional<Part> rowTerakhirPart();

    @Query(value = "SELECT * FROM part WHERE LOWER(nama_part) LIKE LOWER(CONCAT('%', :namaPart, '%'))", nativeQuery = true)
    List <Part> findByNamaPart(@Param("namaPart") String namaPart);

    @Query(value = "SELECT * FROM part WHERE id_part NOT IN :idParts", nativeQuery = true)
    List<Part> findByIdPartNotIn(@Param("idParts") List<Long> idParts);

}
