package com.ojt.wms.dto.request.jasa;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JasaRequest {
    @JsonProperty
    private String namaJasa;
    
    @JsonProperty
    private BigDecimal bid;

    @JsonProperty
    private BigDecimal hargaJasa;
}
