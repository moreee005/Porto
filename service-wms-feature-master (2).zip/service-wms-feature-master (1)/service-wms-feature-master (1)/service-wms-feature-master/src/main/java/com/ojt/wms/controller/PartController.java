package com.ojt.wms.controller;
import com.ojt.wms.dto.request.PartRequest;
import com.ojt.wms.dto.response.MessagesResponse;
import com.ojt.wms.service.PartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/part")
public class PartController {

    @Autowired
    private PartService partService;


    // Endpoint untuk menghandle post request
    @PostMapping("/parts")
    public ResponseEntity<MessagesResponse> createPart(
            @ModelAttribute PartRequest partRequest,   // Menggunakan @ModelAttribute untuk menerima form-data
            @RequestParam(value = "photo", required = false) MultipartFile photo // Field untuk file upload
    ) {
        // Panggil service untuk memproses permintaan
        MessagesResponse response = partService.postPart(partRequest, photo);

        // Kembalikan response sesuai dengan statusnya
        return ResponseEntity
                .status(response.getStatusCode())
                .body(response);
    }

    @GetMapping("/parts")
    public ResponseEntity<MessagesResponse> getParts(
            @RequestParam(value = "namaPart", required = false) String namaPart,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "10") int size,
            @RequestParam(value = "sortBy", defaultValue = "kodePart") String sortBy,
            @RequestParam(value = "orderBy", defaultValue = "asc") String orderBy
    ) {
        MessagesResponse response = partService.getPart(namaPart, page, size, sortBy, orderBy);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/lov-divisi")
    public ResponseEntity<MessagesResponse> getPartLovDivisi(){
        MessagesResponse response = partService.getPartDivision();
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/lov-status")
    public ResponseEntity<MessagesResponse> getPartStatus(){
        MessagesResponse response = partService.getPartStatus();
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/lov-satuan")
    public ResponseEntity<MessagesResponse> getPartSatuan(){
        MessagesResponse response = partService.getPartSatuan();
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/lov-groups")
    public ResponseEntity<MessagesResponse> getPartGroup(){
        MessagesResponse response = partService.getPartGroup();
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/parts/dto")
    public ResponseEntity<MessagesResponse> getPartDto(@RequestParam String kodePart) {
        MessagesResponse response = partService.getPartDto(kodePart);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @PutMapping("/parts/update")
    public ResponseEntity<MessagesResponse> updatePart(@RequestParam String kodePart , PartRequest partRequest) {
        MessagesResponse response = partService.updatePart(kodePart, partRequest);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @DeleteMapping ("/parts/delete")
    public ResponseEntity<MessagesResponse> deletePart(@RequestParam String kodePart) {
        MessagesResponse response = partService.deletePart(kodePart);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @PostMapping ("/parts/import")
    public ResponseEntity<MessagesResponse> importPart(@RequestParam("fileType") MultipartFile fileType) {
        MessagesResponse response = partService.importExelPart(fileType);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/product/download-excel")
    public ResponseEntity<MessagesResponse> getDownloadExel(){
        MessagesResponse response = partService.downloadTemplateExel();
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }


}
