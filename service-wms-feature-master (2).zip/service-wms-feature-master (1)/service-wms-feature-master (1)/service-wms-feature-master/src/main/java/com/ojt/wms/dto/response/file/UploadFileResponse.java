package com.ojt.wms.dto.response.file;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadFileResponse {
    @JsonProperty
    private String fileName;

    @JsonProperty
    private String contentType;

    @JsonProperty
    private Long fileSize;

    @JsonProperty
    private String fileLink;
}
