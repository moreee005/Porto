package com.ojt.wms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ojt.wms.model.PartPaket;

@Repository
public interface PartPaketRepository extends JpaRepository<PartPaket, Long> {
}
