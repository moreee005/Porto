package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import jakarta.persistence.ManyToOne;
import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Person")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "nik", nullable = false, unique = true, updatable = false, length = 50)
    private String nik;

    @ManyToOne
    @JoinColumn(name = "id_kota", referencedColumnName = "id_kota")
    private Kota kota;

    @ManyToOne
    @JoinColumn(name = "id_pendidikan_terakhir", referencedColumnName = "id_pendidikan_terakhir")
    private PendidikanTerakhir pendidikanTerakhir;

    @Column(name = "nama", nullable = true)
    private String nama;

    @Column(name = "alamat", nullable = true, columnDefinition = "TEXT")
    private String alamat;

    @Column(name = "telp", nullable = true)
    private String telp;

    @Column(name = "hp", nullable = true)
    private String hp;

    @Column(name = "email", nullable = true)
    private String email;

    @Column(name = "npwp", nullable = true)
    private String npwp;

    @Column(name = "tempat_lahir", nullable = true)
    private String tempatLahir;

    @Column(name = "tanggal_lahir", nullable = true)
    private LocalDate tanggalLahir;

    @Column(name = "jenis_kelamin", nullable = true)
    private String jenisKelamin;

    @Column(name = "nama_sekolah", nullable = true)
    private String namaSekolah;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
