package com.ojt.wms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ojt.wms.dto.response.MessagesResponse;
import com.ojt.wms.service.RepairService;

@RestController
@RequestMapping("/product")
public class RepairController {
    
    @Autowired
    private RepairService repairService;
    
    @GetMapping("/jasa-service-lov")
    public ResponseEntity<MessagesResponse> getJasaServiceLov() {
        MessagesResponse response = repairService.getJasaServiceLov();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
