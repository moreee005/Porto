package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Inspeksi")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Inspeksi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_inspeksi", nullable = false, unique = true, updatable = false)
    private Long idInspeksi;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "status_inspeksi", nullable = true)
    private String statusInspeksi;

    @Column(name = "tgl_mulai_inspeksi", nullable = true)
    private LocalDate tglMulaiInspeksi;

    @Column(name = "tgl_selesai_inspeksi", nullable = true)
    private LocalDate tglSelesaiInspeksi;

    @Column(name = "foto_inspeksi", nullable = true, columnDefinition = "TEXT")
    private String fotoInspeksi;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
