package com.ojt.wms.model;
import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Supplier")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Supplier {

    @Id
    @ManyToOne
    @JoinColumn(name = "id_organisasi", referencedColumnName = "id_organisasi")
    private Organization organization;
    
    @ManyToOne
    @JoinColumn(name = "id_kota", referencedColumnName = "id_kota")
    private Kota kota;

    @ManyToOne
    @JoinColumn(name = "id_cabang", referencedColumnName = "id_cabang")
    private Cabang cabang;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "nama_organisasi", nullable = true)
    private String namaOrganisasi;

    @Column(name = "alamat", nullable = true, columnDefinition = "TEXT")
    private String alamat;

    @Column(name = "kode_supplier", nullable = true)
    private String kodeSupplier;

    @Column(name = "supplier_due_day", nullable = true)
    private LocalDate supplierDueDay;

    @Column(name = "npwp_supplier", nullable = true)
    private String npwpSupplier;

    @Column(name = "supplier_office_number", nullable = true)
    private String supplierOfficeNumber;

    @Column(name = "supplier_phone_number", nullable = true)
    private String supplierPhoneNumber;

    @Column(name = "supplier_pic", nullable = true)
    private String supplierPic;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}