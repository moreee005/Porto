package com.ojt.wms.dto.response.jasa;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JasaResponse {
    @JsonProperty
    private Integer idJasa;
    
    @JsonProperty
    private String kodeJasa;

    @JsonProperty
    private String namaJasa;

    @JsonProperty
    private BigDecimal hargaJasa;
}
