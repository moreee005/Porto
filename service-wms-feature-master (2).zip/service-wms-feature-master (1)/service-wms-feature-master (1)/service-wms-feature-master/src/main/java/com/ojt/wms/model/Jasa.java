package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Jasa")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Jasa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_jasa", nullable = false, unique = true, updatable = false)
    private Integer idJasa;

    @ManyToOne
    @JoinColumn(name = "kode_kategori", referencedColumnName = "kode_kategori")
    private KategoriLayanan kategoriLayanan;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "kode_jasa", nullable = true)
    private String kodeJasa;

    @Column(name = "nama_jasa", nullable = true)
    private String namaJasa;

    @Column(name = "harga_jasa", nullable = true)
    private BigDecimal hargaJasa;

    @Column(name = "bid", nullable = true)
    private BigDecimal bid;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;

}
