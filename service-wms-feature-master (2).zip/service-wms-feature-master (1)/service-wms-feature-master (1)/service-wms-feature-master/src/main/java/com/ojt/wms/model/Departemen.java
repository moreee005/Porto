package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Departemen")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Departemen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "kode_departemen", nullable = false, unique = true, updatable = false)
    private Integer kodeDepartemen;

    @ManyToOne
    @JoinColumn(name = "id_organisasi", referencedColumnName = "id_organisasi")
    private Organization organization;

    @Column(name = "nama_departemen", nullable = true)
    private String namaDepartemen;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
