package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Kendaraan")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Kendaraan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_kendaraan", nullable = false, unique = true, updatable = false)
    private Long idKendaraan;

    @Column(name = "no_polisi", nullable = true)
    private String noPolisi;

    @ManyToOne
    @JoinColumn(name = "kode_jenis", referencedColumnName = "kode_jenis")
    private JenisKendaraan jenisKendaraan;

    @ManyToOne
    @JoinColumn(name = "kode_tipe", referencedColumnName = "kode_tipe")
    private TipeKendaraan tipeKendaraan;

    @ManyToOne
    @JoinColumn(name = "kode_warna", referencedColumnName = "kode_warna")
    private Warna warna;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "tahun", nullable = true)
    private BigDecimal tahun;

    @Column(name = "no_rangka", nullable = true)
    private String noRangka;

    @Column(name = "no_mesin", nullable = true)
    private String noMesin;

    @Column(name = "transmisi", nullable = true)
    private String transmisi;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
