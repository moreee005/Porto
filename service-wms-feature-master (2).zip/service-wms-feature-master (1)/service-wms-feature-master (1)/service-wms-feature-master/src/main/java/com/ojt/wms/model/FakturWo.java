package com.ojt.wms.model;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "FakturWo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FakturWo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_faktur_wo", nullable = true)
    private Integer idFakturWo;

    @ManyToOne
    @JoinColumn(name = "id_wo")
    private WorkOrder workOrder;

    @ManyToOne
    @JoinColumn(name = "id_faktur_transaksi")
    private FakturTransaksi fakturTransaksi;

    @Column(name = "kode_faktur")
    private String kodeFaktur;

    @Column(name = "tgl_faktur")
    private LocalDate tglFaktur;

    @Column(name = "labor_persen_faktur")
    private Short laborPersenFaktur;
    
    @Column(name = "material_persen_faktur")
    private Short materialPersenFaktur;
    
    @Column(name = "sub_total")
    private BigDecimal subTotal;
    
    @Column(name = "ppn")
    private BigDecimal ppn;
    
    @Column(name = "ppn_jasa")
    private BigDecimal ppn_jasa;
    
    @Column(name = "ppn_part")
    private BigDecimal ppn_part;
    
    @Column(name = "pph")
    private BigDecimal pph;
    
    @Column(name = "materai")
    private BigDecimal materai;
    
    @Column(name = "merimen")
    private BigDecimal merimen;
    
    @Column(name = "salvage")
    private BigDecimal salvage;
    
    @Column(name = "biaya_derek")
    private BigDecimal biayaDerek;
    
    @Column(name = "biaya_bensin")
    private BigDecimal biayaBensin;
    
    @Column(name = "dp")
    private BigDecimal dp;

    @Column(name = "jml_bayar")
    private BigDecimal jmlBayar;
    
    @Column(name = "tgl_jatuh_tempo")
    private LocalDate tglJatuhTempo;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}