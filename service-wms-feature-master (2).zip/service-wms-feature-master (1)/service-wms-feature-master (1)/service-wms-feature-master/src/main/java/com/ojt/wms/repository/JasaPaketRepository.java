package com.ojt.wms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ojt.wms.model.JasaPaket;

@Repository
public interface JasaPaketRepository extends JpaRepository<JasaPaket, Long> {
    
}
