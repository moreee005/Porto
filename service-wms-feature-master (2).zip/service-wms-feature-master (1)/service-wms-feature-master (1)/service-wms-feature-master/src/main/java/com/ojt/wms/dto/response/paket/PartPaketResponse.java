package com.ojt.wms.dto.response.paket;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartPaketResponse {

    private Integer idPartPaket;
    private String kodePart;
    private String namaPart;
    private BigDecimal hargaPartPaket;
    private Short qtyPart;
    private BigDecimal discPart;
    private BigDecimal jmlPart;
}
