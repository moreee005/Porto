package com.ojt.wms.dto.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartRequest {
    private String kodePart;
    private String partCode2;
    private String partName;
    private Integer idDivisi;
    private String namaDivisi;
    private String partSubDivision;
    private String partBrand;
    private Integer idGroup;
    private String namaGroup;
    private BigDecimal partBuyPrice;
    private BigDecimal partSellPriceR;
    private BigDecimal partSellPriceBP;
    private BigDecimal partSellPriceAG;
    private BigDecimal partSellPriceD;
    private Short partOnHand;
    private Short partMinQty;
    private Short partMaxQty;
    private String partBarcode;
    private Integer idSatuan;
    private String namaSatuan;;
    private BigDecimal partUkuran;
    private Short partNomorStock;
    private Integer idStatus;
    private String namaStatus;
    private String partLocation1;
    private String partLocation2;
    private String partNote;
    private String filename;
    private String fileLink;
    private Boolean partExpired;
    private Boolean partOPSCK;
    private Boolean partOPB;
}
