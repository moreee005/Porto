package com.ojt.wms.model;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "PartInspeksi")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartInspeksi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_part_inspeksi", nullable = true)
    private Long idPartInspeksi;

    @ManyToOne
    @JoinColumn(name = "id_inspeksi")
    private Inspeksi inspeksi;

    @ManyToOne
    @JoinColumn(name = "id_part_pkb")
    private PartPkb partPkb;

    @Column(name = "status_inspeksi_part")
    private String statusInspeksiPart;

    @Column(name = "ket_inspeksi_part", columnDefinition = "TEXT")
    private String ketInspeksiPart;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}