package com.ojt.wms.model;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Bengkel")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Bengkel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_bengkel", nullable = false, unique = true, updatable = false)
    private Integer idBengkel;

    @ManyToOne
    @JoinColumn(name = "id_organisasi", referencedColumnName = "id_organisasi")
    private Organization organization;

    @ManyToOne
    @JoinColumn(name = "id_kota", referencedColumnName = "id_kota")
    private Kota kota;

    @Column(name = "logo_bengkel", columnDefinition = "TEXT")
    private String logoBengkel;

    @Column(name = "nama_bengkel")
    private String namaBengkel;

    @Column(name = "nama_pt_bengkel")
    private String namaPtBengkel;

    @Column(name = "alamat_bengkel", columnDefinition = "TEXT")
    private String alamatBengkel;

    @Column(name = "lokasi_surat_bengkel_dibuat")
    private String lokasiSuratBengkelDibuat;

    @Column(name = "telp_bengkel")
    private String telpBengkel;

    @Column(name = "info_pembayaran_bengkel", columnDefinition = "TEXT")
    private String infoPembayaranBengkel;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}

