package com.ojt.wms.dto.request.paket;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartPaketRequest {

    private String kodePart;
    private String namaPart;
    private BigDecimal hargaPartPaket;
    private Short qtyPart;
    private BigDecimal discPart;
    private BigDecimal jmlPart;
}
