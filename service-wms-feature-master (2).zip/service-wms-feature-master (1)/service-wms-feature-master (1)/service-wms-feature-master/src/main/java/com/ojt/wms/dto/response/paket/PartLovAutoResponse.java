package com.ojt.wms.dto.response.paket;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartLovAutoResponse {

    private String kodePart;
    private String karyawan;
    private String kendaraan;
    private String namaPart;
    private String partBarcode;
    private String partBrand;
    private BigDecimal partBuyPrice;
    private String partCode2;
    private String partDivision;
    private String partGroup;
    private String partLokasi1;
    private String partLokasi2;
    private Short partMaxQty;
    private Short partMinQty;
    private Short partNomorStock;
    private String note;
    private Boolean partOpb;
    private Boolean partOpsck;
    private Short partOnHand;
    private String partSatuan;
    private BigDecimal partSellPriceAg;
    private BigDecimal partSellPriceBp;
    private BigDecimal partSellPriceD;
    private BigDecimal partSellPriceR;
    private String partStatus;
    private String partSubDivision;
    private BigDecimal partUkuran;
    private Boolean partExpired;
    private String partPhoto;
    private Timestamp createdDate;
    private String createdBy;
    private Timestamp modifiedDate;
    private String modifiedBy;
    private Boolean isDeleted;
}
