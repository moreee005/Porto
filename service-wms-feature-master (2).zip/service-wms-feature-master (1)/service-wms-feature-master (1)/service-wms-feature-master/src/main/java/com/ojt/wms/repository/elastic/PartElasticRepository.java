package com.ojt.wms.repository.elastic;

import com.ojt.wms.model.elastic.PartElastic;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PartElasticRepository extends ElasticsearchRepository<PartElastic, String> {
    // Di sini Anda bisa menambahkan query method kustom jika diperlukan
}
