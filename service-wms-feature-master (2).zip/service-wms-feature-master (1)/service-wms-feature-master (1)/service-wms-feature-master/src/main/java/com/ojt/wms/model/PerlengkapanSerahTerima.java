package com.ojt.wms.model;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "PerlengkapanSerahTerima")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PerlengkapanSerahTerima {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_perlengkapan_serah_terima", nullable = true)
    private Long idPerlengkapanSerahTerima;

    @ManyToOne
    @JoinColumn(name = "kode_perlengkapan")
    private PerlengkapanKendaran perlengkapanKendaraan; 

    @ManyToOne
    @JoinColumn(name = "kode_serah_terima")
    private SerahTerima serahTerima;
    
    @Column(name = "status_perlengkapan")
    private String statusPerlengkapan;

    @Column(name = "ket_perlengkapan")
    private String ketPerlengkapan;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}