package com.ojt.wms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import com.ojt.wms.model.Jasa;

@Repository
public interface JasaRepository extends JpaRepository<Jasa, Integer> {
    Optional<Jasa> findByKodeJasa(String kodeJasa);
}
