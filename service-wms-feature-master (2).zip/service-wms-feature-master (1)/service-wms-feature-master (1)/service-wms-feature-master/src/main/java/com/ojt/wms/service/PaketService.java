package com.ojt.wms.service;

import com.ojt.wms.dto.request.paket.PaketRequest;
import com.ojt.wms.dto.response.MessagesResponse;
import com.ojt.wms.dto.response.paket.JasaPaketResponse;
import com.ojt.wms.dto.response.paket.PaketDetailResponse;
import com.ojt.wms.dto.response.paket.PaketResponse;
import com.ojt.wms.dto.response.paket.PartPaketResponse;
import com.ojt.wms.dto.response.paket.TipeServiceResponse;
import com.ojt.wms.exception.CustomErrorWithStatusException;
import com.ojt.wms.model.Jasa;
import com.ojt.wms.model.JasaPaket;
import com.ojt.wms.model.Paket;
import com.ojt.wms.model.Part;
import com.ojt.wms.model.PartPaket;
import com.ojt.wms.repository.JasaRepository;
import com.ojt.wms.repository.PaketRepository;
import com.ojt.wms.repository.PartRepository;
import com.ojt.wms.util.MessageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PaketService {

    
    @Autowired
    private PaketRepository paketRepository;

    @Autowired
    private PartRepository partRepository;

    @Autowired
    private JasaRepository jasaRepository;

    @Autowired
    private MessageUtil messageUtil;

    // Fungsi untuk mendapatkan semua packages
    public MessagesResponse getPackages(
            String searchKeyword,
            int pageNumber,
            int pageSize,
            String sortBy,
            String orderBy) {

        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;
        MessagesResponse.Meta meta = null;

        try {
            // Default sorting by 'namaPaket' ASC
            Sort sort = Sort.by(Sort.Direction.ASC, "namaPaket");
            if (sortBy != null && !sortBy.isEmpty()) {
                sort = Sort.by(Sort.Direction.fromString(orderBy), sortBy);
            }

            Pageable pageable = PageRequest.of(pageNumber - 1, pageSize, sort);
            Page<Paket> pagedResult = paketRepository.findAll(pageable);

            if (pagedResult.isEmpty()) {
                throw new CustomErrorWithStatusException(
                        messageUtil.get("application.error.notfound", "Packages"),
                        null,
                        HttpStatus.NOT_FOUND
                );
            }

            List<PaketResponse> paketResponses = pagedResult.getContent().stream()
                .map(this::mapToPaketResponse)
                .collect(Collectors.toList());

            // Create metadata
            meta = new MessagesResponse.Meta(
                    (int) pagedResult.getTotalElements(), // Total records
                    pageable.getPageSize(), // Records per page
                    pageable.getPageNumber() + 1, // Current page number (Pageable starts at 0)
                    pagedResult.getTotalPages() // Total pages available
            );

            message = messageUtil.get("application.success.retrieve", "Packages");
            data = paketResponses;

        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }

        return new MessagesResponse(message, status.value(), status.getReasonPhrase(), data, meta);
    }

    private PaketResponse mapToPaketResponse(Paket paket) {
        return PaketResponse.builder()
            .kodePaket(paket.getKodePaket())
            .namaPaket(paket.getNamaPaket())
            .tipeService(TipeServiceResponse.builder()
                .idTipeService(1) // hardcoded idTipeService
                .namaTipeService(paket.getTipeService())
                .build())
            .totalHarga(calculateTotalHarga(paket))
            .build();
    }

    private BigDecimal calculateTotalHarga(Paket paket) {
        // Add your logic to calculate totalHarga
        return paket.getTotalHarga();
    }

    // Fungsi untuk mendapatkan package by kode
    public MessagesResponse getPackageByKodePaket(String kodePaket) {
        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;

        try {
            // Fetch Paket by kodePaket
            Paket paket = paketRepository.findByKodePaket(kodePaket)
                .orElseThrow(() -> new CustomErrorWithStatusException(
                    messageUtil.get("application.error.notfound", "Package"),
                    null,
                    HttpStatus.NOT_FOUND
                ));

            PaketDetailResponse response = mapToPaketDetailResponse(paket);

            message = messageUtil.get("application.success.retrieve", "Package");
            data = response;

        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }

        return new MessagesResponse(message, status.value(), status.getReasonPhrase(), data, (String) null);
    }

    // Fungsi untuk menambahkan paket baru
    public MessagesResponse createPackage(PaketRequest paketRequest) {
        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;
    
        try {
            // Generate kode paket otomatis
            String kodePaketOtomatis = generateKodePaket();
    
            // Map request data ke entitas Paket dan gunakan kodePaketOtomatis
            Paket paket = Paket.builder()
                .kodePaket(kodePaketOtomatis)  // Gunakan kode paket otomatis
                .namaPaket(paketRequest.getNamaPaket())
                .tipeService(paketRequest.getTipeService())
                .totalHarga(paketRequest.getTotalHarga())
                .build();
    
            // Simpan Paket entity ke database
            final Paket savedPaket = paketRepository.save(paket);
    
            // Proses dataPart
            List<PartPaket> partPakets = paketRequest.getDataPart().stream()
                .map(partRequest -> {
                    Part part = partRepository.findByKodePart(partRequest.getKodePart())
                        .orElseThrow(() -> new CustomErrorWithStatusException(
                            messageUtil.get("application.error.partNotFound"),
                            null,
                            HttpStatus.NOT_FOUND
                        ));
    
                    return PartPaket.builder()
                        .part(part)
                        .paket(savedPaket)  // Gunakan paket yang baru disimpan
                        .hargaPartPaket(partRequest.getHargaPartPaket())
                        .qtyPartPaket(partRequest.getQtyPart())
                        .discPartPaket(partRequest.getDiscPart())
                        .jmlPartPaket(partRequest.getJmlPart())
                        .build();
                })
                .collect(Collectors.toList());
    
            // Proses dataJasa
            List<JasaPaket> jasaPakets = paketRequest.getDataJasa().stream()
                .map(jasaRequest -> {
                    Jasa jasa = jasaRepository.findByKodeJasa(jasaRequest.getKodeJasa())
                        .orElseThrow(() -> new CustomErrorWithStatusException(
                            messageUtil.get("application.error.jasaNotFound"),
                            null,
                            HttpStatus.NOT_FOUND
                        ));
    
                    return JasaPaket.builder()
                        .jasa(jasa)
                        .paket(savedPaket)  // Gunakan paket yang baru disimpan
                        .hargaPaketJasa(jasaRequest.getHargaPaketJasa())
                        .discJasaPaket(jasaRequest.getDiscJasa())
                        .jmlJasaPaket(jasaRequest.getJmlJasa())
                        .build();
                })
                .collect(Collectors.toList());
    
            // Set dataPart dan dataJasa ke Paket
            savedPaket.setPartPakets(partPakets);
            savedPaket.setJasaPakets(jasaPakets);
    
            // Simpan update Paket dengan Part dan Jasa
            paketRepository.save(savedPaket);
    
            // Map saved Paket entity ke response
            PaketDetailResponse response = mapToPaketDetailResponse(savedPaket);
    
            message = messageUtil.get("application.success.create", "Package");
            data = response;
    
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
            return new MessagesResponse(message, status.value(), status.getReasonPhrase(), e.getMessage());
        }
    
        return new MessagesResponse(message, status.value(), status.getReasonPhrase(), data);
    }
    
    private String generateKodePaket() {
        // Ambil paket terakhir berdasarkan kodePaket
        Optional<Paket> lastPaket = paketRepository.findTopByOrderByKodePaketDesc();
        
        // Jika belum ada paket, mulai dari "PKT001"
        if (!lastPaket.isPresent()) {
            return "PKT001";
        }
    
        // Ambil kode paket terakhir dan konversi angka
        String lastKodePaket = lastPaket.get().getKodePaket();
        int nomorPaket = Integer.parseInt(lastKodePaket.substring(3));
    
        // Tambahkan 1 untuk kode berikutnya
        nomorPaket += 1;
    
        // Kembalikan dalam format "PKT" diikuti angka dengan 3 digit
        return String.format("PKT%03d", nomorPaket);
    }

    private PaketDetailResponse mapToPaketDetailResponse(Paket paket) {
        List<PartPaketResponse> partPaketResponses = paket.getPartPakets().stream()
            .map(partPaket -> PartPaketResponse.builder()
                .idPartPaket(partPaket.getIdPartPaket())
                .kodePart(partPaket.getPart().getKodePart())
                .namaPart(partPaket.getPart().getNamaPart())
                .hargaPartPaket(partPaket.getHargaPartPaket())
                .qtyPart(partPaket.getQtyPartPaket())
                .discPart(partPaket.getDiscPartPaket())
                .jmlPart(partPaket.getJmlPartPaket())
                .build())
            .collect(Collectors.toList());

        List<JasaPaketResponse> jasaPaketResponses = paket.getJasaPakets().stream()
            .map(jasaPaket -> JasaPaketResponse.builder()
                .idJasaPaket(jasaPaket.getIdPaketJasa())
                .kodeJasa(jasaPaket.getJasa().getKodeJasa())
                .namaJasa(jasaPaket.getJasa().getNamaJasa())
                .hargaPaketJasa(jasaPaket.getHargaPaketJasa())
                .discJasa(jasaPaket.getDiscJasaPaket())
                .jmlJasa(jasaPaket.getJmlJasaPaket())
                .build())
            .collect(Collectors.toList());

        return PaketDetailResponse.builder()
            .informasiUmum(PaketResponse.builder()
                .kodePaket(paket.getKodePaket())
                .namaPaket(paket.getNamaPaket())
                .tipeService(TipeServiceResponse.builder()
                    .idTipeService(1) // hardcoded idTipeService
                    .namaTipeService(paket.getTipeService())
                    .build())
                .totalHarga(paket.getTotalHarga())
                .build())
            .dataPart(partPaketResponses)
            .dataJasa(jasaPaketResponses)
            .build();
    }

    // Fungsi untuk UpdatePacakge
    public MessagesResponse updatePackage(String kodePaket, PaketRequest paketRequest) {
        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;
    
        try {
            // Fetch Paket by kodePaket
            Paket paket = paketRepository.findByKodePaket(kodePaket)
                    .orElseThrow(() -> new CustomErrorWithStatusException(
                            messageUtil.get("application.error.notfound", "Package"),
                            null,
                            HttpStatus.NOT_FOUND
                    ));
    
            // Update paket details
            paket.setNamaPaket(paketRequest.getNamaPaket());
            paket.setTipeService(paketRequest.getTipeService());
            paket.setTotalHarga(paketRequest.getTotalHarga());
    
            // Convert PartPaketRequest to PartPaket 
            List<PartPaket> partPakets = paketRequest.getDataPart().stream()
                    .map(partRequest -> PartPaket.builder()
                            .part(Part.builder()
                                .kodePart(partRequest.getKodePart())
                                .namaPart(partRequest.getNamaPart())
                                .build())
                            .paket(paket)
                            .hargaPartPaket(partRequest.getHargaPartPaket())
                            .qtyPartPaket(partRequest.getQtyPart())
                            .discPartPaket(partRequest.getDiscPart())
                            .jmlPartPaket(partRequest.getJmlPart())
                            .build())
                    .collect(Collectors.toList());
    
            // Convert JasaPaketRequest to JasaPaket
            List<JasaPaket> jasaPakets = paketRequest.getDataJasa().stream()
                    .map(jasaRequest -> JasaPaket.builder()
                            .jasa(Jasa.builder()
                                .kodeJasa(jasaRequest.getKodeJasa())
                                .namaJasa(jasaRequest.getNamaJasa())
                                .build())
                            .paket(paket)
                            .hargaPaketJasa(jasaRequest.getHargaPaketJasa())
                            .discJasaPaket(jasaRequest.getDiscJasa())
                            .jmlJasaPaket(jasaRequest.getJmlJasa())
                            .build())
                    .collect(Collectors.toList());
    
            // Update partPakets and jasaPakets
            paket.setPartPakets(partPakets);
            paket.setJasaPakets(jasaPakets);
    
            // Save updated paket
            paketRepository.save(paket);
    
            // Map updated paket to response
            PaketDetailResponse response = mapToPaketDetailResponse(paket);
    
            message = messageUtil.get("application.success.update", "Package");
            data = response;
    
        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }
    
        return new MessagesResponse(message, status.value(), status.getReasonPhrase(), data);
    }

    public MessagesResponse deletePackage(String kodePaket) {
        HttpStatus status = HttpStatus.OK;
        String message = null;

        try {
            // Fetch Paket by kodePaket
            Paket paket = paketRepository.findByKodePaket(kodePaket)
                    .orElseThrow(() -> new CustomErrorWithStatusException(
                            messageUtil.get("application.error.notfound", "Package"),
                            null,
                            HttpStatus.NOT_FOUND
                    ));

            // Delete paket
            paketRepository.delete(paket);

            message = messageUtil.get("application.success.delete", "Package");

        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }

        return new MessagesResponse(message, status.value(), status.getReasonPhrase());
    }
}
