package com.ojt.wms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ojt.wms.dto.response.MessagesResponse;
import com.ojt.wms.dto.response.paket.JasaServiceLovResponse;
import com.ojt.wms.exception.CustomErrorWithStatusException;
import com.ojt.wms.model.Jasa;
import com.ojt.wms.repository.JasaRepository;
import com.ojt.wms.util.MessageUtil;

import java.util.List;
import java.util.stream.Collectors; // Import Collectors

@Service
public class RepairService {

    @Autowired 
    private JasaRepository jasaRepository;

    @Autowired
    private MessageUtil messageUtil;

    public MessagesResponse getJasaServiceLov() {
        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;

        try {
            // Fetch jasa without any filtering
            List<Jasa> jasaList = jasaRepository.findAll();

            if (jasaList.isEmpty()) {
                throw new CustomErrorWithStatusException(
                        messageUtil.get("application.error.notfound", "Jasa"),
                        null,
                        HttpStatus.NOT_FOUND
                );
            }

            // Map the jasaList to JasaServiceLovResponse
            List<JasaServiceLovResponse> responseData = jasaList.stream()
                    .map(jasa -> mapToJasaServiceLovResponse(jasa))
                    .collect(Collectors.toList());

            message = messageUtil.get("application.success.retrieve", "Jasa");
            data = responseData;

        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }

        return new MessagesResponse(message, status.value(), status.getReasonPhrase(), data, (String) null);
    }

    private JasaServiceLovResponse mapToJasaServiceLovResponse(Jasa jasa) {
        return JasaServiceLovResponse.builder()
                .idJasa(jasa.getIdJasa())
                .kodeJasa(jasa.getKodeJasa())
                .namaJasa(jasa.getNamaJasa())
                .hargaJasa(jasa.getHargaJasa())
                .build();
    }
}
