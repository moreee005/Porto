package com.ojt.wms.dto.response.paket;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JasaPaketResponse {

    private Integer idJasaPaket;
    private String kodeJasa;
    private String namaJasa;
    private BigDecimal hargaPaketJasa;
    private BigDecimal discJasa;
    private BigDecimal jmlJasa;
}
