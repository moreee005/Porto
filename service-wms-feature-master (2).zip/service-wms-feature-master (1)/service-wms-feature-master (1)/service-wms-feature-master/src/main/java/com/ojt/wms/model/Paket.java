package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Paket")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Paket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_paket", nullable = false, unique = true, updatable = false)
    private Integer idPaket;

    @Column(name = "kode_paket", nullable = true)
    private String kodePaket;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "tipe_service", nullable = true)
    private String tipeService;

    @Column(name = "nama_paket", nullable = true)
    private String namaPaket;

    @Column(name = "total_harga", nullable = true)
    private BigDecimal totalHarga;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;

    @OneToMany(mappedBy = "paket", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PartPaket> partPakets;

    @OneToMany(mappedBy = "paket", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<JasaPaket> jasaPakets;
}
