package com.ojt.wms.config.hardcode;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import java.math.BigDecimal;

public class ExcelUtils {

    // Helper method to get cell value as String
    public static String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return ""; // Jika sel null, kembalikan string kosong
        }
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> String.valueOf(cell.getNumericCellValue()); // Konversi nilai numerik ke string
            default -> "";
        };
    }

    // Helper method to get cell value as BigDecimal
    public static BigDecimal getCellValueAsBigDecimal(Cell cell) {
        if (cell == null) {
            return BigDecimal.ZERO; // Jika sel null, kembalikan BigDecimal nol
        }

        return switch (cell.getCellType()) {
            case NUMERIC -> BigDecimal.valueOf(cell.getNumericCellValue());
            case STRING -> {
                try {
                    yield new BigDecimal(cell.getStringCellValue());
                } catch (NumberFormatException e) {
                    yield BigDecimal.ZERO; // Kembalikan 0 jika string tidak dapat dikonversi
                }
            }
            default -> BigDecimal.ZERO; // Kembalikan 0 untuk tipe lain
        };
    }

    // Helper method to get cell value as Integer
    public static Integer getCellValueAsInteger(Cell cell) {
        if (cell == null) {
            return null; // Jika sel null, kembalikan null
        }

        return switch (cell.getCellType()) {
            case NUMERIC -> (int) cell.getNumericCellValue(); // Konversi nilai numerik ke integer
            case STRING -> {
                try {
                    yield Integer.parseInt(cell.getStringCellValue());
                } catch (NumberFormatException e) {
                    yield null; // Jika gagal, kembalikan null
                }
            }
            default -> null;
        };
    }
    // Helper method to get cell value as Boolean
    public static Boolean getCellValueAsBoolean(Cell cell) {
        if (cell == null) {
            return false; // Jika sel null, kembalikan false
        }

        return switch (cell.getCellType()) {
            case BOOLEAN -> cell.getBooleanCellValue(); // Jika tipe BOOLEAN, langsung kembalikan nilai boolean
            case STRING -> {
                String value = cell.getStringCellValue().toLowerCase();
                yield value.equals("true") || value.equals("yes"); // Konversi string 'true' atau 'yes' jadi true
            }
            case NUMERIC -> cell.getNumericCellValue() != 0; // Angka bukan nol dianggap true
            default -> false; // Tipe lain dianggap false
        };
    }


    // Helper method to get cell value as Short
    public static Short getCellValueAsShort(Cell cell) {
        if (cell == null) {
            return 0; // Jika sel null, kembalikan 0
        }

        return switch (cell.getCellType()) {
            case NUMERIC -> (short) cell.getNumericCellValue(); // Konversi nilai numerik ke short
            case STRING -> {
                try {
                    yield Short.parseShort(cell.getStringCellValue());
                } catch (NumberFormatException e) {
                    yield 0; // Kembalikan 0 jika string tidak dapat dikonversi
                }
            }
            default -> 0; // Kembalikan 0 untuk tipe lain
        };
    }

    public static boolean isRowEmpty(Row row) {
        // Anda dapat menambahkan kolom lain yang dianggap penting
        return ExcelUtils.getCellValueAsString(row.getCell(0)).isEmpty() &&
                ExcelUtils.getCellValueAsString(row.getCell(1)).isEmpty() &&
                ExcelUtils.getCellValueAsString(row.getCell(3)).isEmpty() &&
                ExcelUtils.getCellValueAsString(row.getCell(4)).isEmpty() &&
                ExcelUtils.getCellValueAsString(row.getCell(5)).isEmpty();
    }

    public static boolean isValidTemplate(Sheet sheet) {
        // Akses baris kedua (baris dengan indeks 1, karena indeks Excel dimulai dari 0)
        Row headerRow = sheet.getRow(1);

        if (headerRow == null) {
            return false; // Jika baris kedua tidak ada
        }

        // Periksa apakah setiap header sesuai dengan yang diharapkan
        return "Nama Part *".equals(getCellValueAsString(headerRow.getCell(0))) &&
                "Kode Part 2".equals(getCellValueAsString(headerRow.getCell(1))) &&
                "Harga Beli".equals(getCellValueAsString(headerRow.getCell(2))) &&
                "Divisi Part".equals(getCellValueAsString(headerRow.getCell(3))) &&
                "Sub Divisi".equals(getCellValueAsString(headerRow.getCell(4))) &&
                "Brand Part".equals(getCellValueAsString(headerRow.getCell(5))) &&
                "Group Part".equals(getCellValueAsString(headerRow.getCell(6))) &&
                "Harga Jual (R)".equals(getCellValueAsString(headerRow.getCell(7))) &&
                "Harga Jual (AG)".equals(getCellValueAsString(headerRow.getCell(8))) &&
                "Harga Jual (BP)".equals(getCellValueAsString(headerRow.getCell(9))) &&
                "Harga Jual (D)".equals(getCellValueAsString(headerRow.getCell(10))) &&
                "On Hand".equals(getCellValueAsString(headerRow.getCell(11))) &&
                "Barcode".equals(getCellValueAsString(headerRow.getCell(12))) &&
                "Qty Minimal".equals(getCellValueAsString(headerRow.getCell(13))) &&
                "Qty Maksimal".equals(getCellValueAsString(headerRow.getCell(14))) &&
                "Satuan".equals(getCellValueAsString(headerRow.getCell(15))) &&
                "Ukuran".equals(getCellValueAsString(headerRow.getCell(16))) &&
                "Nomor Stok".equals(getCellValueAsString(headerRow.getCell(17))) &&
                "Status(ORI / OEM / KW)".equals(getCellValueAsString(headerRow.getCell(18))) &&
                "Lokasi 1".equals(getCellValueAsString(headerRow.getCell(19))) &&
                "Lokasi 2".equals(getCellValueAsString(headerRow.getCell(20))) &&
                "Catatan".equals(getCellValueAsString(headerRow.getCell(21))) &&
                "Expired(Ya / Tidak)".equals(getCellValueAsString(headerRow.getCell(22))) &&
                "OPB(Ya / Tidak)".equals(getCellValueAsString(headerRow.getCell(23))) &&
                "OPSCK(Ya / Tidak)".equals(getCellValueAsString(headerRow.getCell(24))) &&
                // Tambahkan header lain yang diperlukan
                true;
    }

    public static boolean isValidRow(Row row) {
        // Misalnya, validasi bahwa harga beli adalah angka dan nama part tidak kosong
        return !getCellValueAsString(row.getCell(0)).isEmpty() && // Nama Part tidak boleh kosong
                getCellValueAsBigDecimal(row.getCell(7)).compareTo(BigDecimal.ZERO) > 0 &&
                getCellValueAsBigDecimal(row.getCell(8)).compareTo(BigDecimal.ZERO) > 0 &&
                getCellValueAsBigDecimal(row.getCell(9)).compareTo(BigDecimal.ZERO) > 0 &&
                getCellValueAsBigDecimal(row.getCell(10)).compareTo(BigDecimal.ZERO) > 0
                ;
    }


}
