package com.ojt.wms.service;

import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.elasticsearch.client.RequestOptions;

@Service
public class ElasticSearchService {

    @Autowired
    private RestHighLevelClient client;

    public boolean isElasticsearchAvailable() {
        try {
            return client.ping(RequestOptions.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
