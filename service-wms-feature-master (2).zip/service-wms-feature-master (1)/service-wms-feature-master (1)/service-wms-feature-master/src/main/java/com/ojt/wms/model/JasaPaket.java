package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "JasaPaket")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JasaPaket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_paket_jasa", nullable = false, unique = true, updatable = false)
    private Integer idPaketJasa;

    @ManyToOne
    @JoinColumn(name = "id_jasa_asuransi", referencedColumnName = "id_jasa_asuransi")
    private JasaAsuransi jasaAsuransi;

    @ManyToOne
    @JoinColumn(name = "id_jasa", referencedColumnName = "id_jasa")
    private Jasa jasa;

    @ManyToOne
    @JoinColumn(name = "id_paket", referencedColumnName = "id_paket")
    private Paket paket;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "disc_jasa_paket", nullable = true)
    private BigDecimal discJasaPaket;

    @Column(name = "jml_jasa_paket", nullable = true)
    private BigDecimal jmlJasaPaket;

    @Column(name = "harga_paket_jasa", nullable = true)
    private BigDecimal hargaPaketJasa;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
