package com.ojt.wms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

@SpringBootApplication(scanBasePackages = { "com.ojt.wms", "com.ojt.lib.minio" })
@EnableElasticsearchRepositories(basePackages = "com.ojt.wms.repository.elastic")
public class WmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WmsApplication.class, args);
	}

}
