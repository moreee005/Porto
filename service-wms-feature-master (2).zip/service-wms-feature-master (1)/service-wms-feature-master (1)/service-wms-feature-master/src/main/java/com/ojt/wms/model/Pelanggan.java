package com.ojt.wms.model;
import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Pelanggan")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Pelanggan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pelanggan", nullable = false, unique = true, updatable = false)
    private Long idPelanggan;

    @ManyToOne
    @JoinColumn(name = "id_organisasi", referencedColumnName = "id_organisasi")
    private Organization organization;

    @OneToOne
    @JoinColumn(name = "nik", referencedColumnName = "nik")
    private Person person;

    @ManyToOne
    @JoinColumn(name = "id_kendaraan", referencedColumnName = "id_kendaraan")
    private Kendaraan kendaraan;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "pic")
    private String pic;

    @Column(name = "payment", nullable = true)
    private String payment;

    @Column(name = "limit_kredit", nullable = true)
    private BigDecimal limitKredit;

    @Column(name = "due_day")
    private String dueDay;

    @Column(name = "status", nullable = false)
    private String status;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "created_by", nullable = true)
    private String createdBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
