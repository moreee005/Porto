package com.ojt.wms.model;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;


@Entity
@Table(name = "PartPkb")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartPkb {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_part_pkb", nullable = true)
    private Long idPartPkb;

    @ManyToOne
    @JoinColumn(name = "id_wo")
    private WorkOrder workOrder;

    @ManyToOne
    @JoinColumn(name = "id_part")
    private Part part;

    @Column(name = "qty_part_pkb")
    private Short qtyPartPkb;

    @Column(name = "disc_part_pkb")
    private BigDecimal discPartPkb;
    
    @Column(name = "jml_part_pkb")
    private BigDecimal jmlPartPkb;
    
    @Column(name = "harga_part_pkb")
    private BigDecimal hargaPartPkb;
    
    @Column(name = "ppn_part_pkb")
    private BigDecimal ppnPartPkb;
    
    @Column(name = "komentar_part_pkb", columnDefinition = "TEXT")
    private String komentarPartPkb;
    
    @Column(name = "status_pengerjaan_part")
    private String statusPengerjaanPart;
    
    @Column(name = "kode_part_pkb")
    private String kodePartPkb;
    
    @Column(name = "is_from_paket")
    private Boolean isFromPaket;
    
    @Column(name = "is_submitted")
    private Boolean isSubmitted;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}