package com.ojt.wms.model;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.math.BigDecimal;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "WorkOrder")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_wo", nullable = true)
    private Long idWo;

    @Column(name = "kode_wo")
    private String kodeWo;

    @ManyToOne
    @JoinColumn(name = "id_status_pekerjaan")
    private StatusPekerjaan statusPekerjaan;

    @ManyToOne
    @JoinColumn(name = "id_status_wo")
    private StatusWorkOrder statusWo;

    @ManyToOne
    @JoinColumn(name = "id_transaksi")
    private Transaksi transaksi;

    @ManyToOne
    @JoinColumn(name = "kode_kategori")
    private KategoriLayanan kategoriLayanan;

    @ManyToOne
    @JoinColumn(name = "id_asuransi_wo")
    private AsuransiWo asuransiWo;

    @Column(name = "tgl_wo")
    private LocalDate alamat;

    @Column(name = "alasan_batal")
    private String alasanBatal;

    @Column(name = "est_tgl_selesai_est")
    private LocalDate estTglSelesaiEst;

    @Column(name = "est_tgl_selesai_pkb")
    private LocalDate estTglSelesaiPkb;

    @Column(name = "tgl_tutup_wo")
    private LocalDate tglTutuWo;

    @Column(name = "tgl_eksekusi_wo")
    private LocalDate tlgEksekusiWo;

    @Column(name = "tgl_batal_wo")
    private LocalDate tglBatalWo;

    @Column(name = "keluhan", nullable = true, columnDefinition = "TEXT")
    private String keluhan;

    @Column(name = "perintah_kerja", nullable = true, columnDefinition = "TEXT")
    private String perintahKerja;

    @Column(name = "saran", nullable = true, columnDefinition = "TEXT")
    private String saran;

    @Column(name = "ppn_estimasi", nullable = true)
    private BigDecimal ppnEstimasi;

    @Column(name = "grand_total_estimasi", nullable = true)
    private BigDecimal grandTotalEstimasi;

    @Column(name = "ppn_part_est", nullable = true)
    private BigDecimal ppnPartEst;

    @Column(name = "ppn_jasa_est", nullable = true)
    private BigDecimal ppnJasaEst;
    
    @Column(name = "fotoKerusakan", nullable = true, columnDefinition = "TEXT")
    private String fotoKerusakan;

    @Column(name = "overall_disc_est")
    private BigDecimal overallDiscEst;

    @Column(name = "bonus_pekerjaan_est")
    private String bonusPekerjaanEst;

    @Column(name = "harga_bonus_est")
    private BigDecimal hargaBonusEst;

    @Column(name = "foto_persetujuan_est", columnDefinition = "TEXT")
    private String fotoPersetujuanEst;

    @Column(name = "overall_disc_pkb")
    private BigDecimal overallDiscPkb;

    @Column(name = "bonus_pekerjaan_pkb")
    private String bonusPekerjaanPkb;

    @Column(name = "harga_bonus_pkb")
    private BigDecimal hargaBonusPkb;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}