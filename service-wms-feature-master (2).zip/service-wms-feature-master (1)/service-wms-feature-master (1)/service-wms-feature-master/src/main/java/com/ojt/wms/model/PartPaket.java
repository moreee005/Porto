package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "PartPaket")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartPaket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_part_paket", nullable = false, unique = true, updatable = false)
    private Integer idPartPaket;

    @ManyToOne
    @JoinColumn(name = "id_paket", referencedColumnName = "id_paket")
    private Paket paket;

    @ManyToOne
    @JoinColumn(name = "id_part", referencedColumnName = "id_part")
    private Part part;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "qty_part_paket", nullable = true)
    private Short qtyPartPaket;

    @Column(name = "disc_part_paket", nullable = true)
    private BigDecimal discPartPaket;

    @Column(name = "jml_part_paket", nullable = true)
    private BigDecimal jmlPartPaket;

    @Column(name = "harga_part_paket", nullable = true)
    private BigDecimal hargaPartPaket;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
