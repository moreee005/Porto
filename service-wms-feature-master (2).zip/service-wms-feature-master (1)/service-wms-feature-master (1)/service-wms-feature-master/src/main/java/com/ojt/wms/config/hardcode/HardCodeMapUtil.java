package com.ojt.wms.config.hardcode;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

public class HardCodeMapUtil {

    @Getter
    private static final Map<String, Integer> divisionMap = new HashMap<>();

    @Getter
    private static final Map<String, Integer> statusMap = new HashMap<>();

    @Getter
    private static final Map<String, Integer> satuanMap = new HashMap<>();

    @Getter
    private static final Map<String, Integer> merkKendaraanMap = new HashMap<>();

    @Getter
    private static final Map<String, String> sortByMap = new HashMap<>();

    static {
        // Division Map - Semua key diubah ke lowercase
        divisionMap.put("compressor".toLowerCase(), 1);
        divisionMap.put("clutch".toLowerCase(), 2);
        divisionMap.put("evaporator".toLowerCase(), 3);
        divisionMap.put("condenser".toLowerCase(), 4);
        divisionMap.put("receiver dryer".toLowerCase(), 5);
        divisionMap.put("expansion valve".toLowerCase(), 6);
        divisionMap.put("motor".toLowerCase(), 7);
        divisionMap.put("caf".toLowerCase(), 8);
        divisionMap.put("cool gear".toLowerCase(), 9);
        divisionMap.put("ac unit".toLowerCase(), 10);
        divisionMap.put("tools".toLowerCase(), 11);
        divisionMap.put("ban".toLowerCase(), 12);
        divisionMap.put("aksesoris".toLowerCase(), 13);
        divisionMap.put("lainnya".toLowerCase(), 14);

        // Status Map - Semua key diubah ke lowercase
        statusMap.put("ori".toLowerCase(), 1);
        statusMap.put("oem".toLowerCase(), 2);
        statusMap.put("kw".toLowerCase(), 3);

        // Satuan Map - Semua key diubah ke lowercase
        satuanMap.put("pcs".toLowerCase(), 1);
        satuanMap.put("l".toLowerCase(), 2);
        satuanMap.put("lembar".toLowerCase(), 3);
        satuanMap.put("kilo".toLowerCase(), 4);
        satuanMap.put("galon".toLowerCase(), 5);
        satuanMap.put("tabung".toLowerCase(), 6);
        satuanMap.put("liter".toLowerCase(), 7);
        satuanMap.put("cc".toLowerCase(), 8);

        // Merk Kendaraan Map - Semua key diubah ke lowercase
        merkKendaraanMap.put("hyundai".toLowerCase(), 1);
        merkKendaraanMap.put("toyota".toLowerCase(), 2);
        merkKendaraanMap.put("daihatsu".toLowerCase(), 3);
        merkKendaraanMap.put("honda".toLowerCase(), 4);
        merkKendaraanMap.put("mitsubishi".toLowerCase(), 5);
        merkKendaraanMap.put("suzuki".toLowerCase(), 6);
        merkKendaraanMap.put("kia".toLowerCase(), 7);
        merkKendaraanMap.put("mazda".toLowerCase(), 8);
        merkKendaraanMap.put("mercedes-benz".toLowerCase(), 9);
        merkKendaraanMap.put("lexus".toLowerCase(), 10);
        merkKendaraanMap.put("bmw".toLowerCase(), 11);
        merkKendaraanMap.put("ford".toLowerCase(), 12);

        sortByMap.put("kodePart","kode_part");
        sortByMap.put("partName","nama_part");

    }
}
