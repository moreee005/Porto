package com.ojt.wms.model;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Transaksi")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaksi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_transaksi", nullable = false, unique = true, updatable = false)
    private Long idTransaksi;

    @ManyToOne
    @JoinColumn(name = "id_inspeksi")
    private Inspeksi inspeksi;

    @ManyToOne
    @JoinColumn(name = "id_pelanggan")
    private Pelanggan pelanggan;
    
    @ManyToOne
    @JoinColumn(name = "kode_serah_terima")
    private SerahTerima serahTerima;

    @ManyToOne
    @JoinColumn(name = "id_posisi_kendaraan")
    private StatusPosisiKendaraan statusPosisiKendaraan;

    @ManyToOne
    @JoinColumn(name = "id_status_trans")
    private StatusTransaksi statusTrans;
    
    @ManyToOne
    @JoinColumn(name = "id_asuransi_trans")
    private AsuransiTransaksi asuransiTransaksi;

    @Column(name = "no_polisi")
    private String noPolisi;

    @Column(name = "tanggal_dibuat")
    private LocalDate tanggalDibuat;
    
    @Column(name = "status_eksekusi")
    private String statusEksekusi;

    @Column(name = "tgl_keluar")
    private LocalDate tglKeluar;

    @Column(name = "odometer")
    private BigDecimal odometer;

    @Column(name = "agen")
    private String agen;

    @Column(name = "marketing")
    private String marketing;

    @Column(name = "tgl_kembali")
    private LocalDate tglKembali;

    @Column(name = "km_kembali")
    private BigDecimal kmKembali;

    @Column(name = "is_stk_submitted")
    private Boolean isStkSubmitted;

    @Column(name = "is_jk_submitted")
    private Boolean isJkSubmitted;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}