package com.ojt.wms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ojt.wms.dto.request.paket.PaketRequest;
import com.ojt.wms.dto.response.MessagesResponse;
import com.ojt.wms.service.PaketService;
import com.ojt.wms.service.PartService;

@RestController
@RequestMapping("/product")
public class PaketController {

    @Autowired
    private PaketService paketService;

    @Autowired
    private PartService partService;

    @GetMapping("/packages")
    public ResponseEntity<MessagesResponse> getPackages(
        @RequestParam(required = false) String searchKeyword,
        @RequestParam(defaultValue = "1") int page,
        @RequestParam(defaultValue = "10") int size,
        @RequestParam(defaultValue = "idPaket") String sortBy,
        @RequestParam(defaultValue = "asc") String orderBy
    ) {
        MessagesResponse response = paketService.getPackages(searchKeyword, page, size, sortBy, orderBy);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/packages/{kodePaket}")
    public ResponseEntity<MessagesResponse> getPackageByKode(@PathVariable String kodePaket) {
        MessagesResponse response = paketService.getPackageByKodePaket(kodePaket);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @GetMapping("/part-lov-auto")
    public ResponseEntity<MessagesResponse> getPartLovAuto(@RequestParam String search) {
        MessagesResponse response = partService.getPartLovAuto(search);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @PostMapping("/packages")
    public ResponseEntity<MessagesResponse> createPackage(@RequestBody PaketRequest paketRequest) {
        MessagesResponse response = paketService.createPackage(paketRequest);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @PutMapping("/packages/{kodePaket}")
    public ResponseEntity<MessagesResponse> updatePackage(
        @PathVariable String kodePaket,
        @RequestBody PaketRequest paketRequest) {
        
        MessagesResponse response = paketService.updatePackage(kodePaket, paketRequest);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }

    @DeleteMapping("/packages/{kodePaket}")
    public ResponseEntity<MessagesResponse> deletePackage(@PathVariable String kodePaket) {
        MessagesResponse response = paketService.deletePackage(kodePaket);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatusCode()));
    }
}
