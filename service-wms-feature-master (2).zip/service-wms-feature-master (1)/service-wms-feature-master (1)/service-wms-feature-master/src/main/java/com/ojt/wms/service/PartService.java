package com.ojt.wms.service;

import com.ojt.lib.minio.MinioService;
import com.ojt.wms.config.hardcode.HardCodeMapUtil;
import com.ojt.wms.dto.request.PartRequest;
import com.ojt.wms.dto.response.MessagesResponse;
import com.ojt.wms.dto.response.paket.PartLovAutoResponse;
import com.ojt.wms.dto.response.part.*;
import com.ojt.wms.exception.CustomErrorWithStatusException;
import com.ojt.wms.model.Part;
import com.ojt.wms.model.elastic.PartElastic;
import com.ojt.wms.repository.MerkKendaraanRepository;
import com.ojt.wms.repository.PartRepository;
import com.ojt.wms.repository.elastic.PartElasticRepository;
import com.ojt.wms.util.MessageUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

import static com.ojt.wms.config.hardcode.ExcelUtils.*;
import static com.ojt.wms.config.hardcode.ExcelUtils.getCellValueAsBoolean;

@Service
public class PartService {

    @Autowired 
    private PartRepository partRepository;

    @Autowired
    private MessageUtil messageUtil;

    @Autowired
    private MinioService minioService;

    @Autowired
    private PartElasticRepository partElasticRepository;

    @Autowired
    private MerkKendaraanRepository merkKendaraanRepository;

    private static final Logger logger = LoggerFactory.getLogger(PartService.class);


    public MessagesResponse getPartLovAuto(String search) {
        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;
    
        try {
            // Fetch parts based on search criteria
            List<Part> parts = partRepository.findBySearchCriteria(search);
    
            if (parts.isEmpty()) {
                throw new CustomErrorWithStatusException(
                        messageUtil.get("application.error.notfound", "Parts"),
                        null,
                        HttpStatus.NOT_FOUND
                );
            }
    
            // Map the parts to PartLovAutoResponse
            List<PartLovAutoResponse> responseData = parts.stream()
                    .map(part -> mapToPartLovAutoResponse(part))
                    .collect(Collectors.toList());
    
            message = messageUtil.get("application.success.retrieve", "Parts");
            data = responseData;
    
        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }
    
        return new MessagesResponse(message, status.value(), status.getReasonPhrase(), data, (String) null);
    }
    
    private PartLovAutoResponse mapToPartLovAutoResponse(Part part) {
        return PartLovAutoResponse.builder()
                .kodePart(part.getKodePart())
                .karyawan(part.getKaryawan() != null ? part.getKaryawan().getNama() : null)
                .kendaraan(part.getKendaraan() != null ? part.getKendaraan().getTipeKendaraan().getMerkKendaraan().getMerk() : null)
                .namaPart(part.getNamaPart())
                .partBarcode(part.getPartBarcode())
                .partBrand(part.getPartBrand())
                .partBuyPrice(part.getPartBuyPrice())
                .partCode2(part.getPartCode2())
                .partDivision(part.getPartDivision())
                .partGroup(part.getPartGroup())
                .partLokasi1(part.getPartLokasi1())
                .partLokasi2(part.getPartLokasi2())
                .partMaxQty(part.getPartMaxQty())
                .partMinQty(part.getPartMinQty())
                .partNomorStock(part.getPartNomorStock())
                .note(part.getNote())
                .partOpb(part.getPartOpb())
                .partOpsck(part.getPartOpsck())
                .partOnHand(part.getPartOnHand())
                .partSatuan(part.getPartSatuan())
                .partSellPriceAg(part.getPartSellPriceAg())
                .partSellPriceBp(part.getPartSellPriceBp())
                .partSellPriceD(part.getPartSellPriceD())
                .partSellPriceR(part.getPartSellPriceR())
                .partStatus(part.getPartStatus())
                .partSubDivision(part.getPartSubDivision())
                .partUkuran(part.getPartUkuran())
                .partExpired(part.getPartExpired())
                .partPhoto(part.getPartPhoto())
                .createdDate(part.getCreatedDate())
                .createdBy(part.getCreatedBy())
                .modifiedDate(part.getModifiedDate())
                .modifiedBy(part.getModifiedBy())
                .isDeleted(part.getIsDeleted())
                .build();
    }

    public MessagesResponse postPart(PartRequest partRequest, MultipartFile photo) {
        try {

            // Validasi jika namaPart sudah ada di database
            List <Part> existingPart = partRepository.findByNamaPart(partRequest.getPartName().toLowerCase());
            Optional<Part> rowTerakhirPart = partRepository.rowTerakhirPart();

            Long count = rowTerakhirPart.get().getIdPart();
            String kodePart = "P" + (count+1);

            for (Part parts : existingPart){
                if (parts.getNamaPart().toLowerCase().equals(partRequest.getPartName().toLowerCase())) {
                    return new MessagesResponse(
                            "Part name already exists, duplicates are not allowed.",
                            HttpStatus.BAD_REQUEST.value(),
                            HttpStatus.BAD_REQUEST.getReasonPhrase()
                    );
                }
            }


            Map<String, Integer> divisionMap = HardCodeMapUtil.getDivisionMap();
            Map<String, Integer> statusMap = HardCodeMapUtil.getStatusMap();
            Map<String, Integer> satuanMap = HardCodeMapUtil.getSatuanMap();
            Map<String, Integer> merkKendaraanMap = HardCodeMapUtil.getMerkKendaraanMap();

            String fileName = null;
            if (photo != null && !photo.isEmpty()) {
                try {
                    fileName = minioService.uploadFileToMinio(photo, "part-photo");
                } catch (IOException e) {
                    return new MessagesResponse(
                            "Failed to upload photo to MinIO",
                            HttpStatus.INTERNAL_SERVER_ERROR.value(),
                            HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                            e.getMessage());
                }
            }

            PartElastic partElastic;
            try {
                partElastic = PartElastic.builder()
                        .kodePart(kodePart)
                        .partCode2(partRequest.getPartCode2())
                        .namaPart(partRequest.getPartName())
                        .partDivision(partRequest.getNamaDivisi())
                        .partSubDivision(partRequest.getPartSubDivision())
                        .partGroup(partRequest.getNamaGroup())
                        .partBuyPrice(partRequest.getPartBuyPrice())
                        .partSellPriceR(partRequest.getPartSellPriceR())
                        .partSellPriceBp(partRequest.getPartSellPriceBP())
                        .partSellPriceAg(partRequest.getPartSellPriceAG())
                        .partSellPriceD(partRequest.getPartSellPriceD())
                        .partOnHand(partRequest.getPartOnHand())
                        .partMinQty(partRequest.getPartMinQty())
                        .partMaxQty(partRequest.getPartMaxQty())
                        .partBarcode(partRequest.getPartBarcode())
                        .partSatuan(partRequest.getNamaSatuan())
                        .partUkuran(partRequest.getPartUkuran())
                        .partNomorStock(partRequest.getPartNomorStock())
                        .partStatus(partRequest.getNamaStatus())
                        .partLokasi1(partRequest.getPartLocation1())
                        .partLokasi2(partRequest.getPartLocation2())
                        .note(partRequest.getPartNote())
                        .partPhoto(fileName)
                        .partExpired(partRequest.getPartExpired())
                        .partOpsck(partRequest.getPartOPSCK())
                        .partOpb(partRequest.getPartOPB())
                        .build();
                logger.info("PartElastic berhasil dibangun");
            } catch (Exception e) {
                logger.error("Gagal membangun PartElastic: {}", e.getMessage(), e);
                return new MessagesResponse(
                        "Failed to build PartElastic object",
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                        e.getMessage());
            }

            // Logging sebelum penyimpanan ke Elasticsearch
            logger.info("Menyimpan PartElastic ke Elasticsearch...");

            try {
                partElasticRepository.save(partElastic);
                logger.info("PartElastic berhasil disimpan ke Elasticsearch");
            } catch (Exception e) {
                logger.error("Gagal menyimpan PartElastic ke Elasticsearch: {}", e.getMessage(), e);
                return new MessagesResponse(
                        "Failed to save PartElastic to Elasticsearch",
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                        e.getMessage());
            }

            Part part = Part.builder()
                    .kodePart(kodePart)
                    .partCode2(partRequest.getPartCode2())
                    .namaPart(partRequest.getPartName())
                    .partDivision(partRequest.getNamaDivisi())
                    .partSubDivision(partRequest.getPartSubDivision())
                    .partGroup(partRequest.getNamaGroup())
                    .partBuyPrice(partRequest.getPartBuyPrice())
                    .partSellPriceR(partRequest.getPartSellPriceR())
                    .partSellPriceBp(partRequest.getPartSellPriceBP())
                    .partSellPriceAg(partRequest.getPartSellPriceAG())
                    .partSellPriceD(partRequest.getPartSellPriceD())
                    .partOnHand(partRequest.getPartOnHand())
                    .partMinQty(partRequest.getPartMinQty())
                    .partMaxQty(partRequest.getPartMaxQty())
                    .partBarcode(partRequest.getPartBarcode())
                    .partSatuan(partRequest.getNamaSatuan())
                    .partUkuran(partRequest.getPartUkuran())
                    .partNomorStock(partRequest.getPartNomorStock())
                    .partStatus(partRequest.getNamaStatus())
                    .partLokasi1(partRequest.getPartLocation1())
                    .partLokasi2(partRequest.getPartLocation2())
                    .note(partRequest.getPartNote())
                    .partPhoto(fileName)
                    .partExpired(partRequest.getPartExpired())
                    .partOpsck(partRequest.getPartOPSCK())
                    .partOpb(partRequest.getPartOPB())
                    .build();

            partRepository.save(part);

            String link = (fileName != null) ? minioService.getPublicLink(part.getPartPhoto()) : null;

            List<PartResponse.PartPhoto> partPhotoList = Collections.singletonList(
                    PartResponse.PartPhoto.builder()
                            .filename(fileName)
                            .fileLink(link)
                            .build()
            );

            PartResponse partResponse = PartResponse.builder()
                    .kodePart(kodePart)
                    .partCode2(partRequest.getPartCode2())
                    .partName(partRequest.getPartName())
                    .partDivision(
                            PartResponse.PartDivision.builder()
                                    .idDivisi(divisionMap.getOrDefault(
                                            partRequest.getNamaDivisi() != null ? partRequest.getNamaDivisi().toLowerCase() : "", 0))
                                    .namaDivisi(partRequest.getNamaDivisi())
                                    .build())
                    .partSubDivision(partRequest.getPartSubDivision())
                    .partBrand(partRequest.getPartBrand())
                    .partGroup(
                            PartResponse.PartGroup.builder()
                                    .idGroup(merkKendaraanMap.getOrDefault(partRequest.getNamaGroup() != null ? partRequest.getNamaGroup().toLowerCase() : "", 0))
                                    .namaGroup(partRequest.getNamaGroup())
                                    .build())
                    .partBuyPrice(partRequest.getPartBuyPrice())
                    .partSellPriceR(partRequest.getPartSellPriceR())
                    .partSellPriceBP(partRequest.getPartSellPriceBP())
                    .partSellPriceAG(partRequest.getPartSellPriceAG())
                    .partSellPriceD(partRequest.getPartSellPriceD())
                    .partOnHand(partRequest.getPartOnHand())
                    .partMinQty(partRequest.getPartMinQty())
                    .partMaxQty(partRequest.getPartMaxQty())
                    .partBarcode(partRequest.getPartBarcode())
                    .partSatuan(
                            PartResponse.PartSatuan.builder()
                                    .idSatuan(satuanMap.getOrDefault(partRequest.getNamaSatuan() != null ?  partRequest.getNamaSatuan().toLowerCase() : "", 0))
                                    .namaSatuan(partRequest.getNamaSatuan())
                                    .build())
                    .partUkuran(partRequest.getPartUkuran())
                    .partNomorStock(partRequest.getPartNomorStock())
                    .partStatus(
                            PartResponse.PartStatus.builder()
                                    .idStatus(statusMap.getOrDefault(partRequest.getNamaStatus() != null ? partRequest.getNamaStatus().toLowerCase() : "", 0))
                                    .namaStatus(partRequest.getNamaStatus())
                                    .build())
                    .partLocation1(partRequest.getPartLocation1())
                    .partLocation2(partRequest.getPartLocation2())
                    .partNote(partRequest.getPartNote())
                    .partPhoto(partPhotoList)
                    .partExpired(partRequest.getPartExpired())
                    .partOPSCK(partRequest.getPartOPSCK())
                    .partOPB(partRequest.getPartOPB())
                    .build();

            return new MessagesResponse("Part successfully created", HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(),
                    partResponse);

        } catch (Exception e) {
            return new MessagesResponse(
                    "Error occurred while uploading part",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }
    }

    public MessagesResponse getPart(String namaPart, int page, int size, String sortBy, String orderBy) {
        try {
            // Sorting direction
            Sort sort = orderBy.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();

            // Pageable request
            Pageable pageable = PageRequest.of(page, size, sort);


            // Fetch paginated parts (filter by namaPart if provided)
            Page <PartElastic> partPage = null;
            if (namaPart != null && !namaPart.isEmpty()) {
//                partPage = partRepository.findByNamaPartContaining(namaPart, pageable);
            } else {
                partPage = partElasticRepository.findAll(pageable);
            }

            if (partPage.isEmpty()) {
                return new MessagesResponse(
                        "Part not found",
                        HttpStatus.NOT_FOUND.value(),
                        HttpStatus.NOT_FOUND.getReasonPhrase());
            }

            // Convert Page<Part> to List<PartResponseGet.PartData>
            List<PartResponseGet.PartData> partDataList = partPage.getContent().stream()
                    .map(part -> PartResponseGet.PartData.builder()
                            .kodePart(part.getKodePart())
                            .partName(part.getNamaPart()) // Menggunakan namaPart
                            .partDivision(part.getPartDivision()) // Misalnya Anda ingin ambil dari Karyawan
                            .partOnHand(part.getPartOnHand())
                            .partBuyPrice(part.getPartBuyPrice())
                            .partSellPrice(part.getPartSellPriceR())
                            .partBrand(part.getPartBrand())
                            .build())
                    .collect(Collectors.toList());

            // Build PartResponseGet object
            PartResponseGet response = PartResponseGet.builder()
                    .data(partDataList)
                    .totalItems(partPage.getTotalElements())
                    .totalPages(partPage.getTotalPages())
                    .currentPage(partPage.getNumber())
                    .build();

            // Return successful response
            return new MessagesResponse("Part successfully retrieved", HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(), response);

        } catch (Exception e) {
            // Handle exception
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }
    }

    public MessagesResponse getPartDivision(){

        try {
            // Daftar nama divisi dan id yang diinginkan
            Map<String,Integer> divisionMap = HardCodeMapUtil.getDivisionMap();
            // Ambil semua data part dari database
            List<Part> partList = partRepository.findAll();

            // Map partList ke partDivisionList menggunakan stream dan map
            List<PartDivisionResponse> partDivisionList = partList.stream()
                    .map(part -> PartDivisionResponse.builder()
                            // Cek apakah partDivision ada di dalam divisionMap, jika iya, ambil id dari map
                            .idDivisi(divisionMap.getOrDefault(
                                    part.getPartDivision() != null ? part.getPartDivision().toLowerCase() : "", 0))  // Default ke 0 jika nama divisi tidak ditemukan
                            .namaDivisi(part.getPartDivision())
                            .build())
                    .collect(Collectors.toList());

            // Kembalikan response sesuai dengan format MessagesResponse
            return new MessagesResponse("Part successfully retrieved", HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(), partDivisionList);

        }catch (Exception e) {
            // Handle exception
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }

    }

    public MessagesResponse getPartStatus(){

        try {
            Map<String, Integer> statusMap = HardCodeMapUtil.getStatusMap();

            // Ambil semua data part dari database
            List<Part> partList = partRepository.findAll();

            // Map partList ke partSatuanList menggunakan stream dan map
            List<PartStatusResponse> partSatusList = partList.stream()
                    .map(part -> PartStatusResponse.builder()
                            // Cek apakah partStatus ada di dalam statusMap, konversi ke lowercase untuk pencocokan
                            .idStatus(statusMap.getOrDefault(
                                    part.getPartStatus() != null ? part.getPartStatus().toLowerCase() : "", 0))  // Default ke 0 jika nama status tidak ditemukan
                            .namaStatus(part.getPartStatus())  // Ubah part status ke lowercase
                            .build())
                    .collect(Collectors.toList());
            // Kembalikan response sesuai dengan format MessagesResponse
            return new MessagesResponse("Part successfully retrieved", HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(), partSatusList);

        }catch (Exception e) {
            // Handle exception
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }

    }

    public MessagesResponse getPartSatuan(){

        try {
            Map<String,Integer> satuanMap = HardCodeMapUtil.getSatuanMap();

            // Ambil semua data part dari database
            List<Part> partList = partRepository.findAll();

            // Map partList ke partSatuanList menggunakan stream dan map
            List<PartUnitResponse> partSatusList = partList.stream()
                    .map(part -> PartUnitResponse.builder()
                            // Cek apakah partStatus ada di dalam statusMap, konversi ke lowercase untuk pencocokan
                            .idSatuan(satuanMap.getOrDefault(
                                    part.getPartSatuan() != null ? part.getPartSatuan().toLowerCase() : "", 0))
                            .namaSatuan(part.getPartSatuan())  // Ubah part status ke lowercase
                            .build())
                    .collect(Collectors.toList());
            // Kembalikan response sesuai dengan format MessagesResponse
            return new MessagesResponse("Part successfully retrieved", HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(), partSatusList);

        }catch (Exception e) {
            // Handle exception
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }

    }

    public MessagesResponse getPartGroup(){

        try {
            // Daftar nama divisi dan id yang diinginkan
            Map<String,Integer> merkKendaraanMap = HardCodeMapUtil.getMerkKendaraanMap();
            // Ambil semua data part dari database
            List<Part> partList = partRepository.findAll();


            // Map partList ke partDivisionList menggunakan stream dan map
            List<PartGroupResponse> partDivisionList = partList.stream()
                    .map(part -> PartGroupResponse.builder()
                            // Cek apakah partDivision ada di dalam divisionMap, jika iya, ambil id dari map
                            .idGroup(merkKendaraanMap.getOrDefault(
                                    part.getPartGroup() != null ? part.getPartGroup().toLowerCase() : "", 0))  // Default ke 0 jika nama divisi tidak ditemukan
                            .namaGroup(part.getPartGroup())
                            .build())
                    .collect(Collectors.toList());

            // Kembalikan response sesuai dengan format MessagesResponse
            return new MessagesResponse("Part successfully retrieved", HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(), partDivisionList);

        }catch (Exception e) {
            // Handle exception
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }

    }

    public MessagesResponse getPartDto(String kodePart) {
        try {
            // Mendapatkan data dari HardCodeMapUtil
            Map<String,Integer> divisionMap = HardCodeMapUtil.getDivisionMap();
            Map<String,Integer> statusMap = HardCodeMapUtil.getStatusMap();
            Map<String,Integer> satuanMap = HardCodeMapUtil.getSatuanMap();
            Map<String,Integer> merkKendaraanMap = HardCodeMapUtil.getMerkKendaraanMap();

            // Cari part berdasarkan partId
            List<Part> partList = partRepository.findByIdPart(kodePart.toLowerCase());

            // Periksa apakah partList kosong
            if (partList.isEmpty()) {
                return new MessagesResponse(
                        "Part not found",
                        HttpStatus.NOT_FOUND.value(),
                        HttpStatus.NOT_FOUND.getReasonPhrase(),
                        "No part found with the given partId: " + kodePart);
            }

            // Mengubah setiap Part di partList menjadi PartResponse
            List<PartResponse> partResponses = partList.stream().map(part -> {
                String link = (part.getPartPhoto() != null) ? minioService.getPublicLink(part.getPartPhoto()) : null;

                List<PartResponse.PartPhoto> partPhotoList = Collections.singletonList(
                        PartResponse.PartPhoto.builder()
                                .filename(part.getPartPhoto())
                                .fileLink(link)
                                .build()
                );

                return PartResponse.builder()
                        .kodePart(part.getKodePart())
                        .partCode2(part.getPartCode2())
                        .partName(part.getNamaPart())
                        .partDivision(
                                PartResponse.PartDivision.builder()
                                        .idDivisi(divisionMap.getOrDefault(
                                                part.getPartDivision() != null ? part.getPartDivision().toLowerCase() : "", 0))
                                        .namaDivisi(part.getPartDivision())
                                        .build())
                        .partSubDivision(part.getPartSubDivision())
                        .partBrand(part.getPartBrand())
                        .partGroup(
                                PartResponse.PartGroup.builder()
                                        .idGroup(merkKendaraanMap.getOrDefault(
                                                part.getPartGroup() != null ? part.getPartGroup().toLowerCase() : "", 0))
                                        .namaGroup(part.getPartGroup())
                                        .build())
                        .partBuyPrice(part.getPartBuyPrice())
                        .partSellPriceR(part.getPartSellPriceR())
                        .partSellPriceBP(part.getPartSellPriceBp())
                        .partSellPriceAG(part.getPartSellPriceAg())
                        .partSellPriceD(part.getPartSellPriceD())
                        .partOnHand(part.getPartOnHand())
                        .partMinQty(part.getPartMinQty())
                        .partMaxQty(part.getPartMaxQty())
                        .partBarcode(part.getPartBarcode())
                        .partSatuan(
                                PartResponse.PartSatuan.builder()
                                        .idSatuan(satuanMap.getOrDefault(
                                                part.getPartSatuan() != null ? part.getPartSatuan().toLowerCase() : "", 0))
                                        .namaSatuan(part.getPartSatuan())
                                        .build())
                        .partUkuran(part.getPartUkuran())
                        .partNomorStock(part.getPartNomorStock())
                        .partStatus(
                                PartResponse.PartStatus.builder()
                                        .idStatus(statusMap.getOrDefault(
                                                part.getPartStatus() != null ? part.getPartStatus().toLowerCase() : "", 0))
                                        .namaStatus(part.getPartStatus())
                                        .build())
                        .partLocation1(part.getPartLokasi1())
                        .partLocation2(part.getPartLokasi2())
                        .partNote(part.getNote())
                        .partPhoto(partPhotoList)
                        .partExpired(part.getPartExpired())
                        .partOPSCK(part.getPartOpsck())
                        .partOPB(part.getPartOpb())
                        .build();
            }).collect(Collectors.toList());

            // Mengembalikan response dengan semua part data
            return new MessagesResponse(
                    "Parts successfully retrieved",
                    HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(),
                    partResponses);

        } catch (Exception e) {
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }
    }

    public MessagesResponse updatePart (String kodePart , PartRequest partRequest){
        try {

            Map<String,Integer> divisionMap = HardCodeMapUtil.getDivisionMap();
            Map<String,Integer> statusMap = HardCodeMapUtil.getStatusMap();
            Map<String,Integer> satuanMap = HardCodeMapUtil.getSatuanMap();
            Map<String,Integer> merkKendaraanMap = HardCodeMapUtil.getMerkKendaraanMap();

            List<Part> partList = partRepository.findByIdPart(kodePart.toLowerCase());

            if (partList.isEmpty()) {
                return new MessagesResponse(
                        "Part not found with the given code: " + kodePart,
                        HttpStatus.NOT_FOUND.value(),
                        HttpStatus.NOT_FOUND.getReasonPhrase()
                );
            }

            for (Part existingPart : partList) {
                // Update field part dengan data dari partRequest, hanya jika nilai di partRequest tidak null
                existingPart.setNamaPart(partRequest.getPartName() == null ? existingPart.getNamaPart() : partRequest.getPartName());
                existingPart.setKodePart(partRequest.getKodePart() == null ? existingPart.getKodePart() : partRequest.getKodePart());
                existingPart.setPartCode2(partRequest.getPartCode2() == null ? existingPart.getPartCode2() : partRequest.getPartCode2());
                existingPart.setPartDivision(partRequest.getNamaDivisi() == null ? existingPart.getPartDivision() : partRequest.getNamaDivisi());
                existingPart.setPartSubDivision(partRequest.getPartSubDivision() == null ? existingPart.getPartSubDivision() : partRequest.getPartSubDivision());
                existingPart.setPartGroup(partRequest.getNamaGroup() == null ? existingPart.getPartGroup() : partRequest.getNamaGroup());
                existingPart.setPartBuyPrice(partRequest.getPartBuyPrice() == null ? existingPart.getPartBuyPrice() : partRequest.getPartBuyPrice());
                existingPart.setPartSellPriceR(partRequest.getPartSellPriceR() == null ? existingPart.getPartSellPriceR() : partRequest.getPartSellPriceR());
                existingPart.setPartSellPriceBp(partRequest.getPartSellPriceBP() == null ? existingPart.getPartSellPriceBp() : partRequest.getPartSellPriceBP());
                existingPart.setPartSellPriceAg(partRequest.getPartSellPriceAG() == null ? existingPart.getPartSellPriceAg() : partRequest.getPartSellPriceAG());
                existingPart.setPartSellPriceD(partRequest.getPartSellPriceD() == null ? existingPart.getPartSellPriceD() : partRequest.getPartSellPriceD());
                existingPart.setPartOnHand(partRequest.getPartOnHand() == null ? existingPart.getPartOnHand() : partRequest.getPartOnHand());
                existingPart.setPartMinQty(partRequest.getPartMinQty() == null ? existingPart.getPartMinQty() : partRequest.getPartMinQty());
                existingPart.setPartMaxQty(partRequest.getPartMaxQty() == null ? existingPart.getPartMaxQty() : partRequest.getPartMaxQty());
                existingPart.setPartBarcode(partRequest.getPartBarcode() == null ? existingPart.getPartBarcode() : partRequest.getPartBarcode());
                existingPart.setPartSatuan(partRequest.getNamaSatuan() == null ? existingPart.getPartSatuan() : partRequest.getNamaSatuan());
                existingPart.setPartUkuran(partRequest.getPartUkuran() == null ? existingPart.getPartUkuran() : partRequest.getPartUkuran());
                existingPart.setPartNomorStock(partRequest.getPartNomorStock() == null ? existingPart.getPartNomorStock() : partRequest.getPartNomorStock());
                existingPart.setPartStatus(partRequest.getNamaStatus() == null ? existingPart.getPartStatus() : partRequest.getNamaStatus());
                existingPart.setPartLokasi1(partRequest.getPartLocation1() == null ? existingPart.getPartLokasi1() : partRequest.getPartLocation1());
                existingPart.setPartLokasi2(partRequest.getPartLocation2() == null ? existingPart.getPartLokasi2() : partRequest.getPartLocation2());
                existingPart.setNote(partRequest.getPartNote() == null ? existingPart.getNote() : partRequest.getPartNote());
                existingPart.setPartPhoto(partRequest.getFilename() == null ? existingPart.getPartPhoto() : partRequest.getFilename());
                existingPart.setPartExpired(partRequest.getPartExpired() == null ? existingPart.getPartExpired() : partRequest.getPartExpired());
                existingPart.setPartOpsck(partRequest.getPartOPSCK() == null ? existingPart.getPartOpsck() : partRequest.getPartOPSCK());
                existingPart.setPartOpb(partRequest.getPartOPB() == null ? existingPart.getPartOpb() : partRequest.getPartOPB());

                // Simpan perubahan untuk part ini
                partRepository.save(existingPart);
            }

            List<PartResponse> partResponses = partList.stream().map(part -> {
                String link = (part.getPartPhoto() != null) ? minioService.getPublicLink(part.getPartPhoto()) : null;

                List<PartResponse.PartPhoto> partPhotoList = Collections.singletonList(
                        PartResponse.PartPhoto.builder()
                                .filename(part.getPartPhoto())
                                .fileLink(link)
                                .build()
                );

                return PartResponse.builder()
                        .kodePart(part.getKodePart())
                        .partCode2(part.getPartCode2())
                        .partName(part.getNamaPart())
                        .partDivision(
                                PartResponse.PartDivision.builder()
                                        .idDivisi(divisionMap.getOrDefault(
                                                part.getPartDivision() != null ? part.getPartDivision().toLowerCase() : "", 0))
                                        .namaDivisi(part.getPartDivision())
                                        .build())
                        .partSubDivision(part.getPartSubDivision())
                        .partBrand(part.getPartBrand())
                        .partGroup(
                                PartResponse.PartGroup.builder()
                                        .idGroup(merkKendaraanMap.getOrDefault(
                                                part.getPartGroup() != null ? part.getPartGroup().toLowerCase() : "", 0))
                                        .namaGroup(part.getPartGroup())
                                        .build())
                        .partBuyPrice(part.getPartBuyPrice())
                        .partSellPriceR(part.getPartSellPriceR())
                        .partSellPriceBP(part.getPartSellPriceBp())
                        .partSellPriceAG(part.getPartSellPriceAg())
                        .partSellPriceD(part.getPartSellPriceD())
                        .partOnHand(part.getPartOnHand())
                        .partMinQty(part.getPartMinQty())
                        .partMaxQty(part.getPartMaxQty())
                        .partBarcode(part.getPartBarcode())
                        .partSatuan(
                                PartResponse.PartSatuan.builder()
                                        .idSatuan(satuanMap.getOrDefault(
                                                part.getPartSatuan() != null ? part.getPartSatuan().toLowerCase() : "", 0))
                                        .namaSatuan(part.getPartSatuan())
                                        .build())
                        .partUkuran(part.getPartUkuran())
                        .partNomorStock(part.getPartNomorStock())
                        .partStatus(
                                PartResponse.PartStatus.builder()
                                        .idStatus(statusMap.getOrDefault(
                                                part.getPartStatus() != null ? part.getPartStatus().toLowerCase() : "", 0))
                                        .namaStatus(part.getPartStatus())
                                        .build())
                        .partLocation1(part.getPartLokasi1())
                        .partLocation2(part.getPartLokasi2())
                        .partNote(part.getNote())
                        .partPhoto(partPhotoList)
                        .partExpired(part.getPartExpired())
                        .partOPSCK(part.getPartOpsck())
                        .partOPB(part.getPartOpb())
                        .build();
            }).collect(Collectors.toList());

            return new MessagesResponse(
                    "Parts successfully updated",
                    HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(),partResponses
            );

        }catch (Exception e) {
            return new MessagesResponse(
                    "Error occurred while retrieving parts",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }
    }

    public MessagesResponse deletePart(String kodePart) {
        try {
            // Cari data part berdasarkan kodePart
            List<Part> partList = partRepository.findByIdPart(kodePart.toLowerCase());

            // Jika part tidak ditemukan, kembalikan pesan not found
            if (partList.isEmpty()) {
                return new MessagesResponse(
                        "Part not found with the given code: " + kodePart,
                        HttpStatus.NOT_FOUND.value(),
                        HttpStatus.NOT_FOUND.getReasonPhrase()
                );
            }

            // Hapus semua part yang ditemukan
            for (Part part : partList) {
                partRepository.delete(part);  // Menghapus part dari database
            }

            // Kembalikan pesan sukses
            return new MessagesResponse(
                    "Part " + kodePart + " successfully deleted",
                    HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase()
            );

        } catch (Exception e) {
            // Jika ada error, tangani dengan mengembalikan pesan error
            return new MessagesResponse(
                    "Error occurred while deleting part",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage()
            );
        }
    }

    public MessagesResponse importExelPart(MultipartFile typeFile) {
        List<PartRequest> partRequestList = new ArrayList<>();
        Optional<Part> rowTerakhirPart = partRepository.rowTerakhirPart();
        Long count = rowTerakhirPart.map(Part::getIdPart).orElse(0L); // Antisipasi null
        String kodePartPrefix = "P";

        try {
            // Cek apakah file kosong atau tidak
            if (typeFile.isEmpty()) {
                return new MessagesResponse("File is empty", HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
            }


            try (InputStream inputStream = typeFile.getInputStream()) {
                Workbook workbook = new XSSFWorkbook(inputStream); // Membaca file Excel .xlsx
                Sheet sheet = workbook.getSheetAt(0); // Ambil sheet pertama
                if (!isValidTemplate(sheet)) {
                    return new MessagesResponse("Upload failed: Excel template is not valid", HttpStatus.BAD_REQUEST.value(),
                            "Please use the template provided by the API at part/product/download-excel");
                }

                // Looping setiap baris, mulai dari baris ketiga (indeks 2, karena Excel 0-based)
                for (int i = 2; i <= sheet.getLastRowNum(); i++) {
                    Row row = sheet.getRow(i);

                    if (row == null || isRowEmpty(row)) {
                        // Jika baris kosong atau semua sel dalam baris kosong berhenti melakukan pengulangan
                        continue;
                    }

                    if (!isValidRow(row)) {
                        return new MessagesResponse("Upload failed: Data on row " + (i + 1) + " is invalid",
                                HttpStatus.BAD_REQUEST.value(), "Data error");

                    }
                    List <Part> existingPart = partRepository.findByNamaPart(getCellValueAsString(row.getCell(0)));
                    for (Part part : existingPart) {
                        String namaPart= getCellValueAsString(row.getCell(0));
                        if (part.getNamaPart().equals(namaPart)){
                            return new MessagesResponse("Upload failed: Duplicate part name on row " + (i + 1),
                                    HttpStatus.BAD_REQUEST.value(), "Data error");

                        }
                    }


                    // Pengecekan null pada setiap sel sebelum mengambil nilai
                    PartRequest partRequest = PartRequest.builder()
                            .kodePart(kodePartPrefix + (count + i-1)) // Buat kode part unik untuk setiap item
                            .partName(getCellValueAsString(row.getCell(0))) // Kolom pertama untuk nama part
                            .partCode2(getCellValueAsString(row.getCell(1))) // Kolom kedua untuk kode part 2
                            .partBuyPrice(getCellValueAsBigDecimal(row.getCell(2)))// Kolom keetiga untuk harga beli
                            .namaDivisi(getCellValueAsString(row.getCell(3)))
                            .partSubDivision(getCellValueAsString(row.getCell(4)))
                            .partBrand(getCellValueAsString(row.getCell(5)))
                            .namaGroup(getCellValueAsString(row.getCell(6)))
                            .partSellPriceR(getCellValueAsBigDecimal(row.getCell(7)))
                            .partSellPriceAG(getCellValueAsBigDecimal(row.getCell(8)))
                            .partSellPriceBP(getCellValueAsBigDecimal(row.getCell(9)))
                            .partSellPriceD(getCellValueAsBigDecimal(row.getCell(10)))
                            .partOnHand(getCellValueAsShort(row.getCell(11)))
                            .partBarcode(getCellValueAsString(row.getCell(12)))
                            .partMinQty(getCellValueAsShort(row.getCell(13)))
                            .partMaxQty(getCellValueAsShort(row.getCell(14)))
                            .namaSatuan(getCellValueAsString(row.getCell(15)))
                            .partUkuran(getCellValueAsBigDecimal(row.getCell(16)))
                            .partNomorStock(getCellValueAsShort(row.getCell(17)))
                            .namaStatus(getCellValueAsString(row.getCell(18)))
                            .partLocation1(getCellValueAsString(row.getCell(19)))
                            .partLocation2(getCellValueAsString(row.getCell(20)))
                            .partNote(getCellValueAsString(row.getCell(21)))
                            .partExpired(getCellValueAsBoolean(row.getCell(22)))
                            .partOPB(getCellValueAsBoolean(row.getCell(23)))
                            .partOPSCK(getCellValueAsBoolean(row.getCell(24)))
                            // ... tambahkan pemetaan untuk kolom lain yang sesuai dengan PartRequest
                            .build();

                    partRequestList.add(partRequest); // Tambahkan ke list partRequestList
                }

                workbook.close(); // Jangan lupa tutup Workbook
            }

            if (partRequestList.isEmpty()) {
                return new MessagesResponse(
                        "Data not found",
                        HttpStatus.NOT_FOUND.value(),
                        HttpStatus.NOT_FOUND.getReasonPhrase());
            }

            // Iterasi melalui list partRequestList dan simpan ke database
            for (PartRequest partRequest : partRequestList) {
                Part part = Part.builder()
                        .kodePart(partRequest.getKodePart())
                        .partCode2(partRequest.getPartCode2())
                        .namaPart(partRequest.getPartName())
                        .partDivision(partRequest.getNamaDivisi())
                        .partSubDivision(partRequest.getPartSubDivision())
                        .partGroup(partRequest.getNamaGroup())
                        .partBuyPrice(partRequest.getPartBuyPrice())
                        .partSellPriceR(partRequest.getPartSellPriceR())
                        .partSellPriceBp(partRequest.getPartSellPriceBP())
                        .partSellPriceAg(partRequest.getPartSellPriceAG())
                        .partSellPriceD(partRequest.getPartSellPriceD())
                        .partOnHand(partRequest.getPartOnHand())
                        .partMinQty(partRequest.getPartMinQty())
                        .partMaxQty(partRequest.getPartMaxQty())
                        .partBarcode(partRequest.getPartBarcode())
                        .partSatuan(partRequest.getNamaSatuan())
                        .partUkuran(partRequest.getPartUkuran())
                        .partNomorStock(partRequest.getPartNomorStock())
                        .partStatus(partRequest.getNamaStatus())
                        .partLokasi1(partRequest.getPartLocation1())
                        .partLokasi2(partRequest.getPartLocation2())
                        .note(partRequest.getPartNote())
                        .partPhoto(partRequest.getFilename())
                        .partExpired(partRequest.getPartExpired())
                        .partOpsck(partRequest.getPartOPSCK())
                        .partOpb(partRequest.getPartOPB())
                        .build();

                partRepository.save(part); // Simpan setiap objek Part ke database
            }

            return new MessagesResponse("File processed successfully", HttpStatus.OK.value(), HttpStatus.OK.getReasonPhrase());

        } catch (Exception e) {
            // Jika ada error, tangani dengan mengembalikan pesan error
            return new MessagesResponse(
                    "Error import part",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage()
            );
        }
    }

    public MessagesResponse downloadTemplateExel(){
        try {

            String link = minioService.getPublicLink("Import Data Part.xlsx");
            List<PartResponse.PartPhoto> response = Collections.singletonList(
                    PartResponse.PartPhoto.builder()
                            .filename("Import Data Part.xlsx")
                            .fileLink(link)
                            .build()
            );

            return new MessagesResponse(
                    "Parts successfully retrieved",
                    HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(),
                    response);
        }catch (Exception e) {
            // Jika ada error, tangani dengan mengembalikan pesan error
            return new MessagesResponse(
                    "Error import part",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage()
            );
        }
    }


}
