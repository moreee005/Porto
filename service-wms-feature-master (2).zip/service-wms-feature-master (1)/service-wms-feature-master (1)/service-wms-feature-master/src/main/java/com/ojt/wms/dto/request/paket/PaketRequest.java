package com.ojt.wms.dto.request.paket;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaketRequest {

    private String namaPaket;
    private String tipeService;
    private BigDecimal totalHarga;
    private List<PartPaketRequest> dataPart;
    private List<JasaPaketRequest> dataJasa;

}
