package com.ojt.wms.service;

public class SerahTerimaKendaraanService {
}
