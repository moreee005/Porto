package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Asuransi")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Asuransi {

    @Id // Menunjukkan bahwa ini adalah ID untuk entitas Asuransi
    private Long idOrganisasi;

    @OneToOne
    @MapsId // Menghubungkan field organization dengan idOrganisasi sebagai PK
    @JoinColumn(name = "id_organisasi", referencedColumnName = "id_organisasi")
    private Organization organization;

    @ManyToOne
    @JoinColumn(name = "id_cabang", referencedColumnName = "id_cabang")
    private Cabang cabang;    

    @ManyToOne
    @JoinColumn(name = "id_kota", referencedColumnName = "id_kota")
    private Kota kota;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "nama_organisasi", nullable = true)
    private String namaOrganisasi;

    @Column(name = "alamat", nullable = true, columnDefinition = "TEXT")
    private String alamat;

    @Column(name = "pic", nullable = true)
    private String pic;

    @Column(name = "telp", nullable = true)
    private String telp;

    @Column(name = "hp", nullable = true)
    private String hp;

    @Column(name = "alias", nullable = true)
    private String alias;

    @Column(name = "npwp", nullable = false)
    private String npwp;

    @Column(name = "labor_persen", nullable = true)
    private Short laborPersen;

    @Column(name = "material_persen", nullable = true)
    private Short materialPersen;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}

