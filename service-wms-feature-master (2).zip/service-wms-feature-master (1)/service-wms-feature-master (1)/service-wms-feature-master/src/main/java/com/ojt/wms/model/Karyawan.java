package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Karyawan")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Karyawan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_karyawan", nullable = false, unique = true, updatable = false)
    private Long idKaryawan;

    @OneToOne
    @JoinColumn(name = "nik", referencedColumnName = "nik")
    private Person person;

    @ManyToOne
    @JoinColumn(name = "kode_posisi", referencedColumnName = "kode_posisi")
    private Posisi posisi;

    @ManyToOne
    @JoinColumn(name = "id_kota", referencedColumnName = "id_kota")
    private Kota kota;

    @ManyToOne
    @JoinColumn(name = "id_pendidikan_terakhir", referencedColumnName = "id_pendidikan_terakhir")
    private PendidikanTerakhir pendidikanTerakhir;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "nama", nullable = true)
    private String nama;

    @Column(name = "alamat", nullable = true, columnDefinition = "TEXT")
    private String alamat;

    @Column(name = "telp", nullable = true)
    private String telp;

    @Column(name = "hp", nullable = true)
    private String hp;

    @Column(name = "email", nullable = true)
    private String email;

    @Column(name = "npwp", nullable = true)
    private String npwp;

    @Column(name = "tempat_lahir", nullable = true)
    private String tempatLahir;

    @Column(name = "jenis_kelamin", nullable = true)
    private String jenisKelamin;

    @Column(name = "nama_sekolah", nullable = true)
    private String namaSekolah;

    @Column(name = "status_karyawan", nullable = true)
    private String statusKaryawan;

    @Column(name = "cabang", nullable = true)
    private String cabang;

    @Column(name = "tgl_mulai_kerja", nullable = true)
    private LocalDate tglMulaiKerja;

    @Column(name = "target_revenue", nullable = true)
    private BigDecimal targetRevenue;

    @Column(name = "target_unit", nullable = true)
    private BigDecimal targetUnit;

    @Column(name = "nomor_rekening", nullable = true)
    private String nomorRekening;

    @Column(name = "bank_rekening", nullable = true)
    private String bankRekening;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
