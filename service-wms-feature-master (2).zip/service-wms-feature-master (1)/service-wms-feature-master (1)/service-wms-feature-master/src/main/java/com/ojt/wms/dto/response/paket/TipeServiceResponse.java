package com.ojt.wms.dto.response.paket;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TipeServiceResponse {

    private Integer idTipeService;

    private String namaTipeService;
}
