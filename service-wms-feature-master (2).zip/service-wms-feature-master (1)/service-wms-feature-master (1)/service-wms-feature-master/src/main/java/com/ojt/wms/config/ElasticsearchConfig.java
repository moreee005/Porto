package com.ojt.wms.config;

import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import javax.net.ssl.SSLContext;
import java.io.File;
@Configuration
public class ElasticsearchConfig {


    @Bean
    public RestHighLevelClient restHighLevelClient(HttpClientConfigImpl httpClientConfig) {
        RestClientBuilder builder = RestClient.builder(
                        new HttpHost("localhost", 9200, "https")) // Sesuaikan host dan port
                .setHttpClientConfigCallback(httpClientConfig);

        return new RestHighLevelClient(builder);
    }

}

