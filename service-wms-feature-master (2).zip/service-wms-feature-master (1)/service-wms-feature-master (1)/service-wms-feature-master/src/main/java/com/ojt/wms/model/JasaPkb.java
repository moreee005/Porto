package com.ojt.wms.model;
import java.math.BigDecimal;
import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "JasaPkb")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JasaPkb {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_jasa_pkb", nullable = true)
    private Long idJasaPkb;

    @ManyToOne
    @JoinColumn(name = "id_jasa_asuransi", nullable = true)
    private JasaAsuransi jasaAsuransi;

    @ManyToOne
    @JoinColumn(name = "id_jasa", nullable = true)
    private Jasa jasa;

    @ManyToOne
    @JoinColumn(name = "id_wo", nullable = true)
    private WorkOrder workOrder;

    @Column(name = "harga_jasa_pkb")
    private BigDecimal hargaJasaPkb;

    @Column(name = "disc_jasa_pkb")
    private BigDecimal discJasaPkb;

    @Column(name = "komentar_jasa_pkb")
    private String komentarJasaPkb;

    @Column(name = "status_pengerjaan_jasa")
    private String statusPengerjaanJasa;

    @Column(name = "is_from_paket")
    private Boolean isFromPaket;

    @Column(name = "is_submitted")
    private Boolean isSubmitted;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}