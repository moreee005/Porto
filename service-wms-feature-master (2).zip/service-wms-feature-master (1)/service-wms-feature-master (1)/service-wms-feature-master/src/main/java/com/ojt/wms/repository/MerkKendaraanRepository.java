package com.ojt.wms.repository;

import com.ojt.wms.model.Jasa;
import com.ojt.wms.model.MerkKendaraan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerkKendaraanRepository extends JpaRepository<MerkKendaraan, Integer> {
}
