package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Cabang")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Cabang {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cabang", nullable = false, unique = true, updatable = false)
    private Integer idCabang;

    @Column(name = "id_bengkel", nullable = true)
    private Integer idBengkel;

    @Column(name = "nama_cabang", nullable = true)
    private String namaCabang;

    @Column(name = "is_cabang_asuransi", nullable = true)
    private Boolean isCabangAsuransi;

    @Column(name = "is_cabang_bengkel", nullable = true)
    private Boolean isCabangBengkel;

    @Column(name = "is_cabang_supplier", nullable = true)
    private Boolean isCabangSupplier;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;
}
