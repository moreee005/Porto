package com.ojt.wms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ojt.wms.model.Paket;

public interface PaketRepository extends JpaRepository<Paket, Integer>{
    Optional<Paket> findByKodePaket(String kodePaket);
    Optional<Paket> findTopByOrderByKodePaketDesc();
} 
