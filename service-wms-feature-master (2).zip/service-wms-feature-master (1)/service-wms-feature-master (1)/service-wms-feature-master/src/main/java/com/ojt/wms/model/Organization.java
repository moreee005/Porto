package com.ojt.wms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "Organization")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Organization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_organisasi", nullable = false, unique = true, updatable = false)
    private Long idOrganisasi;

    @ManyToOne
    @JoinColumn(name = "id_cabang", referencedColumnName = "id_cabang")
    private Cabang cabang;

    @ManyToOne
    @JoinColumn(name = "id_kota", referencedColumnName = "id_kota")
    private Kota kota;

    @Column(name = "nama_organisasi", nullable = true)
    private String namaOrganisasi;

    @Column(name = "alamat", nullable = true, columnDefinition = "TEXT")
    private String alamat;

    @Column(name = "telp", nullable = true)
    private String telp;

    @Column(name = "hp", nullable = true)
    private String hp;

    @Column(name = "email", nullable = true)
    private String email;

    @Column(name = "npwp", nullable = true)
    private String npwp;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Timestamp createdDate;

    @Column(name = "modified_by", nullable = true)
    private String modifiedBy;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Timestamp modifiedDate;

    @Column(name = "is_deleted", nullable = true)
    @Builder.Default
    private Boolean isDeleted = false;

}
