import oracledb
from . import config

def get_connection_db():
    return oracledb.connect(user=config.DB_USER, password=config.DB_PASSWORD, dsn=config.DB_DSN)
