import threading
from flask import abort, jsonify, request
from src.controller import bond_member_entitlement_route
from src.services.bond_member_entitlement_service import bond_member_entitlement_datas, bond_member_entitlement_sync

@bond_member_entitlement_route.route('/sync', methods=['GET'])
def sync_data():
    # threading.Thread(target=bond_member_entitlement_sync).start()
    bond_member_entitlement_sync()
    return jsonify({
        "message": "Successfully Sync Data Bond Member Entitlement From Oracle To MongoDB"
    })

@bond_member_entitlement_route.route('/', methods=['GET'])
def get_bond_member_datas():
    date = request.args.get('date')
    if not date:
        return abort(400, description="date is require")
    return jsonify(bond_member_entitlement_datas(date))
