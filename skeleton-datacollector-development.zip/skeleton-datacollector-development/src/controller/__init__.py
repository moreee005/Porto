from flask import Blueprint

health_route = Blueprint('health', __name__)

# invitation_letter_route = Blueprint('invitation_letter', __name__)

bond_member_entitlement_route = Blueprint('bond_member_entitlement', __name__)
bond_issuer_overview_route = Blueprint('bond_issuer_overview', __name__)

from . import health
# from . import invitation_letter_controller
from . import bond_member_entitlement_controller
from . import bond_issuer_overview_controller
