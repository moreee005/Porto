from src import log
from src.controller import health_route
from src.config import config

@health_route.route('/', methods=["GET"])
def home():
    log.info('this is an INFO message')
    return {
        "Message": f"Home of Application {config.APP_NAME}"
    }

@health_route.route('/ping', methods=["GET"])
def ping():
    log.info('this is an INFO message')
    return {
        "Message": "OK!"
    }
