import threading
from flask import abort, jsonify, request
from src.controller import bond_issuer_overview_route
from src.services.bond_issuer_overview_service import bond_issuer_overview_datas, bond_issuer_overview_sync

print("Bond Issuer Overview Route Imported:", bond_issuer_overview_route)

@bond_issuer_overview_route.route('/sync', methods=['GET'])
def sync_data():
    # threading.Thread(target=bond_issuer_overview_sync).start()
    bond_issuer_overview_sync()
    return jsonify({
        "message": "Successfully Sync Data Bond Issuer Overview From Oracle To MongoDB"
    })

@bond_issuer_overview_route.route('/', methods=['GET'])
def get_bond_issuer_overview_datas():
    date = request.args.get('date')
    if not date:
        return abort(400, description="date is required")
    return jsonify(bond_issuer_overview_datas(date))


