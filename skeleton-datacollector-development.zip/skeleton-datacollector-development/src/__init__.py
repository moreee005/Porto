import logging
import os
from flask import Flask, abort, request, json
from flask_pymongo import PyMongo
from werkzeug.exceptions import HTTPException
from src.config import config
from keycove import decrypt
from swagger_ui import flask_api_doc

app = Flask(__name__)
app.config["MONGO_URI"] = config.MONGO_URI

mongo = PyMongo(app)

if config.MODE == "development":
    config_path_swagger = os.path.join(os.path.dirname(__file__), 'swagger.yaml')
    flask_api_doc(app, config_path=config_path_swagger, url_prefix='/swagger', title='Data Collector Service')

# Logging
# print(app.url_map)

if __name__ != '__main__':
    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)

log = app.logger

@app.after_request
def logAfterRequest(response):
    log.info(
        "path: %s | method: %s | status: %s | size: %s",
        request.path,
        request.method,
        response.status,
        response.content_length,
    )
    return response

# Register Blueprint

@app.errorhandler(HTTPException)
def handle_exception(e):
    log.error("HTTP Exception occurred: %s | Path: %s | Status: %s", e.description, request.path, e.code)
    """Return JSON instead of HTML for HTTP errors."""
    # start with the correct headers and status code from the error
    response = e.get_response()
    # replace the body with JSON
    response.data = json.dumps({
        "code": e.code,
        "name": e.name,
        "message": e.description,
    })
    response.content_type = "application/json"
    return response

def authenticate_api_key(api_key):
    try:
        if config.API_KEY == decrypt(encrypted_value=api_key, secret_key=config.SECRET_KEY):
            return True
        else:
            return False
    except Exception as e:
        return False


@app.before_request
def before_request():
    log.info("Incoming request to path: %s | method: %s", request.path, request.method)
    if request.path.startswith('/swagger'):
        return
    api_key = request.headers.get('API-Key')
    if not api_key or not authenticate_api_key(api_key):
        abort(401, description="API Key Not Valid")

from src import controller

app.register_blueprint(controller.health_route, url_prefix=config.URL_PREFIX)

app.register_blueprint(controller.bond_member_entitlement_route, url_prefix=config.URL_PREFIX + '/bond-member-entitlement')

app.register_blueprint(controller.bond_issuer_overview_route, url_prefix=config.URL_PREFIX + '/bond-issuer-overview')

log.info("Registered routes:\n%s", app.url_map)

