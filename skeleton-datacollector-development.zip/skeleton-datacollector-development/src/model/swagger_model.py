def hello_swagger():
    """
    A simple hello world endpoint.
    ---
    operationId: getGreetingMessage
    tags:
      - Greeting API
    summary: Returns a greeting message
    description: This endpoint returns a simple hello world message.
    parameters:
      - name: name
        in: query
        type: string
        required: true
        description: The name of the person to greet.
    responses:
      200:
        description: A successful response
        schema:
          type: object
          properties:
            message:
              type: string
              example: Hello, World!
      400:
        description: Bad request
    produces:
      - application/json
    consumes:
      - application/json
    security:
      - ApiKeyAuth: []
    """
    return """
    A simple hello world endpoint.
    ---
    operationId: getGreetingMessage
    tags:
      - Greeting API
    summary: Returns a greeting message
    description: This endpoint returns a simple hello world message.
    parameters:
      - name: name
        in: query
        type: string
        required: true
        description: The name of the person to greet.
    responses:
      200:
        description: A successful response
        schema:
          type: object
          properties:
            message:
              type: string
              example: Hello, World!
      400:
        description: Bad request
    produces:
      - application/json
    consumes:
      - application/json
    security:
      - ApiKeyAuth: []
    """