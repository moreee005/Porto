from src.config import config
from src.model.mongo.gridfs import retrieve_gridfs_data, bio_gridfs_insert

def get_datas_bio(query):
    return retrieve_gridfs_data(config.BOND_ISSUER_OVERVIEW_COL, query)

def insert_datas_bond_issuer_overview(datas):
    bio_gridfs_insert(config.BOND_ISSUER_OVERVIEW_COL, datas)
