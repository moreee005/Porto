from src import mongo
from bson.json_util import dumps, loads
import gridfs

def bmer_gridfs_insert(collection, datas):
    fs = gridfs.GridFS(mongo.db)
    for data in datas:
        json_data = dumps(data)
        file_id = fs.put(json_data.encode('utf-8'), filename=f'{data.get('ID_MEM')}_Bond_Member_Entitlement_KSEI_{data.get('P_SINCE_FN')}.json')
        mongo.db[collection].insert_one({
            "ID_MEM": data.get('ID_MEM'),
            "P_SINCE": data.get('P_SINCE'),
            "P_SINCE_FN": data.get('P_SINCE_FN'),
            "file_id": file_id
        })

def bio_gridfs_insert(collection, datas):
    fs = gridfs.GridFS(mongo.db)
    for data in datas:
        json_data = dumps(data)
        file_id = fs.put(json_data.encode('utf-8'), filename=f'Bond_Issuer_Overview_KSEI_{data.get('ID_CA_CAPCO')}_{data.get('SEC')}_{data.get('ID_MEM')}.json')
        mongo.db[collection].insert_one({
            "ID_CA_CAPCO": data.get('ID_CA_CAPCO'),
            "SEC": data.get('SEC'),
            "ID_MEM": data.get('ID_MEM'),
            "P_REC_DATE": data.get('P_REC_DATE'),
            "file_id": file_id
        })

def retrieve_gridfs_data(collection, query=None):
    fs = gridfs.GridFS(mongo.db)
    collection = mongo.db[collection]
    
    if query is None:
        query = {}
    
    results = []
    for doc in collection.find(query):
        file_id = doc['file_id']
        file_data = fs.get(file_id).read()
        full_doc = loads(file_data.decode('utf-8'))
        results.append(full_doc)
    
    return results