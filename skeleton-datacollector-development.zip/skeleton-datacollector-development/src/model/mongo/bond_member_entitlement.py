from src.config import config
from src.model.mongo.gridfs import retrieve_gridfs_data, bmer_gridfs_insert

def get_datas_bmer(query):
    return retrieve_gridfs_data(config.BOND_MEMBER_ENTITLEMENT_COL, query)

def insert_datas_bond_member_entitlement(datas):
    bmer_gridfs_insert(config.BOND_MEMBER_ENTITLEMENT_COL, datas)
