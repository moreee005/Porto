from src.config import config
from src import mongo

def insert(data):
    mongo.db.get_collection(config.LOG_COL).insert_one(data)