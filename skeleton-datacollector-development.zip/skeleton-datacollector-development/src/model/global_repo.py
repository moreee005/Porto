from oracledb import Connection
import oracledb

def fetch_tgl(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
        to_char(
            get_last_bus_day(sysdate), 
            'DD-MON-YYYY'
        ) tgl, 
        to_char(
            get_next_bus_day(sysdate), 
            'YYYYMMDD'
        ) tgl2 
        from dual
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0], row[1]

def fetch_libur(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            count(*) as libur 
        from off_days 
        where 
            to_char(off_day, 'DD-MON-YYYY')= to_char(sysdate, 'DD-MON-YYYY')
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0]

def insert_report(id_member, tanggal, filename, dsc, conn:Connection):
    try:
        cursor = conn.cursor()
        cursor.execute(f"""
            insert into reports
            values 
            (
                :1, :2, :3, 
                :4, 'C-BEST'
            )
        """, (id_member, tanggal, (filename + ".pdf.zip"), dsc))
        conn.commit()        
    except oracledb.DatabaseError as e:
        print(f"Error Insert To Oracle: {e}")
    finally:
        cursor.close()

def delete_report(id_member, tanggal, dsc, conn:Connection):
    try:
        cursor = conn.cursor()
        cursor.execute("""
            delete from reports
            where 
                tgl = :1 
                and memberid = :2 
                and dsc = :3 
                and tipe = 'C-BEST'
        """, (tanggal, id_member, dsc))
        conn.commit()
    except oracledb.DatabaseError as e:        
        print(f"Error Delete To Oracle: {e}")
    finally:
        cursor.close()