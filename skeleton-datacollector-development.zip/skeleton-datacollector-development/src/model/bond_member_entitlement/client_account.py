from dataclasses import dataclass

@dataclass
class ClientAccount:
    acct_substr: str
    client_acct_id: str
    client_full_acct_id: str
    client_mem_id: str
    client_ata_code: str
    client_blnc_amt: str
    client_ins_id: str
    client_acct_desc: str
    new_client_ca_id: str
    client_tax_rate: str
