import time
from src import log
from src.config.db import get_connection_db
from src.repository.bond_issuer_overview_repo import fetch_bond_issuer, get_json_report_data, map_client_account_data, map_own_account_data
from src.repository.global_repo import fetch_cf_eff_date, fetch_libur_bond, fetch_tgl_bond
from src.repository.mongo.bond_issuer_overview_repo_mongo import bulk_insert_bio, fetch_data_bio
from src.repository.mongo.log_repo_mongo import insert_data_log


def bond_issuer_overview_sync():
    log.info("Start Process Get Data And Insert To MongoDB")
    start_time = time.time()
    
    try:
        conn = get_connection_db()
        
        libur = fetch_libur_bond(conn)

        datas = []
        
        if libur == 0:
            dat_rec, _ = fetch_tgl_bond(conn)
            
            rs_mem = fetch_bond_issuer('19-AUG-2024', conn)
            
            for data in rs_mem:
                try:
                    p_ca_id = data.id_ca_capco
                    id_mem = data.id_mem
                    ca_type = data.catype
                    json_data = get_json_report_data(p_ca_id, id_mem, ca_type, conn)
                    datas.append(json_data)
                except Exception as e:
                    log.error(f"Failed to fetch data for {data.id_mem}: {str(e)}")
            
        if datas:
            bulk_insert_bio(datas)
        else:
            log.info("No data to insert into MongoDB")
        
        end_time = time.time()    
        log.info(f"Sync Data From Oracle To MongoDB Successfully! | Total Data : {len(datas)} | Duration : {(end_time - start_time)} Seconds")
        insert_data_log({
                "operation": "Sync Data Bond Issuer Overview From Oracle",
                "total_data": len(datas),
                "status" : "Success",
                "duration" : f"{(end_time - start_time)} Seconds",
                "exception" : "-"
        }) 
        conn.close()
    except Exception as e:
        log.error("Failed Get Data From Oracle And Insert To MongoDB Because %s", e)
        end_time = time.time()
        insert_data_log({
                "operation": "Sync Data Bond Issuer Overview From Oracle",
                "total_data": 0,
                "status" : "Failed",
                "duration" : f"{(end_time - start_time)} Seconds",
                "exception" : str(e)
        })    
    
def bond_issuer_overview_datas(date):
    results = list(fetch_data_bio({
        'P_REC_DATE': date
    }))

    return results