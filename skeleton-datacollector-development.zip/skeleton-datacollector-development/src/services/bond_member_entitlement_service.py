import time
import json
from src import log
from src.config.db import get_connection_db
from src.repository.bond_member_entitlement_repo import fetch_id_mem, map_to_json2
from src.repository.global_repo import fetch_cf_eff_date, fetch_libur_bond, fetch_tgl_bond
from src.repository.mongo.bond_member_entitlement_repo_mongo import bulk_insert_bmer, fetch_data_bmer
from src.repository.mongo.log_repo_mongo import insert_data_log


def bond_member_entitlement_sync():    
    log.info("Start Process Get Data And Insert To MongoDB")
    start_time = time.time()

    try:
        conn = get_connection_db()

        libur = fetch_libur_bond(conn)

        datas = []

        if libur == 0:
            # tgl, _ = fetch_tgl_bond(conn)
            tgl, _ = ('09-SEP-2024', '20240909')
            
            cf_eff_date = fetch_cf_eff_date(tgl, conn)

            # p_member = fetch_id_mem(tgl, cf_eff_date, conn)
            p_member = ['XL001']           

            for id_mem in p_member:
                datas.append(map_to_json2(id_mem, tgl, cf_eff_date, conn))
            
            # with open('result_XL001_20240909.json', 'r') as file:
            #     json_data = json.load(file)

            # datas.append(json_data)

        if datas:
            bulk_insert_bmer(datas)
        else:
            log.info("No Data To Insert MongoDB")

        end_time_input_data = time.time()

        insert_data_log({
                "operation": "Sync Data Bond Member Entitlement From Oracle",
                "total_data": len(datas),
                "status" : "Success",
                "duration" : f"{(end_time_input_data - start_time)} Seconds",
                "exception" : '-'
        })

        end_time = time.time()        
        log.info(f"Sync Data From Oracle To MongoDB Successfully! | Total Data : {len(datas)} | Duration : {(end_time - start_time)} Seconds")          
    except Exception as e:
        log.error("Failed Get Data From Oracle And Insert To MongoDB Because %s", e)
        end_time = time.time()
        insert_data_log({
                "operation": "Sync Data Bond Member Entitlement From Oracle",
                "total_data": 0,
                "status" : "Failed",
                "duration" : f"{(end_time - start_time)} Seconds",
                "exception" : str(e)
        })  
    finally:
        conn.close()   
        
def bond_member_entitlement_datas(date):
    results = list(fetch_data_bmer({
        'P_SINCE': date
    }))

    return results