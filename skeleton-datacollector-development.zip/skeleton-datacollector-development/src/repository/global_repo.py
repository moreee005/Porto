from oracledb import Connection
from src.config import config

def get_libur(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(
       f"""
        select 
            count(*) as libur 
        from off_days 
        where 
            to_char(off_day,'DD-MON-YYYY')=to_char(sysdate,'DD-MON-YYYY')
        """
    )

    row = cursor.fetchone()
    cursor.close()
    return row[0]

def get_tgl(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(
        f"""
        select 
            to_char(get_last_bus_day(sysdate), 'DD-MON-YYYY') tgl, 
            to_char(get_next_bus_day(sysdate), 'YYYYMMDD') tgl2 
        from dual
        """
    )

    row = cursor.fetchone()
    cursor.close()
    return row[0], row[1]

def fetch_cf_eff_date(p_since, conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT 
            get_next_bus_date@{config.DB_LINK_TOBAMR}(:p_since, 1)
        FROM dual
    """, {'p_since': p_since})

    row = cursor.fetchone()
    cursor.close()

    return row[0]

def fetch_tgl_bond(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            to_char(sysdate, 'DD-MON-YYYY') as dat_rec, 
            to_char(sysdate, 'YYYYMMDD') as dat_rec2 
        from 
            dual
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0], row[1]

def fetch_libur_bond(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            count(*) as libur 
        from 
            vw_off_bi_days 
        where 
            to_char(off_day, 'DD-MON-YYYY')= to_char(sysdate, 'DD-MON-YYYY')
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0]