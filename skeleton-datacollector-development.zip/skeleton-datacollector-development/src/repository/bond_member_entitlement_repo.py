from datetime import datetime
from typing import List
from oracledb import Connection
from src.model.bond_member_entitlement.client_account import ClientAccount
from src.model.bond_member_entitlement.client_entitlement import ClientEntitlement
from src.model.bond_member_entitlement.corporate_action import CorporateAction
from src.model.bond_member_entitlement.total import Total
from src.model.bond_member_entitlement.total_client import TotalClient
from src.model.bond_member_entitlement.total_own import TotalOwn
from src.model.bond_member_entitlement.own_account import OwnAccount
from src.utils.utils import beautify_content, format_frac, format_tax
from src.config import config

def fetch_id_mem(p_since: str, cf_eff_date:str, conn:Connection) -> List[str]:
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT id_mem 
        FROM (
            SELECT DISTINCT rb.mem_id_mem_capco AS id_mem
            FROM record_balances@{config.DB_LINK_TOBAMR} rb
            JOIN corporate_actions@{config.DB_LINK_TOBAMR} ca ON rb.ca_id_ca_capco = ca.id_ca_capco
            JOIN assetclass@{config.DB_LINK_TOBAMR} ac ON ca.ident_assetclass = ac.ident_assetclass AND ac.ident_assetclasstype = 5
            WHERE ca.code_sta = 1
            AND rb.typ_flg_acct = 1
            AND rb.mem_id_mem_capco NOT IN ('AR001','CC001','YP001','KK001','NI001','PD001','HSBC1')
            AND (ca.dat_rec = :p_since OR ca.dat_pay = :cf_eff_date)
            ORDER BY 1
        )
        UNION ALL
        SELECT id_mem 
        FROM (
            SELECT DISTINCT rb.mem_id_mem_capco AS id_mem
            FROM record_balances@{config.DB_LINK_TOBAMR} rb
            JOIN corporate_actions@{config.DB_LINK_TOBAMR} ca ON rb.ca_id_ca_capco = ca.id_ca_capco
            JOIN assetclass@{config.DB_LINK_TOBAMR} ac ON ca.ident_assetclass = ac.ident_assetclass AND ac.ident_assetclasstype = 5
            WHERE ca.code_sta = 1
            AND rb.typ_flg_acct = 1
            AND rb.mem_id_mem_capco IN ('AR001','CC001','YP001','KK001','NI001','PD001','HSBC1')
            AND (ca.dat_rec = :p_since OR ca.dat_pay = :cf_eff_date)
            ORDER BY 1
        )
    """, {'p_since': p_since, 'cf_eff_date': cf_eff_date})

    rows = cursor.fetchall()
    cursor.close()

    return [row[0] for row in rows]

def fetch_corporate_actions(p_member: str, p_since: str, cf_eff_date: str, conn: Connection) -> List[CorporateAction]:
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            distinct ca.id_ca_capco ca_id, 
            ca.ins_id_ins_capco ca_instrument_id, 
            sec.name ca_secshortcode, 
            sec.longname ca_seclongname, 
            ca.dat_ann ca_announcement_date, 
            ca.dat_rec ca_record_date, 
            ca.dat_ex ca_ex_date, 
            ca.dat_pay ca_effective_date, 
            ca.dat_start_per ca_start_date, 
            ca.dat_inst_dead ca_deadline_date, 
            ca.typ_ca ca_type, 
            ca.flg_tax ca_flg_tax, 
            ca.dat_first_int_per ca_interest_start_date, 
            ca.dat_end_int_per ca_interest_end_date, 
            decode(
                ca.code_tax_pay_meth, 1, 'INSIDE THE SYSTEM', 
                2, 'OUTSIDE THE SYSTEM', ''
            ) ca_tax_in_out, 
            upper(ca.ca_type_ncsd_desc) ca_type_dsc, 
            rblnc.mem_id_mem_capco member, 
            rblnc.mem_dsc member_name, 
            rblnc.mem_id_mem_capco member_id 
        from 
            corporate_actions@{config.DB_LINK_TOBAMR} ca, 
            record_balances@{config.DB_LINK_TOBAMR} rblnc, 
            (
                select 
                    ident_instrument, 
                    ident_assetclass, 
                    name, 
                    longname, 
                    isin 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) sec, 
            assetclass@{config.DB_LINK_TOBAMR} ac 
        where 
            ca.code_sta = 1 
            and ac.ident_assetclasstype = 5 
            and ca.id_ca_capco = rblnc.ca_id_ca_capco 
            and ca.ins_id_ins_capco = sec.isin 
            and sec.ident_assetclass = ac.ident_assetclass 
            and rblnc.mem_id_mem_capco = :p_member
            -- and ca.id_ca_capco in ('KSEI202400038115') -- optional for filter by ca_id
            and (
                ca.dat_rec = :p_since 
                or ca.dat_pay = :cf_eff_date
            )
    """, {'p_member': p_member, 'p_since': p_since, 'cf_eff_date': cf_eff_date})

    rows = cursor.fetchall()
    cursor.close()

    return [
        CorporateAction(
            ca_id=beautify_content(row[0]),
            ca_instrument_id=beautify_content(row[1]),
            ca_secshortcode=beautify_content(row[2]),
            ca_seclongname=beautify_content(row[3]),
            ca_announcement_date=beautify_content(row[4], format_date='%d/%m/%Y'),
            ca_record_date=beautify_content(row[5], format_date='%d/%m/%Y'),
            ca_ex_date=beautify_content(row[6], format_date='%d/%m/%Y'),
            ca_effective_date=beautify_content(row[7], format_date='%d/%m/%Y'),
            ca_start_date=beautify_content(row[8], format_date='%d/%m/%Y'),
            ca_deadline_date=beautify_content(row[9], format_date='%d/%m/%Y'),
            ca_type=beautify_content(row[10]),
            ca_flg_tax=beautify_content(row[11]),
            ca_interest_start_date=beautify_content(row[12], format_date='%d/%m/%Y'),
            ca_interest_end_date=beautify_content(row[13], format_date='%d/%m/%Y'),
            ca_tax_in_out=beautify_content(row[14]),
            ca_type_dsc=beautify_content(row[15]),
            member=beautify_content(row[16]),
            member_name=beautify_content(row[17]),
            member_id=beautify_content(row[18])
        ) for row in rows
    ]

def fetch_own_accounts(p_member: str, list_ca_id: List[str], conn: Connection) -> List[OwnAccount]:
    placeholders = ', '.join(':' + str(i+1) for i in range(len(list_ca_id)))
    
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            substr(rblnc.acct_id_acct_capco, 6, length(rblnc.acct_id_acct_capco)-10) entitlement_clnt_id_own, 
            rblnc.acct_id_acct_capco account_id_own, 
            substr(rblnc.acct_id_acct_capco, 1, 5) || '-' || substr(rblnc.acct_id_acct_capco, 6, length(rblnc.acct_id_acct_capco)-10) || '-' || substr(rblnc.acct_id_acct_capco,-5, 3) || '-' || substr(rblnc.acct_id_acct_capco, length(rblnc.acct_id_acct_capco)-1, 2) account_id_disp_own, 
            rblnc.mem_id_mem_capco member_id_own, 
            rblnc.acct_code_ata ata_code_own, 
            rblnc.amt_blnc rblnc_blnc_amt_own, 
            rblnc.ins_id_ins_capco rblnc_ins_id_own, 
            rblnc.accountname account_desc_own, 
            rblnc.ca_id_ca_capco ca_id_own, 
            cae.ins_id_ins_capco entitlement_ins_id_own, 
            cae.amt_gross entitlement_amt_gross_own, 
            cae.amt_tax entitlement_amt_tax_own, 
            cae.amt_net entitlement_amt_net_own, 
            cae.acct_id_acct_capco entitlement_dep_acct_id_own, 
            cae.amt_frac_nom entitlement_frac_nom, 
            cae.amt_frac_denom entitlement_frac_denom, 
            substr(cae.acct_id_acct_capco, 1, 5) || '-' || substr(cae.acct_id_acct_capco, 6, length(cae.acct_id_acct_capco)-10) || '-' || substr(cae.acct_id_acct_capco,-5, 3) || '-' || substr(cae.acct_id_acct_capco, length(cae.acct_id_acct_capco)-1, 2) entitlement_dep_acct_own, 
            ins.ordercol entitlement_ordercol, 
            ins.sht_nm entitlement_ins_sht_nm, 
            ip.hold_days ip_holding_period_own, 
            ip.start_dat ip_start_date_own, 
            ip.end_dat ip_end_date_own, 
            ip.amt_blnc ip_holding_balance_own, 
            ip.amt_gross ip_proceed_amount_own, 
            ip.amt_tax ip_tax_amount_own, 
            ip.amt_net ip_net_amount_own, 
            ip.ca_id_ca_capco ip_ca_id, 
            ip.acct_id_acct_capco ip_acct_id, 
            (ip.applicable_rate * 100) tax_rate_own 
        from 
            record_balances@{config.DB_LINK_TOBAMR} rblnc, 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae, 
            (
                select 
                    code sht_nm, 
                    code id_ins_capco, 
                    1 ordercol 
                from 
                    currency@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null 
                union all 
                select 
                    name sht_nm, 
                    isin id_ins_capco, 
                    2 ordercol 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) ins, 
            interest_payments@{config.DB_LINK_TOBAMR} ip 
        where 
            substr(rblnc.acct_id_acct_capco, 6, 4) = '0000' 
            and cae.client_id(+) = '0000' 
            and rblnc.ca_id_ca_capco = cae.ca_id_ca_capco(+) 
            and rblnc.acct_id_acct_capco = cae.acct_id_acct_capco_src(+) 
            and cae.ins_id_ins_capco = ins.id_ins_capco(+) 
            and cae.acct_id_acct_capco_src = ip.acct_id_acct_capco(+) 
            and cae.ca_id_ca_capco = ip.ca_id_ca_capco(+) 
            and rblnc.mem_id_mem_capco = '{p_member}' -- where member_id_own = member_id in Q_CORPORATE_ACTIONS
            and nls_upper(rblnc.ca_id_ca_capco) in ({placeholders}) -- where ca_id_own = ca_id in Q_CORPORATE_ACTIONS
        order by 
            ins.ordercol, 
            ins.sht_nm, 
            ip.start_dat
    """, list_ca_id)

    rows = cursor.fetchall()
    cursor.close()

    return [
        OwnAccount(
            entitlement_clnt_id_own=beautify_content(row[0]),
            account_id_own=beautify_content(row[1]),
            account_id_disp_own=beautify_content(row[2]),
            member_id_own=beautify_content(row[3]),
            ata_code_own=beautify_content(row[4]),
            rblnc_blnc_amt_own=row[5],
            rblnc_ins_id_own=beautify_content(row[6]),
            account_desc_own=beautify_content(row[7]),
            ca_id_own=beautify_content(row[8]),
            entitlement_ins_id_own=beautify_content(row[9]),
            entitlement_amt_gross_own=beautify_content(row[10]),
            entitlement_amt_tax_own=beautify_content(row[11]),
            entitlement_amt_net_own=beautify_content(row[12]),
            entitlement_dep_acct_id_own=beautify_content(row[13]),
            entitlement_frac_nom=row[14],
            entitlement_frac_denom=row[15],
            entitlement_dep_acct_own=beautify_content(row[16]),
            entitlement_ordercol=beautify_content(row[17]),
            entitlement_ins_sht_nm=beautify_content(row[18]),
            ip_holding_period_own=str(row[19]) if row[19] is not None else "-",
            ip_start_date_own=beautify_content(row[20], format_date="%d %b %Y"),
            ip_end_date_own=beautify_content(row[21], format_date="%d %b %Y"),
            ip_holding_balance_own=beautify_content(row[22]),
            ip_proceed_amount_own=beautify_content(row[23]),
            ip_tax_amount_own=beautify_content(row[24]),
            ip_net_amount_own=beautify_content(row[25]),
            ip_ca_id=beautify_content(row[26]),
            ip_acct_id=beautify_content(row[27]),
            tax_rate_own=row[28]
        ) for row in rows
    ]

def fetch_client_accounts(p_member: str, list_ca_id: List[str], conn: Connection) -> List[ClientAccount]:
    placeholders = ', '.join(':' + str(i+1) for i in range(len(list_ca_id)))
    
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            substr(
                rblnc.acct_id_acct_capco, 
                6, 
                length(rblnc.acct_id_acct_capco)-10
            ) acct_substr, 
            substr(rblnc.acct_id_acct_capco, 1, 5)|| '-' || substr(
                rblnc.acct_id_acct_capco, 
                6, 
                length(rblnc.acct_id_acct_capco)-10
            ) || '-' || substr(rblnc.acct_id_acct_capco,-5, 3)|| '-' || substr(
                rblnc.acct_id_acct_capco, 
                length(rblnc.acct_id_acct_capco)-1, 
                2
            ) client_acct_id, 
            rblnc.acct_id_acct_capco client_full_acct_id, 
            rblnc.mem_id_mem_capco client_mem_id, 
            rblnc.acct_code_ata client_ata_code, 
            rblnc.amt_blnc client_blnc_amt, 
            rblnc.ins_id_ins_capco client_ins_id, 
            rblnc.accountname client_acct_desc, 
            rblnc.ca_id_ca_capco new_client_ca_id, 
            cae.applicable_rate client_tax_rate 
        from 
            record_balances@{config.DB_LINK_TOBAMR} rblnc, 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae 
        where 
            rblnc.amt_blnc != 0 
            and substr(rblnc.acct_id_acct_capco, 6, 4) != '0000' 
            and rblnc.ca_id_ca_capco = cae.ca_id_ca_capco(+) 
            and rblnc.acct_id_acct_capco = cae.acct_id_acct_capco_src(+) 
            and rblnc.mem_id_mem_capco = '{p_member}' -- where client_mem_id = member_id in Q_CORPORATE_ACTIONS
            and nls_upper(rblnc.ca_id_ca_capco) in ({placeholders}) -- where new_client_ca_id = ca_id in Q_CORPORATE_ACTIONS
        order by 
            rblnc.acct_id_acct_capco
    """, list_ca_id)

    rows = cursor.fetchall()
    cursor.close()

    return [
        ClientAccount(
            acct_substr=beautify_content(row[0]),
            client_acct_id=beautify_content(row[1]),
            client_full_acct_id=beautify_content(row[2]),
            client_mem_id=beautify_content(row[3]),
            client_ata_code=beautify_content(row[4]),
            client_blnc_amt=row[5],
            client_ins_id=beautify_content(row[6]),
            client_acct_desc=beautify_content(row[7]),
            new_client_ca_id=beautify_content(row[8]),
            client_tax_rate=row[9]
        ) for row in rows
    ]

def fetch_total_client(p_member: str, list_ca_id: List[str], conn: Connection) -> List[TotalClient]:
    placeholders = ', '.join(':' + str(i+1) for i in range(len(list_ca_id)))
    
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            sum(cae.amt_gross) amt_gross_client, 
            sum(cae.amt_tax) amt_tax_client, 
            sum(cae.amt_net) amt_net_client, 
            sum(cae.amt_frac_nom) frac_nom_client, 
            cae.amt_frac_denom frac_denom_client, 
            cae.ins_id_ins_capco client_ins_id_ins, 
            cae.ca_id_ca_capco total_ca_client_id, 
            ins.ordercol client_ordercol, 
            ins.sht_nm client_ins_sht_nm 
        from 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae, 
            (
                select 
                    code sht_nm, 
                    code id_ins_capco, 
                    1 ordercol 
                from 
                    currency@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null 
                union all 
                select 
                    name sht_nm, 
                    isin id_ins_capco, 
                    2 ordercol 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) ins 
        where 
            substr(cae.acct_id_acct_capco, 6, 4) != '0000' 
            and cae.ins_id_ins_capco = ins.id_ins_capco 
            and substr(cae.acct_id_acct_capco, 1, 5) = '{p_member}' -- parameter P_MEMBER
            and nls_upper(cae.ca_id_ca_capco) in ({placeholders}) -- where total_ca_client_id = ca_id in Q_CORPORATE_ACTION
        group by 
            ca_id_ca_capco, 
            ins_id_ins_capco, 
            cae.amt_frac_denom, 
            ins.ordercol, 
            ins.sht_nm 
        order by 
            ins.ordercol, 
            ins.sht_nm
    """, list_ca_id)

    rows = cursor.fetchall()
    cursor.close()

    return [
        TotalClient(
            amt_gross_client=beautify_content(row[0]),
            amt_tax_client=beautify_content(row[1]),
            amt_net_client=beautify_content(row[2]),
            frac_nom_client=row[3],
            frac_denom_client=row[4],
            client_ins_id_ins=beautify_content(row[5]),
            total_ca_client_id=beautify_content(row[6]),
            client_ordercol=beautify_content(row[7]),
            client_ins_sht_nm=beautify_content(row[8])
        ) for row in rows
    ]

def fetch_total_own(p_member: str, list_ca_id: List[str], conn: Connection) -> List[TotalOwn]:
    placeholders = ', '.join(':' + str(i+1) for i in range(len(list_ca_id)))
    
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            sum(cae.amt_gross) amt_gross_own, 
            sum(cae.amt_tax) amt_tax_own, 
            sum(cae.amt_net) amt_net_own, 
            sum(cae.amt_frac_nom) frac_nom_own, 
            cae.amt_frac_denom frac_denom_own, 
            cae.ins_id_ins_capco own_ins_id_ins, 
            cae.ca_id_ca_capco ca_id_total_own, 
            ins.ordercol ordercol_own, 
            ins.sht_nm ins_sht_nm_own 
        from 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae, 
            (
                select 
                    code sht_nm, 
                    code id_ins_capco, 
                    1 ordercol 
                from 
                    currency@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null 
                union all 
                select 
                    name sht_nm, 
                    isin id_ins_capco, 
                    2 ordercol 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) ins 
        where 
            substr(cae.acct_id_acct_capco, 6, 4) = '0000' 
            and cae.ins_id_ins_capco = ins.id_ins_capco 
            and substr(cae.acct_id_acct_capco, 1, 5) = '{p_member}' -- from parameter P_MEMBER
            and nls_upper(cae.ca_id_ca_capco) in ({placeholders}) -- where ca_id_total_own = ca_id in Q_CORPORATE_ACTION
        group by 
            ca_id_ca_capco, 
            ins_id_ins_capco, 
            cae.amt_frac_denom, 
            ins.ordercol, 
            ins.sht_nm 
        order by 
            ins.ordercol, 
            ins.sht_nm
    """, list_ca_id)

    rows = cursor.fetchall()
    cursor.close()

    return [
        TotalOwn(
            amt_gross_own=beautify_content(row[0]),
            amt_tax_own=beautify_content(row[1]),
            amt_net_own=beautify_content(row[2]),
            frac_nom_own=row[3],
            frac_denom_own=row[4],
            own_ins_id_ins=beautify_content(row[5]),
            ca_id_total_own=beautify_content(row[6]),
            ordercol_own=beautify_content(row[7]),
            ins_sht_nm_own=beautify_content(row[8])
        ) for row in rows
    ]

def fetch_client_entitlements(p_member: str, list_ca_id: List[str], list_client_acct_substr: List[str], list_client_full_acct_id: List[str], conn: Connection) -> List[ClientEntitlement]:
    placeholders_list_ca_id = ', '.join(':' + str(i+1) for i in range(len(list_ca_id)))
    # placeholders_list_client_acct_substr = ', '.join(':' + str(i+len(list_ca_id)+1) for i in range(len(list_client_acct_substr)))
    # placeholders_list_client_full_acct_id = ', '.join(':' + str(i+len(list_ca_id)+len(list_client_acct_substr)+1) for i in range(len(list_client_full_acct_id)))
    # filter_additional = """
    #         --and cae.client_id in ({placeholders_list_client_acct_substr}) -- where cae_client_id = acct_substr in Q_CLIENT_ACCT
    #         --and nls_upper(cae.acct_id_acct_capco_src) in ({placeholders_list_client_full_acct_id}) -- where source_acct = client_full_acct_id in Q_CLIENT_ACCT
    # """


    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            distinct rblnc.mem_id_mem_capco client_member_id, 
            rblnc.ca_id_ca_capco client_ca_id, 
            cae.client_id cae_client_id, 
            cae.amt_gross dep_amt_gross, 
            cae.amt_tax dep_amt_tax, 
            cae.amt_net dep_amt_net, 
            cae.ins_id_ins_capco dep_ins_id, 
            cae.amt_frac_nom dep_frac_nom, 
            cae.amt_frac_denom dep_frac_denom, 
            substr(cae.acct_id_acct_capco, 1, 5) || '-' || substr(
                cae.acct_id_acct_capco, 
                6, 
                length(cae.acct_id_acct_capco)-10
            ) || '-' || substr(cae.acct_id_acct_capco,-5, 3) || '-' || substr(
                cae.acct_id_acct_capco, 
                length(cae.acct_id_acct_capco)-1, 
                2
            ) dep_account_id_disp, 
            cae.acct_id_acct_capco dep_account_id, 
            cae.acct_id_acct_capco_src source_acct, 
            ins.ordercol dep_ordercol, 
            ins.sht_nm dep_ins_sht_nm, 
            ip.hold_days ip_holding_period_client, 
            ip.start_dat ip_start_date_client, 
            ip.end_dat ip_end_date_client, 
            ip.amt_blnc ip_holding_balance_client, 
            ip.amt_gross ip_proceed_amount_client, 
            ip.amt_tax ip_tax_amount_client, 
            ip.amt_net ip_net_amount_client, 
            ip.ca_id_ca_capco ip_ca_id_client, 
            ip.acct_id_acct_capco ip_acct_id_client 
        from 
            record_balances@{config.DB_LINK_TOBAMR} rblnc, 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae, 
            (
                select 
                code sht_nm, 
                code id_ins_capco, 
                1 ordercol 
                from 
                currency@{config.DB_LINK_TOBAMR} 
                where 
                ident_master is null 
                union all 
                select 
                name sht_nm, 
                isin id_ins_capco, 
                2 ordercol 
                from 
                instrument@{config.DB_LINK_TOBAMR} 
                where 
                ident_master is null
            ) ins, 
            interest_payments@{config.DB_LINK_TOBAMR} ip 
        where 
            rblnc.ca_id_ca_capco = cae.ca_id_ca_capco 
            and cae.client_id = substr(
                rblnc.acct_id_acct_capco, 
                6, 
                length(rblnc.acct_id_acct_capco)-10
            ) 
            and substr(rblnc.acct_id_acct_capco, 6, 4) != '0000' 
            and cae.ins_id_ins_capco = ins.id_ins_capco 
            and cae.acct_id_acct_capco_src = ip.acct_id_acct_capco(+) 
            and cae.ca_id_ca_capco = ip.ca_id_ca_capco(+) 
            and rblnc.mem_id_mem_capco = '{p_member}' -- where client_member_id = client_mem_id in Q_CLIENT_ACCT
            and nls_upper(rblnc.ca_id_ca_capco) in ({placeholders_list_ca_id}) -- where client_ca_id = new_client_ca_id in Q_CLIENT_ACCT
        order by 
            ins.ordercol, 
            ins.sht_nm, 
            ip.start_dat
    """, 
    # list_ca_id, list_client_acct_substr, list_client_full_acct_id)
    list_ca_id)

    rows = cursor.fetchall()
    cursor.close()

    return [
        ClientEntitlement(
            client_member_id=beautify_content(row[0]),
            client_ca_id=beautify_content(row[1]),
            cae_client_id=beautify_content(row[2]),
            dep_amt_gross=beautify_content(row[3]),
            dep_amt_tax=beautify_content(row[4]),
            dep_amt_net=beautify_content(row[5]),
            dep_ins_id=beautify_content(row[6]),
            dep_frac_nom=row[7],
            dep_frac_denom=row[8],
            dep_account_id_disp=beautify_content(row[9]),
            dep_account_id=beautify_content(row[10]),
            source_acct=beautify_content(row[11]),
            dep_ordercol=beautify_content(row[12]),
            dep_ins_sht_nm=beautify_content(row[13]),
            ip_holding_period_client=str(row[14]) if row[14] is not None else "-",
            ip_start_date_client=beautify_content(row[15], format_date="%d %b %Y"),
            ip_end_date_client=beautify_content(row[16], format_date="%d %b %Y"),
            ip_holding_balance_client=beautify_content(row[17]),
            ip_proceed_amount_client=beautify_content(row[18]),
            ip_tax_amount_client=beautify_content(row[19]),
            ip_net_amount_client=beautify_content(row[20]),
            ip_ca_id_client=beautify_content(row[21]),
            ip_acct_id_client=beautify_content(row[22])
        ) for row in rows
    ]

def fetch_total(p_member: str, list_ca_id: List[str], conn: Connection) -> List[Total]:
    placeholders = ', '.join(':' + str(i+1) for i in range(len(list_ca_id)))
    
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            sum(cae.amt_gross) amt_gross, 
            sum(cae.amt_tax) amt_tax, 
            sum(cae.amt_net) amt_net, 
            sum(cae.amt_frac_nom) frac_nom, 
            cae.amt_frac_denom frac_denom, 
            cae.ins_id_ins_capco, 
            cae.ca_id_ca_capco, 
            ins.ordercol total_ordercol, 
            ins.sht_nm total_sht_nm 
        from 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae, 
            (
                select 
                    code sht_nm, 
                    code id_ins_capco, 
                    1 ordercol 
                from 
                    currency@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null 
                union all 
                select 
                    name sht_nm, 
                    isin id_ins_capco, 
                    2 ordercol 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) ins 
        where 
            cae.ins_id_ins_capco = ins.id_ins_capco 
            and substr(cae.acct_id_acct_capco, 1, 5) = '{p_member}' -- from parameter P_MEMBER
            and nls_upper(cae.ca_id_ca_capco) in ({placeholders}) -- where ca_id_ca_capco = ca_id in Q_CORPORATE_ACTION
        group by 
            ca_id_ca_capco, 
            ins_id_ins_capco, 
            cae.amt_frac_denom, 
            ins.ordercol, 
            ins.sht_nm 
        order by 
            ins.ordercol, 
            ins.sht_nm
    """, list_ca_id)

    rows = cursor.fetchall()
    cursor.close()

    return [
        Total(
            amt_gross=beautify_content(row[0]),
            amt_tax=beautify_content(row[1]),
            amt_net=beautify_content(row[2]),
            frac_nom=row[3],
            frac_denom=row[4],
            ins_id_ins_capco=beautify_content(row[5]),
            ca_id_ca_capco=beautify_content(row[6]),
            total_ordercol=beautify_content(row[7]),
            total_sht_nm=beautify_content(row[8])
        ) for row in rows
    ]

# def map_to_json(id_mem, tgl, cf_eff_date, conn: Connection):
#     corporate_action_rows=fetch_corporate_actions(id_mem, tgl, cf_eff_date, conn)
#     list_ca_id = [ca.ca_id.upper() for ca in corporate_action_rows]

#     own_account_rows=fetch_own_accounts(id_mem, list_ca_id, conn)
#     client_account_rows=fetch_client_accounts(id_mem, list_ca_id, conn)
#     total_client_rows=fetch_total_client(id_mem, list_ca_id, conn)
#     total_own_rows=fetch_total_own(id_mem, list_ca_id, conn)

#     list_client_acct_substr: List[str] = []
#     list_client_full_acct_id: List[str] = []
#     for cla in client_account_rows:
#         list_client_acct_substr.append(cla.acct_substr)
#         list_client_full_acct_id.append(cla.client_full_acct_id.upper())

#     client_entitlement_rows=fetch_client_entitlements(id_mem, list_ca_id, list_client_acct_substr, list_client_full_acct_id, conn)
#     total_rows=fetch_total(id_mem, list_ca_id, conn)
    
#     corporate_action = corporate_action_rows[0]
#     total_client = total_client_rows[0]
#     total_own = total_own_rows[0]
#     total = total_rows[0]

#     own_account_data = [
#         {
#             "OWN_ACCOUNT": beautify_content_string(row.account_id_disp_own),
#             "OWN_ACCOUNT_DESC": beautify_content_string(row.account_desc_own),
#             "RECORD_BALANCE_OWN": beautify_content_string(row.rblnc_blnc_amt_own),
#             "TAX_PCT": beautify_content_string(row.tax_rate_own),
#             "ENTITLEMENT_DEP_ACCT_OWN": beautify_content_string(row.entitlement_dep_acct_own),
#             "CF_INSTRUMENT_SHORT_OWN": beautify_content_string(row.entitlement_ins_sht_nm),
#             "ENTITLEMENT_AMT_GROSS_OWN": beautify_content_string(row.entitlement_amt_gross_own),
#             "ENTITLEMENT_AMT_NET_OWN": beautify_content_string(row.entitlement_amt_net_own),
#             "ENTITLEMENT_AMT_TAX": beautify_content_string(row.entitlement_amt_tax_own),
#             "CF_ENTITLEMENT_FRAC": format_frac(row.entitlement_frac_nom, row.entitlement_frac_denom),
#             "HOLDING_PERIOD_OWN1": beautify_content_string(row.ip_holding_period_own),
#             "START_HOLDING_PERIOD_OWN1": beautify_content_string(row.ip_start_date_own, format_date='%d %b %Y'),
#             "END_HOLDING_PERIOD_OWN1": beautify_content_string(row.ip_end_date_own, format_date='%d %b %Y'),
#             "HOLDING_BALANCE_OWN1": beautify_content_string(row.ip_holding_balance_own),
#             "NET_AMOUNT_OWN1": beautify_content_string(row.ip_net_amount_own),
#             "PROCEED_AMOUNT_OWN1": beautify_content_string(row.ip_proceed_amount_own),
#             "TAX_AMOUNT_OWN1": beautify_content_string(row.ip_tax_amount_own),
#         } for row in own_account_rows
#     ]

#     client_account_data = [
#         {
#             "CLIENT_ACCOUNT": beautify_content_string(row.client_acct_id),
#             "CLIENT_ACCOUNT_DESC": beautify_content_string(row.client_acct_desc),
#             "CLIENT_RECORD_BALANCE": beautify_content_string(row.client_blnc_amt),
#             "CLIENT_TAX_PCT": beautify_content_string(row.client_tax_rate),
#             "CLIENT_DEPOSIT_ACCOUNT": beautify_content_string(''),
#             "DEP_INSTRUMENT": beautify_content_string(''),
#             "DEP_AMT_GROSS": beautify_content_string(''),
#             "DEP_FRAC": beautify_content_string(''),
#             "DEP_AMT_TAX": beautify_content_string(''),
#             "NET_PROCEED_AMT_CLIENT": beautify_content_string(''),
#             "HOLDING_PERIOD_CLIENT": beautify_content_string(''),
#             "START_HOLDING_PERIOD_CLIENT": beautify_content_string(''),
#             "END_HOLDING_PERIOD_CLIENT": beautify_content_string(''),
#             "HOLDING_BALANCE_CLIENT": beautify_content_string(''),
#             "PROCEED_AMOUNT_CLIENT": beautify_content_string(''),
#             "TAX_AMOUNT_CLIENT": beautify_content_string(''),
#             "NET_AMOUNT_CLIENT": beautify_content_string(''),
#         } for row in client_account_rows
#     ]

#     for client_acc in client_account_rows:
#         for client_entitlement in client_entitlement_rows:
#             if client_acc["client_mem_id"] == client_entitlement["client_member_id"] and client_acc["new_client_ca_id"] == client_entitlement["client_ca_id"]:
#                 client_acc["CLIENT_DEPOSIT_ACCOUNT"] = beautify_content_string(client_entitlement["dep_account_id_disp"])
#                 client_acc["DEP_INSTRUMENT"] = beautify_content_string(client_entitlement["dep_ins_sht_nm"])
#                 client_acc["DEP_AMT_GROSS"] = beautify_content_string(client_entitlement["dep_amt_gross"])
#                 client_acc["DEP_FRAC"] = format_frac(client_entitlement["dep_frac_nom"], client_entitlement["dep_frac_denom"])
#                 client_acc["DEP_AMT_TAX"] = beautify_content_string(client_entitlement["dep_amt_tax"])
#                 client_acc["NET_PROCEED_AMT_CLIENT"] = beautify_content_string(client_entitlement["dep_amt_net"])
#                 client_acc["HOLDING_PERIOD_CLIENT"] = beautify_content_string(client_entitlement["ip_end_date_client"])
#                 client_acc["START_HOLDING_PERIOD_CLIENT"] = beautify_content_string(client_entitlement["ip_start_date_client"], format_date='%d %b %Y')
#                 client_acc["END_HOLDING_PERIOD_CLIENT"] = beautify_content_string(client_entitlement["ip_end_date_client"], format_date='%d %b %Y')
#                 client_acc["HOLDING_BALANCE_CLIENT"] = beautify_content_string(client_entitlement["ip_holding_balance_client"])
#                 client_acc["PROCEED_AMOUNT_CLIENT"] = beautify_content_string(client_entitlement["ip_proceed_amount_client"])
#                 client_acc["TAX_AMOUNT_CLIENT"] = beautify_content_string(client_entitlement["ip_tax_amount_client"])
#                 client_acc["NET_AMOUNT_CLIENT"] = beautify_content_string(client_entitlement["ip_net_amount_client"])

#     # Create JSON structure
#     sum_own_acc = sum(oc.rblnc_blnc_amt_own for oc in own_account_rows)
#     sum_client_acc = sum(ca.client_blnc_amt for ca in client_account_rows)
    
#     json_data = {
#         "SYNC_DATE": datetime.datetime.now().strftime("%d-%b-%y").upper(),
#         "CA_ANNOUNCEMENT_DATE": corporate_action.ca_announcement_date,
#         "CA_DEADLINE_DATE": corporate_action.ca_deadline_date,
#         "CA_EFFECTIVE_DATE": corporate_action.ca_effective_date,
#         "CA_EX_DATE": corporate_action.ca_ex_date,
#         "CA_INT_END_DATE": corporate_action.ca_interest_end_date,
#         "CA_INT_START_DATE": corporate_action.ca_interest_start_date,
#         "CA_RECORD_DATE": corporate_action.ca_record_date,
#         "CA_START_DATE": corporate_action.ca_start_date,
#         "CA_TAX_IN_OUT": " " if corporate_action.ca_flg_tax == 0 or corporate_action.ca_flg_tax is None else corporate_action.ca_tax_in_out,
#         "CORPORATE_ACTION": corporate_action.ca_type_dsc,
#         "SECURITY": corporate_action.ca_seclongname,
#         "SECURITY_SHORT": corporate_action.ca_secshortcode,
#         "TOTAL_RBLNC": f"{sum_own_acc + sum_client_acc}",
#         "AMT_GROSS": total.amt_gross,
#         "AMT_NET": total.amt_net,
#         "AMT_TAX": total.amt_tax,
#         "FRAC": format_frac(total.frac_nom, total.frac_denom),
#         "INSTRUMENT": corporate_action.ca_instrument_id,
#         "SUM_RBLNC_AMT_OWN": f"{sum_own_acc}",
#         "AMT_GROSS_OWN": total_own.amt_gross_own,
#         "AMT_NET_OWN": total_own.amt_net_own,
#         "AMT_TAX_OWN": total_own.amt_tax_own,
#         "FRAC_OWN": format_frac(total_own.frac_nom_own, total_own.frac_denom_own),
#         "OWN_SEC_SHORT": total_own.ins_sht_nm_own,
#         "SUM_CLIENT_RECORD_BALANCE": f"{sum_client_acc}",
#         "AMT_GROSS_CLIENT": total_client.amt_gross_client,
#         "AMT_NET_CLIENT": total_client.amt_net_client,
#         "AMT_TAX_CLIENT": total_client.amt_tax_client,
#         "FRAC_CLIENT": format_frac(total_client.frac_nom_client, total_client.frac_denom_client),
#         "CLIENT_SEC_SHORT": total_client.client_ins_sht_nm,
#         "DATE": datetime.datetime.now().strftime("%d-%b-%y %I:%M %p").upper(),
#         "MEMBER": f"{id_mem} {corporate_action.member_name}",
#         "P_SINCE": f"{tgl}",
#         "OWN_ACCOUNTS": own_account_data,
#         "CLIENT_ACCOUNTS": client_account_data,
#     }

#     return json_data


def map_to_json2(id_mem, tgl, cf_eff_date, conn: Connection):
    corporate_action_rows=fetch_corporate_actions(id_mem, tgl, cf_eff_date, conn)
    list_ca_id = [ca.ca_id.upper() for ca in corporate_action_rows]
    print(list_ca_id)

    own_account_rows=fetch_own_accounts(id_mem, list_ca_id, conn)
    client_account_rows=fetch_client_accounts(id_mem, list_ca_id, conn)
    total_client_rows=fetch_total_client(id_mem, list_ca_id, conn)
    total_own_rows=fetch_total_own(id_mem, list_ca_id, conn)

    list_client_acct_substr: List[str] = []
    list_client_full_acct_id: List[str] = []
    # for cla in client_account_rows:
    #     list_client_acct_substr.append(cla.acct_substr)
    #     list_client_full_acct_id.append(cla.client_full_acct_id.upper())

    client_entitlement_rows=fetch_client_entitlements(id_mem, list_ca_id, list_client_acct_substr, list_client_full_acct_id, conn)
    total_rows=fetch_total(id_mem, list_ca_id, conn)

    own_account_data = [
        {
            "OWN_ACCOUNT": beautify_content(row.account_id_disp_own),
            "OWN_ACCOUNT_DESC": beautify_content(row.account_desc_own),
            "RECORD_BALANCE_OWN": beautify_content(row.rblnc_blnc_amt_own),
            "TAX_PCT": format_tax(row.tax_rate_own),
            "ENTITLEMENT_DEP_ACCT_OWN": beautify_content(row.entitlement_dep_acct_own),
            "CF_INSTRUMENT_SHORT_OWN": beautify_content(row.entitlement_ins_sht_nm),
            "ENTITLEMENT_AMT_GROSS_OWN": beautify_content(row.entitlement_amt_gross_own),
            "ENTITLEMENT_AMT_NET_OWN": beautify_content(row.entitlement_amt_net_own),
            "ENTITLEMENT_AMT_TAX": beautify_content(row.entitlement_amt_tax_own),
            "CF_ENTITLEMENT_FRAC": format_frac(row.entitlement_frac_nom, row.entitlement_frac_denom),
            "HOLDING_PERIOD_OWN1": beautify_content(row.ip_holding_period_own),
            "START_HOLDING_PERIOD_OWN1": beautify_content(row.ip_start_date_own),
            "END_HOLDING_PERIOD_OWN1": beautify_content(row.ip_end_date_own),
            "HOLDING_BALANCE_OWN1": beautify_content(row.ip_holding_balance_own),
            "NET_AMOUNT_OWN1": beautify_content(row.ip_net_amount_own),
            "PROCEED_AMOUNT_OWN1": beautify_content(row.ip_proceed_amount_own),
            "TAX_AMOUNT_OWN1": beautify_content(row.ip_tax_amount_own),
            "MEMBER_ID_OWN": row.member_id_own,
            "CA_ID_OWN": row.ca_id_own
        } for row in own_account_rows
    ]

    client_account_data = [
        {
            "CLIENT_ACCOUNT": beautify_content(row.client_acct_id),
            "CLIENT_ACCOUNT_DESC": beautify_content(row.client_acct_desc),
            "CLIENT_RECORD_BALANCE": beautify_content(row.client_blnc_amt),
            "CLIENT_TAX_PCT": format_tax(row.client_tax_rate),
            "CLIENT_DEPOSIT_ACCOUNT": beautify_content(''),
            "DEP_INSTRUMENT": beautify_content(''),
            "DEP_AMT_GROSS": beautify_content(''),
            "DEP_FRAC": beautify_content(''),
            "DEP_AMT_TAX": beautify_content(''),
            "NET_PROCEED_AMT_CLIENT": beautify_content(''),
            "HOLDING_PERIOD_CLIENT": beautify_content(''),
            "START_HOLDING_PERIOD_CLIENT": beautify_content(''),
            "END_HOLDING_PERIOD_CLIENT": beautify_content(''),
            "HOLDING_BALANCE_CLIENT": beautify_content(''),
            "PROCEED_AMOUNT_CLIENT": beautify_content(''),
            "TAX_AMOUNT_CLIENT": beautify_content(''),
            "NET_AMOUNT_CLIENT": beautify_content(''),
            "CLIENT_MEM_ID": row.client_mem_id,
            "NEW_CLIENT_CA_ID": row.new_client_ca_id,
            "CLIENT_FULL_ACCT_ID": beautify_content(row.client_full_acct_id)
        } for row in client_account_rows
    ]

    for client_acc in client_account_data:
        for client_entitlement in client_entitlement_rows:
            if client_acc["CLIENT_MEM_ID"] == client_entitlement.client_member_id and client_acc["NEW_CLIENT_CA_ID"] == client_entitlement.client_ca_id and client_acc["CLIENT_FULL_ACCT_ID"] == client_entitlement.source_acct:
                client_acc["CLIENT_DEPOSIT_ACCOUNT"] = beautify_content(client_entitlement.dep_account_id_disp)
                client_acc["DEP_INSTRUMENT"] = beautify_content(client_entitlement.dep_ins_sht_nm)
                client_acc["DEP_AMT_GROSS"] = beautify_content(client_entitlement.dep_amt_gross)
                client_acc["DEP_FRAC"] = format_frac(client_entitlement.dep_frac_nom, client_entitlement.dep_frac_denom)
                client_acc["DEP_AMT_TAX"] = beautify_content(client_entitlement.dep_amt_tax)
                client_acc["NET_PROCEED_AMT_CLIENT"] = beautify_content(client_entitlement.dep_amt_net)
                client_acc["HOLDING_PERIOD_CLIENT"] = beautify_content(client_entitlement.ip_holding_period_client)
                client_acc["START_HOLDING_PERIOD_CLIENT"] = beautify_content(client_entitlement.ip_start_date_client)
                client_acc["END_HOLDING_PERIOD_CLIENT"] = beautify_content(client_entitlement.ip_end_date_client)
                client_acc["HOLDING_BALANCE_CLIENT"] = beautify_content(client_entitlement.ip_holding_balance_client)
                client_acc["PROCEED_AMOUNT_CLIENT"] = beautify_content(client_entitlement.ip_proceed_amount_client)
                client_acc["TAX_AMOUNT_CLIENT"] = beautify_content(client_entitlement.ip_tax_amount_client)
                client_acc["NET_AMOUNT_CLIENT"] = beautify_content(client_entitlement.ip_net_amount_client)
                break

    # Create JSON structure
    sub_data = []

    for corporate_action in corporate_action_rows:
        sum_own_acc = sum(oc.rblnc_blnc_amt_own for oc in own_account_rows if oc.ca_id_own == corporate_action.ca_id)
        sum_client_acc = sum(ca.client_blnc_amt for ca in client_account_rows if ca.new_client_ca_id == corporate_action.ca_id)
        total_sum_global = sum_own_acc + sum_client_acc

        total_per_ca_id = None
        total_own_per_ca_id = None
        total_client_per_ca_id = None

        for total in total_rows:
            if total.ca_id_ca_capco == corporate_action.ca_id:
                total_per_ca_id = total
                break
        for total_own in total_own_rows:
            if total_own.ca_id_total_own == corporate_action.ca_id:
                total_own_per_ca_id = total_own
                break
        for total_client in total_client_rows:
            if total_client.total_ca_client_id == corporate_action.ca_id:
                total_client_per_ca_id = total_client
                break

        oad_per_ca_id = [oad for oad in own_account_data if oad["CA_ID_OWN"] == corporate_action.ca_id]
        cad_per_ca_id = [cad for cad in client_account_data if cad["NEW_CLIENT_CA_ID"] == corporate_action.ca_id]

        if len(oad_per_ca_id) == 0:
            oad_per_ca_id = [
                {
                    "OWN_ACCOUNT": "-",
                    "OWN_ACCOUNT_DESC": "-",
                    "RECORD_BALANCE_OWN": "-",
                    "TAX_PCT": "-",
                    "ENTITLEMENT_DEP_ACCT_OWN": "-",
                    "CF_INSTRUMENT_SHORT_OWN": "-",
                    "ENTITLEMENT_AMT_GROSS_OWN": "-",
                    "ENTITLEMENT_AMT_NET_OWN": "-",
                    "ENTITLEMENT_AMT_TAX": "-",
                    "CF_ENTITLEMENT_FRAC": "-",
                    "HOLDING_PERIOD_OWN1": "-",
                    "START_HOLDING_PERIOD_OWN1": "-",
                    "END_HOLDING_PERIOD_OWN1": "-",
                    "HOLDING_BALANCE_OWN1": "-",
                    "NET_AMOUNT_OWN1": "-",
                    "PROCEED_AMOUNT_OWN1": "-",
                    "TAX_AMOUNT_OWN1": "-",
                }
            ]

        if len(cad_per_ca_id) == 0:
            cad_per_ca_id = [
                {
                    "CLIENT_ACCOUNT": "-",
                    "CLIENT_ACCOUNT_DESC": "-",
                    "CLIENT_RECORD_BALANCE": "-",
                    "CLIENT_TAX_PCT": "-",
                    "CLIENT_DEPOSIT_ACCOUNT": "-",
                    "DEP_INSTRUMENT": "-",
                    "DEP_AMT_GROSS": "-",
                    "DEP_FRAC": "-",
                    "DEP_AMT_TAX": "-",
                    "NET_PROCEED_AMT_CLIENT": "-",
                    "HOLDING_PERIOD_CLIENT": "-",
                    "START_HOLDING_PERIOD_CLIENT": "-",
                    "END_HOLDING_PERIOD_CLIENT": "-",
                    "HOLDING_BALANCE_CLIENT": "-",
                    "PROCEED_AMOUNT_CLIENT": "-",
                    "TAX_AMOUNT_CLIENT": "-",
                    "NET_AMOUNT_CLIENT": "-",
                }
            ]
        
        sub_data.append(
            {
                "CORPORATE_ACTION": corporate_action.ca_type_dsc,
                "CA_ANNOUNCEMENT_DATE": corporate_action.ca_announcement_date,
                "CA_DEADLINE_DATE": corporate_action.ca_deadline_date,
                "CA_EFFECTIVE_DATE": corporate_action.ca_effective_date,
                "CA_EX_DATE": corporate_action.ca_ex_date,
                "CA_INT_END_DATE": corporate_action.ca_interest_end_date,
                "CA_INT_START_DATE": corporate_action.ca_interest_start_date,
                "CA_RECORD_DATE": corporate_action.ca_record_date,
                "CA_START_DATE": corporate_action.ca_start_date,
                "CA_TAX_IN_OUT": " " if corporate_action.ca_flg_tax == 0 or corporate_action.ca_flg_tax is None else corporate_action.ca_tax_in_out,
                "SECURITY": corporate_action.ca_seclongname,
                "SECURITY_SHORT": corporate_action.ca_secshortcode,
                "TOTAL_RBLNC": beautify_content(total_sum_global),
                "AMT_GROSS": beautify_content(total_per_ca_id.amt_gross if total_per_ca_id is not None else None),
                "AMT_NET": beautify_content(total_per_ca_id.amt_net if total_per_ca_id is not None else None),
                "AMT_TAX": beautify_content(total_per_ca_id.amt_tax if total_per_ca_id is not None else None),
                "FRAC": format_frac(total_per_ca_id.frac_nom if total_per_ca_id is not None else None, total_per_ca_id.frac_denom if total_per_ca_id is not None else None),
                "INSTRUMENT": beautify_content(total_per_ca_id.total_sht_nm if total_per_ca_id is not None else None),
                "SUM_RBLNC_AMT_OWN": sum_own_acc if sum_own_acc != 0 else "-",
                "AMT_GROSS_OWN": beautify_content(total_own_per_ca_id.amt_gross_own if total_own_per_ca_id is not None else None),
                "AMT_NET_OWN": beautify_content(total_own_per_ca_id.amt_net_own if total_own_per_ca_id is not None else None),
                "AMT_TAX_OWN": beautify_content(total_own_per_ca_id.amt_tax_own if total_own_per_ca_id is not None else None),
                "FRAC_OWN": format_frac(total_own_per_ca_id.frac_nom_own if total_own_per_ca_id is not None else None, total_own_per_ca_id.frac_denom_own if total_own_per_ca_id is not None else None),
                "OWN_SEC_SHORT": beautify_content(total_own_per_ca_id.ins_sht_nm_own if total_own_per_ca_id is not None else None),
                "SUM_CLIENT_RECORD_BALANCE": beautify_content(sum_client_acc),
                "AMT_GROSS_CLIENT": beautify_content(total_client_per_ca_id.amt_gross_client if total_client_per_ca_id is not None else None),
                "AMT_NET_CLIENT": beautify_content(total_client_per_ca_id.amt_net_client if total_client_per_ca_id is not None else None),
                "AMT_TAX_CLIENT": beautify_content(total_client_per_ca_id.amt_tax_client if total_client_per_ca_id is not None else None),
                "FRAC_CLIENT": format_frac(total_client_per_ca_id.frac_nom_client if total_client_per_ca_id is not None else None, total_client_per_ca_id.frac_denom_client if total_client_per_ca_id is not None else None),
                "CLIENT_SEC_SHORT": beautify_content(total_client_per_ca_id.client_ins_sht_nm if total_client_per_ca_id is not None else None),
                "OWN_ACCOUNT_DATA": oad_per_ca_id,
                "CLIENT_ACCOUNT_DATA": cad_per_ca_id,
            }
        )

    if len(own_account_data) == 0:
        own_account_data = [
            {
                "OWN_ACCOUNT": "-",
                "OWN_ACCOUNT_DESC": "-",
                "RECORD_BALANCE_OWN": "-",
                "TAX_PCT": "-",
                "ENTITLEMENT_DEP_ACCT_OWN": "-",
                "CF_INSTRUMENT_SHORT_OWN": "-",
                "ENTITLEMENT_AMT_GROSS_OWN": "-",
                "ENTITLEMENT_AMT_NET_OWN": "-",
                "ENTITLEMENT_AMT_TAX": "-",
                "CF_ENTITLEMENT_FRAC": "-",
                "HOLDING_PERIOD_OWN1": "-",
                "START_HOLDING_PERIOD_OWN1": "-",
                "END_HOLDING_PERIOD_OWN1": "-",
                "HOLDING_BALANCE_OWN1": "-",
                "NET_AMOUNT_OWN1": "-",
                "PROCEED_AMOUNT_OWN1": "-",
                "TAX_AMOUNT_OWN1": "-",
            }
        ]

    if len(client_account_data) == 0:
        client_account_data = [
            {
                "CLIENT_ACCOUNT": "-",
                "CLIENT_ACCOUNT_DESC": "-",
                "CLIENT_RECORD_BALANCE": "-",
                "CLIENT_TAX_PCT": "-",
                "CLIENT_DEPOSIT_ACCOUNT": "-",
                "DEP_INSTRUMENT": "-",
                "DEP_AMT_GROSS": "-",
                "DEP_FRAC": "-",
                "DEP_AMT_TAX": "-",
                "NET_PROCEED_AMT_CLIENT": "-",
                "HOLDING_PERIOD_CLIENT": "-",
                "START_HOLDING_PERIOD_CLIENT": "-",
                "END_HOLDING_PERIOD_CLIENT": "-",
                "HOLDING_BALANCE_CLIENT": "-",
                "PROCEED_AMOUNT_CLIENT": "-",
                "TAX_AMOUNT_CLIENT": "-",
                "NET_AMOUNT_CLIENT": "-",
                }
        ]
    
    if len(sub_data) == 0:
        sub_data = [
            {
                "CA_ANNOUNCEMENT_DATE": "-",
                "CA_DEADLINE_DATE": "-",
                "CA_EFFECTIVE_DATE": "-",
                "CA_EX_DATE": "-",
                "CA_INT_END_DATE": "-",
                "CA_INT_START_DATE": "-",
                "CA_RECORD_DATE": "-",
                "CA_START_DATE": "-",
                "CA_TAX_IN_OUT": "-",
                "CORPORATE_ACTION": "-",
                "SECURITY": "-",
                "SECURITY_SHORT": "-",
                "TOTAL_RBLNC": "-",
                "AMT_GROSS": "-",
                "AMT_NET": "-",
                "AMT_TAX": "-",
                "FRAC": "-",
                "INSTRUMENT": "-",
                "SUM_RBLNC_AMT_OWN": "-",
                "AMT_GROSS_OWN": "-",
                "AMT_NET_OWN": "-",
                "AMT_TAX_OWN": "-",
                "FRAC_OWN": "-",
                "OWN_SEC_SHORT": "-",
                "SUM_CLIENT_RECORD_BALANCE": "-",
                "AMT_GROSS_CLIENT": "-",
                "AMT_NET_CLIENT": "-",
                "AMT_TAX_CLIENT": "-",
                "FRAC_CLIENT": "-",
                "CLIENT_SEC_SHORT": "-",
                "OWN_ACCOUNT_DATA": own_account_data,
                "CLIENT_ACCOUNT_DATA": client_account_data,
            }
        ]

    json_data = {
        "MEMBER": f"{id_mem} {corporate_action.member_name}",
        "P_SINCE": datetime.strptime(tgl, "%d-%b-%Y").strftime("%d %B %Y"),
        "DATE": datetime.now().strftime("%d-%b-%y %I:%M %p").upper(),
        "ID_MEM": id_mem,
        "P_SINCE_FN": datetime.strptime(tgl, "%d-%b-%Y").strftime("%Y%m%d"),
        "SUB_DATA": sub_data,
    }

    return json_data
