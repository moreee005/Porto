from src.model.mongo.log import insert

def insert_data_log(data):
    insert(data)