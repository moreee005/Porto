from src.model.mongo.bond_member_entitlement import get_datas_bmer, insert_datas_bond_member_entitlement

def fetch_data_bmer(query):
    return get_datas_bmer(query)

def bulk_insert_bmer(datas):
    insert_datas_bond_member_entitlement(datas)