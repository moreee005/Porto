from src.model.mongo.bond_issuer_overview import get_datas_bio, insert_datas_bond_issuer_overview

def fetch_data_bio(query):
    return get_datas_bio(query)

def bulk_insert_bio(datas):
    insert_datas_bond_issuer_overview(datas)