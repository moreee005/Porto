import datetime
import decimal


def beautify_content(data, format_date="%d %B %Y", empty_content="STRIPE"):
    if isinstance(data, (datetime.datetime, datetime.date)):
        return data.strftime(format_date)
    elif isinstance(data, float) or isinstance(data, decimal.Decimal) or isinstance(data, int):
        return '{:,.2f}'.format(data) if data is not None else "-"
    else:
        if empty_content == "EMPTY":
            return data if data is not None else ''
        return data if data is not None else '-'    
    
def format_frac(frac_nom, frac_denom):
    return "-" if (frac_nom is None or frac_nom == 0 or frac_nom == decimal.Decimal(0)) and (frac_denom is None or frac_denom == 0 or frac_denom == decimal.Decimal(0)) else f"{frac_nom}/{frac_denom}"

def format_tax(tax):
    return f"{tax} %" if tax is not None and tax != "-" else "-"
