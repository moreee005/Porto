import unittest
from unittest.mock import patch, MagicMock
from src.services.bond_member_entitlement_service import bond_member_entitlement_sync


class TestBondMemberEntitlementSync(unittest.TestCase):

    @patch('src.model.mongo.log.mongo.db.get_collection')
    @patch('src.services.bond_member_entitlement_service.get_connection_db')
    @patch('src.services.bond_member_entitlement_service.fetch_libur_bond')
    @patch('src.services.bond_member_entitlement_service.fetch_tgl_bond')
    @patch('src.services.bond_member_entitlement_service.fetch_cf_eff_date')
    @patch('src.services.bond_member_entitlement_service.fetch_id_mem')
    @patch('src.services.bond_member_entitlement_service.map_to_json2')
    @patch('src.services.bond_member_entitlement_service.bulk_insert_bmer')
    @patch('src.services.bond_member_entitlement_service.log')
    def test_bond_member_entitlement_sync(self, mock_log, mock_bulk_insert_bmer, mock_map_to_json2, mock_fetch_id_mem, mock_fetch_cf_eff_date, mock_fetch_tgl_bond, mock_fetch_libur_bond, mock_get_connection_db, mock_get_collection):

        # Mock the connection and function return values
        mock_get_connection_db.return_value = MagicMock()
        mock_fetch_libur_bond.return_value = 0
        mock_fetch_tgl_bond.return_value = ('19-AUG-24', '20240819')
        mock_fetch_cf_eff_date.return_value = '2024-01-02'
        mock_fetch_id_mem.return_value = ['HSBC1']
        mock_map_to_json2.side_effect = lambda id_mem, tgl, cf_eff_date, conn: {'id': id_mem, 'date': tgl}

        # Mock MongoDB insert operation
        mock_collection = MagicMock()
        mock_get_collection.return_value = mock_collection

        bond_member_entitlement_sync()

        # Assert bulk insert was called with the correct data
        mock_bulk_insert_bmer.assert_called_once_with([
            {'id': 'HSBC1', 'date': '19-AUG-24'}
        ])

        # Ensure the connection was closed
        mock_get_connection_db.return_value.close.assert_called_once()

        # Ensure the insert operation to MongoDB was called correctly
        mock_collection.insert_one.assert_called_once_with({
            "operation": "Sync Data Bond Member Entitlement From Oracle",
            "total_data": 1, 
            "status": "Success",
            "duration": unittest.mock.ANY, 
            "exception": '-'
        })

if __name__ == '__main__':
    unittest.main()
