import unittest
from unittest.mock import patch
from src.services.bond_member_entitlement_service import bond_member_entitlement_datas

class TestBondMemberEntitlementDatas(unittest.TestCase):
    
    @patch('src.services.bond_member_entitlement_service.fetch_data_bmer')
    def test_bond_member_entitlement_datas(self, mock_fetch_data_bmer):
        mock_fetch_data_bmer.return_value = [
            {
                '_id': 1,
                "AMT_GROSS": "10000",
                "AMT_GROSS_CLIENT": "14000",
                "AMT_GROSS_OWN": "7000",
                "AMT_NET": "8000",
                "AMT_NET_CLIENT": "11200",
                "AMT_NET_OWN": "5600",
                "AMT_TAX": "2000",
                "AMT_TAX_CLIENT": "2800",
                "AMT_TAX_OWN": "1400",
                "CA_ANNOUNCEMENT_DATE": "13/06/2024",
                "CA_DEADLINE_DATE": "13/03/2024",
                "CA_EFFECTIVE_DATE": "13/03/2024",
                "CA_EX_DATE": "13/03/2024",
                "CA_INT_END_DATE": "13/03/2024",
                "CA_INT_START_DATE": "13/03/2024",
                "CA_RECORD_DATE": "13/03/2024",
                "CA_START_DATE": "13/03/2024",
                "CA_TAX_IN_OUT": "In",
                "CLIENT_ACCOUNT_DATA": [
                    {
                        "CLIENT_ACCOUNT": "67890",
                        "CLIENT_ACCOUNT_DESC": "Client Account",
                        "CLIENT_DEPOSIT_ACCOUNT": "Dep456",
                        "CLIENT_RECORD_BALANCE": "2000.0",
                        "CLIENT_TAX_PCT": "15%",
                        "DEP_AMT_GROSS": "2200.0",
                        "DEP_AMT_TAX": "330.0",
                        "DEP_FRAC": "0.2",
                        "DEP_INSTRUMENT": "Instr456",
                        "END_HOLDING_PERIOD_CLIENT": "15 JUN 2024",
                        "HOLDING_BALANCE_CLIENT": "2000.0",
                        "HOLDING_PERIOD_CLIENT": 60,
                        "NET_AMOUNT_CLIENT": "1600.0",
                        "NET_PROCEED_AMT_CLIENT": "1870.0",
                        "PROCEED_AMOUNT_CLIENT": "1900.0",
                        "START_HOLDING_PERIOD_CLIENT": "15 JUN 2024",
                        "TAX_AMOUNT_CLIENT": "300.0"
                    }
                ],
                "CLIENT_SEC_SHORT": "CLIXYZ",
                "CORPORATE_ACTION": "Dividend Distribution",
                "DATE": "13-JUL-24 01:01 PM",
                "FRAC": "0.25",
                "FRAC_CLIENT": "0.2",
                "FRAC_OWN": "0.3",
                "INSTRUMENT": "Bond",
                "MEMBER": "John Doe",
                "OWN_ACCOUNT_DATA": [
                    {
                        "CF_ENTITLEMENT_FRAC": "0.1",
                        "CF_INSTRUMENT_SHORT_OWN": "CF123",
                        "END_HOLDING_PERIOD_OWN1": "15 JUN 2024",
                        "ENTITLEMENT_AMT_GROSS_OWN": "1100.0",
                        "ENTITLEMENT_AMT_NET_OWN": "990.0",
                        "ENTITLEMENT_AMT_TAX": "110.0",
                        "ENTITLEMENT_DEP_ACCT_OWN": "Dep123",
                        "HOLDING_BALANCE_OWN1": "1000.0",
                        "HOLDING_PERIOD_OWN1": 30,
                        "NET_AMOUNT_OWN1": "900.0",
                        "OWN_ACCOUNT": "12345",
                        "OWN_ACCOUNT_DESC": "Main Account",
                        "PROCEED_AMOUNT_OWN1": "950.0",
                        "RECORD_BALANCE_OWN": "1000.0",
                        "START_HOLDING_PERIOD_OWN1": "15 JUN 2024",
                        "TAX_AMOUNT_OWN1": "50.0",
                        "TAX_PCT": "10%"
                    }
                ],                
                "OWN_SEC_SHORT": "OWNXYZ",
                "P_SINCE": "12 July 2024",
                "SECURITY": "XYZ Corp",
                "SECURITY_SHORT": "XYZ",
                "SUM_CLIENT_RECORD_BALANCE": "2000",
                "SUM_RBLNC_AMT_OWN": "1500",
                "TOTAL_RBLNC": "5000",
                "_id": "66cfd0d6c981ea72913f9b18"
            }
        ]

        date = "2024-07-13"
        result = bond_member_entitlement_datas(date)

        expected_result = [
            {
                '_id': '1',
                "AMT_GROSS": "10000",
                "AMT_GROSS_CLIENT": "14000",
                "AMT_GROSS_OWN": "7000",
                "AMT_NET": "8000",
                "AMT_NET_CLIENT": "11200",
                "AMT_NET_OWN": "5600",
                "AMT_TAX": "2000",
                "AMT_TAX_CLIENT": "2800",
                "AMT_TAX_OWN": "1400",
                "CA_ANNOUNCEMENT_DATE": "13/06/2024",
                "CA_DEADLINE_DATE": "13/03/2024",
                "CA_EFFECTIVE_DATE": "13/03/2024",
                "CA_EX_DATE": "13/03/2024",
                "CA_INT_END_DATE": "13/03/2024",
                "CA_INT_START_DATE": "13/03/2024",
                "CA_RECORD_DATE": "13/03/2024",
                "CA_START_DATE": "13/03/2024",
                "CA_TAX_IN_OUT": "In",
                "CLIENT_ACCOUNT_DATA": [
                    {
                        "CLIENT_ACCOUNT": "67890",
                        "CLIENT_ACCOUNT_DESC": "Client Account",
                        "CLIENT_DEPOSIT_ACCOUNT": "Dep456",
                        "CLIENT_RECORD_BALANCE": "2000.0",
                        "CLIENT_TAX_PCT": "15%",
                        "DEP_AMT_GROSS": "2200.0",
                        "DEP_AMT_TAX": "330.0",
                        "DEP_FRAC": "0.2",
                        "DEP_INSTRUMENT": "Instr456",
                        "END_HOLDING_PERIOD_CLIENT": "15 JUN 2024",
                        "HOLDING_BALANCE_CLIENT": "2000.0",
                        "HOLDING_PERIOD_CLIENT": 60,
                        "NET_AMOUNT_CLIENT": "1600.0",
                        "NET_PROCEED_AMT_CLIENT": "1870.0",
                        "PROCEED_AMOUNT_CLIENT": "1900.0",
                        "START_HOLDING_PERIOD_CLIENT": "15 JUN 2024",
                        "TAX_AMOUNT_CLIENT": "300.0"
                    }
                ],
                "CLIENT_SEC_SHORT": "CLIXYZ",
                "CORPORATE_ACTION": "Dividend Distribution",
                "DATE": "13-JUL-24 01:01 PM",
                "FRAC": "0.25",
                "FRAC_CLIENT": "0.2",
                "FRAC_OWN": "0.3",
                "INSTRUMENT": "Bond",
                "MEMBER": "John Doe",
                "OWN_ACCOUNT_DATA": [
                    {
                        "CF_ENTITLEMENT_FRAC": "0.1",
                        "CF_INSTRUMENT_SHORT_OWN": "CF123",
                        "END_HOLDING_PERIOD_OWN1": "15 JUN 2024",
                        "ENTITLEMENT_AMT_GROSS_OWN": "1100.0",
                        "ENTITLEMENT_AMT_NET_OWN": "990.0",
                        "ENTITLEMENT_AMT_TAX": "110.0",
                        "ENTITLEMENT_DEP_ACCT_OWN": "Dep123",
                        "HOLDING_BALANCE_OWN1": "1000.0",
                        "HOLDING_PERIOD_OWN1": 30,
                        "NET_AMOUNT_OWN1": "900.0",
                        "OWN_ACCOUNT": "12345",
                        "OWN_ACCOUNT_DESC": "Main Account",
                        "PROCEED_AMOUNT_OWN1": "950.0",
                        "RECORD_BALANCE_OWN": "1000.0",
                        "START_HOLDING_PERIOD_OWN1": "15 JUN 2024",
                        "TAX_AMOUNT_OWN1": "50.0",
                        "TAX_PCT": "10%"
                    }
                ],
                "OWN_SEC_SHORT": "OWNXYZ",
                "P_SINCE": "12 July 2024",
                "SECURITY": "XYZ Corp",
                "SECURITY_SHORT": "XYZ",
                "SUM_CLIENT_RECORD_BALANCE": "2000",
                "SUM_RBLNC_AMT_OWN": "1500",
                "TOTAL_RBLNC": "5000",
                "_id": "66cfd0d6c981ea72913f9b18"
            }
        ]

        self.assertEqual(result, expected_result)

if __name__ == '__main__':
    unittest.main()
