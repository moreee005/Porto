import unittest
from unittest.mock import patch
from src.services.bond_issuer_overview_service import bond_issuer_overview_datas

class TestBondIssuerOverviewDatas(unittest.TestCase):
    
    @patch('src.services.bond_issuer_overview_service.fetch_data_bio')
    def test_bond_issuer_overview_datas(self, mock_fetch_data_bio):
        mock_fetch_data_bio.return_value = [
            {
                "_id": "64d9f3a2c72d9b0012eae394",
                "CA_ANNOUNCEMENT_DATE": "19 July 2024",
                "CA_DEADLINE_DATE": "-",
                "CA_EFFECT_DATE": "20 August 2024",
                "CA_EX_DATE": "-",
                "CA_INTEREST_ST_DATE": "20 May 2024",
                "CA_INT_END_DATE": "20 August 2024",
                "CA_RECORD_DATE": "14 August 2024",
                "CA_START_DATE": "-",
                "CA_TAX_METHOD": "OUTSIDE THE SYSTEM",
                "CORPORATE_ACTION": "INTEREST PAYMENT",
                "CORR_ACCT": "-",
                "CS_SUM_REC_BAL": "450,800,000,000.00",
                "GLOBAL_AMT_GROSS": "573,750,000.00",
                "GLOBAL_AMT_NET": "516,375,000.00",
                "GLOBAL_AMT_TAX": "57,375,000.00",
                "GLOBAL_FRAC": "-",
                "GLOBAL_INSTRUMENT": "IDR",
                "ISSUER_ACCOUNT": "KSEI1TUFI00138",
                "P_REC_DATE": "14 August 2024",
                "SECURITY": "OBLIGASI BERKELANJUTAN V MANDIRI TUNAS FINANCE TAHAP II TAHUN 2021 SERI B",
                "SECURITY_SHORT": "TUFI05BCN2",
                "SUB_DATA": [
                    {
                        "AMT_GROSS": "-",
                        "AMT_NET": "-",
                        "AMT_TAX": "-",
                        "CLIENT_ACCOUNT_DATA": [
                            {
                                "CLIENT_ACCOUNT": "DBJK1-A382-001-48",
                                "CLIENT_ACCOUNT_DESC": "PANIN DANA UTAMA PLUS 2 - 858604000",
                                "CLIENT_DEPOSIT_ACCOUNT": "---",
                                "CLIENT_RECORD_BALANCE": "1,000,000,000.00",
                                "CLIENT_TAX_PCT": "-",
                                "DEP_AMT_GROSS": "-",
                                "DEP_AMT_TAX": "-",
                                "DEP_FRAC": "-",
                                "DEP_INSTRUMENT": "-",
                                "END_HOLDING_PERIOD_CLIENT": "-",
                                "HOLDING_BALANCE_CLIENT": "-",
                                "HOLDING_PERIOD_CLIENT": "-",
                                "NET_AMOUNT_CLIENT": "-",
                                "NET_PROCEED_AMT_CLIENT": "-",
                                "PROCEED_AMOUNT_CLIENT": "-",
                                "START_HOLDING_PERIOD_CLIENT": "-",
                                "TAX_AMOUNT_CLIENT": "-"
                            }
                        ],
                        "CLIENT_RECORD_BALANCE2": "1,000,000,000.00",
                        "FRAC": "-",
                        "INSTRUMENT": "-",
                        "MEMBER": "DBJK1",
                        "OWN_ACCOUNT_DATA": [
                            {
                                "CF_ENTITLEMENT_FRAC": "-",
                                "CF_INSTRUMENT_SHORT_OWN": "-",
                                "END_HOLDING_PERIOD_OWN1": "-",
                                "ENTITLEMENT_AMT_GROSS_OWN": "-",
                                "ENTITLEMENT_AMT_NET_OWN": "-",
                                "ENTITLEMENT_AMT_TAX": "-",
                                "ENTITLEMENT_DEP_ACCT_OWN": "---",
                                "HOLDING_BALANCE_OWN1": "-",
                                "HOLDING_PERIOD_OWN1": "-",
                                "NET_AMOUNT_OWN1": "-",
                                "OWN_ACCOUNT": "-",
                                "OWN_ACCOUNT_DESC": "-",
                                "PROCEED_AMOUNT_OWN1": "-",
                                "RECORD_BALANCE_OWN": "-",
                                "START_HOLDING_PERIOD_OWN1": "-",
                                "TAX_AMOUNT_OWN1": "-",
                                "TAX_PCT": "-"
                            }
                        ]
                    }
                ]
            }
        ]

        date = "2024-08-14"
        
        result = bond_issuer_overview_datas(date)

        expected_result = [
            {
                "_id": "64d9f3a2c72d9b0012eae394", 
                "CA_ANNOUNCEMENT_DATE": "19 July 2024",
                "CA_DEADLINE_DATE": "-",
                "CA_EFFECT_DATE": "20 August 2024",
                "CA_EX_DATE": "-",
                "CA_INTEREST_ST_DATE": "20 May 2024",
                "CA_INT_END_DATE": "20 August 2024",
                "CA_RECORD_DATE": "14 August 2024",
                "CA_START_DATE": "-",
                "CA_TAX_METHOD": "OUTSIDE THE SYSTEM",
                "CORPORATE_ACTION": "INTEREST PAYMENT",
                "CORR_ACCT": "-",
                "CS_SUM_REC_BAL": "450,800,000,000.00",
                "GLOBAL_AMT_GROSS": "573,750,000.00",
                "GLOBAL_AMT_NET": "516,375,000.00",
                "GLOBAL_AMT_TAX": "57,375,000.00",
                "GLOBAL_FRAC": "-",
                "GLOBAL_INSTRUMENT": "IDR",
                "ISSUER_ACCOUNT": "KSEI1TUFI00138",
                "P_REC_DATE": "14 August 2024",
                "SECURITY": "OBLIGASI BERKELANJUTAN V MANDIRI TUNAS FINANCE TAHAP II TAHUN 2021 SERI B",
                "SECURITY_SHORT": "TUFI05BCN2",
                "SUB_DATA": [
                    {
                        "AMT_GROSS": "-",
                        "AMT_NET": "-",
                        "AMT_TAX": "-",
                        "CLIENT_ACCOUNT_DATA": [
                            {
                                "CLIENT_ACCOUNT": "DBJK1-A382-001-48",
                                "CLIENT_ACCOUNT_DESC": "PANIN DANA UTAMA PLUS 2 - 858604000",
                                "CLIENT_DEPOSIT_ACCOUNT": "---",
                                "CLIENT_RECORD_BALANCE": "1,000,000,000.00",
                                "CLIENT_TAX_PCT": "-",
                                "DEP_AMT_GROSS": "-",
                                "DEP_AMT_TAX": "-",
                                "DEP_FRAC": "-",
                                "DEP_INSTRUMENT": "-",
                                "END_HOLDING_PERIOD_CLIENT": "-",
                                "HOLDING_BALANCE_CLIENT": "-",
                                "HOLDING_PERIOD_CLIENT": "-",
                                "NET_AMOUNT_CLIENT": "-",
                                "NET_PROCEED_AMT_CLIENT": "-",
                                "PROCEED_AMOUNT_CLIENT": "-",
                                "START_HOLDING_PERIOD_CLIENT": "-",
                                "TAX_AMOUNT_CLIENT": "-"
                            }
                        ],
                        "CLIENT_RECORD_BALANCE2": "1,000,000,000.00",
                        "FRAC": "-",
                        "INSTRUMENT": "-",
                        "MEMBER": "DBJK1",
                        "OWN_ACCOUNT_DATA": [
                            {
                                "CF_ENTITLEMENT_FRAC": "-",
                                "CF_INSTRUMENT_SHORT_OWN": "-",
                                "END_HOLDING_PERIOD_OWN1": "-",
                                "ENTITLEMENT_AMT_GROSS_OWN": "-",
                                "ENTITLEMENT_AMT_NET_OWN": "-",
                                "ENTITLEMENT_AMT_TAX": "-",
                                "ENTITLEMENT_DEP_ACCT_OWN": "---",
                                "HOLDING_BALANCE_OWN1": "-",
                                "HOLDING_PERIOD_OWN1": "-",
                                "NET_AMOUNT_OWN1": "-",
                                "OWN_ACCOUNT": "-",
                                "OWN_ACCOUNT_DESC": "-",
                                "PROCEED_AMOUNT_OWN1": "-",
                                "RECORD_BALANCE_OWN": "-",
                                "START_HOLDING_PERIOD_OWN1": "-",
                                "TAX_AMOUNT_OWN1": "-",
                                "TAX_PCT": "-"
                            }
                        ]
                    }
                ]
            }
        ]

        self.assertEqual(result, expected_result)

if __name__ == '__main__':
    unittest.main()
