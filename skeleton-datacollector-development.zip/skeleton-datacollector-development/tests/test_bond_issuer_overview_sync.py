import unittest
from unittest.mock import patch, MagicMock
from src.services.bond_issuer_overview_service import bond_issuer_overview_sync


class TestBondIssuerOverviewSync(unittest.TestCase):

    @patch('src.model.mongo.log.mongo.db.get_collection')
    @patch('src.services.bond_issuer_overview_service.get_connection_db')
    @patch('src.services.bond_issuer_overview_service.fetch_libur_bond')
    @patch('src.services.bond_issuer_overview_service.fetch_tgl_bond')
    @patch('src.services.bond_issuer_overview_service.fetch_bond_issuer')
    @patch('src.services.bond_issuer_overview_service.get_json_report_data')
    @patch('src.services.bond_issuer_overview_service.bulk_insert_bio')
    @patch('src.services.bond_issuer_overview_service.log')
    def test_bond_issuer_overview_sync(self, mock_log, mock_bulk_insert_bio, mock_get_json_report_data, mock_fetch_bond_issuer, mock_fetch_tgl_bond, mock_fetch_libur_bond, mock_get_connection_db, mock_get_collection):

        mock_conn = MagicMock()
        mock_get_connection_db.return_value = mock_conn
        mock_fetch_libur_bond.return_value = 0
        mock_fetch_tgl_bond.return_value = ('19-AUG-2024', '20240819')
        mock_fetch_bond_issuer.return_value = [MagicMock(id_ca_capco="CA123", id_mem="MEM001")]
        mock_get_json_report_data.side_effect = lambda p_ca_id, id_mem, conn: {'id_ca_capco': p_ca_id, 'id_mem': id_mem}

        mock_collection = MagicMock()
        mock_get_collection.return_value = mock_collection

        bond_issuer_overview_sync()

        mock_bulk_insert_bio.assert_called_once_with([
            {'id_ca_capco': 'CA123', 'id_mem': 'MEM001'}
        ])

        mock_get_connection_db.return_value.close.assert_called()

        mock_collection.insert_one.assert_called_once_with({
            "operation": "Sync Data Bond Issuer Overview From Oracle",
            "total_data": 1, 
            "status": "Success",
            "duration": unittest.mock.ANY, 
            "exception": '-'
        })

if __name__ == '__main__':
    unittest.main()
