// 1 = NEXT_PUBLIC_API_URL_EMPLOYEE
// 2 = NEXT_PUBLIC_API_URL_APPROVAL
// 3 = NEXT_PUBLIC_API_URL_REFERENCE
// 4 = NEXT_PUBLIC_API_URL_LOG

const endpoints = {
  userManagement: {
    createUser: {
      baseType: 1,
      method: 'post',
      url: '/user-management/create-user',
    },
    login: {
      baseType: 1,
      method: 'post',
      url: '/login',
    },
    profile: {
      method: 'get',
      url: '/user/:userId',
    },
  },
  employeeManagement: {
    detail: {
      baseType: 1,
      method: 'get',
      url: '/employee/:id',
    },
    list: {
      baseType: 1,
      method: 'get',
      url: '/view-employee',
    },
    contractList: {
      baseType: 1,
      method: 'get',
      url: '/data-contract/employees',
    },
    addEmployee: {
      baseType: 1,
      method: 'post',
      url: '/employee-management/add',
    },
    documentUploadImage: {
      baseType: 1,
      method: 'post',
      url: '/document/upload/profile-image-employee',
    },
    documentUploadContract: {
      baseType: 1,
      method: 'post',
      url: '/document/upload/document-contract',
    },
    documentUploadCivil: {
      baseType: 1,
      method: 'post',
      url: '/document/upload/document-civil',
    },
    historyContractListByIdEmployee: {
      baseType: 1,
      method: 'get',
      url: '/employee/contract-history/:employee_id',
    },
    contractHistory:{
      baseType: 1,
      method: 'get',
      url: '/employee/contract-history/:id',
    },
    dataContract: {
      baseType: 1,
      method: 'get',
      url: '/employee/data-contract/detail/:id',
    },
    addendum: {
      baseType: 1,
      method: 'post',
      url: '/employee/data-contract/detail/:employee_id/addendum',
    }
  },
  approval: {
    detail: {
      baseType: 2,
      method: 'get',
      url: '/approval/:id',
    },
    list: {
      baseType: 2,
      method: 'get',
      url: '/view-approval',
    },
    detailResignKontrak: {
      baseType: 2,
      method: 'get',
      url: '/approval/:approval-id',
    },
    detailPerpanjangKontrak: {
      baseType: 2,
      method: 'get',
      url: '/approval/:approval-id'
    },
    approveKontrak: {
      baseType: 2,
      method: 'post',
      url: '/approval/:approval-id/approve'
    },
    rejectKontrak: {
      baseType: 2,
      method: 'post',
      url: '/approval/:approval-id/reject'
    },
  },
  master: {
    'contract-type': {
      baseType: 3,
      method: 'get',
      url: '/master/contract-type',
    },
    'contract-status': {
      baseType: 3,
      method: 'get',
      url: '/master/contract-status',
    },
    'job-position': {
      baseType: 3,
      method: 'get',
      url: '/master/job-position',
    },
    'placement-type': {
      baseType: 3,
      method: 'get',
      url: '/master/placement-type',
    },
    'employe-type': {
      baseType: 3,
      method: 'get',
      url: '/master/party-type',
    },
    division: {
      baseType: 3,
      method: 'get',
      url: '/master/division',
    },
    'allowance-type': {
      baseType: 3,
      method: 'get',
      url: '/master/allowance-type',
    },
    'bank-placement': {
      baseType: 3,
      method: 'get',
      url: '/master/bank-placement',
    },
    'blood-type': {
      baseType: 3,
      method: 'get',
      url: '/master/blood-type',
    },
    city: {
      baseType: 3,
      method: 'get',
      url: '/master/city',
    },
    nationality: {
      baseType: 3,
      method: 'get',
      url: '/master/nationality',
    },
    'education-level': {
      baseType: 3,
      method: 'get',
      url: '/master/education-level-options',
    },
    'emergency-contact': {
      baseType: 3,
      method: 'get',
      url: '/master/emergency-contact-relationship',
    },
    'ptkp-state': {
      baseType: 3,
      method: 'get',
      url: '/master/ptkp-status',
    },
    'bpjs-class': {
      baseType: 3,
      method: 'get',
      url: '/master/bpjs-class',
    },
    'bank-name': {
      baseType: 3,
      method: 'get',
      url: '/master/bank',
    },
    'document-type': {
      baseType: 3,
      method: 'get',
      url: '/master/document-type',
    },
    'social-media': {
      baseType: 3,
      method: 'get',
      url: '/master/social-media-options',
    },
    'religion': {
      baseType: 3,
      method: 'get',
      url: 'master/religion',
    },
    'marital-status': {
      baseType: 3,
      method: 'get',
      url: 'master/marital-status',
    },
    'ethnicity': {
      baseType: 3,
      method: 'get',
      url: 'master/ethnicity',
    },
    'major': {
      baseType: 3,
      method: 'get',
      url: 'master/major',
    },
    'contact-emergency': {
      baseType: 3,
      method: 'get',
      url: 'master/contact-emergency',
    },
    'salary-range': {
      baseType: 3,
      method: 'get',
      url: 'master/salary-range',
    },
    'list-city': {
      baseType: 3,
      method: 'get',
      url: 'master/locations/list-city',
    },
    'course-type': {
      baseType: 3,
      method: 'get',
      url: 'master/course-type',
    },
    'organization': {
      baseType: 3,
      method: 'get',
      url: 'master/organization-member-count',
    },
    'sport': {
      baseType: 3,
      method: 'get',
      url: 'master/sport',
    },
    'art': {
      baseType: 3,
      method: 'get',
      url: 'master/art',
    },
    'foreign-language': {
      baseType: 3,
      method: 'get',
      url: 'master/foreign-language',
    },
  },
};

export default endpoints;
