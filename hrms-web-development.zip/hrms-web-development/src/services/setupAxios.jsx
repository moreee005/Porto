import axios from 'axios';
import toCamelCase from '@/utils/naming-convention-converter';
import endpoint from './endpoints';
import Cookies from 'js-cookie';

const serviceHost = process.env.NEXT_PUBLIC_API_URL;

const getBaseType = (baseType) => {
  switch (baseType) {
    case 1:
      return process.env.NEXT_PUBLIC_API_URL_EMPLOYEE;
    case 2:
      return process.env.NEXT_PUBLIC_API_URL_APPROVAL;
    case 3:
      return process.env.NEXT_PUBLIC_API_URL_REFERENCE;
    case 4:
      return process.env.NEXT_PUBLIC_API_URL_LOG;
    default:
      return process.env.NEXT_PUBLIC_API_URL;
  }
};
const apiClient = axios.create({
  baseURL: getBaseType,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use(
  (config) => {
    // set token localStorage
    // let user = localStorage.getItem('_u')
    //   ? JSON.parse(localStorage.getItem('_u'))
    //   : '';

    // set token with cookie
    const auth = Cookies.get('accessToken');
    if (auth && !config?.service) {
      config.headers.Authorization = `Bearer ${auth}`;
    }
    return config;
  },
  (err) => Promise.reject(err)
);

apiClient.interceptors.response.use(
  (response) => {
    response = JSON.parse(JSON.stringify(response), toCamelCase);
    const {
      data,
      config: { url },
    } = response;
    if (data && url?.includes('auth')) {
      const { info, status } = data;
      if (status === 'error') {
        console.log('Error : ', info.message || 'Error occurred');
      }
    }
    return Promise.resolve(response);
  },
  async (error) => {
    if (error.response) {
      if (error.response.status === 401) {
        //console.log(error?.response?.data?.message);
        localStorage.clear();
        localStorage.setItem(
          'Unautorized',
          error?.response?.data?.message || 'Expired Token'
        );
        Cookies.remove('accessToken');
        Cookies.remove('userId');
        // window.location.href = '/login';
        return Promise.reject(error?.response?.data);
      }
    }
    return Promise.reject(error?.response);
  }
);

export const urlBuilder = ({ query, urlApi }) => {
  if (query)
    return Object.keys(query).reduce(
      (url, key) => url?.replace(`:${key}`, query[key]),
      urlApi
    );
  return urlApi;
};

export const API = (...args) => {
  const [urlMethod, params] = args;
  const [name, method] = urlMethod.split('.');

  const context = { ...endpoint[name][method], ...params };
  const endpoints = endpoint[name][method];

  const baseType = endpoints?.baseType;
  context.baseURL = getBaseType(baseType);

  const urlTemp = endpoints?.url;
  context.url = urlBuilder({ ...params, urlApi: urlTemp });

  return apiClient(context);
};

export default apiClient;
