'use client';

import React, { useEffect, useState } from 'react';
import { Box } from '@mui/material';
import { useForm, FormProvider } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import {
  HmButton,
  HmModal,

  HmTypography,
} from '@/components/component';
import colors from '@/components/colors';
import { MdKeyboardArrowLeft } from 'react-icons/md';
import { useRouter } from 'next/navigation';
import {
  initialDefaultValues,
  steps,
} from '@/components/section/form-karyawan/data-and-validation/form-data';
import * as yup from 'yup';
import ScFormIdentitasDiri from '@/components/section/form-karyawan/ScFormIdentitasDiri';
import ScFormKontrak from '@/components/section/form-karyawan/ScFormKontrak';
import ScFormKependudukan from '@/components/section/form-karyawan/ScFormKependudukan';
import ScFormUnggahDokumen from '@/components/section/form-karyawan/ScFormUnggahDokumen';
import Grid from '@mui/material/Grid2';
import { API } from '@/services/setupAxios';
import { useToast } from '@/context/toastContext';
import {
  identitasDiriSchema,
  kependudukanSchema,
  kontrakSchema,
  unggahDokumenSchema,
} from '@/components/section/form-karyawan/data-and-validation/validation-schema';
import HmStepper from '@/components/component/HmStepper';
import mapRequestBody from '@/components/section/form-karyawan/data-and-validation/request-mapper';
import { VARIABLES } from '@/data/variables';

const TambahKaryawan = () => {
  const router = useRouter();
  const { showToast } = useToast();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [openModal, setOpenModal] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);
  const [uploadKontrak, setUploadKontrak] = useState<File | null>(null);
  const [uploadDoc, setUploadDoc] = useState<any[]>([]);

  useEffect(() => {
    // mapping document file
    const documentKontrak = formData[1]?.contractInformation?.contractDocument?.documentName?.[0];
    const documentEmployee = formData[3]?.documents?.documentEmployee;

    if (documentKontrak) {
      setUploadKontrak(documentKontrak);
    }
    if (Array.isArray(documentEmployee)) {
      // Set array doc employee
      setUploadDoc(documentEmployee);
      console.log('Document Employee:', documentEmployee);
    }
  }, [formData]);


  const getValidationSchema = (step: number) => {
    switch (step) {
      case 0:
        return identitasDiriSchema;
      case 1:
        return kontrakSchema;
      case 2:
        return kependudukanSchema;
      case 3:
        return unggahDokumenSchema;
      default:
        return yup.object().shape({});
    }
  };


  const handleImageUpload = (file: File | null) => {
    setUploadedImage(file);
    console.log('Uploaded Image ()=>):', file);
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return <ScFormIdentitasDiri onImageUpload={handleImageUpload} />;
      case 1:
        return <ScFormKontrak />;
      case 2:
        return <ScFormKependudukan />;
      case 3:
        return <ScFormUnggahDokumen />;
      default:
        return null;
    }
  };

  const methods = useForm({
    resolver: yupResolver(getValidationSchema(activeStep)),
    defaultValues: initialDefaultValues,
    mode: 'onChange',
  });

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleCancel = () => {
    router.back();
  };

  const handleNext = async () => {
    try {
      const currentData = methods.getValues();
      // Trigger validation using react-hook-form
      const isValid = await methods.trigger();

      if (isValid) {
        const updatedFormData = { ...formData, [activeStep]: currentData };
        console.log('Updated Form Data:', updatedFormData);
        setFormData(updatedFormData);

        if (activeStep === steps.length - 1) {
          // Validate all steps before opening the modal
          for (let i = 0; i < steps.length; i++) {
            const stepSchema = getValidationSchema(i);
            await stepSchema.validate(formData[i], { abortEarly: false });
          }

          setLoading(true);
          setTimeout(() => {
            setLoading(false);
            setOpenModal(true);
            console.log('Modal open ');
          }, 2000);
        } else {
          setLoading(true);
          setTimeout(() => {
            setLoading(false);
            setActiveStep((prev) => prev + 1);
          }, 2000);
        }
      } else {
        // If validation fails, log the errors
        console.log('Validation failed, please check your inputs.');
        const errors = methods.formState.errors;
        console.log('Validation Errors:', errors);
      }
    } catch (error) {
      console.error('Error during form validation:', error);
    }
  };

  const onSubmit = async (data: any) => {
    console.log('Data submitted:', data);
    try {
      console.log('Form Data for step', activeStep, ':', data);
      const updatedFormData = { ...formData, [activeStep]: data };
      console.log('Updated Form Data:', updatedFormData);
      setFormData(updatedFormData);
    } catch (error) {
      console.error('Form submission error:', error);
      alert((error as Error).message);
    }
  };

  const onClose = () => {
    console.log('Modal closed');
    setOpenModal(false);
  };

  // API
  const sendEmployeeData = async (bodyData: any) => {
    const addEmployeeResponse = await API('employeeManagement.addEmployee', {
      data: bodyData,
    });

    return addEmployeeResponse;
  };

  const uploadImages = async (uploadedImage: File, emailEmployee: string) => {
    const imageFormData = new FormData();
    imageFormData.append('document', uploadedImage, uploadedImage.name);
    imageFormData.append('emailEmployee', emailEmployee);

    const imageUploadResponse = await API('employeeManagement.documentUploadImage', {
      data: imageFormData,
      headers: { 'Content-Type': 'multipart/form-data' },
    });


    return imageUploadResponse;
  };

  const uploadContracts = async (uploadKontrak: File, emailEmployee: string) => {
    const kontrakFormData = new FormData();
    kontrakFormData.append('document', uploadKontrak);
    kontrakFormData.append('emailEmployee', emailEmployee);

    const kontrakUploadResponse = await API('employeeManagement.documentUploadContract', {
      data: kontrakFormData,
      headers: { 'Content-Type': 'multipart/form-data' },
    });

    return kontrakUploadResponse;
  };

  const uploadDocuments = async (file: File, emailEmployee: string, documentType: string) => {
    const docFormData = new FormData();
    docFormData.append('document', file);
    docFormData.append('emailEmployee', emailEmployee);
    docFormData.append('documentType', documentType);

    const docUploadResponse = await API('employeeManagement.documentUploadCivil', {
      data: docFormData,
      headers: { 'Content-Type': 'multipart/form-data' },
    });

    return docUploadResponse;
  };


  const handleSendEmployee = async () => {
    console.log('Sending employee data:', formData);
    setOpenModal(false);

    const bodyData = mapRequestBody(formData);
    console.log('Body Data:', bodyData);

    try {


      // Step 1: Send employee data
      const addEmployeeResponse = await sendEmployeeData(bodyData);

      if (!addEmployeeResponse || addEmployeeResponse.status !== 200) {
        throw new Error('Failed to add employee');
      }

      // Step 2: Upload Images
      if (uploadedImage) {
        const emailEmployee = formData[0].personalIdentity.email;
        const imageUploadResponse = await uploadImages(uploadedImage, emailEmployee);

        if (!imageUploadResponse || imageUploadResponse.status !== 200) {
          throw new Error('Failed to upload image');
        }
      }

      // // Step 3: Upload Files Contract
      if (uploadKontrak) {
        const emailEmployee = formData[0].personalIdentity.email;
        const kontrakUploadResponse = await uploadContracts(uploadKontrak, emailEmployee);

        if (!kontrakUploadResponse || kontrakUploadResponse.status !== 200) {
          throw new Error('Failed to upload image');
        }
      }

      // // Step 4: Upload Documents
      if (uploadDoc && Array.isArray(uploadDoc)) {
        for (const docItem of uploadDoc) {
          const file = docItem.document?.[0];
          if (file) {
            try {
              const emailEmployee = formData[0].personalIdentity.email;
              const documentType = docItem.documentType?.toString() || VARIABLES.DOC_TYPE_KTP;
              const docUploadResponse = await uploadDocuments(file, emailEmployee, documentType);

              if (!docUploadResponse || docUploadResponse.status !== 200) {
                throw new Error('Failed to upload employee document');
              }
            } catch (error) {
              showToast('error', (error as Error).message);
            }
          }
        }
      }

      showToast('success', 'Karyawan berhasil ditambahkan');
      router.push('/karyawan');
    } catch (error) {
      showToast('error', (error as Error).message);
    }

  }

  const formatDate = (dateString: string) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const modalContent = [
    { id: 1, label: 'Nama Lengkap', value: formData[0]?.personalIdentity.fullname },
    { id: 2, label: 'Divisi', value: formData[1]?.contractInformation.divisionId },
    { id: 3, label: 'Tanggal Mulai Masuk Kontrak', value: formatDate(formData[1]?.contractInformation.contractStartDate) },
    { id: 4, label: 'Status Kontrak', value: formData[1]?.contractInformation.statusId },
    { id: 5, label: 'Jabatan', value: formData[1]?.contractInformation.jobPositionId },
    { id: 6, label: 'Tanggal Akhir Masuk Kontrak', value: formatDate(formData[1]?.contractInformation.contractEndDate) },
  ];

  return (
    <FormProvider {...methods}>
      <Box sx={{ width: '100%', margin: 'auto', px: 3, mt: 2 }}>
        <form onSubmit={methods.handleSubmit(onSubmit)}>
          <HmStepper activeStep={activeStep} steps={steps} />

          <Box sx={{ mt: 4, mb: 4 }}>{renderStepContent(activeStep)}</Box>

          <Box
            sx={{
              display: 'flex',
              flexDirection: { xs: 'column', sm: 'row' },
              justifyContent: 'space-between',
              gap: 2,
              mt: 4,
              mb: 4,
              mx: 2,
            }}
          >
            <HmButton
              onClick={handleBack}
              type="button"
              color="transparent"
              borderColor={colors.palette.primary}
              labelColor={colors.palette.primary}
              variant="outlined"
              label="Kembali"
              disabled={activeStep === 0}
              icon={
                activeStep > 0 && (
                  <MdKeyboardArrowLeft style={{ marginRight: 2 }} size={17} />
                )
              }
            />

            <Box
              sx={{
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' },
                gap: 1,
                width: { xs: '100%', sm: 'auto' },
              }}
            >
              <HmButton
                type="button"
                color="transparent"
                borderColor={colors.palette.primary}
                labelColor={colors.palette.primary}
                variant="outlined"
                label="Batal"
                onClick={handleCancel}
              />
              <HmButton
                type="button"
                variant="contained"
                label={
                  activeStep === steps.length - 1 ? 'Selesai' : 'Selanjutnya'
                }
                onClick={handleNext}
                disabled={activeStep === steps.length || loading}
                loading={loading}
              />
            </Box>
          </Box>
        </form>
      </Box>
      <HmModal
        isOpen={openModal}
        onClose={onClose}
        title="Kirim Data Karyawan"
        zIndex={100}
        onClickAction={handleSendEmployee}
        maxWidth="sm"
        isAction={true}
        labelAction="Kirim Karyawan"
        colorActionButton={colors.palette.primary}
      >
        <Box sx={{ width: '100%' }}>
          <Grid container spacing={4} sx={{ my: 2 }}>
            {modalContent.map((item, index) => (
              <Grid key={item.id} size={{ xs: 12, sm: 6 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <HmTypography>{item.label}</HmTypography>
                  <HmTypography semiBold>{item.value || '-'}</HmTypography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      </HmModal>
    </FormProvider>
  );
};

export default TambahKaryawan;
