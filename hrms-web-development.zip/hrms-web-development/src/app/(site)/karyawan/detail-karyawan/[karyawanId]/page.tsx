'use client';

import React, { useEffect, useState } from 'react';
import Grid from '@mui/material/Grid2';
import { HmTabs } from '@/components/component';
import DetailKaryawanHeader from '@/components/section/detail-karyawan/DetailKaryawanHeader';
import { AccountCircle, Work, CreditCard, Receipt } from '@mui/icons-material';
import IdentitasDiriContent from '@/components/section/detail-karyawan/IdentitasDiriContent';
import DataKependudukanContent from '@/components/section/detail-karyawan/DataKependudukanContent';
import InformasiKontrakContent from '@/components/section/detail-karyawan/InformasiKontrakContent';
import DocumentContent from '@/components/section/detail-karyawan/DocumentContent';
import { API } from '@/services/setupAxios';
import { Box, CircularProgress } from '@mui/material';
import { useToast } from '@/context/toastContext';
import { useParams } from 'next/navigation';

interface EmployeeData {
  personalIdentity: any;
  contractInformation: any;
  healthAndFinance: any;
  documents: any;
}

const DetailKaryawan = () => {
  const [employeeData, setEmployeeData] = useState<EmployeeData | null>(null);
  const { showToast } = useToast();
  const { karyawanId } = useParams();

  const EmployeeDetails = async () => {
    try {
      const response = await API('employeeManagement.detail', {
        query: { id: karyawanId },
      });
      const data = response.data.data;
      setEmployeeData(data);
    } catch (error) {
      // showToast('error', (error as Error).message);
    }
  };

  useEffect(() => {
    if (karyawanId) {
      EmployeeDetails();
    }
  }, [karyawanId]);

  if (!employeeData) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '50vh',
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  const tabs = [
    {
      label: 'Identitas Diri',
      icon: <AccountCircle />,
      // @ts-ignore
      content: <IdentitasDiriContent data={employeeData} />,
    },
    {
      label: 'Informasi Kontrak',
      icon: <Work />,
      content: (
        <InformasiKontrakContent data={employeeData.contractInformation} />
      ),
    },
    {
      label: 'Data Kependudukan',
      icon: <CreditCard />,
      content: <DataKependudukanContent data={employeeData.healthAndFinance} />,
    },
    {
      label: 'Dokumen',
      icon: <Receipt />,
      content: <DocumentContent data={employeeData.documents} />,
    },
  ];

  return (
    <Grid container>
      <Grid
        size={12}
        sx={{
          padding: '16px',
        }}
      >
        {/*@ts-ignore*/}
        <DetailKaryawanHeader employeeData={employeeData} />
      </Grid>
      <Grid size={12}>
        <HmTabs tabs={tabs} />
      </Grid>
    </Grid>
  );
};

export default DetailKaryawan;
