'use client';

import React, { useState } from 'react';
import { Box } from '@mui/material';
import { useForm, FormProvider } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { HmButton, HmModal, HmTypography } from '@/components/component';
import colors from '@/components/colors';
import { MdKeyboardArrowLeft } from 'react-icons/md';
import { useRouter } from 'next/navigation';
import { steps } from '@/components/section/form-karyawan/data-and-validation/form-data';
import * as yup from 'yup';
import ScFormIdentitasDiri from '@/components/section/form-karyawan/ScFormIdentitasDiri';
import ScFormKontrak from '@/components/section/form-karyawan/ScFormKontrak';
import ScFormKependudukan from '@/components/section/form-karyawan/ScFormKependudukan';
import ScFormUnggahDokumen from '@/components/section/form-karyawan/ScFormUnggahDokumen';
import Grid from '@mui/material/Grid2';
import { identitasDiriSchema, kependudukanSchema, kontrakSchema, unggahDokumenSchema } from '@/components/section/form-karyawan/data-and-validation/validation-schema';
import HmStepper from '@/components/component/HmStepper';
import { initialEditData } from '@/data/dummyEditKaryawan';

const EditKaryawan = () => {
  const router = useRouter();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [openModal, setOpenModal] = useState(false);

  const getValidationSchema = (step: number) => {
    switch (step) {
      case 0:
        return identitasDiriSchema;
      case 1:
        return kontrakSchema;
      case 2:
        return kependudukanSchema;
      case 3:
        return unggahDokumenSchema;
      default:
        return yup.object().shape({});
    }
  };

  const methods = useForm({
    resolver: yupResolver(getValidationSchema(activeStep)),
    defaultValues: initialEditData,
    mode: 'onChange',
  });

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleCancel = () => {
    router.back();
  };

  const handleNext = async () => {
    try {

      const currentData = methods.getValues();

      // Trigger validation using react-hook-form
      const isValid = await methods.trigger();

      if (isValid) {
        const updatedFormData = { ...formData, [activeStep]: currentData };
        console.log('Updated Form Data:', updatedFormData);
        setFormData(updatedFormData);

        if (activeStep === steps.length - 1) {
          // Validate all steps before opening the modal
          for (let i = 0; i < steps.length; i++) {
            const stepSchema = getValidationSchema(i);
            await stepSchema.validate(formData[i], { abortEarly: false });
          }

          setLoading(true);
          setTimeout(() => {
            setLoading(false);
            setOpenModal(true);
            console.log("Modal open");
          }, 2000);
        } else {
          setLoading(true);
          setTimeout(() => {
            setLoading(false);
            setActiveStep((prev) => prev + 1);
          }, 2000);
        }
      } else {
        // If validation fails, log the errors
        console.log('Validation failed, please check your inputs.');
        const errors = methods.formState.errors;
        console.log('Validation Errors:', errors);
      }
    } catch (error) {
      console.error('Error during form validation:', error);
    }
  };


  const onSubmit = async (data: any) => {
    try {
      console.log('Form Data for step', activeStep, ':', data);
      const updatedFormData = { ...formData, [activeStep]: data };
      console.log('Updated Form Data:', updatedFormData);
      setFormData(updatedFormData);
    } catch (error) {
      console.error('Form submission error:', error);
      alert((error as Error).message);
    }
  };

  const onClose = () => {
    console.log('Modal closed');
    setOpenModal(false);
  }

  const handleSendEmployee = () => {
    console.log('Sending employee data:', formData);
    setOpenModal(false);
    router.push('/karyawan');
  }

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return <ScFormIdentitasDiri />;
      case 1:
        return <ScFormKontrak />;
      case 2:
        return <ScFormKependudukan />;
      case 3:
        return <ScFormUnggahDokumen />;
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  const modalContent = [
    { id: 1, label: 'Nama Lengkap', value: formData[0]?.personalIdentity.fullname },
    { id: 2, label: 'Divisi', value: formData[1]?.contractInformation.divisionId },
    { id: 3, label: 'Tanggal Mulai Masuk Kontrak', value: formatDate(formData[1]?.contractInformation.contractStartDate) },
    { id: 4, label: 'Status Kontrak', value: formData[1]?.contractInformation.statusId },
    { id: 5, label: 'Jabatan', value: formData[1]?.contractInformation.jobPositionId },
    { id: 6, label: 'Tanggal Akhir Masuk Kontrak', value: formatDate(formData[1]?.contractInformation.contractEndDate) },
  ];

  return (
    <FormProvider {...methods}>
      <Box sx={{ width: '100%', margin: 'auto', px: 3, mt: 2 }}>
        <form onSubmit={methods.handleSubmit(onSubmit)}>
          <HmStepper activeStep={activeStep} steps={steps} />

          <Box sx={{ mt: 4, mb: 4 }}>
            {renderStepContent(activeStep)}
          </Box>

          <Box
            sx={{
              display: 'flex',
              flexDirection: { xs: 'column', sm: 'row' },
              justifyContent: 'space-between',
              gap: 2,
              mt: 4,
              mb: 4,
              mx: 2,
            }}
          >
            <HmButton
              onClick={handleBack}
              type="button"
              color="transparent"
              borderColor={colors.palette.primary}
              labelColor={colors.palette.primary}
              variant="outlined"
              label="Kembali"
              disabled={activeStep === 0}
              icon={activeStep > 0 && <MdKeyboardArrowLeft style={{ marginRight: 2 }} size={17} />}
            />

            <Box
              sx={{
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' },
                gap: 1,
                width: { xs: '100%', sm: 'auto' },
              }}
            >
              <HmButton
                type="button"
                color="transparent"
                borderColor={colors.palette.primary}
                labelColor={colors.palette.primary}
                variant="outlined"
                label="Batal"
                onClick={handleCancel}
              />
              <HmButton
                type="button"
                variant="contained"
                label={activeStep === steps.length - 1 ? 'Selesai' : 'Selanjutnya'}
                onClick={handleNext}
                disabled={activeStep === steps.length || loading}
                loading={loading}
              />
            </Box>
          </Box>
        </form>
      </Box>
      <HmModal
        isOpen={openModal}
        onClose={onClose}
        title="Update Data Karyawan"
        zIndex={100}
        onClickAction={handleSendEmployee}
        maxWidth="sm"
        isAction={true}
        labelAction='Update Karyawan'
        colorActionButton={colors.palette.primary}
      >
        <Box sx={{ width: "100%" }}>
          <Grid container spacing={4} sx={{ my: 2 }}>
            {modalContent.map((item, index) => (
              <Grid key={item.id} size={{ xs: 12, sm: 6 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <HmTypography>{item.label}</HmTypography>
                  <HmTypography semiBold>{item.value || '-'}</HmTypography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      </HmModal>
    </FormProvider>
  );
};

export default EditKaryawan;

