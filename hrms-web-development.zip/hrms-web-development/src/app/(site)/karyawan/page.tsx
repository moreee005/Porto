'use client';

import React, { useEffect, useMemo, useState } from 'react';
import {
  HmAutoComplete,
  HmButton,
  HmChip,
  HmSearch,
  HmTable,
  HmTypography,
} from '@/components/component';
import { Avatar, Box, Tooltip, useMediaQuery, useTheme } from '@mui/material';
import Grid from '@mui/material/Grid2';
import ImageComponent from '@/components/component/HmCircleImage';
import colors from '@/components/colors';
import { useRouter } from 'next/navigation';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { formatDate } from '@/utils/date-formatter';
import { API } from '@/services/setupAxios';
import { useToast } from '@/context/toastContext';

interface Option {
  id: number;
  value: string;
}

interface DataRow {
  draw: number;
  recordsTotal: number;
  recordsFiltered: number;
  data: {
    partyId: string;
    photoFilename: string | null;
    fullname: string;
    contractTypeId: number;
    contractTypeName: string;
    positionId: number;
    positionName: string;
    geographyName: string;
    placementTypeId: number;
    placementTypeName: string;
    dateOfBirthStr: string;
    bankingPlacementId: number;
    bankingPlacementName: string;
  }[];
}

const Karyawan = () => {
  const { showToast } = useToast();
  const router = useRouter();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [data, setData] = useState<DataRow>({
    draw: 0,
    recordsTotal: 0,
    recordsFiltered: 0,
    data: [
      {
        partyId: '',
        photoFilename: '',
        fullname: '',
        contractTypeId: 1,
        contractTypeName: '',
        positionId: 1,
        positionName: '',
        geographyName: '',
        placementTypeId: 1,
        placementTypeName: '',
        dateOfBirthStr: '',
        bankingPlacementId: 1,
        bankingPlacementName: '',
      },
    ],
  });

  const [loading, setLoading] = useState(false);

  const [params, setParams] = useState({
    page: 0,
    size: 10,
    contract: null,
    role: null,
    placement: null,
    dateOfBirth: null,
    bank: null,
    search: '',
    sort: '',
  });

  // const [filters, setFilters] = useState({
  //   contract: null,
  //   role: null,
  //   placement: null,
  //   dateOfBirth: null,
  //   bank: null,
  // });

  const [contractOptions, setContractOptions] = useState<Option[]>([]);
  const [roleOptions, setRoleOptions] = useState<Option[]>([]);
  const [placementOptions, setPlacementOptions] = useState<Option[]>([]);
  const [bankOptions, setBankOptions] = useState<Option[]>([]);

  // const getItemOptions = async (
  //   endpoint: string,
  //   idProps: any,
  //   setOptions: React.Dispatch<React.SetStateAction<Option[]>>
  // ) => {
  //   try {
  //     const response = await API(endpoint);

  //     if (response?.status === 200 && response?.data) {
  //       const options: Option[] = response.data.map(
  //         (item: Record<string, any>) => ({
  //           id: item?.[idProps],
  //           value: item?.value,
  //         })
  //       );
  //       console.log(options);
  //       setOptions(options);
  //     } else {
  //       console.error('API response was not successful', response);
  //     }
  //   } catch (error: any) {
  //     if (error.response) {
  //       console.error('Error fetching options from', endpoint, error.response);
  //     } else if (error.message) {
  //       console.error('Error message:', error.message);
  //     } else {
  //       console.error('Unknown error:', error);
  //     }
  //   }
  // };

  const getItemOptions = async (
    endpoint: string,
    idProps: any,
    setOptions: React.Dispatch<React.SetStateAction<Option[]>>
  ) => {
    try {
      const response = await API(endpoint);
      if (response?.status === 200) {
        const items = response?.data?.data;
        const options: Option[] = items?.map((item: any) => ({
          id: item?.[idProps],
          value: item?.name,
        }));
        setOptions(options);
      } else {
        console.error('API response was not successful', response);
      }
    } catch (error) { }
  };

  //fetching data
  // const getDataEmployee = async () => {
  //   setLoading(true);
  //   setError('');
  //   try {
  //     const response = await API('employeeManagement.list', {
  //       params: {
  //         contract: filters?.contract ? filters.contract : '',
  //         position: filters?.role ? filters.role : '',
  //         placement: filters?.placement ? filters.placement : '',
  //         dateOfBirth: filters?.dateOfBirth ? filters.dateOfBirth : '',
  //         bankPlacementAgreement: filters?.bank ? filters.bank : '',
  //         page,
  //         size: rowsPerPage,
  //         sort: sortConfig?.key
  //           ? `${sortConfig?.key},${sortConfig?.direction}`
  //           : 'fullname,asc',
  //       },
  //     });
  //     if (
  //       response?.data?.data?.data &&
  //       Array.isArray(response?.data?.data?.data)
  //     ) {
  //       const employees = response.data.data.data;
  //       console.log('Employee data:', employees);
  //       setData(employees);
  //     } else {
  //       console.error(
  //         'Expected employee data to be an array, but got:',
  //         response?.data?.data
  //       );
  //     }
  //   } catch (err: any) {
  //     console.error('Error fetching employee data:', err);
  //     showToast('error', err?.message);
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const getEmployeeList = async () => {
    setLoading(true)
    try {
      const response = await API('employeeManagement.list', { params });
      const data = response?.data?.data;
      setData(data);
      setLoading(false)
    } catch (error: any) {
      console.log('Error fetching data employee');
      showToast('error', error);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        await Promise.all([getEmployeeList()]);
      } catch (err) {
        showToast('error', 'Failed to load initial data');
      }
    };
    fetchData();
  }, [params]);

  useEffect(() => {
    getItemOptions('master.contract-type', 'contractTypeId', setContractOptions);
    getItemOptions('master.job-position', 'posisionId', setRoleOptions);
    getItemOptions('master.placement-type', 'placementTypeId', setPlacementOptions);
    // getItemOptions('master.bank-placement', 'id', setBankOptions)
  }, []);

  // Sorting handler
  const handleSort = (column: keyof (typeof data.data)[0]) => {
    console.log('Column', column);
    setParams((prevParams) => {
      const currentSortKey = prevParams.sort.split(',')[0];
      const currentDirection = prevParams.sort.split(',')[1];

      const nextDirection =
        currentSortKey === column && currentDirection === 'asc'
          ? 'desc'
          : 'asc';

      return {
        ...prevParams,
        sort: `${column},${nextDirection}`,
      };
    });
  };

  // Filtering data
  // const filteredData = useMemo(() => {
  //   const validData = Array.isArray(data) ? data : [];

  //   return validData.filter((item) => {
  //     const matchSearch = `${item?.fullname}`
  //       .toLowerCase()
  //       .includes(searchValue.toLowerCase());
  //     const matchContract =
  //       !filters.contract ||
  //       item?.contractTypeName ===
  //         contractOptions.find((c) => c.id === filters.contract)?.value;
  //     const matchRole =
  //       !filters.role ||
  //       item?.positionName ===
  //         roleOptions.find((r) => r.id === filters?.role)?.value;
  //     const matchPlacement =
  //       !filters.placement ||
  //       item?.placementTypeName ===
  //         placementOptions.find((p) => p.id === filters?.placement)?.value;
  //     const matchBirthDate =
  //       !filters.dateOfBirth ||
  //       dayjs(item?.dateOfBirthStr).format('MM DD YYYY') ===
  //         filters?.dateOfBirth;
  //     const matchBank =
  //       !filters.bank ||
  //       item?.bankingPlacementName ===
  //         bankOptions.find((b) => b.id === filters?.bank)?.value;
  //     return (
  //       matchSearch &&
  //       matchContract &&
  //       matchRole &&
  //       matchPlacement &&
  //       matchBirthDate &&
  //       matchBank
  //     );
  //   });
  // }, [searchValue, filters, data]);

  // Pagination
  // const paginatedData = useMemo(() => {
  //   const startIndex = page * rowsPerPage;
  //   return filteredData.slice(startIndex, startIndex + rowsPerPage);
  // }, [filteredData, page, rowsPerPage]);

  // Handler
  const handleFilterChange =
    (filterName: string) => (event: React.SyntheticEvent, value: any) => {
      setParams({ ...params, page: 0, [filterName]: value });
    };

  const handleSearchChange = (value: string) => {
    setParams({ ...params, page: 0, search: value });
  };

  const handlePageChange = (event: unknown, newPage: number) => {
    setParams({ ...params, page: newPage - 1 });
  };

  const handleRowsPerPageChange = (value: number) => {
    setParams({ ...params, page: 0, size: value });
  };

  // data
  const columns = [
    {
      header: 'Employee',
      sortable: true,
      accessor: 'fullname',
      render: (row: any) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {row?.photoFileName ? (
            <ImageComponent
              src={row?.photoFilename}
              alt={`${row?.fullname}`}
              size={40}
            />
          ) : (
            <Avatar>{`${row?.fullname}`.charAt(0)}</Avatar>
          )}
          <HmTypography bold color="text.secondary">
            {`${row?.fullname}`}
          </HmTypography>
        </Box>
      ),
    },
    {
      header: 'Kontrak',
      sortable: true,
      accessor: 'contractTypeName',
      render: (row: any) => {
        const contractStyles = {
          'Full Time': {
            bgColor: 'rgb(227,242,250)',
            textColor: colors.palette.info,
          },
          Probation: {
            bgColor: 'rgb(228,247,231)',
            textColor: colors.palette.success,
          },
          OJT: {
            bgColor: 'rgb(255,246,227)',
            textColor: colors.palette.warning,
          },
          'Back to back': {
            bgColor: 'rgb(255,236,231)',
            textColor: colors.palette.orange,
          },
          Permanent: {
            bgColor: 'rgb(234,235,249)',
            textColor: colors.palette.primary,
          },
        };
        const { bgColor, textColor } = contractStyles[
          row?.contractTypeName as
          | 'Full Time'
          | 'Probation'
          | 'OJT'
          | 'Back to back'
          | 'Permanent'
        ] || {
          bgColor: 'rgb(207,208,218)',
          textColor: colors.palette.secondary,
        };
        return (
          <HmChip
            label={row?.contractTypeName}
            backgroundColor={bgColor}
            textColor={textColor}
            fontSize="14px"
            sx={{
              fontWeight: 600,
              height: '24px',
            }}
          />
        );
      },
    },
    {
      header: 'Jabatan',
      sortable: true,
      accessor: 'positionName',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row?.positionName}
        </HmTypography>
      ),
    },
    {
      header: 'Posisi',
      sortable: true,
      accessor: 'geographyName',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row?.geographyName}
        </HmTypography>
      ),
    },
    {
      header: 'Penempatan',
      sortable: true,
      accessor: 'placementTypeName',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row?.placementTypeName}
        </HmTypography>
      ),
    },
    {
      header: 'Ulang Tahun',
      sortable: true,
      accessor: 'dateOfBirthStr',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row?.dateOfBirthStr
            ? formatDate(new Date(row?.dateOfBirthStr))
            : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'Bank',
      sortable: true,
      accessor: 'bankingPlacementName',
      render: (row: any) => {
        const getBankIcon = (status: string) => {
          switch (status) {
            case 'Bersedia':
              return {
                icon: '/icons/check-succes.svg',
                tooltipMessage: 'Bersedia ditempatkan di bank',
              };
            case 'Tidak Bersedia':
              return {
                icon: '/icons/close-error.svg',
                tooltipMessage: 'Tidak bersedia ditempatkan di bank',
              };
            case 'Bersedia di bank/asuransi syariah':
              return {
                icon: '/icons/strip-green.svg',
                tooltipMessage: 'Bersedia Ditempatkan DiBank Syariah',
              };
            case 'Bersedia di bank selama tidak core banking & loan':
              return {
                icon: '/icons/strip-orange.svg',
                tooltipMessage:
                  'Bersedia dibank selama tidak core banking & loan',
              };
            default:
              return {
                icon: '/icons/close-error.svg',
                tooltipMessage: '',
              };
          }
        };

        const bankConfig = getBankIcon(row?.bankingPlacementName);

        return (
          <Tooltip
            title={
              <span style={{ fontSize: '12px' }}>
                {bankConfig.tooltipMessage}
              </span>
            }
            arrow
            placement="top"
          >
            <img
              src={bankConfig.icon}
              alt={bankConfig.tooltipMessage}
              width={24}
              height={24}
              style={{
                verticalAlign: 'middle',
              }}
            />
          </Tooltip>
        );
      },
    },
    {
      header: 'Aksi',
      accessor: 'partyId',
      render: (row: any) => (
        <Box sx={{ display: 'flex', gap: 1 }}>
          <HmButton
            icon={
              <img
                src="/icons/eyes.svg"
                alt="View Details"
                width={16}
                height={16}
              />
            }
            labelColor={colors.palette.primary}
            color="rgb(230, 242, 255)"
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
            onClick={(event) =>
              router.push(`/karyawan/detail-karyawan/${row?.partyId}`)
            }
          />
          <HmButton
            icon={
              <img
                src="/icons/whatsapp.svg"
                alt="WhatsApp"
                width={16}
                height={16}
              />
            }
            labelColor={colors.palette.primary}
            color="rgb(228,247,231)"
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
          />
        </Box>
      ),
    },
  ];

  return (
    <Box
      sx={{
        width: '100%',
        paddingX: isMobile ? 2 : 3,
        marginBottom: isMobile ? 2 : 3,
      }}
    >
      {/* filters */}
      <Box sx={{ marginTop: 2 }}>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmSearch
              searchValue={params?.search}
              onSearchChange={handleSearchChange}
              width="100%"
              size="medium"
              fullWidth
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={contractOptions}
              value={params?.contract}
              onChange={handleFilterChange('contract')}
              label="Kontrak"
              placeholder="Cari Kontrak"
              width="100%"
              size="medium"
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={roleOptions}
              value={params?.role}
              onChange={handleFilterChange('role')}
              label="Jabatan"
              placeholder="Cari jabatan"
              width="100%"
              size="medium"
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={placementOptions}
              value={params?.placement}
              onChange={handleFilterChange('placement')}
              label="Penempatan"
              placeholder="Cari penempatan"
              width="100%"
              size="medium"
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                label="Ulang Tahun"
                sx={{
                  width: '100%',
                  borderRadius: 10,
                }}
                onChange={(newValue) => {
                  const formattedDate = dayjs(newValue).format('D MMM YYYY');
                  // handleFilterChange('dateOfBirth')(formattedDate);
                  console.log(formattedDate);
                }}
              />
            </LocalizationProvider>
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={bankOptions}
              value={params?.bank}
              onChange={handleFilterChange('bank')}
              label="Bank/insurance"
              placeholder="Bank/insurance"
              width="100%"
              size="medium"
            />
          </Grid>
        </Grid>
      </Box>

      {/* data table */}
      <Box
        sx={{
          overflowX: 'auto',
          marginTop: '1rem',
        }}
      >
        <HmTable
          minWidth={1000}
          data={data?.data}
          columns={columns}
          loading={loading}
          page={params?.page}
          rowsPerPage={params?.size}
          totalItems={data?.recordsTotal}
          onPageChange={handlePageChange}
          handleRowsPerPageChange={handleRowsPerPageChange}
          showNumberColumn={false}
          onSort={(column) => handleSort(column as keyof (typeof data.data)[0])}
        />
      </Box>
    </Box>
  );
};

export default Karyawan;
