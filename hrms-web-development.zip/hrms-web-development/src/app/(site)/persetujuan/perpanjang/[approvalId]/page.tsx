'use client';

import { MdOutlineRemoveRedEye } from 'react-icons/md';
import DownloadIcon from '@mui/icons-material/Download';
import React, { useEffect, useState } from 'react';
import {
  HmButton,
  HmTable,
  HmTypography,
  HmChip,
  HmModal,
  HmTextField,
} from '@/components/component';
import { Container, Box, Grid2, Button, List, ListItem } from '@mui/material';
import FormatListNumberedIcon from '@mui/icons-material/FormatListNumbered';
import theme from '@/utils/theme';
import colors from '@/components/colors';
import { API } from '@/services/setupAxios';
import { useParams } from 'next/navigation';
import { formatDate } from '@/utils/date-formatter';
import { formatRupiah } from '@/utils/rupiah-formatter';
import { useToast } from '@/context/toastContext';

// HmTable

interface ContractDataDetail {
  approvalId: string;
  employeeDetail: {
    id: string;
    fullName: string;
    date: string;
  };
  contractInfo: {
    status: string;
    placementType: string;
    employeeType: string;
    bankPlacement: string;
    division: string;
    position: string;
    contractStartDate: string;
    contractEndDate: string;
    generation: string;
    document: {
      index: number; // tambahan untuk unique key
      name: string;
      url: string;
      date: string;
    }[];
    salary: number;
  };
  placementAllowance: {
    index: number; // tambahan untuk unique key
    allowanceType: string;
    amount: number;
  }[];
  otherAllowance: {
    index: number; // tambahan untuk unique key
    allowanceType: string;
    amount: number;
  }[];
}

interface HistoryContractEmployeeData {
  contract: string;
  contractDocument: string; // url minio
  startDate: string;
  endDate: string;
  bankInsuranceAgreement: string;
  placement: string;
  allowanceGroups: {
    groupName: string;
    allowances: {
      allowance_id: string;
      allowance_type: string;
      amount: number;
    }[];
  }[];
}

const Perpanjangan = () => {
  const params = useParams();
  const approvalId = params.approvalId;
  const { showToast } = useToast();
  // HmTable
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const handlePageChange = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleRowsPerPageChange = (value: number) => {
    setRowsPerPage(value);
  };

  // modal history contract
  const [openHistory, setOpenHistory] = useState(false);

  const handleOpenHistory = () => {
    setOpenHistory(true);
  };

  const handleClose = () => {
    setOpenHistory(false);
  };

  // modal allowances
  const [openAllowances, setOpenAllowances] = useState(false);
  const handleOpenAllowances = (allowances: any) => {
    handleAllowancesFromHistory(allowances);
    setOpenAllowances(true);
  };

  //modal approve
  const [openApprove, setOpenApprove] = useState(false);

  const handleOpenApprove = () => setOpenApprove(true);
  const handleCloseApprove = () => setOpenApprove(false);

  //modal reject
  const handleInputChange = (value: string) => {
    setRejectReason(value);
    setIsDisableButton(value.trim() === '');
  };

  const [openReject, setOpenReject] = useState(false);
  const [isDisableButton, setIsDisableButton] = useState(true);
  const [rejectReason, setRejectReason] = useState('');

  const handleOpenReject = () => setOpenReject(true);
  const handleCloseReject = () => setOpenReject(false);

  // API

  // Get Approval Detail Data
  const [approvalDetailData, setApprovalDetailData] =
    useState<ContractDataDetail>();
  const getApprovalDetailData = async () => {
    try {
      const response = await API('approval.detailPerpanjangKontrak', {
        query: { 'approval-id': approvalId },
      });

      if (response.status === 200) {
        setApprovalDetailData(mappingNewField(response.data.data));
        console.log('Detail Data', response.data.data);
      }
    } catch (error: any) {
      console.log('API ERROR', error);
    }
  };

  const mappingNewField = (data: ContractDataDetail) => {
    // Menambahkan nomor urut ke placementAllowance dan otherAllowance
    const placementAllowanceWithIndex = data.placementAllowance.map(
      (item: any, index: number) => ({
        ...item,
        index: index + 1,
      })
    );

    const otherAllowanceWithIndex = data.otherAllowance.map(
      (item: any, index: number) => ({
        ...item,
        index: index + 1,
      })
    );

    //
    const documentWithIndex = data.contractInfo.document.map(
      (item: any, index: number) => ({
        ...item,
        index: index + 1,
      })
    );

    data.placementAllowance = placementAllowanceWithIndex;
    data.otherAllowance = otherAllowanceWithIndex;
    data.contractInfo.document = documentWithIndex;
    return data;
  };

  // Post Approve
  const postApprove = async () => {
    try {
      const response = await API('approval.approveKontrak', {
        query: { 'approval-id': approvalId },
      });

      if (response.status === 200) {
        console.log('API approve response', response);
        showToast('success', response.data.message);
        setOpenApprove(false);
      }
    } catch (error: any) {
      console.log('API ERROR', error);
      showToast('error', error.response.data.message);
    }
  };

  const handlePostApprove = () => {
    postApprove();
  };

  // Post Reject
  const postReject = async () => {
    try {
      const response = await API('approval.rejectKontrak', {
        query: { 'approval-id': approvalId },
        data: {
          reason: rejectReason,
        },
      });

      if (response.status === 200) {
        console.log('API reject response', response);
        showToast('success', response.data.message);
        setOpenReject(false);
      }
    } catch (error: any) {
      console.log('API ERROR', error);
      showToast('error', error.response.data.message);
    }
  };

  const handlePostReject = () => {
    postReject();
  };

  // Get History Contract
  const [historyContractEmployeeData, setHistoryContractEmployeeData] =
    useState<HistoryContractEmployeeData[]>([]);
  const getHistoryContractIdEmployeeData = async () => {
    try {
      const response = await API(
        'employeeManagement.historyContractListByIdEmployee',
        {
          query: { employee_id: approvalDetailData?.employeeDetail.id },
        }
      );
      setHistoryContractEmployeeData(response.data.data);

      console.log('History Contract', response);
    } catch (error: any) {
      console.log('History Contract ERROR', error);
    }
  };

  // allowances on modal for history contract modal
  const [allowancesFromHistory, setAllowancesFromHistory] = useState<any>();
  const handleAllowancesFromHistory = (data: any) => {
    const placementAllowanceWithIndex = data[0].allowances.map(
      (item: any, index: number) => ({
        ...item,
        placementType: item.allowanceType,
        index: index + 1, // Menambahkan nomor urut mulai dari 1
      })
    );

    const otherAllowanceWithIndex = data[1].allowances.map(
      (item: any, index: number) => ({
        ...item,
        placementType: item.allowanceType,
        index: index + 1, // Menambahkan nomor urut mulai dari 1
      })
    );

    // Hasil baru setelah penambahan
    data[0] = placementAllowanceWithIndex;
    data[1] = otherAllowanceWithIndex;
    setAllowancesFromHistory(data);
  };

  useEffect(() => {
    getApprovalDetailData();
    console.log('Approval Task ID:', approvalId);
  }, []);

  useEffect(() => {
    if (approvalDetailData?.employeeDetail.id) {
      getHistoryContractIdEmployeeData();
    }
  }, [approvalDetailData]);

  useEffect(() => {
    if (rejectReason === '') {
      setIsDisableButton(true);
    } else if (rejectReason !== '') {
      setIsDisableButton(false);
    }
  }, [rejectReason]);

  // colums for allowances on detail page
  const columns = [
    {
      header: 'No',
      accessor: 'index',
      render: (row: any) => (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            width: '50px',
            maxWidth: '50px',
          }}
        >
          <HmTypography semiBold small>
            {row.index}
          </HmTypography>
        </div>
      ),
    },
    {
      header: 'Jenis Tunjangan',
      accessor: 'placementType',
      render: (row: any) => (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            width: '600px',
            maxWidth: '600px',
          }}
        >
          <HmTypography semiBold small>
            {row.placementType}
          </HmTypography>
        </div>
      ),
    },
    {
      header: 'Nominal',
      accessor: 'amount',
      render: (row: any) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <HmTypography semiBold small>
            {row.amount ? 'Rp ' + formatRupiah(row.amount) : '-'}
          </HmTypography>
        </div>
      ),
    },
  ];

  // modal history contract
  const columns2 = [
    {
      header: 'KONTRAK',
      accessor: 'kontrak',
      render: (row: any) => {
        // Menentukan warna berdasarkan jenis kontrak
        let chipStyle = {};
        if (row.kontrak === 'Fulltime') {
          chipStyle = {
            color: theme.palette.info.main, // Teks warna info
            backgroundColor: theme.palette.info.light, // Background warna info
          };
        } else if (row.kontrak === 'Probation') {
          chipStyle = {
            color: theme.palette.success.main, // Teks warna success
            backgroundColor: theme.palette.success.light, // Background warna success
          };
        } else {
          chipStyle = {
            color: theme.palette.warning.main, // Teks warna warning
            backgroundColor: theme.palette.warning.light, // Background warna warning
          };
        }

        return <HmChip label={row.contract} sx={chipStyle} />;
      },
    },
    {
      header: 'ACTION',
      accessor: 'action',
      render: (row: any) => (
        <div style={{ margin: '10px', display: 'flex', gap: '10px' }}>
          <HmButton
            icon={<MdOutlineRemoveRedEye />}
            labelColor={theme.palette.info.main}
            color={theme.palette.info.light}
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
            onClick={() => {
              const url = row.contractDocument;
              if (!url) {
                showToast('error', 'URL Dokumen tidak tersedia.');
                return;
              }

              const link = document.createElement('a');
              link.href = url; // URL file dari MinIO
              link.target = '_blank'; // Untuk membuka file di tab baru (opsional)
              document.body.appendChild(link); // Tambahkan ke DOM sementara
              link.click(); // Trigger klik untuk memulai download
              document.body.removeChild(link); // Hapus elemen setelah selesai
            }}
          />
          <HmButton
            icon={<DownloadIcon sx={{ color: 'white' }}></DownloadIcon>}
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
            color={theme.palette.primary.main}
            borderRadius="10"
            onClick={() => {
              const url = row.contractDocument;
              if (!url) {
                showToast('error', 'URL Dokumen tidak tersedia.');
                return;
              }

              fetch(url) // Pastikan URL file dapat diakses
                .then(response => {
                  if (!response.ok) {
                    throw new Error('Gagal mengunduh dokumen.');
                  }
                  return response.blob();
                })
                .then(blob => {
                  const link = document.createElement('a');
                  const blobUrl = window.URL.createObjectURL(blob);
                  link.href = blobUrl;
                  link.download = url.split('/').pop() || 'default_filename.pdf'; // Nama file unduhan
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  window.URL.revokeObjectURL(blobUrl); // Bersihkan URL Blob setelah selesai
                })
                .catch(error => {
                  console.error('Error saat mengunduh dokumen:', error);
                });
            }}
          />
        </div>
      ),
    },
    {
      header: 'START',
      accessor: 'startDate',
      render: (row: any) => (
        <HmTypography small color="#5D6283">
          {row.startDate}
        </HmTypography>
      ),
    },
    {
      header: 'END',
      accessor: 'endDate',
      render: (row: any) => (
        <HmTypography small color="#5D6283">
          {row.endDate}
        </HmTypography>
      ),
    },
    {
      header: 'GAJI POKOK',
      accessor: 'salary',
      render: (row: any) => (
        <HmTypography small color="#5D6283">
          {row.salary ? 'Rp ' + formatRupiah(row.salary) : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'BANK/INSURANCE',
      accessor: 'bankPlacement',
      render: (row: any) => {
        const getIcon = (status: string) => {
          switch (status) {
            case 'Tidak Bersedia':
              return {
                icon: '/icons/close-error.svg',
              };
            case '':
              return {
                icon: '/icons/strip-green.svg',
              };
            default:
              return {
                icon: '/icons/check-succes.svg',
              };
          }
        };

        const statusConfig = getIcon(row?.bankInsuranceAgreement);
        return (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <img alt="" src={statusConfig.icon} width={20} height={20} />
          </Box>
        );
      },
    },
    {
      header: 'PENEMPATAN',
      accessor: 'placement',
      render: (row: any) => (
        <HmTypography small color="#5D6283">
          {row.placement}
        </HmTypography>
      ),
    },
    {
      header: 'TUNJANGAN',
      accessor: 'allowanceGroups',
      render: (row: any) => (
        <div style={{ display: 'flex' }}>
          <HmButton
            icon={<MdOutlineRemoveRedEye />}
            labelColor={theme.palette.info.main}
            color={theme.palette.info.light}
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
            onClick={() => handleOpenAllowances(row.allowanceGroups)}
          />
        </div>
      ),
    },
  ];

  return (
    <Container maxWidth="lg">
      <Box sx={{ paddingY: '20px' }}>
        <HmTypography sx={{ color: 'text.secondary' }}>
          DATA PENGAJUAN
        </HmTypography>
        <Grid2 container sx={{ padding: '20px' }}>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.fullName}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Pengajuan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.date
                    ? formatDate(
                        new Date(approvalDetailData?.employeeDetail?.date)
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  History Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <Button
                  onClick={handleOpenHistory}
                  variant="outlined"
                  color="warning"
                  startIcon={<FormatListNumberedIcon />}
                >
                  <HmTypography>History Kontrak</HmTypography>
                </Button>
              </ListItem>
            </List>
          </Grid2>
        </Grid2>
      </Box>
      <Box sx={{ paddingY: '20px' }}>
        <HmTypography sx={{ color: 'text.secondary' }}>
          INFORMASI KONTRAK
        </HmTypography>
        <Grid2 container sx={{ padding: '20px' }}>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.status}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jenis Penempatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.placementType}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jenis Karyawan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.employeeType}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Bersedia Ditempatkan di Bank/Insurance
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.bankPlacement}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.division}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.position}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Mulai Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractStartDate
                    ? formatDate(
                        new Date(
                          approvalDetailData?.contractInfo?.contractStartDate
                        )
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Akhir Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractEndDate
                    ? formatDate(
                        new Date(
                          approvalDetailData?.contractInfo?.contractEndDate
                        )
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Generasi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.generation}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              {Array.isArray(approvalDetailData?.contractInfo?.document) &&
                approvalDetailData.contractInfo.document.map((row, index) => (
                  <Box key={row.index}>
                    <ListItem>
                      <HmTypography sx={{ color: 'text.secondary' }} semiBold>
                        {row.name + ' (' + formatDate(new Date(row.date)) + ')'}
                      </HmTypography>
                    </ListItem>
                    <ListItem>
                      <HmButton
                        label={'Download Dokumen'}
                        labelColor="white"
                        sx={{ paddingX: '12px', paddingY: '6px' }}
                        onClick={() => {
                          const url = row.url;
                          if (!url) {
                            showToast('error', 'URL Dokumen tidak tersedia.')
                            return;
                          }
            
                          fetch(url) // Pastikan URL file dapat diakses
                            .then(response => {
                              if (!response.ok) {
                                throw new Error('Gagal mengunduh dokumen.');
                              }
                              return response.blob();
                            })
                            .then(blob => {
                              const link = document.createElement('a');
                              const blobUrl = window.URL.createObjectURL(blob);
                              link.href = blobUrl;
                              link.download = url.split('/').pop() ?? 'default_filename.pdf'; // Nama file unduhan
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                              window.URL.revokeObjectURL(blobUrl); // Bersihkan URL Blob setelah selesai
                            })
                            .catch(error => {
                              console.error('Error saat mengunduh dokumen:', error);
                            });
                        }}
                      />
                      <HmButton
                        icon={<MdOutlineRemoveRedEye size={16} />}
                        labelColor={theme.palette.info.main}
                        color={theme.palette.info.light}
                        borderRadius="10"
                        sx={{
                          marginX: '8px',
                          minWidth: '38px',
                          width: '38px',
                          height: '38px',
                        }}
                        onClick={() => {
                          const url = row.url;
                          if (!url) {
                            showToast('error', 'URL Dokumen tidak tersedia.')
                            return;
                          }
                          const link = document.createElement('a');
                          link.href = url; // URL file dari MinIO
                          link.target = '_blank'; // Untuk membuka file di tab baru (opsional)
                          document.body.appendChild(link); // Tambahkan ke DOM sementara
                          link.click(); // Trigger klik untuk memulai download
                          document.body.removeChild(link); // Hapus elemen setelah selesai
                        }}
                      />
                    </ListItem>
                  </Box>
                ))}
            </List>
          </Grid2>
          <Grid2 size={{ sm: 6 }}></Grid2>
        </Grid2>
      </Box>
      <Box>
        <HmTypography sx={{ marginBottom: '8px', color: 'text.secondary' }}>
          GAJI POKOK & TUNJANGAN
        </HmTypography>

        {/* Tabel: Tunjangan Penempatan */}
        <Grid2 container spacing={'20px'} sx={{ padding: '40px' }}>
          <Grid2 size={{ xs: 12, sm: 12 }}>
            <HmTypography
              variant="body2"
              sx={{ marginBottom: '8px', color: 'text.secondary' }}
            >
              Tunjangan Penempatan
            </HmTypography>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 12 }} sx={{ paddingX: '16px' }}>
            <HmTable
              data={approvalDetailData?.placementAllowance ?? []}
              columns={columns}
              loading={loading}
              page={page}
              rowsPerPage={rowsPerPage}
              totalItems={approvalDetailData?.placementAllowance?.length ?? 0}
              onPageChange={handlePageChange}
              handleRowsPerPageChange={handleRowsPerPageChange}
            />
          </Grid2>

          {/* Tabel: Tunjangan Lain-lain */}
          <Grid2 size={{ xs: 12, sm: 12 }}>
            <HmTypography
              variant="body2"
              sx={{ marginBottom: '8px', color: 'text.secondary' }}
            >
              Tunjangan Lain-lain
            </HmTypography>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 12 }} sx={{ paddingX: '16px' }}>
            <HmTable
              data={approvalDetailData?.otherAllowance ?? []}
              columns={columns}
              loading={loading}
              page={page}
              rowsPerPage={rowsPerPage}
              totalItems={approvalDetailData?.otherAllowance?.length ?? 0}
              onPageChange={handlePageChange}
              handleRowsPerPageChange={handleRowsPerPageChange}
            />
          </Grid2>
        </Grid2>
      </Box>

      {/* Action Buttons */}
      <Box
        sx={{
          paddingY: '24px',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '8px',
        }}
      >
        <HmButton
          color={'white'}
          borderColor="#5557CD"
          label="Batal"
          labelColor="#5557CD"
        />
        <HmButton
          icon={
            <img
              src="/icons/reject-resign-icon.svg"
              alt="reject perpanjang icon"
            />
          }
          onClick={handleOpenReject}
          color={theme.palette.error.main}
          label="Reject"
          labelColor="white"
        />
        <HmButton
          icon={
            <img
              src="/icons/approve-resign-icon.svg"
              alt="approve perpanjang icon"
            />
          }
          onClick={handleOpenApprove}
          color={theme.palette.success.main}
          label="Approve Karyawan"
          labelColor="white"
        />
      </Box>

      {/* Modal History */}
      <HmModal
        isOpen={openHistory}
        onClose={handleClose}
        title={
          'Histori Kontrak - ' + approvalDetailData?.employeeDetail?.fullName
        }
        zIndex={1}
        maxWidth="lg"
      >
        <HmTable
          data={historyContractEmployeeData ?? []}
          columns={columns2}
          loading={loading}
          page={page}
          rowsPerPage={rowsPerPage}
          totalItems={historyContractEmployeeData?.length}
          onPageChange={handlePageChange}
          handleRowsPerPageChange={handleRowsPerPageChange}
        />
      </HmModal>

      {/* Modal Allowances */}
      <HmModal
        isOpen={openAllowances}
        onClose={() => setOpenAllowances(false)}
        title={'Allowances'}
        zIndex={2}
        maxWidth="lg"
      >
        <Box>
          {/* Tabel: Tunjangan Penempatan */}
          <Grid2 container spacing={'20px'} sx={{ padding: '40px' }}>
            <Grid2 size={{ xs: 12, sm: 12 }}>
              <HmTypography
                variant="body2"
                sx={{ marginBottom: '8px', color: 'text.secondary' }}
              >
                Tunjangan Penempatan
              </HmTypography>
            </Grid2>
            <Grid2 size={{ xs: 12, sm: 12 }} sx={{ paddingX: '16px' }}>
              <HmTable
                data={allowancesFromHistory?.[0] ?? []}
                columns={columns}
                loading={loading}
                page={page}
                rowsPerPage={rowsPerPage}
                totalItems={allowancesFromHistory?.[0].length}
                onPageChange={handlePageChange}
                handleRowsPerPageChange={handleRowsPerPageChange}
              />
            </Grid2>

            {/* Tabel: Tunjangan Lain-lain */}
            <Grid2 size={{ xs: 12, sm: 12 }}>
              <HmTypography
                variant="body2"
                sx={{ marginBottom: '8px', color: 'text.secondary' }}
              >
                Tunjangan Lain-lain
              </HmTypography>
            </Grid2>
            <Grid2 size={{ xs: 12, sm: 12 }} sx={{ paddingX: '16px' }}>
              <HmTable
                data={allowancesFromHistory?.[1] ?? []}
                columns={columns}
                loading={loading}
                page={page}
                rowsPerPage={rowsPerPage}
                totalItems={allowancesFromHistory?.[1].length}
                onPageChange={handlePageChange}
                handleRowsPerPageChange={handleRowsPerPageChange}
              />
            </Grid2>
          </Grid2>
        </Box>
      </HmModal>

      {/* Modal Reject */}
      <HmModal
        isOpen={openReject}
        onClose={handleCloseReject}
        title="Reject Karyawan"
        zIndex={1}
        isAction={true}
        labelAction="Reject"
        onClickAction={handlePostReject}
        colorActionButton={
          isDisableButton ? colors.palette.greyPrimary : colors.palette.primary
        }
        isDisableButton={isDisableButton}
        maxWidth="sm"
      >
        <Grid2 container>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.fullName}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.status}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.division}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.position}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Mulai Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractStartDate
                    ? formatDate(
                        new Date(
                          approvalDetailData?.contractInfo?.contractStartDate
                        )
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Akhir Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractEndDate
                    ? formatDate(
                        new Date(
                          approvalDetailData?.contractInfo?.contractEndDate
                        )
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 12 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Alasan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTextField
                  placeholder="Placeholder text"
                  value={rejectReason}
                  onChange={handleInputChange}
                />
              </ListItem>
            </List>
          </Grid2>
        </Grid2>
      </HmModal>

      {/* Modal Approve*/}
      <HmModal
        isOpen={openApprove}
        onClose={handleCloseApprove}
        title="Approve Karyawan"
        zIndex={2}
        isAction={true}
        onClickAction={handlePostApprove}
        labelAction="Approve Karyawan"
        colorActionButton={colors.palette.success}
        isIconActionButton={true}
        maxWidth="md"
      >
        <Grid2 container>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.fullName}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.status}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.division}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.position}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Mulai Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractStartDate
                    ? formatDate(
                        new Date(
                          approvalDetailData?.contractInfo?.contractStartDate
                        )
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
          <Grid2 size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Akhir Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractEndDate
                    ? formatDate(
                        new Date(
                          approvalDetailData?.contractInfo?.contractEndDate
                        )
                      )
                    : '-'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid2>
        </Grid2>
      </HmModal>
    </Container>
  );
};

export default Perpanjangan;
