'use client';

import React, { useEffect, useState } from 'react';
import {
  HmAutoComplete,
  HmButton,
  HmChip,
  HmSearch,
  HmTable,
  HmTypography,
} from '@/components/component';
import { Avatar, Box, useMediaQuery, useTheme } from '@mui/material';
import Grid from '@mui/material/Grid2';
import ImageComponent from '@/components/component/HmCircleImage';
import colors from '@/components/colors';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import { useRouter } from 'next/navigation';
import { API } from '@/services/setupAxios';
import { formatDate } from '@/utils/date-formatter';

interface DataRow {
  draw: number;
  recordsTotal: number;
  recordsFiltered: number;
  data: {
    partyId: string;
    photoFilename: string;
    fullname: string;
    contractTypeId: number;
    contractTypeName: string;
    approvalTypeId: number;
    approvalTypeName: string;
    startDateStr: string;
    endDateStr: string;
    stage: string;
    approvalId: string;
    approvaTasklId: string;
  }[]
}

interface ContractType {
  id: number,
  value: string
}

const Persetujuan = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const router = useRouter();

  const [data, setData] = useState<DataRow>({
    draw: 0,
    recordsTotal: 0,
    recordsFiltered: 0,
    data: [
      {
        partyId: '',
        photoFilename: '',
        fullname: '',
        contractTypeId: 1,
        contractTypeName: '',
        approvalTypeId: 0,
        approvalTypeName: '',
        startDateStr: '',
        endDateStr: '',
        stage: '',
        approvalId: '',
        approvaTasklId: ''
      }
    ]
  });

  // Filter
  const handleSort = (column: keyof typeof data.data[0]) => {
    console.log("Column", column)
    setParams((prevParams) => {
      const currentSortKey = prevParams.sort.split(',')[0];
      const currentDirection = prevParams.sort.split(',')[1];
  
      const nextDirection =
        currentSortKey === column && currentDirection === 'asc'
          ? 'desc'
          : 'asc';
  
      return {
        ...prevParams,
        sort: `${column},${nextDirection}`,
      };
    });
  };
  
  const [contractOptions, setContractOptions] = useState<ContractType[]>([]);

  // API
  const [params, setParams] = useState({
    page: 0,
    size: 10,
    contract: null,
    search: '',
    sort: ''
  })

  const getApprovalList = async () => {
    try {
      const response = await API('approval.list', {
        params
      })
      setData(response.data.data)
      console.log("Approval List:", response)
    } catch (error : any) {
      if(error.data.message === 'Not found'){
        setData((prev)=>({
          ...prev,
          data: []
        }))
      }
      console.log("Approval list ERROR:", error)
    }
  }

  const getMasterContractType = async () => {
    try {
      const response = await API('master.contract-type')
      const mappedContractOptions: ContractType[] = response.data.data.map((item:any)=>({
        id: item.contractTypeId,
        value: item.name
      }))
      setContractOptions(mappedContractOptions)
      // console.log("Contract Type:", mappedContractOptions)
    } catch (error : any) {
      console.log("Contract Type ERROR", error)
    }
  }

  useEffect(()=> {
    getApprovalList()
    console.log("params:", params)
  }, [params])

  useEffect(()=>{
    getMasterContractType()
  }, [])

  // Handler
  const handleFilterChange =
    (filterName: string) => (event: React.SyntheticEvent, value: any) => {
      setParams({...params, page: 0, [filterName]: value})
    };

  const handleSearchChange = (value: string) => {
    setParams({...params, page: 0, search: value});
  };

  const handlePageChange = (event: unknown, newPage: number) => {
    setParams({...params, page: newPage-1})
  };

  const handleRowsPerPageChange = (value: number) => {
    setParams({...params, page: 0, size: value})
  };

  // untuk pindah ke detail. Tunggu API approval list sama dropdown nya
  const handleDetail = (approvalTypeId: number, approvalTaskId?: string) => {
    if (approvalTypeId === 1) {
      router.push(`/persetujuan/karyawan-baru/${approvalTaskId}`);
    } 
    else if (approvalTypeId === 2) {
      router.push(`/persetujuan/perpanjang/${approvalTaskId}`);
    } 
    else {
      router.push(`/persetujuan/resign/${approvalTaskId}`);      
    }
  };

  // data
  const columns = [
    {
      header: 'Employee',
      sortable: true,
      accessor: 'fullname',
      render: (row: any) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {row.profileImage ? (
            <ImageComponent
              src={row.photoFilename}
              alt={row.fullname}
              size={40}
            />
          ) : (
            <Avatar>{`${row.firstName} ${row.lastName}`.charAt(0)}</Avatar>
          )}
          <HmTypography bold color="text.secondary">
            {row.fullname}
          </HmTypography>
        </Box>
      ),
    },
    {
      header: 'Kontrak',
      sortable: true,
      accessor: 'contractTypeName',
      render: (row: any) => {
        const contractStyles = {
          'Full Time': {
            bgColor: 'rgb(227,242,250)',
            textColor: colors.palette.info,
          },
          Probation: {
            bgColor: 'rgb(228,247,231)',
            textColor: colors.palette.success,
          },
          OJT: {
            bgColor: 'rgb(255,246,227)',
            textColor: colors.palette.warning,
          },
          'Back to back': {
            bgColor: 'rgb(255,236,231)',
            textColor: colors.palette.orange,
          },
          Permanent: {
            bgColor: 'rgb(234,235,249)',
            textColor: colors.palette.primary,
          },
        };
        const { bgColor, textColor } = contractStyles[
          row.contractTypeName as
            | 'Full Time'
            | 'Probation'
            | 'OJT'
            | 'Back to back'
            | 'Permanent'
        ] || {
          bgColor: 'rgb(207,208,218)',
          textColor: colors.palette.secondary,
        };
        return (
          <HmChip
            label={row.contractTypeName}
            backgroundColor={bgColor}
            textColor={textColor}
            fontSize="14px"
            sx={{
              fontWeight: 600,
              height: '24px',
            }}
          />
        );
      },
    },
    {
      header: 'Start',
      sortable: true,
      accessor: 'startDateStr',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.startDateStr? formatDate(new Date(row.startDateStr)) : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'End',
      sortable: true,
      accessor: 'endDateStr',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.endDateStr? formatDate(new Date(row.endDateStr)) : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'Tahapan',
      sortable: true,
      accessor: 'stage',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.stage? row.stage : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'Keterangan',
      sortable: true,
      accessor: 'description',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.approvalTypeName? row.approvalTypeName : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'Aksi',
      accessor: (row: any) => (
        <Box sx={{ display: 'flex', gap: 1 }}>
          <HmButton
            icon={<MdOutlineRemoveRedEye size={17} />}
            label={
              <HmTypography color="text.main" sx={{ marginLeft: 1 }}>
                Detail
              </HmTypography>
            }
            labelColor={colors.palette.primary}
            color="rgb(230, 242, 255)"
            borderRadius="10"
            sx={{
              minWidth: '28px',
            }}
            onClick={() => handleDetail(row.approvalTypeId, row.approvalTaskId)}
          />
        </Box>
      ),
    },
  ];

  return (
    <Box
      sx={{
        width: '100%',
        paddingX: isMobile ? 2 : 3,
        marginBottom: isMobile ? 2 : 3,
      }}
    >
      {/* filters */}
      <Box sx={{ marginTop: 2 }}>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmSearch
              searchValue={params.search}
              onSearchChange={handleSearchChange}
              width="100%"
              size="medium"
              fullWidth
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={contractOptions}
              value={params.contract}
              onChange={handleFilterChange('contract')}
              label="Kontrak"
              placeholder="Pilih Jenis Kontrak"
              width="100%"
              size="medium"
            />
          </Grid>
        </Grid>
      </Box>

      {/* data table */}
      <Box
        sx={{
          marginTop: '1rem',
          overflowX: 'auto',
        }}
      >
        <HmTable
          minWidth={1000}
          data={data.data}
          columns={columns}
          page={params.page}
          rowsPerPage={params.size}
          totalItems={data.recordsTotal}
          onPageChange={handlePageChange}
          handleRowsPerPageChange={handleRowsPerPageChange}
          showNumberColumn={false}
          loading={false}
          onSort={(column) => handleSort(column as keyof typeof data.data[0])}
        />
      </Box>
    </Box>
  );
};

export default Persetujuan;
