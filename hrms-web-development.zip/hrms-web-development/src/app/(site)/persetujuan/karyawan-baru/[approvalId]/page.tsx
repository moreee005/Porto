'use client';

import React, { useEffect, useState } from 'react';
import { Box } from '@mui/material';
import {
  HmButton,
  HmModal,
  HmTextField,
  HmTypography,
} from '@/components/component';
import colors from '@/components/colors';
import { MdKeyboardArrowLeft } from 'react-icons/md';
import { useParams, useRouter } from 'next/navigation';
import Grid from '@mui/material/Grid2';
import HmStepper from '@/components/component/HmStepper';
import IdentitasDiri from '@/components/section/karyawan-baru/IdentitasDiri';
import InformasiKontrak from '@/components/section/karyawan-baru/InformasiKontrak';
import DataKependudukan from '@/components/section/karyawan-baru/DataKependudukan';
import UnggahDokumen from '@/components/section/karyawan-baru/UnggahDokumen';
import { API } from '@/services/setupAxios';
import { useToast } from '@/context/toastContext';
import { steps } from '@/components/section/form-karyawan/data-and-validation/form-data';

const KaryawanBaru = () => {
  const router = useRouter();
  const { showToast } = useToast();
  const { approvalId } = useParams();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [openModalApprove, setOpenModalApprove] = useState(false);
  const [openModalReject, setOpenModalReject] = useState(false);
  const [formDataKaryawanBaru, setFormDataKaryawanBaru] = useState({});
  const [isCompletedDoc, setIsCompletedDoc] = useState(false)
  const [reason, setReason] = React.useState('');
  const [modalContent, setModalContent] = useState<{
    id: number;
    label: string;
    value: string;
  }[]>([]);

  const NewEmployeeApproval = async () => {
    try {
      const response = await API('approval.detail', {
        query: { id: approvalId },
      });
      const data = response.data.data;

      setFormDataKaryawanBaru(data);
      const modalContentData = [
        { id: 1, label: 'Nama Lengkap', value: data.fullname },
        { id: 2, label: 'Divisi', value: data.divisionName },
        { id: 3, label: 'Tanggal Mulai Masuk Kontrak', value: data.contractInformation.contractStartDate },
        { id: 4, label: 'Status Kontrak', value: data.contractInformation.statusName },
        { id: 5, label: 'Jabatan', value: data.contractInformation.jobPositionName },
        { id: 6, label: 'Tanggal Akhir Masuk Kontrak', value: data.contractInformation.contractEndDate },
      ];
      setModalContent(modalContentData);
    } catch (error) {
      console.error("Error fetching employee details:", error);
      showToast('error', (error as Error).message);
    }
  };

  useEffect(() => {
    NewEmployeeApproval();
  }, [approvalId]);


  if (!formDataKaryawanBaru) {
    return <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100vh',
      }}
    >
      <Box sx={{ display: 'flex', justifyContent: 'center' }}>
        <HmTypography>Data Not found</HmTypography>
      </Box>
    </Box>
  }

  const handleAllDocsChecked = () => {
    setIsCompletedDoc(true);
    console.log('All documents checked. Proceeding...');
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return <IdentitasDiri formDataKaryawanBaru={formDataKaryawanBaru} />;
      case 1:
        return <InformasiKontrak formDataKaryawanBaru={formDataKaryawanBaru} />;
      case 2:
        return <DataKependudukan formDataKaryawanBaru={formDataKaryawanBaru} />;
      case 3:
        return <UnggahDokumen formDataKaryawanBaru={formDataKaryawanBaru} onAllDocsChecked={handleAllDocsChecked} />;
      default:
        return null;
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleCancel = () => {
    router.back();
  };

  const handleNext = async () => {
    try {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        if (activeStep === steps.length - 1) {
          setOpenModalApprove(true);
          console.log('Modal open ');
        } else {
          setActiveStep((prev) => prev + 1);
        }
      }, 1500);
    } catch (error) {
      console.error('Error():', error);
    }
  };

  const handleReject = () => {
    setOpenModalReject(true);
  }

  const onClose = () => {
    console.log('Modal closed');
    setOpenModalApprove(false);
    setOpenModalReject(false);
  };


  const handleApproveEmployee = async () => {
    console.log('approve employee');
    setOpenModalApprove(false);

    try {
      const response = await API('approval.approveKontrak', {
        query: { 'approval-id': approvalId },
      });
      console.log("API response", response);
      showToast('success', "Persetujuan Berhasil Disetujui");
      router.push('/persetujuan');
    } catch (error) {
      console.error("Error approve employee :", error);
      showToast('error', (error as Error).message);
    }
  }

  const handleRejectEmployee = async () => {
    console.log('reject employee');
    setOpenModalReject(false);

    try {
      const response = await API('approval.rejectKontrak', {
        query: { 'approval-id': approvalId },
        data: { reason },
      });
      console.log("API response", response);
      showToast('success', "Persetujuan Berhasil Ditolak");
      router.push('/persetujuan');
    } catch (error) {
      console.error("Error reject employee :", error);
      showToast('error', (error as Error).message);
    }
  }


  return (
    <Box sx={{ width: '100%', margin: 'auto', px: 3, mt: 2 }}>
      <HmStepper activeStep={activeStep} steps={steps} />

      <Box sx={{ mt: 4, mb: 4 }}>{renderStepContent(activeStep)}</Box>

      <Box
        sx={{
          display: 'flex',
          flexDirection: { xs: 'column', sm: 'row' },
          justifyContent: 'space-between',
          gap: 2,
          mt: 4,
          mb: 4,
          mx: 2,
        }}
      >
        <HmButton
          onClick={handleBack}
          type="button"
          color="transparent"
          borderColor={colors.palette.primary}
          labelColor={colors.palette.primary}
          variant="outlined"
          label="Kembali"
          disabled={activeStep === 0}
          icon={
            activeStep > 0 && (
              <MdKeyboardArrowLeft style={{ marginRight: 2 }} size={17} />
            )
          }
        />

        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            gap: 1,
            width: { xs: '100%', sm: 'auto' },
          }}
        >
          <HmButton
            type="button"
            color="transparent"
            borderColor={colors.palette.primary}
            labelColor={colors.palette.primary}
            variant="outlined"
            label="Batal"
            onClick={handleCancel}
          />

          {activeStep === steps.length - 1 && (
            <HmButton
              type="button"
              variant="contained"
              color={colors.palette.error}
              borderColor={colors.palette.white}
              labelColor={colors.palette.white}
              icon={
                <img
                  src="/icons/reject-resign-icon.svg"
                  alt="Reject"
                  width={16}
                  height={16}
                  style={{ display: 'block', margin: 'auto' }}
                />
              }
              label="Reject"
              onClick={handleReject}
              disabled={!isCompletedDoc}
            />
          )}

          <HmButton
            type="button"
            variant="contained"
            icon={
              activeStep === steps.length - 1 &&
              <img
                src="/icons/approve-resign-icon.svg"
                alt="Approve"
                width={16}
                height={16}
                style={{ display: 'block', margin: 'auto' }}
              />
            }
            label={
              activeStep === steps.length - 1 ? 'Approval Karyawan' : 'Selanjutnya'
            }
            onClick={handleNext}
            disabled={
              activeStep === steps.length ||
              loading ||
              (activeStep === steps.length - 1 && !isCompletedDoc)
            }
            loading={loading}
            color={activeStep === steps.length - 1 ? colors.palette.success : colors.palette.primary}
          />
        </Box>
      </Box>

      {/* Modal approve */}
      <HmModal
        isOpen={openModalApprove}
        onClose={onClose}
        title="Approve Karyawan"
        zIndex={100}
        onClickAction={handleApproveEmployee}
        maxWidth="sm"
        isAction={true}
        labelAction="Approve Karyawan"
        colorActionButton={colors.palette.success}
      >
        <Box sx={{ width: '100%' }}>
          <Grid container spacing={4} sx={{ my: 2 }}>
            {modalContent.map((item, index) => (
              <Grid key={item.id} size={{ xs: 12, sm: 6 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <HmTypography>{item.label}</HmTypography>
                  <HmTypography semiBold>{item.value || '-'}</HmTypography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      </HmModal>

      {/* Modal reject */}
      <HmModal
        isOpen={openModalReject}
        onClose={onClose}
        title="Reject  Karyawan"
        zIndex={100}
        onClickAction={handleRejectEmployee}
        maxWidth="sm"
        isAction={true}
        labelAction="Reject Karyawan"
        colorActionButton={colors.palette.error}
      >
        <Box sx={{ width: '100%' }}>
          <Grid container spacing={4} sx={{ my: 2 }}>
            {modalContent.map((item, index) => (
              <Grid key={item.id} size={{ xs: 12, sm: 6 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <HmTypography>{item.label}</HmTypography>
                  <HmTypography semiBold>{item.value || '-'}</HmTypography>
                </Box>
              </Grid>
            ))}
          </Grid>
          <HmTypography>Alasan<span style={{ color: 'red' }}>*</span></HmTypography>
          <HmTextField
            isTextArea
            label='Alasan'
            required={true}
            value={reason}
            onChange={(value: string) => setReason(value)}
          />
        </Box>
      </HmModal>
    </Box>
  );
};

export default KaryawanBaru;
