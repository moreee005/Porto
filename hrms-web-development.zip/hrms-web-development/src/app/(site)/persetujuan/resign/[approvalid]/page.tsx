'use client';

import { MdOutlineRemoveRedEye } from 'react-icons/md';
import DownloadIcon from '@mui/icons-material/Download';
import React, { useEffect, useState } from 'react';
import {
  HmButton,
  HmTable,
  HmTypography,
  HmChip,
  HmModal,
  HmTextField,
} from '@/components/component';
import { Container, Box, ListItem, List } from '@mui/material';
import Grid from '@mui/material/Grid2';
import theme from '@/utils/theme';
import colors from '@/components/colors';
import { API } from '@/services/setupAxios';
import { useRouter } from 'next/navigation';
import { formatDate } from '@/utils/date-formatter';

interface ResignDataDetail {
  approvalId: string;
  employeeDetail: {
    id: string;
    fullName: string;
    date: string;
    resignDate: string;
    resignDocument: string;
    resignReason: string;
  };
  contractInfo: {
    status: string;
    placementType: string;
    employeeType: string;
    bankPlacement: string;
    division: string;
    position: string;
    contractStartDate: string;
    contractEndDate: string;
    generation: string;
    document: {
      name: string;
      url: string;
      date: string;
    }[];
    salary: number;
  };
  placementAllowance: {
    placementType: string;
    amount: number;
  }[];
  otherAllowance: {
    allowanceType: string;
    amount: number;
  }[];
}

// HmTable
interface Employee {
  foto: string;
  nama: string;
}

interface Data {
  id: number;
  employee: Employee;
  kontrak: string;
  jabatan: string;
  posisi: string;
  penempatan: string;
  bank: boolean;
  nominal: string;
}


const resign = () => {
  // HmTable
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const handlePageChange = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleRowsPerPageChange = (value: number) => {
    setRowsPerPage(value);
  };

  //modal approve

  const [openApprove, setOpenApprove] = useState(false);

  const handleOpenApprove = () => setOpenApprove(true);
  const handleCloseApprove = () => setOpenApprove(false);

  //modal reject

  const handleInputChange = (value: string) => {
    setInputValue(value);
    setIsDisableButton(value.trim() === '');
  };

  const [openReject, setOpenReject] = useState(false);
  const [isDisableButton, setIsDisableButton] = React.useState(true);
  const [inputValue, setInputValue] = React.useState('');

  const handleOpenReject = () => setOpenReject(true);
  const handleCloseReject = () => setOpenReject(false);

  // Dialog State
  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };


  // API

  // Get Approval Detail Data resign

  const [approvalDetailData, setApprovalDetailData] =
    useState<ResignDataDetail>();
  const getApprovalDetailData = async () => {
    try {
      const response = await API('approval.detailResignKontrak', {
        query: { 'approval-id': '664b813d-219b-4637-a8ac-5fe196d95a5b' },
        // query: {'approval-id': approvalDetailData?.approvalId},
      });

      if (response.status === 200) {
        setApprovalDetailData(response.data.data);
        console.log('Detail Data', response.data.data);
      }
    } catch (error: any) {
      console.log('API ERROR', error);
    }
  };

  // Post Approve

  const postApprove = async () => {
    try {
      const response = await API('approval.approveKontrak', {
        // query: { 'approval-id': '664b813d-219b-4637-a8ac-5fe196d95a5b' },
        query: { 'approval-id': approvalDetailData?.approvalId }
      })

      console.log("API response", response)
    } catch (error: any) {
      console.log("API ERROR", error)
    }
  };

  const router = useRouter();


  const handlePostApprove = () => {
    postApprove()
    router.push(`/persetujuan`);
  }

  // Post Reject
  const postReject = async () => {
    try {
      const response = await API('approval.rejectKontrak', {
        // query: { 'approval-id': '664b813d-219b-4637-a8ac-5fe196d95a5b' },
        query: { 'approval-id': approvalDetailData?.approvalId },
        data: {
          reason: inputValue,
        }
      })

      console.log("API response", response)
    } catch (error: any) {
      console.log("API ERROR", error)
    }
  };

  const handlePostReject = () => {
    postReject()
    router.push(`/persetujuan`);

  }

  useEffect(() => {
    getApprovalDetailData();
    // getHistoryContractIdEmployeeData();
  }, []);

  useEffect(() => {
    if (inputValue === '') {
      setIsDisableButton(true);
    } else if (inputValue !== '') {
      setIsDisableButton(false);
    }
  }, [inputValue]);

  // table allowance

  const columns = [
    {
      header: 'No',
      accessor: (row: any) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <HmTypography semiBold small>
            {row.id}
          </HmTypography>
        </div>
      ),
    },
    {
      header: 'Jenis Tunjangan', // Assuming 'penempatan' refers to the allowance type
      accessor: (row: any) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <HmTypography semiBold small>
            {row.penempatan}
          </HmTypography>
        </div>
      ),
    },
    {
      header: 'Nominal', // Displaying the formatted currency
      accessor: (row: any) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <HmTypography semiBold small>
            {row.nominal}
          </HmTypography>
        </div>
      ),
    },
  ];

  // Transformasi data untuk placementAllowance
  const allowancetable = approvalDetailData?.placementAllowance
    ? approvalDetailData.placementAllowance.map((allowance, index) => ({
      id: index + 1,
      penempatan: allowance.placementType,
      nominal: allowance.amount.toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
      }),
    }))
    : [];

  // Transformasi data untuk placementAllowance
  const otherallowancetable = approvalDetailData?.otherAllowance
    ? approvalDetailData.otherAllowance.map((allowance, index) => ({
      id: index + 1,
      penempatan: allowance.allowanceType,
      nominal: allowance.amount.toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
      }),
    }))
    : [];

  return (
    <Container maxWidth="lg">
      <Box sx={{ paddingY: '20px' }}>
        <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
          DATA PENGAJUAN
        </HmTypography>
        <Grid container sx={{ padding: '20px' }}>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.fullName}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Tanggal Pengajuan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.date
                    ? formatDate(new Date(approvalDetailData.employeeDetail.date))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Tanggal Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.resignDate
                    ? formatDate(new Date(approvalDetailData.employeeDetail.resignDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Dokumen Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmButton
                  gapIcon={'0.2rem'}
                  icon={<DownloadIcon fontSize="small" />}
                  label={
                    <HmTypography small semiBold>
                      Download Dokumen Resign
                    </HmTypography>
                  }
                  labelColor="white"
                  sx={{ paddingX: '12px', paddingY: '6px' }}
                  onClick={() => {
                    const url = approvalDetailData?.employeeDetail?.resignDocument;
                    if (!url) {
                      console.error('URL dokumen tidak tersedia');
                      return;
                    }

                    fetch(url) // Pastikan URL file dapat diakses
                      .then(response => {
                        if (!response.ok) {
                          throw new Error('Gagal mengunduh dokumen.');
                        }
                        return response.blob();
                      })
                      .then(blob => {
                        const link = document.createElement('a');
                        const blobUrl = window.URL.createObjectURL(blob);
                        link.href = blobUrl;
                        link.download = url.split('/').pop() || 'default_filename.pdf'; // Nama file unduhan
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        window.URL.revokeObjectURL(blobUrl); // Bersihkan URL Blob setelah selesai
                      })
                      .catch(error => {
                        console.error('Error saat mengunduh dokumen:', error);
                      });
                  }}
                />
                <HmButton
                  icon={<MdOutlineRemoveRedEye size={16} />}
                  labelColor={theme.palette.info.main}
                  color={theme.palette.info.light}
                  borderRadius="10"
                  sx={{
                    marginX: '8px',
                    minWidth: '38px',
                    width: '38px',
                    height: '38px',
                  }}
                  onClick={() => {
                    const url = approvalDetailData?.employeeDetail?.resignDocument;
                    if (!url) {
                      console.error('URL dokumen tidak tersedia');
                      return;
                    }

                    const link = document.createElement('a');
                    link.href = url; // URL file dari backend
                    link.target = '_blank'; // Membuka file di tab baru
                    document.body.appendChild(link); // Tambahkan elemen <a> ke DOM
                    link.click(); // Trigger klik untuk membuka file
                    document.body.removeChild(link); // Hapus elemen setelah selesai
                  }}
                />
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Alasan Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.resignReason}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
        </Grid>
      </Box>
      <Box sx={{ paddingY: '20px' }}>
        <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
          INFORMASI KONTRAK
        </HmTypography>
        <Grid container sx={{ padding: '20px' }}>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.status}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Jenis Penempatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.placementType}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Jenis Karyawan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.employeeType}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Bersedia Ditempatkan di Bank/Insurance
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.bankPlacement}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.division}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.position}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Tanggal Mulai Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractStartDate
                    ? formatDate(new Date(approvalDetailData.contractInfo.contractStartDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Tanggal Akhir Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractEndDate
                    ? formatDate(new Date(approvalDetailData.contractInfo.contractEndDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                  Generasi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.generation}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              {Array.isArray(approvalDetailData?.contractInfo?.document) &&
                approvalDetailData.contractInfo.document.map((row, index) => (
                  <Box key={index}>
                    <ListItem>
                      <HmTypography sx={{ color: 'text.secondary' }} semiBold small>
                        Dokumen Kontrak ({formatDate(new Date(row.date))})
                      </HmTypography>
                    </ListItem>
                    <ListItem>
                      <HmButton
                        gapIcon={'0.2rem'}
                        icon={<DownloadIcon fontSize="small" />}
                        label={
                          <HmTypography small semiBold>
                            Download Dokumen
                          </HmTypography>
                        }
                        labelColor="white"
                        sx={{ paddingX: '12px', paddingY: '6px' }}
                        onClick={() => {
                          const url = row.url;
                          if (!url) {
                            console.error('URL dokumen tidak tersedia');
                            return;
                          }

                          fetch(url) // Pastikan URL file dapat diakses
                            .then(response => {
                              if (!response.ok) {
                                throw new Error('Gagal mengunduh dokumen.');
                              }
                              return response.blob();
                            })
                            .then(blob => {
                              const link = document.createElement('a');
                              const blobUrl = window.URL.createObjectURL(blob);
                              link.href = blobUrl;
                              link.download = url.split('/').pop() || row.name; // Nama file unduhan
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                              window.URL.revokeObjectURL(blobUrl); // Bersihkan URL Blob setelah selesai
                            })
                            .catch(error => {
                              console.error('Error saat mengunduh dokumen:', error);
                            });
                        }}
                      />
                      <HmButton
                        icon={<MdOutlineRemoveRedEye size={16} />}
                        labelColor={theme.palette.info.main}
                        color={theme.palette.info.light}
                        borderRadius="10"
                        sx={{
                          marginX: '8px',
                          minWidth: '38px',
                          width: '38px',
                          height: '38px',
                        }}
                        onClick={() => {
                          const link = document.createElement('a');
                          link.href = row.url; // URL file dari backend
                          link.target = '_blank'; // Membuka file di tab baru
                          document.body.appendChild(link); // Tambahkan elemen <a> ke DOM
                          link.click(); // Trigger klik untuk membuka file
                          document.body.removeChild(link); // Hapus elemen setelah selesai
                        }}
                      />
                    </ListItem>
                  </Box>
                ))
              }
            </List>
          </Grid>
        </Grid>
      </Box>
      <Box>
        <HmTypography
          sx={{ marginBottom: '8px', color: 'text.secondary' }}
          semiBold
          small
        >
          GAJI POKOK & TUNJANGAN
        </HmTypography>

        {/* Tabel: Tunjangan Penempatan */}

        <Grid container spacing={'20px'} sx={{ padding: '40px' }}>
          <Grid size={12}>
            <HmTypography
              variant="body2"
              sx={{ marginBottom: '8px', color: 'text.secondary' }}
              semiBold
              small
            >
              Tunjangan Penempatan
            </HmTypography>
          </Grid>
          <Grid size={12} sx={{ paddingX: '16px' }}>
            <HmTable
              data={allowancetable}
              columns={columns}
              loading={loading}
              page={page}
              rowsPerPage={rowsPerPage}
              totalItems={allowancetable.length}
              onPageChange={handlePageChange}
              handleRowsPerPageChange={handleRowsPerPageChange}
              noPagination
            />
          </Grid>

          {/* Tabel: Tunjangan Lain-lain */}
          <Grid size={12}>
            <HmTypography
              variant="body2"
              sx={{ marginBottom: '8px', color: 'text.secondary' }}
              semiBold
              small
            >
              Tunjangan Lain-lain
            </HmTypography>
          </Grid>
          <Grid size={12} sx={{ paddingX: '16px' }}>
            <HmTable
              data={otherallowancetable}
              columns={columns}
              loading={loading}
              page={page}
              rowsPerPage={rowsPerPage}
              totalItems={otherallowancetable.length}
              onPageChange={handlePageChange}
              handleRowsPerPageChange={handleRowsPerPageChange}
              noPagination
            />
          </Grid>
        </Grid>
      </Box>

      {/* Action Buttons */}
      <Box
        sx={{
          paddingY: '24px',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '8px',
        }}
      >
        <HmButton
          variant="outlined"
          color="white"
          borderColor={theme.palette.primary.main}
          labelColor={theme.palette.primary.main}
          label="Batal"
        />
        <HmButton
          icon={
            <img src="/icons/reject-resign-icon.svg" alt="reject resign icon" />
          }
          gapIcon="0.5rem"
          onClick={handleOpenReject}
          color={theme.palette.error.main}
          labelColor="white"
          label="Reject"
        />
        <HmButton
          icon={
            <img
              src="/icons/approve-resign-icon.svg"
              alt="reject resign icon"
            />
          }
          gapIcon="0.5rem"
          onClick={handleOpenApprove}
          color={theme.palette.success.main}
          labelColor="white"
          label="Approve Resign"
        />
      </Box>

      {/* modal Approve  */}
      <HmModal
        isOpen={openApprove}
        onClose={handleCloseApprove}
        title="Approve Karyawan"
        zIndex={2}
        isAction={true}
        onClickAction={handlePostApprove}
        labelAction="Approve Karyawan Resign"
        colorActionButton={colors.palette.success}
        isIconActionButton={true}
        maxWidth="md"
      >
        <Grid container>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.fullName}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography small semiBold sx={{ color: 'text.secondary' }}>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.status}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.division}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.position}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Mulai Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractStartDate
                    ? formatDate(new Date(approvalDetailData.contractInfo.contractStartDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Akhir Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractEndDate
                    ? formatDate(new Date(approvalDetailData.contractInfo.contractEndDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.resignDate
                    ? formatDate(new Date(approvalDetailData.employeeDetail.resignDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Alasan Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.resignReason}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
        </Grid>
      </HmModal>

      {/* modal reject */}
      <HmModal
        isOpen={openReject}
        onClose={handleCloseReject}
        title="Reject Karyawan"
        zIndex={1}
        isAction={true}
        labelAction="Reject"
        onClickAction={handlePostReject}
        isDisableButton={isDisableButton}
        maxWidth="sm"
      >
        <Grid container>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.fullName}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.status}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.division}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.position}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Mulai Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractStartDate
                    ? formatDate(new Date(approvalDetailData.contractInfo.contractStartDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Akhir Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.contractInfo?.contractEndDate
                    ? formatDate(new Date(approvalDetailData.contractInfo.contractEndDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.resignDate
                    ? formatDate(new Date(approvalDetailData.employeeDetail.resignDate))
                    : 'N/A'}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Alasan Resign
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>
                  {approvalDetailData?.employeeDetail?.resignReason}
                </HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid size={12}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Alasan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTextField
                  placeholder="Placeholder text"
                  value={inputValue}
                  onChange={handleInputChange}
                />
              </ListItem>
            </List>
          </Grid>
        </Grid>
      </HmModal>
    </Container>
  );
};

export default resign;
function setIsModalBasicActionOpen(arg0: boolean) {
  throw new Error('Function not implemented.');
}
