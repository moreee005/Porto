'use client';
import React, { useState, useEffect } from 'react';
import { CardContract, ExtendDialog } from '@/components/section';
import { HmButton } from '@/components/component';
import { Container, Box } from '@mui/material';
import Grid from '@mui/material/Grid2';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useRouter, useParams } from 'next/navigation';
import { DataContract } from '@/components/section/kontrak-karyawan/DataContractContext';
import { API } from '@/services/setupAxios';

const PerbaikanPerpanjanganKontrak = () => {
  const [open, setOpen] = useState(false);
  const [contractData, setContractData] = useState<DataContract | null>(null);
  const router = useRouter();
  const { employeeId } = useParams();

  const contractDataDetail = async () => {
    try {
      const response = await API('dataContract.detail', { query: { id: employeeId } });
      setContractData(response.data.data);
    } catch (error) {
      console.error('Failed to fetch contract data:', error);
    }
  };

  useEffect(() => {
    if (employeeId) {
      contractDataDetail();
    }
  }, [employeeId]);


  const handleOpen = () => { setOpen(true); };
  const handleClose = () => { setOpen(false); };

  if (!contractData) {
    return <p>Loading...</p>;
  }

  const { contractStartDate, contractEndDate } = contractData.contractInfo;
  const startDate = new Date(contractStartDate);
  const endDate = new Date(contractEndDate);
  return (
    <Container maxWidth="lg">
      <Box sx={{ marginBottom: '20px' }}>
        <CardContract data={contractData} onSuccess={handleOpen} />
        <Grid
          container
          spacing={2}
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            padding: '20px',
          }}>
          <HmButton
            icon={<ArrowBackIosIcon />}
            label="Kembali"
            labelColor="#3f51b5"
            color="#ffffff"
            borderColor="#3f51b5"
            variant="contained"
            sx={{
              fontSize: '14px',
            }}
            onClick={(event) => router.push('/kontrak')}
          />
          <Grid
            sx={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
              gap: 2,
            }}>
            <HmButton
              label="Batal"
              borderRadius="1"
              variant="contained"
              labelColor="#3f51b5"
              color="#ffffff"
              borderColor="#3f51b5"
              sx={{
                padding: '12px',
                fontSize: '14px',
              }}
              onClick={handleOpen}
            />
            <HmButton
              icon={<ArrowForwardIosIcon />}
              label="Kirim"
              labelColor="white"
              variant="contained"
              sx={{
                width: '100px',
                padding: '12px',
              }}
              onClick={handleOpen}
            />
          </Grid>
        </Grid>
      </Box>
      <ExtendDialog open={open} onClose={handleClose} employeeDetail={contractData.employeeDetail}
        contractInfo={{
          ...contractData.contractInfo,
          contractStartDate: startDate,
          contractEndDate: endDate,
        }} />
    </Container>
  );
};

export default PerbaikanPerpanjanganKontrak;
