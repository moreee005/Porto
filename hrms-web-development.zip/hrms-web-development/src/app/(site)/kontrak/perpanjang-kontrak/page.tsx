'use client';

import {
  FieldComponent,
  HmButton,
  HmDynamicForm,
  HmModal,
  HmTypography,
} from '@/components/component';
import { Box, Grid, List, ListItem } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useRouter } from 'next/navigation';
import { UUIDTypes } from 'uuid';
import { contractExtedDetailData } from '@/data/dummyContractExtend';

interface KontrakInputs {
  statusKontrak: string;
  jenisPenempatan: string;
  jenisKaryawan: string;
  bersediaDitempatkan: string;
  divisi: string;
  jabatan: string;
  tanggalMulaiKontrak: string;
  tanggalAkhirKontrak: string;
  generasi: string;
  gajiPokok: string;
  dokumenKontrak: File | null;
}

interface ContractExtedDetailData {
  approvalId: UUIDTypes;
  employeeDetail: {
    id: number;
    fullName: string;
    division: string;
    contractStatus: string;
    position: string;
  };
  contractInfo: {
    status: string;
    placementType: string;
    employeeType: string;
    bankPlacement: string;
    division: string;
    position: string;
    contractStartDate: string;
    contractEndDate: string;
    generation: string;
    contractDocument: string; // url minio
    contractDocumentName: string;
    salary: number;
  };
  placementAllowance: {
    id: number;
    allowanceType: string;
    amount: number;
  }[];
  otherAllowance: {
    id: number;
    allowanceType: string;
    amount: number;
  }[];
}

const PerpanjangKontrak = () => {
  const methods = useForm<KontrakInputs>();
  const router = useRouter();
  const [data, setData] = useState<ContractExtedDetailData>(
    contractExtedDetailData.data
  );

  // TODO : OnchangeData belum

  // Dynamic Table Columns for "Tunjangan"
  const tunjanganPenempatanColumns = [
    {
      header: 'Jenis Tunjangan',
      field: 'jenisTunjangan',
      type: 'dropdown',
      placeholder: 'Pilih jenis tunjangan',
      size: 'small' as const,
      options: [
        { id: '1', value: 'Tunjangan Jakarta' },
        { id: '2', value: 'Tunjangan Bandung' },
        { id: '3', value: 'Tunjangan Hybrid' },
      ],
    },
    {
      header: 'Nama Tunjangan',
      field: 'namaTunjangan',
      type: 'textfield',
      placeholder: 'Masukkan nama tunjangan',
      options: [],
    },
  ];

  const tunjanganLainColumns = [
    {
      header: 'Jenis Tunjangan',
      field: 'jenisTunjangan',
      type: 'dropdown',
      placeholder: 'Pilih jenis tunjangan',
      size: 'small' as const,
      options: [
        { id: '1', value: 'Tunjangan Tetap' },
        { id: '2', value: 'Tunjangan Tidak Tetap' },
      ],
    },
    {
      header: 'Nama Tunjangan',
      field: 'namaTunjangan',
      type: 'textfield',
      placeholder: 'Masukkan nama tunjangan',
      options: [],
    },
  ];

  useEffect(() => {
    console.log('Data', data);
  }, [data]);

  // Modal Confirm Extend Contract
  const [isModalConfirmOpen, setIsModalConfirmOpen] = useState(false);
  const submitPerpanjangKontrak = () => {};

  return (
    <Box sx={{ maxWidth: 1100, width: '100%', margin: 'auto', px: 2, mt: 5 }}>
      {/* Detail Karyawan */}
      <Box mb={3}>
        <HmTypography fontWeight={600} fontSize={'14px'} color="#989BB3">
          DETAIL KARYAWAN
        </HmTypography>
        <Grid container spacing={2} mt={1} paddingX={'15px'}>
          <Grid item xs={12} sm={6}>
            <HmTypography fontWeight={600} fontSize={'14px'} color="#586A84">
              Nama Lengkap
            </HmTypography>
            <Box>
              <HmTypography fontWeight={400} fontSize={'16px'} color="#212121">
                {data.employeeDetail.fullName}
              </HmTypography>
            </Box>
          </Grid>

          <Grid item xs={12} sm={6}>
            <HmTypography fontWeight={600} fontSize={'14px'} color="#586A84">
              Divisi
            </HmTypography>
            <Box>
              <HmTypography fontWeight={400} fontSize={'16px'} color="#212121">
                {data.employeeDetail.division}
              </HmTypography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <HmTypography fontWeight={600} fontSize={'14px'} color="#586A84">
              Status Kontrak
            </HmTypography>
            <Box>
              <HmTypography fontWeight={400} fontSize={'16px'} color="#212121">
                {data.employeeDetail.contractStatus}
              </HmTypography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <HmTypography fontWeight={600} fontSize={'14px'} color="#586A84">
              Jabatan
            </HmTypography>
            <Box>
              <HmTypography fontWeight={400} fontSize={'16px'} color="#212121">
                {data.employeeDetail.position}
              </HmTypography>
            </Box>
          </Grid>
        </Grid>
      </Box>

      <FormProvider {...methods}>
        <form onSubmit={submitPerpanjangKontrak}>
          <Box>
            {/* First Row */}
            <HmTypography bold color="gray">
              INFORMASI KONTRAK
            </HmTypography>
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                mt: 2,
                mb: 2,
                paddingLeft: 2,
                paddingRight: 2,
              }}
            >
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="statusKontrak"
                  label="Status Kontrak"
                  placeholder="Pilih Status Kontrak"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: '1', value: 'Kontrak' },
                    { id: '2', value: 'Tetap' },
                    { id: '3', value: 'Probation' },
                  ]}
                  required
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="jenisPenempatan"
                  label="Jenis Penempatan"
                  placeholder="Pilih Jenis Penempatan"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: '1', value: 'Onsite' },
                    { id: '2', value: 'Remote' },
                    { id: '3', value: 'Hybrid' },
                  ]}
                />
              </Box>
            </Box>

            {/* Second Row */}
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                mb: 2,
                paddingLeft: 2,
                paddingRight: 2,
              }}
            >
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="jenisKaryawan"
                  label="Jenis Karyawan"
                  placeholder="Pilih Jenis Karyawan"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: '1', value: 'Full-Time' },
                    { id: '2', value: 'Part-Time' },
                    { id: '3', value: 'Freelance' },
                  ]}
                  required
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="bersediaDitempatkan"
                  label="Bersedia Ditempatkan di Bank/Insurance"
                  placeholder="Pilih Kesiapan"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: 'yes', value: 'Ya' },
                    { id: 'no', value: 'Tidak' },
                  ]}
                />
              </Box>
            </Box>

            {/* Third Row */}
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                mb: 2,
                paddingLeft: 2,
                paddingRight: 2,
              }}
            >
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="divisi"
                  label="Divisi"
                  placeholder="Pilih Divisi"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: 'it', value: 'IT' },
                    { id: 'hr', value: 'Human Resources' },
                    { id: 'finance', value: 'Finance' },
                  ]}
                  required
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="jabatan"
                  label="Jabatan"
                  placeholder="Pilih Jabatan"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: 'staff', value: 'Staff' },
                    { id: 'supervisor', value: 'Supervisor' },
                    { id: 'manager', value: 'Manager' },
                  ]}
                  required
                />
              </Box>
            </Box>

            {/* Fourth Row */}
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                mb: 2,
                paddingLeft: 2,
                paddingRight: 2,
              }}
            >
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="tanggalMulaiKontrak"
                  label="Tanggal Mulai Kontrak"
                  placeholder="Pilih Tanggal"
                  type="date"
                  size="small"
                  required
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="tanggalAkhirKontrak"
                  label="Tanggal Akhir Kontrak"
                  placeholder="Pilih Tanggal"
                  type="date"
                  size="small"
                  required
                />
              </Box>
            </Box>

            {/* Fifth Row */}
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                mb: 2,
                paddingLeft: 2,
                paddingRight: 2,
              }}
            >
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="generasi"
                  label="Generasi"
                  placeholder="Pilih Generasi"
                  type="dropdown"
                  size="small"
                  options={[
                    { id: '1', value: 'Generasi X' },
                    { id: '2', value: 'Generasi Y' },
                    { id: '3', value: 'Generasi Z' },
                  ]}
                  required
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <Box>
                  <FieldComponent
                    name="uploadedFiles"
                    label="Dokumen Kontrak"
                    type="file"
                    required
                    fullWidth={false}
                    control={methods.control}
                  />
                </Box>
              </Box>
            </Box>

            {/* Sixth Row */}
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                mb: 2,
                paddingLeft: 2,
                paddingRight: 2,
              }}
            >
              <Box sx={{ flex: 1 }}>
                <FieldComponent
                  control={methods.control}
                  name="gajiPokok"
                  label="Gaji Pokok"
                  placeholder="Rp Placeholder"
                  required
                />
              </Box>
              <Box sx={{ flex: 1 }}></Box>
            </Box>
          </Box>

          {/* Dynamic Table for "Tunjangan Penempatan" */}
          <Box sx={{ mt: 3 }}>
            <HmTypography bold color="gray">
              TUNJANGAN
            </HmTypography>
            <Box sx={{ mt: 2, paddingLeft: 2, paddingRight: 2 }}>
              <HmTypography>Tunjangan Penempatan</HmTypography>
              <HmDynamicForm
                name="tunjanganPenempatan"
                label=""
                required={false}
                columns={tunjanganPenempatanColumns}
                buttonText="Tambah Tunjangan"
                control={methods.control}
              />
            </Box>
          </Box>

          {/* Dynamic Table for "Tunjangan Lain-lain" */}
          <Box sx={{ mt: 4 }}>
            <Box sx={{ paddingLeft: 2, paddingRight: 2 }}>
              <HmTypography>Tunjangan Lain-lain</HmTypography>
              <HmDynamicForm
                name="tunjanganLainLain"
                label=""
                required={false}
                columns={tunjanganLainColumns}
                buttonText="Tambah Tunjangan"
                control={methods.control}
              />
            </Box>
          </Box>
        </form>
      </FormProvider>

      <Grid
        container
        spacing={2}
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          marginTop: 5,
          padding: '20px',
          gap: '10px',
        }}
      >
        <HmButton
          icon={<ArrowBackIosIcon />}
          label="Kembali"
          labelColor="#3f51b5"
          color="#ffffff"
          borderColor="#3f51b5"
          variant="contained"
          sx={{
            fontSize: '14px',
          }}
          onClick={(event) => router.push('/kontrak')}
        />
        <Grid
          sx={{
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            gap: 2,
          }}
        >
          <HmButton
            label="Batal"
            borderRadius="1"
            variant="contained"
            labelColor="#3f51b5"
            color="#ffffff"
            borderColor="#3f51b5"
            sx={{
              padding: '12px',
              fontSize: '14px',
            }}
            onClick={() => setIsModalConfirmOpen(false)}
          />
          <HmButton
            icon={<ArrowForwardIosIcon />}
            label="Kirim"
            labelColor="white"
            variant="contained"
            sx={{
              width: '100px',
              padding: '12px',
            }}
            onClick={() => setIsModalConfirmOpen(true)}
          />
        </Grid>
      </Grid>

      <HmModal
        isOpen={isModalConfirmOpen}
        onClose={() => setIsModalConfirmOpen(false)}
        title="Extend Kontrak"
        zIndex={1}
        isAction={true}
        onClickAction={() => setIsModalConfirmOpen(false)}
        labelAction="Diperpanjang"
        colorActionButton={'#23BD33'}
        isIconActionButton={true}
        maxWidth="md"
      >
        <Grid container>
          <Grid item xs={12} sm={6}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Nama Lengkap
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>Afdal Ramdan</HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={12} sm={6}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>Fulltime</HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={12} sm={6}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Divisi
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>KTI</HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={12} sm={6}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Jabatan
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>UI/UX Designer</HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={12} sm={6}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Mulai Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>21 November 2024</HmTypography>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={12} sm={6}>
            <List>
              <ListItem>
                <HmTypography sx={{ color: 'text.secondary' }}>
                  Tanggal Akhir Status Kontrak
                </HmTypography>
              </ListItem>
              <ListItem>
                <HmTypography>21 November 2026</HmTypography>
              </ListItem>
            </List>
          </Grid>
        </Grid>
      </HmModal>
    </Box>
  );
};

export default PerpanjangKontrak;
