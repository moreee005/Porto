'use client';

import React, { useEffect, useState } from 'react';
import {
  HmAutoComplete,
  HmButton,
  HmChip,
  HmModal,
  HmSearch,
  HmTable,
  HmTextField,
  HmTypography,
} from '@/components/component';
import {
  Avatar,
  Box,
  Grid2,
  MenuItem,
  Tooltip,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import Grid from '@mui/material/Grid2';
import ImageComponent from '@/components/component/HmCircleImage';
import colors from '@/components/colors';
import StyledMenu from '@/utils/contract/StyledMenu';
import menuItems from '@/utils/contract/MenuItems';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { formatDate, getEndDateInfo } from '@/utils/date-formatter';
import { API } from '@/services/setupAxios';
import useModal from '@/hooks/useModal';
import { useToast } from '@/context/toastContext';
import ModalEndContract from '@/components/section/kontrak-karyawan/ModalEndContract';

interface DataRow {
  draw: number;
  recordsTotal: number;
  recordsFiltered: number;
  data: {
    partyId: string;
    photoFilename: string;
    fullname: string;
    contractTypeId: number;
    contractTypeName: string;
    workPeriodStr: string;
    startDateStr: string;
    endDateStr: string;
    contractStatusId: number;
    contractStatusName: string;
  }[];
}

interface ListItemProps {
  label: string;
  value: string;
  size?: { xs?: number; sm?: number; md?: number; lg?: number };
}

interface Option {
  id: number;
  value: string;
}

const ListItem: React.FC<ListItemProps> = ({
  label = 'label',
  value = 'value',
  size = { xs: 12, md: 6 },
}) => {
  return (
    <Grid2 size={size}>
      <HmTypography
        semiBold
        color="#586A84"
        sx={{ display: 'block', marginBottom: '3px' }}
      >
        {label}
      </HmTypography>
      {typeof value === 'string' ? (
        <HmTypography semiBold>{value}</HmTypography>
      ) : (
        value
      )}
    </Grid2>
  );
};

const Kontrak = () => {
  const theme = useTheme();
  const { showToast } = useToast();
  const modalResign = useModal();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [data, setData] = useState<DataRow>({
    draw: 0,
    recordsTotal: 0,
    recordsFiltered: 0,
    data: [
      {
        partyId: '',
        photoFilename: '',
        fullname: '',
        contractTypeId: 1,
        contractTypeName: '',
        workPeriodStr: '',
        startDateStr: '',
        endDateStr: '',
        contractStatusId: 1,
        contractStatusName: '',
      },
    ],
  });
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const [contractOptions, setContractOptions] = useState<Option[]>([]);
  const [statusOptions, setStatusOptions] = useState<Option[]>([]);

  const [params, setParams] = useState({
    page: 0,
    size: 10,
    employeeName: null,
    contract: null,
    end: null,
    status: null,
    search: '',
    sort: '',
  });
  const modalEnd = useModal();
  const [openModal, setOpenModal] = useState(null);

  const handleMenuItemClick = (modalType: any) => {
    setOpenModal(modalType);
  };

  const handleCloseModal = () => {
    setOpenModal(null);
  };

  const getMasterContractType = async () => {
    try {
      const response = await API('master.contract-type');
      if (response?.status === 200) {
        const items = response?.data?.data;
        const options: Option[] = items?.map((item: any) => ({
          id: item?.contractTypeId,
          value: item?.name,
        }));
        setContractOptions(options);
      } else {
        console.error('API response was not successful', response);
      }
    } catch (error) {}
  };

  const getMasterStatus = async () => {
    try {
      const response = await API('master.contract-status');
      if (response?.status === 200) {
        const items = response?.data?.data;
        const options: Option[] = items?.map((item: any) => ({
          id: item?.contractStatusId,
          value: item?.name,
        }));
        setStatusOptions(options);
      } else {
        console.error('API response was not successful', response);
      }
    } catch (error) {}
  };

  const getContractList = async () => {
    try {
      const response = await API('employeeManagement.contractList', { params });
      const data = response?.data?.data;
      setData(data);
      console.log('response data kontrak', data);
    } catch (error: any) {
      console.log('failed to get data contract', error?.message);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        await Promise.all([
          getContractList(),
          getMasterContractType(),
          getMasterStatus(),
        ]);
      } catch (error: any) {
        showToast('error', error);
      }
    };
    fetchData();
  }, [params]);

  // Sorting handler
  const handleSort = (column: keyof (typeof data.data)[0]) => {
    console.log('Column', column);
    setParams((prevParams) => {
      const currentSortKey = prevParams.sort.split(',')[0];
      const currentDirection = prevParams.sort.split(',')[1];

      const nextDirection =
        currentSortKey === column && currentDirection === 'asc'
          ? 'desc'
          : 'asc';

      return {
        ...prevParams,
        sort: `${column},${nextDirection}`,
      };
    });
  };

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  // Handler
  const handleFilterChange =
    (filterName: string) => (event: React.SyntheticEvent, value: any) => {
      setParams({ ...params, page: 0, [filterName]: value });
    };

  const handleSearchChange = (value: string) => {
    setParams({ ...params, page: 0, search: value });
  };

  const handlePageChange = (event: unknown, newPage: number) => {
    setParams({ ...params, page: newPage - 1 });
  };

  const handleRowsPerPageChange = (value: number) => {
    setParams({ ...params, page: 0, size: value });
  };

  const handleResignKaryawan = async () => {
    modalResign?.toggleModal();
    await new Promise((resolve) => setTimeout(resolve, 150));
    alert('Success resign');
  };

  // data
  const columns = [
    {
      header: 'Employee',
      sortable: true,
      accessor: 'fullname',
      render: (row: any) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {row?.photoFileName ? (
            <ImageComponent
              src={row?.photoFileName}
              alt={`${row?.fullname}`}
              size={40}
            />
          ) : (
            <Avatar>{`${row?.fullname}`.charAt(0)}</Avatar>
          )}
          <HmTypography bold color="text.secondary">
            {`${row?.fullname}`}
          </HmTypography>
        </Box>
      ),
    },
    {
      header: 'Kontrak',
      sortable: true,
      accessor: 'contractTypeName',
      render: (row: any) => {
        const contractStyles = {
          Fulltime: {
            bgColor: 'rgb(227,242,250)',
            textColor: colors.palette.info,
          },
          Probation: {
            bgColor: 'rgb(228,247,231)',
            textColor: colors.palette.success,
          },
          OJT: {
            bgColor: 'rgb(255,246,227)',
            textColor: colors.palette.warning,
          },
          'Back to back': {
            bgColor: 'rgb(255,236,231)',
            textColor: colors.palette.orange,
          },
          Permanent: {
            bgColor: 'rgb(234,235,249)',
            textColor: colors.palette.primary,
          },
        };
        const { bgColor, textColor } = contractStyles[
          row.contractType as
            | 'Fulltime'
            | 'Probation'
            | 'OJT'
            | 'Back to back'
            | 'Permanent'
        ] || {
          bgColor: 'rgb(207,208,218)',
          textColor: colors.palette.secondary,
        };
        return (
          <HmChip
            label={row?.contractTypeName}
            backgroundColor={bgColor}
            textColor={textColor}
            fontSize="14px"
            sx={{
              fontWeight: 600,
              height: '24px',
            }}
          />
        );
      },
    },
    {
      header: 'Masa Kerja',
      sortable: true,
      accessor: 'workPeriodStr',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row?.workPeriodStr}
        </HmTypography>
      ),
    },
    {
      header: 'Start',
      sortable: true,
      accessor: 'startDateStr',
      render: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row?.startDateStr ? formatDate(new Date(row?.startDateStr)) : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'End',
      sortable: true,
      accessor: 'endDateStr',
      render: (row: any) => {
        const { is90DaysLeft, endDate } = getEndDateInfo(row);

        return (
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
            }}
          >
            {is90DaysLeft && (
              <Tooltip
                title={<span style={{ fontSize: '12px' }}>90 Days Left</span>}
                arrow
                placement="top"
                sx={{ marginRight: 2 }}
              >
                <img
                  src="/icons/info.svg"
                  alt={endDate.toLocaleDateString()}
                  width={13}
                  height={13}
                  style={{
                    verticalAlign: 'middle',
                  }}
                />
              </Tooltip>
            )}
            <HmTypography
              fontSize={14}
              color={is90DaysLeft ? colors.palette.error : 'text'}
              semiBold={is90DaysLeft}
            >
              {row?.endDateStr ? formatDate(new Date(row?.endDateStr)) : '-'}
            </HmTypography>
          </Box>
        );
      },
    },
    {
      header: 'Status',
      sortable: true,
      accessor: 'contractStatusName',
      render: (row: any) => {
        const getStatusIcon = (status: string) => {
          switch (status) {
            case 'Perpanjangan Kontrak Ditolak':
              return {
                icon: '/icons/dot-red.svg',
                text: 'Perpanjangan Kontrak Ditolak',
              };
            case 'Waiting Persetujuan Karyawan Baru':
              return {
                icon: '/icons/dot-yellow.svg',
                text: 'Waiting Persetujuan Karyawan Baru',
              };
            case 'Active':
              return {
                icon: '/icons/active.svg',
                text: 'Active',
              };
            case 'Off':
              return {
                icon: '/icons/off.svg',
                text: 'Off',
              };
            default:
              return {
                icon: '/icons/dot-red.svg',
                text: '',
              };
          }
        };

        const statusConfig = getStatusIcon(row?.contractStatusName);
        return (
          <Box
            sx={{
              display: 'flex',
              width: '10rem',
              alignItems: 'center',
              gap: 1,
            }}
          >
            <img
              src={statusConfig.icon}
              alt={statusConfig.text}
              width={20}
              height={20}
              style={{
                verticalAlign: 'middle',
              }}
            />
            <HmTypography fontSize={14} color="text.secondary">
              {row?.contractStatusName}
            </HmTypography>
          </Box>
        );
      },
    },
    {
      header: 'Aksi',
      accessor: () => {
        return (
          <Box>
            <HmButton
              icon={
                <img
                  src="/icons/dots-menu.svg"
                  alt="Menu"
                  width={17}
                  height={17}
                  style={{ verticalAlign: 'middle' }}
                />
              }
              labelColor={colors.palette.grey}
              color={colors.palette.white}
              borderColor={colors.palette.grey}
              borderRadius="10"
              sx={{ minWidth: '28px' }}
              onClick={handleClick}
            />
            <StyledMenu
              id="demo-customized-menu"
              MenuListProps={{
                'aria-labelledby': 'demo-customized-button',
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
            >
              {menuItems.map((item) => (
                <MenuItem key={item?.id} onClick={handleClose} disableRipple>
                  <HmButton
                    icon={item.icon}
                    label={
                      <HmTypography
                        color={item.labelColor}
                        fontSize={13}
                        sx={{ marginLeft: 1 }}
                      >
                        {item.label}
                      </HmTypography>
                    }
                    onClick={() => handleMenuItemClick(item?.label)}
                    labelColor={item.labelColor}
                    color={item.color}
                    borderRadius="10"
                    fullWidth
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'flex-start',
                      padding: '4px 8px',
                    }}
                  />
                </MenuItem>
              ))}
            </StyledMenu>
          </Box>
        );
      },
    },
  ];

  return (
    <Box
      sx={{
        width: '100%',
        paddingX: isMobile ? 2 : 3,
        marginBottom: isMobile ? 2 : 3,
      }}
    >
      {/* filters */}
      <Box sx={{ marginTop: 2 }}>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmSearch
              searchValue={params?.search}
              onSearchChange={handleSearchChange}
              width="100%"
              size="medium"
              fullWidth
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={contractOptions}
              value={params?.contract}
              onChange={handleFilterChange('contract')}
              label="Kontrak"
              placeholder="Pilih Jenis Kontrak"
              width="100%"
              size="medium"
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <HmAutoComplete
              options={statusOptions}
              value={params?.status}
              onChange={handleFilterChange('status')}
              label="Status"
              placeholder="Pilih Status"
              width="100%"
              size="medium"
            />
          </Grid>
          <Grid size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                label="Akhir Kontrak"
                sx={{
                  width: '100%',
                  borderRadius: 10,

                  textOverflow: 'ellipsis',
                }}
                onChange={(newValue) => {
                  const formattedDate = dayjs(newValue).format('D MMM YYYY');
                  // handleFilterChange('end')(formattedDate);
                  console.log(formattedDate);
                }}
              />
            </LocalizationProvider>
          </Grid>
        </Grid>
      </Box>

      {/* data table */}
      <Box
        sx={{
          marginTop: '1rem',
          overflowX: 'auto',
        }}
      >
        <HmTable
          minWidth={1000}
          data={data?.data}
          columns={columns}
          page={params?.page}
          rowsPerPage={params?.size}
          totalItems={data?.recordsTotal}
          onPageChange={handlePageChange}
          handleRowsPerPageChange={handleRowsPerPageChange}
          showNumberColumn={false}
          loading={false}
          onSort={(column) => handleSort(column as keyof (typeof data.data)[0])}
        />
      </Box>
      {/* <HistoryContract onClose={modalHistroy?.closeModal} isModalOpen={true} /> */}
      <ModalEndContract
        employeeId="b631595e-d2b9-40d7-993f-d4d910a63c1e"
        isOpen={modalEnd?.isOpen}
        onClose={false}
      />
      <HmModal
        isOpen={modalResign?.isOpen}
        onClose={modalResign?.closeModal}
        title="Resign Karyawan"
        zIndex={1}
        isAction={true}
        labelAction="Reject"
        onClickAction={handleResignKaryawan}
        isDisableButton={false}
        maxWidth="md"
      >
        <Grid2 container spacing={2} padding={2}>
          <ListItem label="Example Label" value="Example for value" />
          <ListItem label="Example Label" value="Example for value" />
          <HmTextField
            placeholder='Type "action" to enable the button'
            value={undefined}
            onChange={undefined}
          />
        </Grid2>
      </HmModal>
    </Box>
  );
};

export default Kontrak;
