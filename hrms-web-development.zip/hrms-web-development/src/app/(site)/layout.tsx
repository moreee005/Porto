import { Box } from '@mui/material';
import Sidebar from '@/components/sidebar';
import Content from '@/components/content';
import NextTopLoader from 'nextjs-toploader';

export default function SiteLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <Box display="flex" minHeight="100vh" sx={{ overflow: 'hidden' }}>
      <NextTopLoader />
      <Sidebar />
      <Box sx={{ flexGrow: 1, overflowY: 'auto', minHeight: '100%' }}>
        <Content>{children}</Content>
      </Box>
    </Box>
  );
}
