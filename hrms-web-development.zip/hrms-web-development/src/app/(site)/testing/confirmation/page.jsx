'use client';

import React, { useState } from 'react';
import { HmButton, HmTypography, HmConfirmation } from '@/components/component';

export default function page() {
  const [openConfirmation, setOpenConfirmation] = useState(false);

  const handleCloseConfirmation = () => {
    setOpenConfirmation(false);
  };

  const handleOpenConfirmation = () => {
    setOpenConfirmation(true);
  };

  const handleConfirm = async () => {
    console.log('confirm');
  };

  return (
    <>
      <HmButton
        label={<HmTypography>Confirmation</HmTypography>}
        onClick={handleOpenConfirmation}
      />
      <HmConfirmation
        open={openConfirmation}
        onClose={handleCloseConfirmation}
        onConfirm={handleConfirm}
        fullWidth
        fixedWidth="600px"
        centeredContent
        title={
          <div>
            <HmTypography fontSize="20px" semiBold>
              This is Tittle
            </HmTypography>
          </div>
        }
        content={
          <HmTypography>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not
            only five centuries, but also the leap into electronic typesetting,
            remaining essentially unchanged. It was popularised in the 1960s
            with the release of Letraset sheets containing Lorem Ipsum passages,
            and more recently with desktop publishing software like Aldus
            PageMaker including versions of Lorem Ipsum.
          </HmTypography>
        }
        confirmLabel={
          <HmTypography bold small sx={{ marginLeft: '0.5rem' }}>
            Save Changes
          </HmTypography>
        }
      />
    </>
  );
}
