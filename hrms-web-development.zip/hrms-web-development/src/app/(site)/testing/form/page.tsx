'use client';

import React from 'react';
import { useForm } from 'react-hook-form';

interface FormData {
  username: string;
  password: string;
  number: number;
}

function App() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  const onSubmit = (data: FormData) => {
    console.log(data); // Output data form
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div>
        <input
          {...register('username', {
            required: 'this field must not empty',
            maxLength: {
              value: 2,
              message: 'Maximum length is 2 characters',
            },
          })}
          placeholder="Username"
        />
        {errors.username && (
          <span style={{ color: 'red' }}>{errors.username.message}</span>
        )}
      </div>

      <div>
        <input
          type="password"
          {...register('password', {
            required: 'this field must not empty',
            minLength: {
              value: 2,
              message: 'Minimum length is 2 characters',
            },
          })}
          placeholder="Password"
        />

        {errors.password && (
          <span style={{ color: 'red' }}>{errors.password.message}</span>
        )}
      </div>
      <div>
        <input
          type="number"
          {...register('number', {
            max: {
              value: 3,
              message: 'max number 3', // JS only: <p>error message</p> TS only support string
            },
            min: {
              value: 1,
              message: 'min number 1', // JS only: <p>error message</p> TS only support string
            },
          })}
        />
        {errors.number && (
          <span style={{ color: 'red' }}>{errors.number.message}</span>
        )}
      </div>
      <button type="submit">Submit</button>
    </form>
  );
}
export default App;
