'use client';

import React from 'react';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import { HmChip } from '@/components/component';

export default function page() {
  return (
    <ThemeProvider theme={theme}>
      <div style={{ margin: '10px', display: 'flex', gap: '10px' }}>
        <HmChip
          label={'Allocated'}
          textColor={theme.palette.success.main}
          backgroundColor={theme.palette.success.light}
        />
      </div>
    </ThemeProvider>
  );
}
