'use client';

import React from 'react';
import { HmTypography } from '@/components/component';

export default function page() {
  return <HmTypography>HmTypography</HmTypography>;
}
