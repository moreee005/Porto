'use client';

import colors from '@/components/colors';
import { HmButton } from '@/components/component';
import { useToast } from '@/context/toastContext';
import { Grid, Grid2 } from '@mui/material';
import React from 'react';

const Toast: React.FC = () => {
  const { showToast } = useToast();

  const message = 'This is a toast message';

  const handleSuccess = () => {
    showToast('success', message);
  };

  const handleError = () => {
    showToast('error', message);
  };

  const handleInfo = () => {
    showToast('info', message);
  };

  const handleWarning = () => {
    showToast('warning', message);
  };

  return (
    <Grid2 container sx={{ padding: '20px' }} gap={2}>
      <Grid item>
        <HmButton
          onClick={handleSuccess}
          label={'success'}
          color={colors.palette.success}
          labelColor={colors.palette.white}
        ></HmButton>
      </Grid>
      <Grid item>
        <HmButton
          onClick={handleError}
          label={'error'}
          color={colors.palette.error}
          labelColor={colors.palette.white}
        ></HmButton>
      </Grid>
      <Grid item>
        <HmButton
          onClick={handleInfo}
          label={'info'}
          color={colors.palette.info}
          labelColor={colors.palette.white}
        ></HmButton>
      </Grid>
      <Grid item>
        <HmButton
          onClick={handleWarning}
          label={'warning'}
          color={colors.palette.orange}
          labelColor={colors.palette.white}
        ></HmButton>
      </Grid>
    </Grid2>
  );
};

export default Toast;
