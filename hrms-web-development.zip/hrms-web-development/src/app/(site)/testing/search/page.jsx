'use client';

import React, { useState } from 'react';
import { HmSearch } from '@/components/component';

export default function Search() {
  const [searchValue, setSearchValue] = useState('');
  const handleSearchChange = (value) => {
    setSearchValue(value);
  };

  return (
    <div style={{ margin: '10px', display: 'flex', gap: '10px' }}>
      <HmSearch searchValue={searchValue} onSearchChange={handleSearchChange} />
    </div>
  );
}
