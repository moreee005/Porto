'use client';
import React from 'react';
import { Box } from '@mui/material';
import { HmButton, HmModal, HmTextField } from '@/components/component';
import colors from '@/components/colors';

const App = () => {
  const [isModalBasicOpen, setIsModalBasicOpen] = React.useState(false);
  const [isModalBasicActionOpen, setIsModalBasicActionOpen] =
    React.useState(false);
  const [isModalBasicActionDisable, setIsModalBasicActionDisable] =
    React.useState(false);
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isModalOpenNested, setIsModalOpenNested] = React.useState(false);

  const [isDisableButton, setIsDisableButton] = React.useState(true);
  const [inputValue, setInputValue] = React.useState('');

  const openModalBasic = () => {
    setIsModalBasicOpen(true);
  };

  const openModalBasicAction = () => {
    setIsModalBasicActionOpen(true);
  };

  const openModalBasicActionDisable = () => {
    setIsModalBasicActionDisable(true);
  };

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setIsModalBasicOpen(false);
    setIsModalBasicActionOpen(false);
  };

  const handleActionModal = () => {
    alert('Example action');
    setIsModalBasicActionOpen(false);
  };

  const handleActionNested = () => {
    setIsModalOpenNested(true);
  };

  const closeModalNested = () => {
    setIsModalOpenNested(false);
  };

  const handleInputChange = (value: string) => {
    setInputValue(value);
    setIsDisableButton(value.trim() === '');
  };

  const closeModalBasicActionDisable = () => {
    setIsModalBasicActionDisable(false);
    setInputValue('');
    setIsDisableButton(true);
  };

  const handleActionModalDisable = () => {
    alert('Example submit success');
    setIsModalBasicActionDisable(false);
    setInputValue('');
    setIsDisableButton(true);
  };
  return (
    <>
      <Box
        style={{
          minHeight: '100vh',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: '1rem',
        }}
      >
        <HmButton
          label="Open Basic Modal"
          color={colors.palette.secondary}
          onClick={openModalBasic}
        />

        <HmButton
          label="Open Basic Action Modal"
          color={colors.palette.warning}
          onClick={openModalBasicAction}
        />

        <HmButton
          label="Open Basic Action Modal Disabled"
          color={colors.palette.error}
          onClick={openModalBasicActionDisable}
        />

        <HmButton
          label="Open Nested Modal"
          color={colors.palette.info}
          onClick={openModal}
        />
      </Box>

      {/* Basic modal */}
      <HmModal
        isOpen={isModalBasicOpen}
        onClose={closeModal}
        title="Appove Modal"
        zIndex={1}
        maxWidth="xs"
      >
        <p>This is the content of the modal!</p>
      </HmModal>

      {/* Basic modal with action button */}
      <HmModal
        isOpen={isModalBasicActionOpen}
        onClose={closeModal}
        title="Basic Action Modal"
        zIndex={1}
        isAction={true}
        labelAction="Action"
        onClickAction={handleActionModal}
        maxWidth="sm"
      >
        <p>This is the content of the basic action modal!</p>
      </HmModal>

      {/* Basic modal with action button disabled */}
      <HmModal
        isOpen={isModalBasicActionDisable}
        onClose={closeModalBasicActionDisable}
        title="Basic Action Modal Disabled"
        zIndex={1}
        isAction={true}
        labelAction="Action"
        onClickAction={handleActionModalDisable}
        isDisableButton={isDisableButton}
        maxWidth="md"
      >
        <HmTextField
          placeholder='Type "action" to enable the button'
          value={inputValue}
          onChange={handleInputChange}
        />
      </HmModal>

      {/* Nested modal with icon action button */}
      <HmModal
        isOpen={isModalOpen}
        onClose={closeModal}
        title="Basic Nested Modal"
        zIndex={2}
        isAction={true}
        onClickAction={handleActionNested}
        labelAction="Action"
        colorActionButton={colors.palette.success}
        isIconActionButton={true}
        maxWidth="lg"
      >
        <p>This is the content of the basic nested modal!</p>
      </HmModal>

      <HmModal
        isOpen={isModalOpenNested}
        onClose={closeModalNested}
        title="Example Modal"
        zIndex={4}
        maxWidth="xl"
      >
        <p>This is the content of the nested modal!</p>
      </HmModal>
    </>
  );
};

export default App;
