'use client';

import React from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import {
  FieldComponent,
  HmButton,
  HmDynamicForm,
} from '@/components/component';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';

const schema = Yup.object().shape({
  username: Yup.string()
    .required('Username is required')
    .min(3, 'Username must be at least 3 characters'),
  password: Yup.string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters'),
  description: Yup.string()
    .required('Description is required')
    .max(500, 'Description must be at most 500 characters'),
  kontrak: Yup.string().required('Kontrak  is required'),
  birthDate: Yup.date().required('Birth Date is required'),
  gender: Yup.string().required('Gender is required'),
  uploadedFiles: Yup.mixed().test(
    'fileRequired',
    'File is required',
    (value) => value && value.length > 0
  ),
  dataDiri: Yup.array()
    .min(1, 'At least one field is required')
    .of(
      Yup.object().shape({
        name: Yup.string().required('Name is required'),
        email: Yup.string()
          .email('Invalid email format')
          .required('Email is required'),
        role: Yup.string().required('Role is required'),
      })
    ),
  lainLain: Yup.array().of(
    Yup.object().shape({
      birthDate: Yup.date().required('Birth Date is required'),
      status: Yup.string().required('statusis required'),
      role: Yup.string().required('Role is required'),
    })
  ),
});

const RhfTest = () => {
  const methods = useForm({
    resolver: yupResolver(schema),
    // mode: "onChange",
    //  mode:"onBlur",
    defaultValues: {
      username: '',
      password: '',
      description: '',
      kontrak: '',
      birthDate: null,
      dataDiri: [],
      lainLain: [],
    },
  });

  const onSubmit = (data) => {
    console.log(data);
  };

  return (
    <div style={{ margin: '4rem' }}>
      <FormProvider {...methods}>
        <form onSubmit={methods.handleSubmit(onSubmit)}>
          <FieldComponent
            name="username"
            label="Username"
            required
            placeholder="Enter your username"
            fullWidth
          />

          <FieldComponent
            name="password"
            label="Password"
            required
            inputType="password"
            visibilityToggle
            width="500px"
          />

          <FieldComponent
            name="description"
            label="Description"
            required
            type="textarea"
            placeholder="Enter a description"
            fullWidth
          />

          <FieldComponent
            type="autocomplete"
            name="kontrak"
            label="Kontrak"
            options={[
              { id: 1, value: 'Fulltime' },
              { id: 2, value: 'Probation' },
              { id: 3, value: 'Ojt' },
            ]}
            required
            onChange={(newValue) => {
              methods.setValue('kontrak', newValue);
            }}
            placeholder="Kontrak"
          />
          <FieldComponent
            type="autocomplete"
            name="kontrak"
            fieldLabel="Kontrak"
            options={[
              { id: 1, value: 'Fulltime' },
              { id: 2, value: 'Probation' },
              { id: 3, value: 'Ojt' },
            ]}
            onChange={(newValue) => {
              methods.setValue('kontrak', newValue);
            }}
            width="200px"
          />
          <FieldComponent
            name="kontrak"
            label="Select"
            type="dropdown"
            options={[
              { id: 1, value: 'Fulltime' },
              { id: 2, value: 'Probation' },
              { id: 3, value: 'Ojt' },
            ]}
            required
            placeholder="Kontrak"
            variant="filled"
            size="small"
          />
          <FieldComponent
            name="kontrak"
            type="dropdown"
            options={[
              { id: 1, value: 'Fulltime' },
              { id: 2, value: 'Probation' },
              { id: 3, value: 'Ojt' },
            ]}
            variant="filled"
            size="small"
          />

          <FieldComponent
            name="birthDate"
            label="Tanggal Lahir"
            type="date"
            required
            size="small"
          />

          <FieldComponent
            name="birthDate"
            fieldLabel="Tanggal Lahir"
            type="date"
            size="small"
          />

          <FieldComponent
            name="gender"
            fieldLabel="Jenis Kelamin"
            type="radio"
            options={[
              { id: 1, value: 'Male' },
              { id: 2, value: 'Female' },
              { id: 3, value: 'Female' },
            ]}
            flex
          />

          <FieldComponent
            name="uploadedFiles"
            label="Upload Files"
            type="file"
            required
            fullWidth={false}
          />

          <HmDynamicForm
            name="dataDiri"
            label="Data Diri"
            required
            columns={[
              {
                header: 'Name',
                field: 'name',
                type: 'textfield',
                placeholder: 'Enter name',
                hideLabel: true,
              },
              {
                header: 'Email',
                field: 'email',
                type: 'textfield',
                placeholder: 'Enter email',
                hideLabel: true,
              },
              {
                header: 'Role',
                field: 'role',
                type: 'select',
                options: [
                  { id: 1, value: 'Admin' },
                  { id: 2, value: 'User ' },
                ],
                placeholder: 'Select role',
                size: 'small',
                hideLabel: true,
              },
            ]}
            buttonText="Add Row"
            control={methods.control}
          />

          <HmDynamicForm
            name="lainLain"
            label="Lain Lain"
            required
            columns={[
              {
                header: 'Birth Date',
                name: 'birthDate',
                field: 'birthDate',
                type: 'date',
                size: 'small',
                hideLabel: true,
              },
              {
                header: 'Status',
                field: 'status',
                type: 'radio',
                flex: true,
                options: [
                  { id: 1, value: 'Aktif' },
                  { id: 2, value: 'Tidak Aktif' },
                ],
                hideLabel: true,
              },
              {
                header: 'Role',
                field: 'role',
                type: 'autocomplete',
                options: [
                  { id: 1, value: 'Admin' },
                  { id: 2, value: 'User ' },
                ],
                placeholder: 'Select role',
                hideLabel: true,
              },
            ]}
            buttonText="Add Row"
            control={methods.control}
          />

          <HmButton type="submit" label="Submit" />
        </form>
      </FormProvider>
    </div>
  );
};

export default RhfTest;
