'use client';

import React from 'react';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import { HmTypography, HmButton } from '@/components/component';
import { PiNotePencilBold } from 'react-icons/pi';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import { FaListOl, FaWhatsapp } from 'react-icons/fa';
import { FiTrash } from 'react-icons/fi';
import { FaPlus } from 'react-icons/fa6';
import { GrDocumentExcel } from 'react-icons/gr';

export default function page() {
  return (
    <ThemeProvider theme={theme}>
      <div style={{ margin: '10px', display: 'flex', gap: '10px' }}>
        <HmButton
          icon={<MdOutlineRemoveRedEye size={16} />}
          labelColor={theme.palette.info.main}
          color={theme.palette.info.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<PiNotePencilBold size={16} />}
          labelColor={theme.palette.warning.main}
          color={theme.palette.warning.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<FiTrash size={16} />}
          labelColor={theme.palette.error.main}
          color={theme.palette.error.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<FaPlus size={16} />}
          labelColor={theme.palette.primary.main}
          color={theme.palette.primary.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          label={
            <HmTypography extraSmall semiBold>
              EXTEND
            </HmTypography>
          }
          color={theme.palette.success.main}
          borderRadius="10"
        />
        <HmButton
          label={
            <HmTypography extraSmall semiBold>
              END
            </HmTypography>
          }
          color={theme.palette.error.main}
          borderRadius="10"
        />
        <HmButton
          icon={
            <HmTypography extraSmall semiBold>
              DETAIL
            </HmTypography>
          }
          color={theme.palette.primary.main}
          borderRadius="10"
        />
        <HmButton
          icon={
            <HmTypography extraSmall semiBold>
              UPDATE
            </HmTypography>
          }
          color={theme.palette.warning.main}
          borderRadius="10"
        />
        <HmButton
          icon={<GrDocumentExcel size={16} />}
          labelColor={theme.palette.secondary.main}
          color={theme.palette.secondary.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<FaListOl size={16} />}
          labelColor={theme.palette.orange.main}
          color={theme.palette.orange.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<FaWhatsapp size={16} />}
          labelColor={theme.palette.success.main}
          color={theme.palette.success.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
      </div>
    </ThemeProvider>
  );
}
