'use client';

import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { HmAutoComplete } from '@/components/component';

const schema = Yup.object().shape({
  contract: Yup.string().required('Kontrak harus dipilih'), // Validasi: harus diisi
});

export default function Page() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onBlur', // Set mode ke "onChange"
    defaultValues: { contract: '' }, // Set default value jika perlu
  });

  const onSubmit = (data) => {
    console.log(data);
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      style={{ margin: '10px', display: 'flex', gap: '10px' }}
    >
      <Controller
        name="contract"
        control={control}
        defaultValue="" // Set default value untuk Controller
        render={({ field: { onChange, onBlur, value } }) => (
          <HmAutoComplete
            options={['Fulltime', 'Probation', 'Ojt']}
            value={value}
            label="Kontrak"
            onChange={(event, newValue) => {
              onChange(newValue); // Set nilai ke React Hook Form
            }}
            onBlur={onBlur} // Panggil onBlur untuk validasi
            error={!!errors.contract} // Tampilkan error jika ada
            helperText={errors.contract ? errors.contract.message : ''} // Tampilkan pesan error
            width="200px"
          />
        )}
      />
      <button type="submit">Submit</button>
    </form>
  );
}
