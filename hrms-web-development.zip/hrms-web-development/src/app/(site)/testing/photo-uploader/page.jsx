'use client';

import * as React from 'react';
import { Box, Typography } from '@mui/material';
import { HmPhotoUploader } from '@/components/component';

export default function PhotoUploaderPage() {
  const [uploadedFile, setUploadedFile] = React.useState(null);

  const handleFileUpload = (file) => {
    setUploadedFile(file);
    if (file) {
      console.log('Uploaded file:', file.name);
      console.log('File size:', file.size);
      console.log('File type:', file.type);
    } else {
      console.log('No file uploaded.');
    }
  };

  return (
    <Box
      sx={{
        maxWidth: 600,
        margin: 'auto',
        padding: 4,
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
        textAlign: 'center',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Typography variant="h4" component="h1" gutterBottom>
        Photo Uploader Page
      </Typography>
      <HmPhotoUploader
        onFileUpload={handleFileUpload}
        initialPreview={
          uploadedFile ? URL.createObjectURL(uploadedFile) : undefined
        }
        width="100px"
        height="100px"
        borderRadius="12px"
      />
      {uploadedFile && (
        <Typography variant="body1" sx={{ marginTop: 2 }}>
          {uploadedFile.name}
        </Typography>
      )}
    </Box>
  );
}
