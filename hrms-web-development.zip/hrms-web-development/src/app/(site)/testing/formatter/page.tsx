'use client';
import { calculateAge, formatDate, formatIdr } from '@/utils/truncate';
import React from 'react';

const Formatter = () => {
  const date = '2024-11-03';
  const formattedDate = formatDate(date);

  const rupee = 1000000;
  const formatToIdr = formatIdr(rupee);

  const age1 = calculateAge('2000-03-02');
  const age2 = calculateAge('1999-03-02');
  const age3 = calculateAge('2024-11-02');
  const age4 = calculateAge('2024-12-02');

  return (
    <div>
      <h1>Formatter Date</h1>
      <h3>Date To :{formattedDate.ddmmyyyy}</h3>
      <h3>Date To :{formattedDate.fullDate}</h3>
      <h3>Date To :{formattedDate.dateMonthYear}</h3>
      <h3>Date To :{formattedDate.shortDate}</h3>
      <h3>Date To :{formattedDate.dayOnly}</h3>
      <h3>Date To :{formattedDate.monthOnly}</h3>
      <h3>Date To :{formattedDate.shortMonthOnly}</h3>
      <h3>Date To :{formattedDate.yearOnly}</h3>
      <h1>Formatter IDR</h1>
      <h3>Format IDR :{formatToIdr}</h3>
      <h1>Formatter Age</h1>
      <h3>Age :input : 2000-03-02 output {age1}</h3>
      <h3>Age :input : 1999-03-02 output {age2}</h3>
      <h3>Age :input : 2024-11-02 output {age3}</h3>
      <h3>Age :input : 2024-12-02 output {age4}</h3>
    </div>
  );
};

export default Formatter;
