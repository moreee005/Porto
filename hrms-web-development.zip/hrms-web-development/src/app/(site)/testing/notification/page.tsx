'use client';

import React from 'react';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import HmNotification from '@/components/component/HmNotification';

const notification = [
  {
    id: '1',
    title: 'This is title of notification',
    date: '12 Nov 2024',
    description: 'This is description of notifcation!',
    image: 'none',
  },
  {
    id: '2',
    title: 'This is title of notification 2',
    date: '13 Nov 2024',
    description: 'This is description of notifcation2!',
    image: 'none',
  },
];

export default function testingNotification() {
  return (
    <ThemeProvider theme={theme}>
      <div style={{ margin: '10px', display: 'flex', gap: '10px' }}>
        <HmNotification itemProps={notification} />
      </div>
    </ThemeProvider>
  );
}
