'use client';

import React, { useState } from 'react';
import {
  HmButton,
  HmCard,
  HmChip,
  HmTable,
  HmTypography,
} from '@/components/component';
import { Container } from '@mui/material';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import { PiNotePencilBold } from 'react-icons/pi';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import { FaWhatsapp } from 'react-icons/fa';

interface Employee {
  foto: string;
  nama: string;
}

interface Data {
  id: number;
  employee: Employee;
  kontrak: string;
  jabatan: string;
  posisi: string;
  penempatan: string;
  bank: boolean;
}

const dummyData = [
  {
    id: 1,
    employee: {
      foto: 'https://via.placeholder.com/50',
      nama: 'John Doe',
    },
    kontrak: 'Fulltime',
    jabatan: 'UI/UX Designer',
    posisi: 'Bandung',
    penempatan: 'Jakarta',
    bank: true,
  },
  {
    id: 2,
    employee: {
      foto: 'https://picsum.photos/200/300',
      nama: 'Jane Smith',
    },
    kontrak: 'Probation',
    jabatan: 'Frontend',
    posisi: 'Yogyakarta',
    penempatan: 'Bandung',
    bank: false,
  },

  // Add more data as needed
];

const columns = [
  {
    header: 'Employee',
    accessor: (row: Data) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <img
          src={row.employee.foto}
          alt={row.employee.nama}
          style={{ width: '30px', height: '30px', borderRadius: '50%' }}
        />
        <HmTypography semiBold small>
          {row.employee.nama}
        </HmTypography>
      </div>
    ),
  },
  {
    header: 'Kontrak',
    accessor: (row: Data) => {
      // Menentukan warna berdasarkan jenis kontrak
      let chipStyle = {};
      if (row.kontrak === 'Fulltime') {
        chipStyle = {
          color: theme.palette.info.main, // Teks warna info
          backgroundColor: theme.palette.info.light, // Background warna info
        };
      } else if (row.kontrak === 'Probation') {
        chipStyle = {
          color: theme.palette.success.main, // Teks warna success
          backgroundColor: theme.palette.success.light, // Background warna success
        };
      } else {
        chipStyle = {
          color: theme.palette.warning.main, // Teks warna warning
          backgroundColor: theme.palette.warning.light, // Background warna warning
        };
      }

      return <HmChip label={row.kontrak} sx={chipStyle} />;
    },
  },
  {
    header: 'Jabatan',
    accessor: (row: Data) => (
      <HmTypography small color="#5D6283">
        {row.jabatan}
      </HmTypography>
    ),
  },
  {
    header: 'Posisi',
    accessor: (row: Data) => (
      <HmTypography small color="#5D6283">
        {row.posisi}
      </HmTypography>
    ),
  },
  {
    header: 'Penempatan',
    accessor: (row: Data) => (
      <HmTypography small color="#5D6283">
        {row.penempatan}
      </HmTypography>
    ),
  },
  {
    header: 'Bank',
    accessor: (row: Data) => (row.bank ? 'Yes' : 'No'),
  },
  {
    header: 'Action',
    accessor: () => (
      <div style={{ margin: '10px', display: 'flex', gap: '10px' }}>
        <HmButton
          icon={<MdOutlineRemoveRedEye size={16} />}
          labelColor={theme.palette.info.main}
          color={theme.palette.info.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<FaWhatsapp size={16} />}
          labelColor={theme.palette.success.main}
          color={theme.palette.success.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
        <HmButton
          icon={<PiNotePencilBold size={16} />}
          labelColor={theme.palette.warning.main}
          color={theme.palette.warning.light}
          borderRadius="10"
          sx={{
            minWidth: '28px',
            width: '28px',
            height: '28px',
          }}
        />
      </div>
    ),
  },
];
export default function Table() {
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handlePageChange = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleRowsPerPageChange = (value: number) => {
    setRowsPerPage(value);
  };
  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="xl" sx={{ marginTop: '2rem' }}>
        <HmCard
          bodyOnly
          bodyContent={
            <>
              <HmTypography big bold>
                Contract List
              </HmTypography>
              <HmTable
                data={dummyData}
                columns={columns}
                loading={loading}
                page={page}
                rowsPerPage={rowsPerPage}
                totalItems={dummyData.length}
                onPageChange={handlePageChange}
                handleRowsPerPageChange={handleRowsPerPageChange}
              />
            </>
          }
        />
      </Container>
    </ThemeProvider>
  );
}
