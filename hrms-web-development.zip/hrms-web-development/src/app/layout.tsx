import { Metadata } from 'next';
import localFont from 'next/font/local';
import './globals.css';
import { DrawerProvider } from '@/context/drawerContext';
import { ToastProvider } from '@/components/providers/ToastProvider';

const sourceSans = localFont({
  src: '../fonts/SourceSans3-VariableFont_wght.ttf',
  variable: '--font-source-sans',
  weight: '400 500 600 700 800',
});

const sourceSansItalic = localFont({
  src: '../fonts/SourceSans3-Italic-VariableFont_wght.ttf',
  variable: '--font-source-sans-italic',
  weight: '400 500 600 700 800',
});

export const metadata: Metadata = {
  title: 'HRMS',
  description: 'Human Resource Management System',
  icons: {
    icon: '/logo-no-text.svg',
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={`${sourceSans.variable} ${sourceSansItalic.variable}`}>
        <DrawerProvider>
          <ToastProvider>{children}</ToastProvider>
        </DrawerProvider>
      </body>
    </html>
  );
}
