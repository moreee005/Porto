import Sidebar from '@/components/sidebar';

export default function Home() {
  return <Sidebar />;
}
