'use client';

import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { Box } from '@mui/material';
import {
  HmButton,
  HmTextField,
  HmTypography,
  HmLink,
  HmDivider,
} from '@/components/component';
import Cookies from 'js-cookie';
import Image from 'next/image';
import GoogleIcon from '@public/icons/google-icon.svg';
import ProfileIcon from '@public/icons/human-icon.svg';
import InfoIcon from '@public/icons/information-icon.svg';
import Tooltip from '@mui/material/Tooltip';
import { useRouter } from 'next/navigation';
import { useToast } from '@/context/toastContext';
import { API } from '@/services/setupAxios';
import { AxiosError } from 'axios';

interface LoginFormInputs {
  email: string;
  password: string;
}

const schema = yup.object().shape({
  email: yup
    .string()
    .required('Email is required')
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      'Email is not valid'
    ),
  password: yup
    .string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters'),
});

const Login = () => {
  const router = useRouter();
  const { showToast } = useToast();
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormInputs>({
    resolver: yupResolver(schema),
  });

  const handleLoginWithGoogle = async () => {
    console.log('Login with Google');
  };
  // with API
  const onSubmit = async (data: LoginFormInputs) => {
    try {
      // API call to login
      const response = await API('userManagement.login', {
        data: {
          email: data.email,
          password: data.password,
        },
      });
      // show toast if login success
      showToast('success', response.data.message);
      // set cookies
      Cookies.set('userId', response.data.data.userId);
      Cookies.set('accessToken', response.data.data.accessToken);
      // redirect to main page
      router.push('/karyawan');
    } catch (error) {
      if ((error as AxiosError).status === 404) {
        showToast('error', 'Email not found');
      } else {
        showToast('error', (error as Error).message);
      }
    }
  };

  return (
    <Box sx={{ maxWidth: 400, width: '100%', margin: 'auto', px: 2 }}>
      {/* Google Login */}
      <Box sx={{ display: 'grid', justifyItems: 'center' }}>
        <HmTypography
          big
          color="gray"
          sx={{
            fontSize: 16,
            marginTop: 5,
            marginBottom: 1,
          }}
        >
          Login with
        </HmTypography>
      </Box>

      <Box sx={{ display: 'grid', justifyItems: 'center' }}>
        <HmButton
          type="submit"
          variant="contained"
          onClick={handleLoginWithGoogle}
          icon={
            <Image
              src={GoogleIcon}
              alt="google-icon"
              width={18}
              height={18}
              priority
              style={{ marginRight: '10px' }}
            />
          }
          label="Google"
          labelColor="#3c4043"
          color="#ffffff"
          borderColor="#dadce0"
          sx={{
            width: { xs: '100%', sm: '200px' },
            marginTop: 1,
            marginBottom: 1,
            fontSize: 16,
            paddingY: 1,
            '&:hover': { backgroundColor: '#514bcf' },
          }}
        />
      </Box>

      <Box sx={{ display: 'grid', justifyItems: 'center' }}>
        <HmDivider sx={{ marginBottom: 20, marginTop: 20 }} />
      </Box>

      {/* Form */}
      <form onSubmit={handleSubmit(onSubmit)}>
        <Box>
          {/* Email Field */}
          <Box>
            <HmTypography color="black">
              Email <span style={{ color: 'red' }}>*</span>
              <Tooltip
                title="Please enter a valid email address (e.g.,example@domain.com)"
                placement="top"
                arrow
              >
                <Image
                  src={InfoIcon}
                  alt="info-icon"
                  width={14}
                  height={14}
                  priority
                />
              </Tooltip>
            </HmTypography>
          </Box>
          <Box>
            <Controller
              name="email"
              control={control}
              render={({ field }) => (
                <HmTextField
                  {...field}
                  label="Email"
                  placeholder="Email"
                  error={!!errors.email}
                  helperText={errors.email?.message}
                  startIcon={
                    <Image
                      src={ProfileIcon}
                      alt="profile-icon"
                      width={23}
                      height={23}
                      priority
                    />
                  }
                  sx={{ marginBottom: 2 }}
                />
              )}
            />
          </Box>

          {/* Password Field */}
          <Box>
            <HmTypography color="black">
              Password <span style={{ color: 'red' }}>*</span>
              <Tooltip
                title="Please enter a password of at least 6 characters"
                placement="top"
                arrow
              >
                <Image
                  src={InfoIcon}
                  alt="info-icon"
                  width={14}
                  height={14}
                  priority
                />
              </Tooltip>
            </HmTypography>
          </Box>
          <Box>
            <Controller
              name="password"
              control={control}
              render={({ field }) => (
                <HmTextField
                  {...field}
                  type="password"
                  label="Password"
                  placeholder="Password"
                  error={!!errors.password}
                  helperText={errors.password?.message}
                  startIcon={
                    <Image
                      src={ProfileIcon}
                      alt="profile-icon"
                      width={23}
                      height={23}
                      priority
                    />
                  }
                  sx={{ marginBottom: 1 }}
                />
              )}
            />
          </Box>

          {/* Forgot Password */}
          <Box sx={{ textAlign: 'right', mt: 1 }}>
            <HmLink href="#" color="#6c63ff">
              Forgot Password
            </HmLink>
          </Box>

          {/* Submit Button */}
          <Box
            sx={{
              display: 'grid',
              justifyItems: 'center',
              marginTop: 3,
              marginBottom: 5,
            }}
          >
            <HmButton
              type="submit"
              variant="contained"
              label="Sign In"
              color="#6c63ff"
              sx={{
                width: { xs: '100%', sm: '150px' }, // Responsive width
                fontSize: 16,
                paddingY: 1,
                '&:hover': { backgroundColor: '#514bcf' },
              }}
            />
          </Box>
        </Box>
      </form>
    </Box>
  );
};

export default Login;
