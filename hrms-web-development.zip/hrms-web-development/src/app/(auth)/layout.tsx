import { Box } from '@mui/material';
import NextTopLoader from 'nextjs-toploader';
import AuthContent from '@/components/authContent';

export default function SiteLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <Box display="flex" minHeight="100vh" sx={{ overflow: 'hidden' }}>
      <NextTopLoader />
      <Box sx={{ flexGrow: 1, overflowY: 'auto', minHeight: '100%' }}>
        <AuthContent>{children}</AuthContent>
      </Box>
    </Box>
  );
}
