/**
 * Fungsi untuk memformat path URL menjadi array breadcrumb.
 * Contoh:
 * "/karyawan/tambah-karyawan" => ["Karyawan", "Tambah Karyawan"]
 * "/karyawan" => ["Karyawan"]
 */
export function formatBreadcrumb(path: string): string[] {
  if (!path) return [];
  const segments = path.split('/').filter((segment) => segment);
  return segments.map((segment) =>
    segment
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ')
  );
}

/**
 * Fungsi untuk memformat path URL menjadi title aplikasi.
 * Contoh:
 * "/karyawan/tambah-karyawan" => "Tambah Karyawan"
 * "/karyawan" => "Karyawan"
 * "/karyawan/detail-karyawan/1" => "Detail Karyawan"
 */
export const formatAppTitle = (pathname: string): string => {
  let pathParts = pathname.split('/');

  if (pathParts.length === 2) {
    return pathParts[1]
      .split('-')
      .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  return pathParts[2]
    .split('-')
    .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

// Utility function to format IDR
export function formatIdr(value: number): string {
  return `Rp ${value.toLocaleString('id-ID')}`;
}

// Utility function to format date with YYYY-MM-DD input
export function formatDate(dateString: string): {
  ddmmyyyy: string;
  fullDate: string;
  dateMonthYear: string;
  shortDate: string;
  dayOnly: string;
  monthOnly: string;
  yearOnly: string;
  shortMonthOnly: string;
} {
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const months = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];
  const shortMonths = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'Mei',
    'Jun',
    'Jul',
    'Agu',
    'Sep',
    'Okt',
    'Nov',
    'Des',
  ];

  const date = new Date(dateString); // Convert the YYYY-MM-DD string to a Date object

  // Format DD/MM/YYYY
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  const ddmmyyyy = `${dd}/${mm}/${yyyy}`;

  // Format Hari, Tanggal Bulan Tahun
  const dayName = days[date.getDay()];
  const monthName = months[date.getMonth()];
  const fullDate = `${dayName}, ${date.getDate()} ${monthName} ${yyyy}`;

  // Format Tanggal Bulan Tahun
  const dateMonthYear = `${date.getDate()} ${monthName} ${yyyy}`;

  // Format Singkat Tanggal Bulan Tahun
  const shortMonthName = shortMonths[date.getMonth()];
  const shortDate = `${date.getDate()} ${shortMonthName} ${yyyy}`;

  // Day, Month, Year only
  const dayOnly = `${date.getDate()}`;
  const monthOnly = `${monthName}`;
  const shortMonthOnly = `${shortMonthName}`;
  const yearOnly = `${yyyy}`;

  return {
    ddmmyyyy,
    fullDate,
    dateMonthYear,
    shortDate,
    dayOnly,
    monthOnly,
    yearOnly,
    shortMonthOnly,
  };
}

// Utility function to calculate age with YYYY-MM-DD input
export function calculateAge(birthDate: string): string {
  const birth = new Date(birthDate); // Convert the birth date string to Date object
  const today = new Date();

  const years = today.getFullYear() - birth.getFullYear();
  const months = today.getMonth() - birth.getMonth();
  const days = today.getDate() - birth.getDate();

  let age = '';

  if (years > 0) {
    age = `${years} tahun`;
  }

  // Show months if there are months
  if (months > 0 || (months === 0 && days > 0)) {
    if (age) age += ' ';
    age += `${months} bulan`;
  }

  // If no full years or months, show the difference in days
  if (years === 0 && months === 0) {
    if (days > 0) {
      age = `${days} hari`;
    } else if (days === 0) {
      age = 'Hari ini';
    }
  }

  return age;
}
