import { camelCase, upperFirst } from 'lodash';

export default function toCamelCase(
  key: string,
  value: Record<string, any>
): Record<string, any> {
  // Variabel untuk menyimpan hasil konversi camelCase dan PascalCase
  let camelCaseString: string = '';
  let pascalCaseString: string = '';

  // Memeriksa apakah value adalah objek
  if (value && typeof value === 'object') {
    // Melakukan iterasi pada setiap properti objek
    for (const k in value) {
      // Jika properti dimulai dengan huruf kapital (PascalCase)
      if (/^[A-Z]/.test(k) && Object.hasOwn(value, k)) {
        // Mengubah nama properti menjadi camelCase
        camelCaseString = camelCase(k);
        // Menambahkan properti baru dengan nama camelCase dan menghapus properti lama
        value[camelCaseString] = value[k];
        delete value[k];
        // Jika properti dalam format snake_case
      } else if (/\b[a-z]+(_[a-z]+)*\b/.test(k) && Object.hasOwn(value, k)) {
        pascalCaseString = upperFirst(camelCase(k));
        value[pascalCaseString] = value[k];
        // Menambahkan properti baru dengan nama PascalCase dan menghapus properti lama
        delete value[k];

        // Mengubah nama properti PascalCase menjadi camelCase lagi
        const newKey = pascalCaseString;
        camelCaseString = camelCase(newKey);
        value[camelCaseString] = value[newKey];
        delete value[newKey];
      }
    }
  }

  // Mengembalikan objek yang sudah dimodifikasi dengan properti dalam camelCase
  return value;
}
