// formmat date
export const formatDate = (date: Date): string => {
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  return `${day} ${month} ${year}`;
};

// date info
export const getEndDateInfo = (row: any) => {
  const endDate = new Date(row.end);
  const today = new Date();
  const diffDays = Math.round(
    (endDate.getTime() - today.getTime()) / (1000 * 3600 * 24)
  );
  const is90DaysLeft = diffDays <= 90;

  return { is90DaysLeft, endDate };
};
