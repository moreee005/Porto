import React from 'react';

const menuItems = [
  {
    id: 1,
    icon: (
      <img src="/icons/extend-icon.svg" alt="extend" width={16} height={16} />
    ),
    label: 'Extend',
    labelColor: 'rgb(34, 197, 94)',
    color: 'rgb(228,247,231)',
  },
  {
    id: 2,
    icon: <img src="/icons/end-icon.svg" alt="end" width={16} height={16} />,
    label: 'End',
    labelColor: 'rgb(255, 0, 0)',
    color: 'rgb(255,232,234)',
  },
  {
    id: 3,
    icon: (
      <img src="/icons/addendum.svg" alt="addendum" width={16} height={16} />
    ),
    label: 'Addendum',
    labelColor: 'rgb(0, 0, 255)',
    color: 'rgb(234,235,249)',
  },
  {
    id: 4,
    icon: <img src="/icons/menu.svg" alt="histori" width={16} height={16} />,
    label: 'Histori',
    labelColor: 'rgb(255, 165, 0)',
    color: 'rgb(255,236,231)',
  },
  {
    id: 5,
    icon: <img src="/icons/resign.svg" alt="resign" width={16} height={16} />,
    label: 'Resign',
    labelColor: 'rgb(0, 0, 0)',
    color: 'rgb(231,232,236)',
  },
];

export default menuItems;
