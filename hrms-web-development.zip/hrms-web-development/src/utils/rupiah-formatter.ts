// without currency
export const formatRupiah = (value: number): string => {
    return new Intl.NumberFormat('id-ID', {
      minimumFractionDigits: 0
    }).format(value);
}