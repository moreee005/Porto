import { createTheme } from '@mui/material';

const theme = createTheme({
  palette: {
    primary: {
      main: '#5557CD',
      light: '#EAEBF9',
      dark: '#24283E',
    },
    secondary: {
      main: '#5C5E66',
      light: '#E7E8EC',
    },
    warning: {
      main: '#FFBB34',
      light: '#FFF6E3',
    },
    error: {
      main: '#FF3548',
      light: '#FFE8EA',
    },
    info: {
      main: '#0078D7',
      light: '#E2F0FB',
    },
    success: {
      main: '#23BD33',
      light: '#E4F7E7',
    },
    orange: {
      main: '#FF6E41',
      light: '#FFECE7',
    },
  },
});

export default theme;
