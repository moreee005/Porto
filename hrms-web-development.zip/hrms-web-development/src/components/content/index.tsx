import Navbar from '@/components/navbar';
import { Box, Container, Stack, Typography } from '@mui/material';
import { ReactNode } from 'react';
import theme from '../colors';
import Tittle from '@/components/title';
import CopyrightIcon from '@mui/icons-material/Copyright';
interface ContentProps {
  children: ReactNode;
}

const Content: React.FC<ContentProps> = ({ children }) => {
  return (
    <Box
      padding={{ xs: 0, md: 0 }}
      sx={{
        display: 'flex',
        height: '100%',
        width: '100%',
        overflow: 'hidden',
        position: 'relative',
      }}
    >
      <Stack
        bgcolor={theme.palette.whiteBackground}
        sx={{
          overflow: 'auto',
          position: 'relative',
          width: '100%',
          height: '100%',
        }}
      >
        <Box sx={{ flexShrink: 0 }}>
          <Navbar />
          {/* Section Background */}
          <Box
            sx={{
              height: '300px',
              bgcolor: theme.palette.primary,
              position: 'relative',
              zIndex: 1,
            }}
          />

          {/* Floating Content Box */}
          <Container
            sx={{
              maxWidth: 1208,
              position: 'absolute',
              top: 120,
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 3,
            }}
          >
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                flexGrow: 1,
                bgcolor: theme.palette.white,
                overflow: 'auto',
                width: '100%',
                boxShadow: ' 8px 8px 8px rgba(0, 0, 0, 0.05)',
                borderRadius: '8px',
                marginBottom: '10rem',
              }}
            >
              <Box sx={{ flexShrink: 0 }}>
                <Tittle />
              </Box>

              {children}
            </Box>
          </Container>
        </Box>
      </Stack>
      <Box
        sx={{
          bgcolor: theme.palette.grey[200],
          py: 2,
          px: 3,
          position: 'absolute',
          top: '93vh',
          alignItems: 'center',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <CopyrightIcon
            fontSize="small"
            sx={{ mr: 0.5, color: theme.palette.greyFooter }}
          />
          <Typography variant="body2" color="textSecondary">
            {2024} Tujuh Sebmbilan. All Rights Reserved.
          </Typography>
        </Box>
      </Box>
      {/* Footer */}
    </Box>
  );
};

export default Content;
