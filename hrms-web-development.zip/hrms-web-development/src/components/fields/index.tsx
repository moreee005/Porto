'use client';

import React, { useState } from 'react';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import {
  Box,
  FormControl,
  FormHelperText,
  Select,
  MenuItem,
  FormControlLabel,
  RadioGroup,
  Radio,
  Checkbox,
  FormGroup,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useController } from 'react-hook-form';
import {
  HmTextField,
  HmAutoComplete,
  HmTypography,
  HmFileUploader,
  HmButton,
  HmDropdown,
} from '@/components/component';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import { BsTrash3Fill } from 'react-icons/bs';
import HmDatePicker from '../component/HmDatePicker';

interface FieldOption {
  id: string | number;
  value: string;
}

interface FieldComponentProps {
  control: any;
  name: string;
  label?: string;
  fieldLabel?: string;
  required?: boolean;
  disabled?: boolean;
  placeholder?: string;
  type?: string;
  inputType?: string;
  hideLabel?: boolean;
  startIcon?: React.ReactNode;
  endIcon?: React.ReactNode;
  visibilityToggle?: boolean;
  sx?: Record<string, any>;
  rules?: Record<string, any>;
  size?: 'small' | 'medium' | undefined;
  fullWidth?: boolean;
  width?: string;
  options?: FieldOption[];
  flex?: boolean;
  onChange?: (value: any) => void;
  onFileNameChange?: (fileName: string) => void;
}

const FieldComponent: React.FC<FieldComponentProps> = ({
  control,
  name,
  label,
  fieldLabel,
  required = false,
  disabled,
  placeholder,
  type = 'textfield',
  inputType = 'text',
  options = [],
  visibilityToggle = false,
  hideLabel,
  startIcon,
  endIcon = null,
  sx,
  rules = {},
  size,
  fullWidth = true,
  width,
  flex,
  onFileNameChange,
  onChange,

}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [fileName, setFileName] = useState('');

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  const {
    field,
    fieldState: { error },
  } = useController({
    name,
    control,
    rules,
    defaultValue: '',
  });

  const isTextArea = Boolean(type === 'textarea');
  const placeholderTemp = placeholder ?? label;

  const renderDropdownField = () => (
    <HmDropdown
      options={options}
      value={field.value}
      onChange={(event) => {
        field.onChange(event.target.value)
        if (onChange) onChange(event.target.value);
      }}
      disabled={disabled}
      size={size}
      sx={sx}
      placeholder={placeholder}
    />
  );

  const renderAutocompleteField = () => (
    <HmAutoComplete
      options={options}
      label={fieldLabel}
      placeholder={placeholder}
      disableClearable={visibilityToggle}
      value={field.value}
      size={size}
      sx={sx}
      onChange={(event, newValue) => {
        field.onChange(newValue)
        if (onChange) onChange(newValue);
      }}
      width={width}
    />
  );

  const renderTextField = () => (
    <HmTextField
      {...field}
      sx={{
        ...sx,
        '& .MuiOutlinedInput-root': { borderRadius: sx?.borderRadius },
        input: { fontWeight: 400 },
      }}
      type={showPassword && visibilityToggle ? 'text' : inputType}
      required={required}
      disabled={disabled}
      label={label}
      placeholder={placeholderTemp}
      isTextArea={isTextArea}
      error={!!error}
      onChange={(event: string) => {
        field.onChange(event);
        if (onChange) onChange(event);
      }}
      // helperText={error?.message}
      startIcon={startIcon}
      width={width}
      endIcon={
        visibilityToggle ? (
          <button
            type="button"
            onClick={togglePasswordVisibility}
            style={{ background: 'none', border: 'none', cursor: 'pointer' }}
          >
            {showPassword ? (
              <VisibilityOffIcon sx={{ color: 'black' }} />
            ) : (
              <VisibilityIcon sx={{ color: 'black' }} />
            )}
          </button>
        ) : (
          endIcon
        )
      }
    />
  );

  const renderDatePicker = () => (
    <HmDatePicker
      name={name}
      value={field.value ? dayjs(field.value) : null}
      onChange={(newValue) => {
        field.onChange(newValue)
        if (onChange) onChange(newValue);
      }}
      error={!!error}
      // helperText={error?.message}
      disabled={disabled}
      fullWidth={fullWidth}
    />
  );

  const renderRadioField = () => (
    <RadioGroup
      name="radio-buttons-group"
      value={field.value} // field.value berupa `id`
      onChange={(event) => {
        const selectedValue = Number(event.target.value); // Mengubah ke number
        field.onChange(selectedValue); // Update nilai field
        const selectedIndex = options.findIndex(option => option.id === selectedValue); // Mencari indeks
        console.log('Selected Index:', selectedIndex); // Tampilkan indeks yang dipilih di konsol
      }}
      sx={
        flex
          ? {
            display: 'flex',
            flexDirection: 'row',
            gap: '5px',
            alignItems: 'center',
          }
          : {}
      }
    >
      {options.map((option) => (
        <FormControlLabel
          key={option.id}
          value={option.id} // Gunakan `id` sebagai nilai
          control={
            <Radio
              sx={{
                color: '#5557CD',
                '&.Mui-checked': {
                  color: 'white',
                },
                '& .MuiSvgIcon-root': {
                  borderRadius: '50%',
                  backgroundColor:
                    field.value === option.id ? '#5557CD' : 'white',
                  transition: 'background-color 0.3s ease',
                },
              }}
            />
          }
          label={option.value} // Tampilkan label dengan `value`
          sx={{
            border: `${field.value === option.id ? '1px solid #9799E1' : '1px solid #E7E8EC'}`,
            borderRadius: '6px',
            marginLeft: '1px',
            width: width,
            flex: 1,
          }}
        />
      ))}
    </RadioGroup>
  );

  const renderCheckboxField = () => (
    <FormGroup
      sx={
        flex
          ? {
            display: 'flex',
            flexDirection: 'row',
            gap: '5px',
            alignItems: 'center',
          }
          : {}
      }
    >
      {options.map((option) => (
        <FormControlLabel
          key={option.id}
          control={
            <Checkbox
              checked={Array.isArray(field.value) && field.value.includes(option.id)} // Cek apakah id ada dalam array
              onChange={(event) => {
                // Jika checkbox dicentang, set nilai baru ke array yang hanya berisi id yang dicentang
                const newValue = event.target.checked ? [option.id] : []; // Hanya satu yang bisa dipilih
                field.onChange(newValue); // Update nilai
              }}
              sx={{
                color: '#5557CD',
                '&.Mui-checked': {
                  color: '#5557CD',
                },
                '& .MuiSvgIcon-root': {
                  borderRadius: '6px',
                  backgroundColor: Array.isArray(field.value) && field.value.includes(option.id) ? '5557CD' : 'white',
                  transition: 'background-color 0.3s ease',
                },
              }}
            />
          }
          label={option.value} // Tampilkan label dengan `value`
          sx={{
            border: `${Array.isArray(field.value) && field.value.includes(option.id) ? '1px solid #9799E1' : '1px solid #E7E8EC'}`,
            borderRadius: '6px',
            marginLeft: '1px',
            padding: '5px',
            width: width,
            flex: 1,
          }}
        />
      ))}
    </FormGroup>
  );

  const renderFileUploader = () => (
    <>
      <div>
        <HmFileUploader
          onChange={(event) => {
            const files = event.target.files;
            if (files && files.length > 0) {
              field.onChange(files); // Perbarui nilai jika file dipilih
              setFileName(files[0].name); // Atur nama file pertama
            } else {
              // Jika dialog dibatalkan, tidak mengubah nilai field
              field.onChange(field.value); // Pertahankan nilai sebelumnya
            }
          }}
          nameUpload={fieldLabel}
        />
        {fileName && (
          <HmButton
            label={<BsTrash3Fill size={14} />}
            labelColor="white"
            color="red"
            borderRadius="46px"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
              marginLeft: '0.5rem',
            }}
            onClick={() => {
              setFileName(''); // Hapus nama file
              field.onChange(null); // Setel ulang nilai field
            }}
          />
        )}
      </div>

      {fileName && (
        <FormHelperText sx={{ color: 'gray', marginTop: '4px' }}>
          {fileName}
        </FormHelperText>
      )}
    </>
  );

  const renderDokumenUploader = () => (

    <div>
      <HmFileUploader
        onChange={(event) => {
          const files = event.target.files;
          if (files && files.length > 0) {
            field.onChange(files); // Perbarui nilai jika file dipilih
            setFileName(files[0].name); // Atur nama file pertama
            if (onFileNameChange) {
              onFileNameChange(files[0].name); // Panggil prop untuk mengirim nama file
            }
          } else {
            // Jika dialog dibatalkan, tidak mengubah nilai field
            field.onChange(field.value); // Pertahankan nilai sebelumnya
            if (onFileNameChange) {
              onFileNameChange(''); // Reset nama file jika tidak ada file
            }
          }
        }}
        nameUpload={fieldLabel}
      />
    </div>

  );



  const renderField = () => {
    switch (type) {
      case 'dropdown':
        return renderDropdownField();
      case 'autocomplete':
        return renderAutocompleteField();
      case 'date':
        return renderDatePicker();
      case 'radio':
        return renderRadioField();
      case 'file':
        return renderFileUploader();
      case 'checkbox':
        return renderCheckboxField();
      case 'document':
        return renderDokumenUploader();
      case 'text':
        return renderTextField();
      default:
        return renderTextField();
    }
  };

  return (
    <Box>
      <FormControl fullWidth={fullWidth}>
        {!hideLabel && (
          <HmTypography sx={{ marginBottom: '4px' }}>
            {label} {required && <span style={{ color: 'red' }}>*</span>}
          </HmTypography>
        )}

        {renderField()}
        <FormHelperText
          sx={{
            overflowWrap: 'break-word',
            visibility: error ? 'visible' : 'hidden',
            color: error ? 'red' : 'black',
            marginLeft: '16px !important',
          }}
        >
          {error?.message || ''}
        </FormHelperText>
      </FormControl>
    </Box>
  );
};

export default FieldComponent;
