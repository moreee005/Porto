'use client';

import theme from '@/components/colors';
import { HmButton, HmTypography } from '@/components/component';
import { VARIABLES } from '@/data/variables';
import {
  AppBar,
  Box,
  Divider,
  IconButton,
  Toolbar,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import DownloadIcon from '@mui/icons-material/Download';
import ArrowBackIcon from '@public/icons/arrow-back.svg';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import { formatAppTitle } from '@/utils/truncate';

const Tittle: React.FC = () => {
  const pathname = usePathname();
  const router = useRouter();
  const muiTheme = useTheme();
  const isMobile = useMediaQuery(muiTheme.breakpoints.down('md'));

  // Get the last word from the pathname and capitalize the first letter of each word
  let appTitle: string = formatAppTitle(pathname);

  // change the title to 'Table Karyawan' if the title is 'Karyawan'
  if (appTitle === VARIABLES.KARYAWAN_TITLE) {
    appTitle = VARIABLES.TABLE_KARYAWAN;
  } else if (appTitle === VARIABLES.KONTRAK_TITLE) {
    appTitle = VARIABLES.KONTRAK_LIST;
  }

  const handleBackButton = () => {
    router.back();
  };

  const handleClickDownload = () => {
    alert('Download Data');
  };

  const handleClickAddEmployee = () => {
    router.push('/karyawan/tambah-karyawan');
  };

  const shouldHideBackButton =
    appTitle === VARIABLES.TABLE_KARYAWAN ||
    appTitle === VARIABLES.KONTRAK_LIST ||
    appTitle === VARIABLES.PERSETUJUAN_PAGE;

  const shouldShowactionButtonDownload = appTitle === VARIABLES.TABLE_KARYAWAN;

  return (
    <Box sx={{ flexGrow: 1 }} boxShadow={0}>
      <AppBar
        position="relative"
        sx={{
          height: isMobile ? '100px' : '77px',
          bgcolor: theme.palette.white,
          boxShadow: 0,
        }}
      >
        <Toolbar
          sx={{
            height: isMobile ? '160px' : '77px',
            display: 'flex',
            justifyContent: 'space-between',
            px: 2,
          }}
        >
          {' '}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: isMobile ? 0.5 : 1,
              justifyContent: 'center',
            }}
          >
            {!shouldHideBackButton && (
              <IconButton
                onClick={handleBackButton}
                sx={{
                  backgroundColor: theme.palette.tertiary,
                  width: isMobile ? 30 : 40,
                  height: isMobile ? 30 : 40,
                }}
              >
                <Image
                  src={ArrowBackIcon}
                  alt="arrow-back"
                  priority
                  height={isMobile ? 8 : 10}
                  width={isMobile ? 8 : 10}
                />
              </IconButton>
            )}
            <HmTypography
              fontSize={20}
              fontWeight={600}
              sx={{ fontFamily: 'Roboto, sans-serif' }}
              color={theme.palette.black}
            >
              {appTitle}
            </HmTypography>
          </Box>
          {shouldShowactionButtonDownload && (
            <Box
              sx={{
                display: 'flex',
                gap: isMobile ? 1 : 2,
                flexDirection: isMobile ? 'column' : 'row',
              }}
            >
              <HmButton
                onClick={handleClickDownload}
                color={theme.palette.success}
                label={
                  <Box
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '0.5rem',
                    }}
                  >
                    <DownloadIcon
                      fontSize={isMobile ? 'small' : 'medium'}
                      style={{ color: theme.palette.white }}
                    />
                    <HmTypography
                      fontWeight={600}
                      fontSize={isMobile ? 16 : 18}
                      color={theme.palette.white}
                    >
                      Download Data
                    </HmTypography>
                  </Box>
                }
              />
              <HmButton
                onClick={handleClickAddEmployee}
                color={theme.palette.primary}
                label={
                  <Box
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '0.5rem',
                    }}
                  >
                    <AddCircleIcon
                      fontSize={isMobile ? 'small' : 'medium'}
                      style={{ color: theme.palette.white }}
                    />
                    <HmTypography
                      fontWeight={600}
                      fontSize={isMobile ? 16 : 18}
                      color={theme.palette.white}
                    >
                      {isMobile ? 'Tambah' : 'Tambah Data Karyawan'}
                    </HmTypography>
                  </Box>
                }
              />
            </Box>
          )}
        </Toolbar>
      </AppBar>
      <Divider
        sx={{
          marginBottom: '1rem',
        }}
      />
    </Box>
  );
};

export default Tittle;
