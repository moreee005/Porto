'use client';

import React, { useState, ReactNode } from 'react';
import { Snackbar, Alert, SnackbarOrigin } from '@mui/material';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { ToastContext } from '@/context/toastContext';

type ToastType = 'success' | 'info' | 'warning' | 'error' | '';

interface ToastState {
  open: boolean;
  message: string;
  type: ToastType;
}
interface ToastProviderProps {
  children: ReactNode;
}

export const ToastProvider = ({ children }: ToastProviderProps) => {
  const [toast, setToast] = useState<ToastState>({
    open: false,
    message: '',
    type: '',
  });

  const showToast = (type: ToastType, message: string) => {
    setToast({ open: true, message, type });
  };

  const hideToast = () => {
    setToast({ open: false, message: '', type: '' });
  };

  const anchor: SnackbarOrigin = {
    vertical: 'top',
    horizontal: 'center',
  };

  return (
    <ToastContext.Provider value={{ showToast, hideToast }}>
      {children}
      <Snackbar
        open={toast.open}
        autoHideDuration={3000}
        onClose={hideToast}
        anchorOrigin={anchor}
        style={{ top: -5 }}
      >
        <Alert
          onClose={hideToast}
          severity={toast.type || 'info'}
          variant="filled"
          sx={{
            width: '676px',
            borderBottomLeftRadius: '10px',
            borderBottomRightRadius: '10px',
            borderTopLeftRadius: 0,
            borderTopRightRadius: 0,
          }}
          iconMapping={{
            error: <HighlightOffIcon fontSize="inherit" />,
          }}
        >
          {toast.message}
        </Alert>
      </Snackbar>
    </ToastContext.Provider>
  );
};
