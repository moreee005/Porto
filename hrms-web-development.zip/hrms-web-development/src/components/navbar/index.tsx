"use client"

import React, { useState } from 'react';
import colors from '@/components/colors';
import {
  HmBreadcrumbs,
  HmButton,
  HmNotification,
  HmTypography,
} from '@/components/component';
import { useDrawer } from '@/context/drawerContext';
import {
  AppBar,
  Box,
  Toolbar,
  IconButton,
  useMediaQuery,
  useTheme,
  Badge,
  Popover,
  Menu,
  MenuItem,
} from '@mui/material';
import { usePathname, useRouter } from 'next/navigation';
import MenuIcon from '@mui/icons-material/Menu';
import Image from 'next/image';
import Notification from '@public/icons/notification.svg';
import User from '@public/user-profile-sample.svg';
import { DummyNotification } from '@/data/dumyNotifications';
import Cookies from 'js-cookie';

const notification = [
  {
    id: '1',
    title: 'This is title of notification',
    date: '12 Nov 2024',
    description: 'This is description of notifcation!',
    image: 'none',
  },
  {
    id: '2',
    title: 'This is title of notification 2',
    date: '13 Nov 2024',
    description: 'This is description of notifcation2!',
    image: 'none',
  },
  {
    id: '3',
    title: 'This is title of notification 3',
    date: '13 Nov 2024',
    description: 'This is description of notifcation2!',
    image: 'none',
  },
  {
    id: '4',
    title: 'This is title of notification 4',
    date: '13 Nov 2024',
    description: 'This is description of notifcation2!',
    image: 'none',
  },
  {
    id: '5',
    title: 'This is title of notification 5',
    date: '13 Nov 2024',
    description:
      'This is description of notifcation5! This is description of notifcation5! This is description of notifcation5! This is description of notifcation5! This is description of notifcation5!',
    image: 'none',
  },
];

const Navbar: React.FC = () => {
  const { setCollapseDrawer } = useDrawer();
  const [openNotification, setOpenNotification] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [userMenuAnchorEl, setUserMenuAnchorEl] = useState<null | HTMLElement>(null);
  const theme = useTheme();
  const pathname = usePathname();
  const router = useRouter();

  const isMd = useMediaQuery(theme.breakpoints.up('md'));

  const handleOpenNotification = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setOpenNotification(true);
  };

  const handleCloseNotification = () => {
    setAnchorEl(null);
    setOpenNotification(false);
  };

  const toggleDrawer = () => {
    setCollapseDrawer((prev) => !prev);
  };

  const handleUserMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setUserMenuAnchorEl(event.currentTarget);
  };

  const handleUserMenuClose = () => {
    setUserMenuAnchorEl(null);
  };

  const handleLogout = () => {
    Cookies.remove('userId');
    Cookies.remove('accessToken');
    router.push('/login');
  };

  return (
    <Box sx={{ flexGrow: 1 }} boxShadow={0}>
      <AppBar
        position="relative"
        sx={{
          height: '77px',
          bgcolor: colors.palette.primary,
          boxShadow: 0,
        }}
      >
        <Toolbar
          sx={{
            height: '77px',
            display: 'flex',
            justifyContent: 'space-between',
          }}
        >
          {isMd ? (
            <HmBreadcrumbs pathname={pathname} />
          ) : (
            <IconButton color="inherit" onClick={toggleDrawer}>
              <MenuIcon />
            </IconButton>
          )}

          <Box
            sx={{
              display: 'flex',
              gap: 1,
            }}
          >
            <IconButton
              sx={{ position: 'relative' }}
              onClick={handleOpenNotification}
            >
              {DummyNotification.data.length ? (
                <Badge
                  color="error"
                  variant="dot"
                  overlap="circular"
                  sx={{
                    top: 0,
                    right: 0,
                    '& .MuiBadge-dot': {
                      border: '2px solid white',
                      backgroundColor: colors.palette.error,
                      width: 12,
                      height: 12,
                      borderRadius: '50%',
                    },
                  }}
                >
                  <Image
                    src={Notification}
                    alt="notification"
                    width={18}
                    height={18}
                  />
                </Badge>
              ) : (
                <Image
                  src={Notification}
                  alt="notification"
                  width={18}
                  height={18}
                />
              )}
            </IconButton>
            <Popover
              open={openNotification}
              anchorEl={anchorEl}
              onClose={handleCloseNotification}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
            >
              <HmNotification
                itemProps={notification}
                total={notification.length}
                width={isMd ? '800px' : 'auto'}
              />
            </Popover>
            <HmButton
              icon={
                <Box
                  style={{
                    display: 'flex',
                    gap: 10,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Image
                    src={User}
                    alt="user"
                    width={36}
                    height={36}
                    style={{ borderRadius: '50%' }}
                  />
                  <HmTypography
                    fontSize={19}
                    fontWeight={400}
                    color={colors.palette.white}
                  >
                    Admin Padepokan 79
                  </HmTypography>
                </Box>
              }
              sx={{
                padding: '0.7rem',
                borderRadius: '50%',
              }}
              onClick={handleUserMenuClick}
            />
            <Menu
              anchorEl={userMenuAnchorEl}
              open={Boolean(userMenuAnchorEl)}
              onClose={handleUserMenuClose}
            >
              <MenuItem onClick={handleLogout}>Logout</MenuItem>
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
};

export default Navbar;