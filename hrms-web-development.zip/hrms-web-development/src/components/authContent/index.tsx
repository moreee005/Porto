'use client';

import { Box, Container, Stack } from '@mui/material';
import { ReactNode } from 'react';
import colors from '../colors';
import Image from 'next/image';
import logo from '@public/icons/logo-white.svg';
import globe from '@public/icons/globe.svg';
import { HmTypography } from '../component';
import CopyrightIcon from '@mui/icons-material/Copyright';

interface AuthContentProps {
  children: ReactNode;
}

const AuthContent: React.FC<AuthContentProps> = ({ children }) => {
  return (
    <Box
      padding={{ xs: 0, md: 0 }}
      sx={{
        minHeight: '100vh',
        width: '100%',
        overflow: 'hidden',
      }}
    >
      <Box sx={{ flexShrink: 0 }}>
        {/* Section Background */}
        <Box
          sx={{
            height: '100vh',
            background: `linear-gradient(-3deg, ${colors.palette.black} 60%, ${colors.palette.primary} 60%)`,
            position: 'relative',
            zIndex: 1,
          }}
        >
          {/* Header */}
          <Box
            sx={{
              position: 'absolute',
              top: '20px',
              left: '0',
              right: '0',
              zIndex: 3,
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              sx={{
                width: '100%',
                padding: {
                  xs: '0 0.2rem',
                  sm: '0 4rem',
                  md: '0 10rem',
                },
                flexWrap: 'wrap',
                justifyContent: 'space-between',
              }}
            >
              <Image src={logo} alt="logo" width={103} height={30} />
              <Stack
                direction="row"
                spacing={0.5}
                alignItems="center"
                justifyContent="space-between"
              >
                <Image src={globe} alt="logo" width={16} height={16} />
                <HmTypography variant="h6" fontWeight={400} color="white">
                  Padepokan Tujuh Sembilan
                </HmTypography>
              </Stack>
            </Stack>
          </Box>

          {/* Floating Content Box */}
          <Container
            sx={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              maxWidth: 400,
              width: {
                xs: '90%',
                md: '30%',
              },
              height: 'auto',
              zIndex: 4,
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                flexGrow: 1,
                bgcolor: colors.palette.white,
                overflow: 'auto',
                width: '100%',
                maxHeight: '77vh',
                height: 'fit-content',
                borderRadius: '6px',
              }}
            >
              {children}
            </Box>
          </Container>

          {/* Footer */}
          <Box
            sx={{
              position: 'absolute',
              bottom: '20px',
              left: '0',
              right: '0',
              zIndex: 3,
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              sx={{
                width: '100%',
                padding: {
                  xs: '0 0.2rem',
                  sm: '0 4rem',
                  md: '0 10rem',
                },
                flexWrap: 'wrap',
                justifyContent: {
                  xs: 'center',
                  sm: 'space-between',
                },
              }}
            >
              <Stack
                direction="row"
                spacing={0.5}
                alignItems="center"
                justifyContent="space-between"
              >
                <CopyrightIcon
                  fontSize="inherit"
                  sx={{
                    color: colors.palette.greyFooter,
                  }}
                />
                <HmTypography
                  fontWeight={400}
                  color={colors.palette.greyFooter}
                >
                  2024
                </HmTypography>
                <HmTypography fontWeight={400} color={colors.palette.primary}>
                  Padepokan Tujuh Sembilan
                </HmTypography>
              </Stack>

              <Stack
                direction="row"
                spacing={2}
                alignItems="center"
                justifyContent="space-between"
              >
                <HmTypography
                  fontWeight={400}
                  color={colors.palette.greyFooter}
                >
                  Creative Tim
                </HmTypography>
                <HmTypography
                  fontWeight={400}
                  color={colors.palette.greyFooter}
                >
                  About Us
                </HmTypography>
                <HmTypography
                  fontWeight={400}
                  color={colors.palette.greyFooter}
                >
                  Blog
                </HmTypography>
                <HmTypography
                  fontWeight={400}
                  color={colors.palette.greyFooter}
                >
                  MIT License
                </HmTypography>
              </Stack>
            </Stack>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default AuthContent;
