import PeopleAltRoundedIcon from '@mui/icons-material/PeopleAltRounded';
import { RiFilePaper2Line } from 'react-icons/ri';
import CircleIcon from '@mui/icons-material/Circle';
import { GoGear } from 'react-icons/go';
import masterDataIcon from '@public/master-data.svg';
import Image from 'next/image';

interface MenuItemChildOption {
  id: string;
  icon: JSX.Element;
  text: string;
  pathname: string;
  isActive: boolean;
}

interface MenuItem {
  id: string;
  icon: JSX.Element;
  text: string;
  pathname?: string;
  isActive: boolean;
  children?: MenuItemChildOption[];
}

const createChildItem = (
  id: string,
  text: string,
  pathname: string
): MenuItemChildOption => ({
  id,
  icon: <CircleIcon sx={{ width: 4, marginLeft: 1, marginRight: 1 }} />,
  text,
  pathname,
  isActive: false,
});

export const menuItems: MenuItem[] = [
  {
    id: 'data-karyawan',
    icon: <PeopleAltRoundedIcon style={{ height: 24, width: 24 }} />,
    text: 'Data Karyawan',
    pathname: '/karyawan',
    isActive: false,
  },
  {
    id: 'kontrak',
    icon: <RiFilePaper2Line style={{ height: 24, width: 24 }} />,
    text: 'Kontrak',
    isActive: false,
    children: [
      createChildItem('data-kontrak', 'Data Kontrak', '/kontrak'),
      createChildItem('persetujuan', 'Persetujuan', '/persetujuan'),
    ],
  },
  {
    id: 'master-data',
    icon: (
      <Image
        src={masterDataIcon}
        alt="master-data-icon"
        width={24}
        height={24}
      />
    ),
    text: 'Master Data',
    isActive: false,
    children: [
      createChildItem('identitas-diri', 'Identitas Diri', '/karyawan'),
      createChildItem('persetujuanMd', 'Approval', '/persetujuan'),
      createChildItem('data-kontrak', 'Kontrak', '/kontrak'),
    ],
  },
  {
    id: 'testing',
    icon: <GoGear style={{ height: 24, width: 24 }} />,
    text: 'Testing',
    isActive: false,
    children: [
      createChildItem('button', 'Testing Button', '/testing/button'),
      createChildItem(
        'autocomplete',
        'Testing Autocomplete',
        '/testing/autocomplete'
      ),
      createChildItem('chip', 'Testing Chip', '/testing/chip'),
      createChildItem(
        'confirmation',
        'Testing Confirmation',
        '/testing/confirmation'
      ),
      createChildItem(
        'date-picker',
        'Testing Date Picker',
        '/testing/datepicker'
      ),
      createChildItem(
        'dynamic-form',
        'Testing Dynamic Form',
        '/testing/dynamic-form'
      ),
      createChildItem('form', 'Testing Form', '/testing/form'),
      createChildItem('formatter', 'Testing Formatter', '/testing/formatter'),
      createChildItem('modal', 'Testing Modal', '/testing/modal'),
      createChildItem(
        'photo-uploader',
        'Testing Photo Uploader',
        '/testing/photo-uploader'
      ),
      createChildItem(
        'rhf-test',
        'Testing React Hook Form',
        '/testing/rhf-test'
      ),
      createChildItem('search', 'Testing Search', '/testing/search'),
      createChildItem('table', 'Testing Table', '/testing/table'),
      createChildItem(
        'typography',
        'Testing Typography',
        '/testing/typography'
      ),
    ],
  },
];
