'use client';
import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import { HmButton, HmTypography } from '@/components/component';
import { usePathname, useRouter } from 'next/navigation';
import Image from 'next/image';
import logoText from '@public/logo-hrms.svg';
import logo from '@public/logo-no-text.svg';
import colors from '@/components/colors';
import CircleIcon from '@mui/icons-material/Circle';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { List, useMediaQuery, useTheme } from '@mui/material';
import { useDrawer } from '@/context/drawerContext';
import {
  DummyNotificationContract,
  DummyNotificationPersetujuan,
} from '@/data/dumyNotifications';
import { menuItems } from './option';

interface MenuResponse {
  id: string;
  children?: MenuResponse[];
}
interface MenuItem {
  id: string;
  icon: any;
  text: string;
  pathname?: string;
  onClick?: (item: MenuItem) => void;
  isActive?: boolean;
  children?: MenuItem[];
}

// Example menu response to map over
const exampleMenuResponse = [
  { id: 'data-karyawan' },
  // show data kontrak(button dont show because parent have no children)
  { id: 'kontrak', children: [{ id: 'data-kontrak' }, { id: 'persetujuan' }] },
  { id: 'kontrak', children: [{ id: 'persetujuan' }, { id: 'button' }] },
  {
    id: 'testing',
    children: [
      { id: 'button' },
      { id: 'autocomplete' },
      { id: 'rhf-test' },
      { id: 'table' },
    ],
  },
  // didn't show data autocomplete because children is not have parent
  { id: 'autocomplete' },
  {
    id: 'master-data',
    children: [
      { id: 'identitas-diri' },
      { id: 'persetujuanMd' },
      { id: 'data-kontrak' },
    ],
  },
];

// get menu item from local storage
// const exampleMenuResponse2 = localStorage.getItem('menuItem');
// // parse menu item from local storage
// const parsedMenuResponse: MenuResponse[] = JSON.parse(
//   exampleMenuResponse2 || '[]'
// );
// console.log('exampleResponse ', exampleMenuResponse);
// console.log('exampleResponse 2', exampleMenuResponse2);
// console.log('parsedMenuResponse', parsedMenuResponse);

const filteredMenuItem = menuItems.filter((option) => {
  // Cek apakah option.id ada di exampleMenuResponse
  const optionMatch = exampleMenuResponse.some(
    (response) => response.id === option.id
  );

  // Jika option memiliki children, filter children yang ada
  if (option.children) {
    // Filter children hanya jika parent dan child keduanya ada dalam exampleMenuResponse
    option.children = option.children.filter((child) => {
      // Pastikan parent dan child ada dalam exampleMenuResponse
      return exampleMenuResponse.some(
        (response) =>
          response.id === option.id &&
          response.children?.some(
            (childResponse) => childResponse.id === child.id
          )
      );
    });
  }

  // Kembalikan parent jika ditemukan kecocokan atau jika ada children yang valid
  // return optionMatch ;
  return optionMatch || (option.children && option.children.length > 0);
});

const Sidebar = () => {
  const { collapseDrawer, setCollapseDrawer } = useDrawer();
  const [subMenuState, setSubMenuState] = React.useState<
    Record<string, boolean>
  >({});
  const router = useRouter();
  const pathname = usePathname();
  const theme = useTheme();

  const isXsScreen = useMediaQuery(theme.breakpoints.down('md'));

  // Toggle sub menu
  // If collapse drawer is true, open the drawer and set the sub menu state to true
  const toggleSubMenu = (id: string) => {
    if (collapseDrawer) {
      setCollapseDrawer(false);
      setSubMenuState((prevState) => ({
        ...prevState,
        [id]: true,
      }));
    } else {
      setSubMenuState((prevState) => ({
        ...prevState,
        [id]: !prevState[id],
      }));
    }
  };

  // Set active menu
  // If the path is the same as the current path, set the active menu to true
  const setActiveMenu = (path: string, isParent: boolean) => {
    if (isParent) {
      return false;
    }
    return pathname.startsWith(path);
  };

  // Set active sub menu by path automatically
  React.useEffect(() => {
    const activePath = pathname;

    const openMenu = (itemId: string) => {
      setSubMenuState((prevState) => ({
        ...prevState,
        [itemId]: true,
      }));
    };

    if (!collapseDrawer) {
      filteredMenuItem.forEach((item) => {
        const isActivePath = activePath.startsWith(item.pathname ?? '');

        if (item.children) {
          item.children.forEach((subItem) => {
            if (activePath.startsWith(subItem.pathname ?? '')) {
              openMenu(item.id);
            }
          });
        } else if (isActivePath) {
          openMenu(item.id);
        }
      });
    }
  }, [pathname, collapseDrawer]);

  // Reset sub menu state when drawer is collapsed
  React.useEffect(() => {
    if (collapseDrawer) {
      setSubMenuState({});
    }
  }, [collapseDrawer]);

  // fetch notification count example
  const notificationCountApporval = DummyNotificationPersetujuan.total;
  const notificationCountContract = DummyNotificationContract.total;

  const renderMenuItems = (items: MenuItem[]) => {
    return items.map((item) => {
      // Show notification badge by id
      let notificationCount: number | null = null;

      if (item.id === 'persetujuan') {
        notificationCount = notificationCountApporval;
      } else if (item.id === 'data-kontrak') {
        notificationCount = notificationCountContract;
      }

      const isActive = setActiveMenu(
        item.pathname ?? '',
        !!item.children?.length
      );

      return (
        <React.Fragment key={item.id}>
          <HmButton
            label={
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: collapseDrawer ? 0 : '0.7rem',
                }}
              >
                {item.icon}
                <HmTypography semiBold>
                  {!collapseDrawer && item.text}
                </HmTypography>
                {item.children && !collapseDrawer && (
                  <ExpandMoreIcon
                    sx={{
                      position: 'absolute',
                      left: 165,
                      transform: subMenuState[item.id]
                        ? 'rotate(0deg)'
                        : 'rotate(180deg)',
                      transition: 'transform 0.3s',
                    }}
                  />
                )}

                {!item.children && notificationCount && (
                  <Box
                    sx={{
                      position: 'absolute',
                      display: 'inline-flex',
                      left: 165,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <CircleIcon
                      sx={{
                        width: 20,
                        height: 20,
                        color: colors.palette.error,
                      }}
                    />
                    <Box
                      sx={{
                        position: 'absolute',
                        fontSize: '12px',
                        top: 1.2,
                        color: 'white',
                      }}
                    >
                      {notificationCount}
                    </Box>
                  </Box>
                )}
              </Box>
            }
            onClick={() => {
              if (item.pathname) {
                router.push(item.pathname);
                if (isXsScreen) {
                  setCollapseDrawer(true);
                }
              } else if (item.children) {
                toggleSubMenu(item.id);
              }
            }}
            isActive={isActive}
            sx={{
              padding: '0.7rem',
              width: collapseDrawer ? '50px' : '200px',
              justifyContent: collapseDrawer ? 'center' : 'flex-start',
              textAlign: 'left',
            }}
            isHover={true}
            labelColor={colors.palette.greyPrimary}
            color="white"
          />
          {item.children &&
            subMenuState[item.id] &&
            renderMenuItems(item.children)}
        </React.Fragment>
      );
    });
  };

  const DrawerList = (
    <Box
      sx={{
        [theme.breakpoints.up('xs')]: {
          width: collapseDrawer ? 0 : 240,
        },
        [theme.breakpoints.up('md')]: {
          width: collapseDrawer ? 80 : 240,
        },
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '100%',
        margin: '3rem 0',
        transition: 'width 0.5s ease-in-out',
      }}
    >
      <Box>
        <Image
          src={collapseDrawer ? logo : logoText}
          alt="logo"
          width={collapseDrawer ? 60 : 200}
          height={30}
          priority
          style={{
            marginBottom: '2rem',
            transition: 'width 0.5s ease-in-out',
          }}
        />

        <List
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: '0.5rem',
          }}
        >
          {renderMenuItems(filteredMenuItem)}
        </List>
      </Box>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.2rem',
        }}
      >
        <IconButton
          onClick={() => setCollapseDrawer(!collapseDrawer)}
          style={{
            width: '28px',
            height: '28px',
            backgroundColor: colors.palette.primary,
          }}
        >
          <ArrowBackIosNewIcon
            style={{
              color: colors.palette.white,
              fontSize: '0.8rem',
              transform: collapseDrawer ? 'rotate(180deg)' : 'rotate(0deg)',
            }}
          />
        </IconButton>
        {!collapseDrawer && (
          <HmTypography semiBold color={colors.palette.greyPrimary}>
            Collapse
          </HmTypography>
        )}
      </Box>
    </Box>
  );

  return (
    <Drawer
      open={!collapseDrawer}
      onClose={() => setCollapseDrawer(false)}
      variant={
        useMediaQuery(theme.breakpoints.up('md')) ? 'permanent' : 'temporary'
      }
      sx={{
        [theme.breakpoints.up('xs')]: {
          width: collapseDrawer ? 0 : 240,
        },
        [theme.breakpoints.up('md')]: {
          width: collapseDrawer ? 80 : 240,
        },
        flexShrink: 0,
        transition: 'width 0.5s ease-in-out',
      }}
    >
      {DrawerList}
    </Drawer>
  );
};

export default Sidebar;
