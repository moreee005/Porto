import { Box } from '@mui/material';
import DetailSection from './DetailSection';
import HmButton from '../../component/HmButton';
import colors from '@/components/colors';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import DownloadIcon from '@mui/icons-material/Download';
import React from 'react';
import { v4 as uuidv4 } from 'uuid';

interface AllowanceDetail {
  allowanceId: string;
  allowanceType: string;
  amount: number;
}

interface AllowanceGroup {
  groupName: string;
  allowances: AllowanceDetail[];
}

interface Data {
  statusName: string | null;
  placementTypeName: string | null;
  employeeTypeName: string | null;
  willingToBePlacedInBankOrInsurance: boolean | null;
  divisionName: string | null;
  jobPositionName: string | null;
  contractStartDate: string | null;
  contractEndDate: string | null;
  generation: string | null;
  contractDocument: {
    documentName: string;
    documentUrl: string;
  } | null;
  allowances: AllowanceGroup[];
}

const InformasiKontrakContent = ({ data }: { data: Data | null }) => {
  const handleDownload = () => {
    if (data?.contractDocument?.documentUrl) {
      const link = document.createElement('a');
      link.href = data.contractDocument.documentUrl;
      link.download = data.contractDocument.documentName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const sections = [
    {
      id: uuidv4(),
      title: 'Informasi Kontrak',
      details: [
        { label: 'Status Kontrak', value: data?.statusName ?? '-' },
        { label: 'Jenis Penempatan', value: data?.placementTypeName ?? '-' },
        { label: 'Jenis Karyawan', value: data?.employeeTypeName ?? '-' },
        {
          label: 'Bersedia Ditempatkan di Bank/Insurance ',
          value: data?.willingToBePlacedInBankOrInsurance
            ? 'Bersedia'
            : 'Tidak',
        },
        { label: 'Divisi', value: data?.divisionName ?? '-' },
        { label: 'Jabatan', value: data?.jobPositionName ?? '-' },
        {
          label: 'Tanggal Mulai Kontrak',
          value: data?.contractStartDate ?? '-',
        },
        { label: 'Tanggal Akhir Kontrak', value: data?.contractEndDate ?? '-' },
        { label: 'Generasi', value: data?.generation ?? '-' },
        {
          label: 'Dokumen Kontrak',
          value: (
            <Box display="flex" gap={1}>
              <HmButton
                icon={<DownloadIcon sx={{ fontSize: 16 }} />}
                color={colors.palette.primary}
                labelColor={colors.palette.white}
                label="Download Dokumen"
                onClick={handleDownload}
              />
              <HmButton
                color={colors.palette.skyblue}
                icon={<MdOutlineRemoveRedEye size={16} />}
                onClick={() =>
                  data?.contractDocument?.documentUrl &&
                  window.open(data.contractDocument.documentUrl, '_blank')
                }
                sx={{
                  minWidth: '38px',
                  width: '38px',
                  height: '38px',
                }}
              />
            </Box>
          ),
        },
      ],
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Gaji Pokok & Tunjangan',
      tableTitle: 'Gaji Pokok & Tunjangan',
      columns: [
        { header: 'Jenis Tunjangan', accessor: 'jenisTunjangan' },
        { header: 'Nominal', accessor: 'nominal' },
      ],
      data:
        data?.allowances?.flatMap((group) =>
          group.allowances.map((allowance, index) => ({
            id: index + 1,
            jenisTunjangan: allowance.allowanceType,
            nominal: `Rp ${allowance.amount.toLocaleString()}`,
          }))
        ) ?? [],
      showDivider: false,
    },
  ];

  return (
    <Box>
      {sections.map((section) => (
        // @ts-ignore
        <DetailSection key={section.id} {...section} />
      ))}
    </Box>
  );
};

export default InformasiKontrakContent;
