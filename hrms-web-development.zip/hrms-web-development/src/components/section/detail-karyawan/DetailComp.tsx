import React from 'react';
import { Box } from '@mui/material';
import colors from '@/components/colors';
import HmTypography from '@/components/component/HmTypography';

interface DetailCompProps {
  label: string;
  value: string | React.ReactNode;
}

const DetailComp: React.FC<DetailCompProps> = ({ label, value }) => (
  <Box sx={{ marginBottom: '16px', display: 'flex', flexDirection: 'column' }}>
    <HmTypography small semiBold color={colors.palette.greyLabel}>
      {label}
    </HmTypography>
    <HmTypography color={colors.palette.black}>{value ?? ''}</HmTypography>
  </Box>
);

export default DetailComp;
