'use client';

import React, { useState } from 'react';
import { HmTypography, HmTable, HmDivider } from '@/components/component';
import DetailComp from '@/components/section/detail-karyawan/DetailComp';
import colors from '@/components/colors';
import { useMediaQuery, useTheme, Box } from '@mui/material';

interface DetailSectionProps {
  title: string;
  tableTitle?: string;
  details?: { label: string; value: string | React.ReactNode }[];
  data?: {
    id: string | number;
    jenisKelamin?: string;
    tanggalLahir?: string;
    pekerjaanSekolah?: string;
    jenjangPendidikan?: string;
    sekolahKampus?: string;
    jenjang?: string;
    kotaAsal?: string;
    tahunLulus?: string;
    jenis?: string;
    namaPelatihan?: string;
    tempat?: string;
    tanggal?: string;
    bulan?: string;
    tahun?: string;
    lama?: string;
    intansi?: string;
    nomorSertifikat?: string;
    namaOrganisasi?: string;
    tahunJabat?: string;
    jabatan?: string;
    jmlAnggota?: string;
    lamanya?: string;
    jenisTunjangan?: string;
    nominal?: string;
    tipe?: string;
    download?: string;
    aksi?: React.ReactNode;
    socialMedia?: string;
    sMLink?: string;
    typeId?: string;
    amount?: string;
  }[];
  columns?: {
    header: string;
    accessor: keyof {
      id: string | number;
      jenisKelamin?: string;
      tanggalLahir?: string;
      pekerjaanSekolah?: string;
      jenjangPendidikan?: string;
      sekolahKampus?: string;
      jenjang?: string;
      kotaAsal?: string;
      tahunLulus?: string;
      jenis?: string;
      namaPelatihan?: string;
      tempat?: string;
      tanggal?: string;
      bulan?: string;
      tahun?: string;
      lama?: string;
      intansi?: string;
      nomorSertifikat?: string;
      namaOrganisasi?: string;
      tahunJabat?: string;
      jabatan?: string;
      jmlAnggota?: string;
      lamanya?: string;
      jenisTunjangan?: string;
      nominal?: string;
      tipe?: string;
      download?: string;
      aksi?: React.ReactNode;
      socialMedia?: string;
      sMLink?: string;
      typeId?: string;
      amount?: string;
    };
  }[];
  secondTableTitle?: string;
  secondData?: {
    id: string | number;
    jenisKelamin?: string;
    tanggalLahir?: string;
    pekerjaanSekolah?: string;
    jenjangPendidikan?: string;
    tahunMasuk?: string;
    jurusan?: string;
    jenisTunjangan?: string;
    nominal?: string;
    tipe?: string;
    download?: string;
    aksi?: React.ReactNode;
  }[];
  secondColumns?: {
    header: string;
    accessor:
      | keyof {
          id: string | number;
          jenisKelamin?: string;
          tanggalLahir?: string;
          pekerjaanSekolah?: string;
          jenjangPendidikan?: string;
          tahunMasuk?: string;
          jurusan?: string;
          jenisTunjangan?: string;
          nominal?: string;
          tipe?: string;
          download?: string;
          aksi?: React.ReactNode;
        }
      | ((row: {
          id: string | number;
          jenisKelamin?: string;
          tanggalLahir?: string;
          pekerjaanSekolah?: string;
          jenjangPendidikan?: string;
          tahunMasuk?: string;
          jurusan?: string;
          jenisTunjangan?: string;
          nominal?: string;
          tipe?: string;
          download?: string;
          aksi?: React.ReactNode;
        }) => React.ReactNode);
  }[];
  showDivider?: boolean;
}

const DetailSection: React.FC<DetailSectionProps> = ({
  title,
  details,
  data,
  columns,
  tableTitle,
  secondTableTitle,
  secondData,
  secondColumns,
  showDivider = true,
}) => {
  const [loading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const handlePageChange = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleRowsPerPageChange = (value: number) => {
    setRowsPerPage(value);
  };

  return (
    <Box>
      <HmTypography
        color={colors.palette.grey}
        semiBold
        sx={{
          textTransform: 'uppercase',
        }}
      >
        {title}
      </HmTypography>
      {details && (
        <Box display="flex" flexWrap="wrap" gap={0.5} ml={2} mt={2}>
          {details.map((detail) => (
            <Box
              key={detail.label}
              flex={isMobile ? '1 1 100%' : '1 1 calc(50% - 16px)'}
              mb={1}
            >
              <DetailComp
                label={detail.label}
                value={detail.value !== undefined ? detail.value : ''}
              />
            </Box>
          ))}
        </Box>
      )}
      {data && columns && (
        <Box px={2}>
          <HmTypography
            color={colors.palette.greyPrimary}
            small
            semiBold
            sx={{
              marginTop: '16px',
            }}
          >
            {tableTitle}
          </HmTypography>
          <HmTable
            data={data}
            columns={columns}
            loading={loading}
            page={page}
            rowsPerPage={rowsPerPage}
            totalItems={data.length}
            noPagination
            showNumberColumn
            onPageChange={handlePageChange}
            handleRowsPerPageChange={handleRowsPerPageChange}
          />
        </Box>
      )}
      {secondData && secondColumns && (
        <Box px={2} my={1}>
          <HmTypography
            color={colors.palette.greyPrimary}
            small
            semiBold
            sx={{
              marginTop: '16px',
            }}
          >
            {secondTableTitle}
          </HmTypography>
          <HmTable
            data={secondData}
            columns={secondColumns}
            loading={loading}
            page={page}
            rowsPerPage={rowsPerPage}
            totalItems={secondData.length}
            noPagination
            showNumberColumn
            onPageChange={handlePageChange}
            handleRowsPerPageChange={handleRowsPerPageChange}
          />
        </Box>
      )}
      {showDivider && <HmDivider sx={{ margin: '1rem 0' }} />}
    </Box>
  );
};

export default DetailSection;
