import React from 'react';
import { Box } from '@mui/material';
import DetailSection from './DetailSection';
import { v4 as uuidv4 } from 'uuid';

interface IdentitasDiriContentProps {
  data: {
    fullname: string | null;
    gender: string | null;
    placeOfBirth: string | null;
    dateofBirth: string | null;
    ethnicity: string | null;
    religion: string | null;
    bloodType: string | null;
    maritalStatus: string | null;
    email: string | null;
    phoneNumber: string | null;
    emergencyContact: {
      phoneNumber: string | null;
      relationship: string | null;
    } | null;
    background: string | null;
    homeAddress: {
      fullAddress: string | null;
      province: string | null;
      city: string | null;
      district: string | null;
      subdistrict: string | null;
      postalCode: string | null;
    } | null;
    motherIdentity: {
      name: string | null;
      dateOfBirth: string | null;
      highestEducation: string | null;
      occupation: string | null;
      motherSalary: string | null;
      phoneNumber: string | null;
      statusAlive: string | null;
      address: string | null;
    } | null;
    fatherIdentity: {
      name: string | null;
      dateOfBirth: string | null;
      highestEducation: string | null;
      occupation: string | null;
      salary: string | null;
      phoneNumber: string | null;
      statusAlive: string | null;
      address: string | null;
    } | null;
    spouseIdentity: {
      partnerName: string | null;
      partnerAge: number | null;
      partnerHighestEducation: string | null;
      partnerOccupation: string | null;
      partnerSalary: string | null;
      separateTax: string | null;
      partnerAddress: string | null;
    } | null;
    familyOrder: {
      childNumber: number | null;
      totalSiblings: number | null;
    } | null;
    siblings: Array<{
      idSiblings: number | null;
      gender: string | null;
      dateOfBirth: string | null;
      occupation: string | null;
      educationLevel: string | null;
    }> | null;
    familyMembersInKk: Array<{
      idMember: number | null;
      gender: string | null;
      dateOfBirth: string | null;
      occupation: string | null;
      education: string | null;
      yearJoined: number | null;
      major: string | null;
    }> | null;
    educationHistory: Array<{
      idEducation: number | null;
      jenjang: string | null;
      institutionName: string | null;
      location: string | null;
      startDate: string | null;
      month: string | null;
      year: number | null;
      endDate: string | null;
    }> | null;
    coursesOrUpgrading: Array<{
      idCourse: number | null;
      type: string | null;
      courseName: string | null;
      city: string | null;
      date: string | null;
      month: string | null;
      year: number | null;
      durationMonths: number | null;
      institution: string | null;
      certificateNumber: string | null;
    }> | null;
    organizationalLife: Array<{
      organizationId: number | null;
      organizationName: string | null;
      yearInPosition: string | null;
      position: string | null;
      memberCount: number | null;
      city: string | null;
      durationMonths: number | null;
    }> | null;
    sports: Array<{
      sport: string | null;
      activePassive: string | null;
    }> | null;
    art: Array<string | null> | null;
    other: Array<{
      foreignLanguageProficiency: string[] | null;
      hobbies: string[] | null;
      active: string | null;
    }> | null;
  } | null;
}

const IdentitasDiriContent: React.FC<IdentitasDiriContentProps> = ({
  data,
}) => {
  const sections = [
    {
      id: uuidv4(),
      title: 'Identitas Diri',
      details: [
        { label: 'Nama Lengkap', value: data?.fullname ?? '-' },
        { label: 'Jenis Kelamin', value: data?.gender ?? '-' },
        { label: 'Tempat Lahir', value: data?.placeOfBirth ?? '-' },
        { label: 'Tanggal Lahir', value: data?.dateofBirth ?? '-' },
        { label: 'Suku Bangsa', value: data?.ethnicity ?? '-' },
        { label: 'Agama', value: data?.religion ?? '-' },
        { label: 'Golongan Darah', value: data?.bloodType ?? '-' },
        { label: 'Status Menikah', value: data?.maritalStatus ?? '-' },
        { label: 'Email', value: data?.email ?? '-' },
        { label: 'Nomor Telepon', value: data?.phoneNumber ?? '-' },
        {
          label: 'Kontak Darurat Yang Dapat Dihubungi',
          value: data?.emergencyContact?.phoneNumber ?? '-',
        },
        {
          label: 'Hubungan Kontak Darurat',
          value: data?.emergencyContact?.relationship ?? '-',
        },
        { label: 'Background (IT/Non IT)', value: data?.background ?? '-' },
      ],
    },
    {
      id: uuidv4(),
      title: 'Alamat Rumah',
      details: [
        {
          label: 'Alamat Lengkap',
          value: data?.homeAddress?.fullAddress ?? '-',
        },
        { label: 'Provinsi', value: data?.homeAddress?.province ?? '-' },
        { label: 'Kota/Kabupaten', value: data?.homeAddress?.city ?? '-' },
        { label: 'Kecamatan', value: data?.homeAddress?.district ?? '-' },
        { label: 'Kelurahan', value: data?.homeAddress?.subdistrict ?? '-' },
      ],
    },
    {
      id: uuidv4(),
      title: 'Identitas Orang Tua (Ibu)',
      details: [
        { label: 'Nama Ibu', value: data?.motherIdentity?.name ?? '-' },
        {
          label: 'Tanggal Lahir Ibu',
          value: data?.motherIdentity?.dateOfBirth ?? '-',
        },
        {
          label: 'Pendidikan Terakhir Ibu',
          value: data?.motherIdentity?.highestEducation ?? '-',
        },
        {
          label: 'Pekerjaan Ibu',
          value: data?.motherIdentity?.occupation ?? '-',
        },
        { label: 'Gaji Ibu', value: data?.motherIdentity?.motherSalary ?? '-' },
      ],
    },
    {
      id: uuidv4(),
      title: 'Identitas Orang Tua (Ayah)',
      details: [
        { label: 'Nama Ayah', value: data?.fatherIdentity?.name ?? '-' },
        {
          label: 'Tanggal Lahir Ayah',
          value: data?.fatherIdentity?.dateOfBirth ?? '-',
        },
        {
          label: 'Pendidikan Terakhir Ayah',
          value: data?.fatherIdentity?.highestEducation ?? '-',
        },
        {
          label: 'Pekerjaan Ayah',
          value: data?.fatherIdentity?.occupation ?? '-',
        },
        { label: 'Gaji Ayah', value: data?.fatherIdentity?.salary ?? '-' },
        {
          label: 'Nomor Telepon Ayah',
          value: data?.fatherIdentity?.phoneNumber ?? '-',
        },
      ],
    },
    {
      id: uuidv4(),
      title: 'Identitas Suami/Istri',
      details: [
        {
          label: 'Nama Suami/Istri',
          value: data?.spouseIdentity?.partnerName ?? '-',
        },
        {
          label: 'Tanggal Lahir Suami/Istri',
          value: data?.spouseIdentity?.partnerAge?.toString() ?? '-',
        },
        {
          label: 'Pendidikan Terakhir Suami/Istri',
          value: data?.spouseIdentity?.partnerHighestEducation ?? '-',
        },
        {
          label: 'Pekerjaan Suami/Istri',
          value: data?.spouseIdentity?.partnerOccupation ?? '-',
        },
        {
          label: 'Gaji Suami/Istri',
          value: data?.spouseIdentity?.partnerSalary ?? '-',
        },
        {
          label: 'Pisah Pajak',
          value: data?.spouseIdentity?.separateTax ?? '-',
        },
      ],
    },
    {
      id: uuidv4(),
      title: 'Urutan Keluarga',
      details: [
        {
          label: 'Saya Anak Ke?',
          value: data?.familyOrder?.childNumber?.toString() ?? '-',
        },
        {
          label: 'Dari Berapa Bersaudara?',
          value: data?.familyOrder?.totalSiblings?.toString() ?? '-',
        },
      ],
      tableTitle: 'Saudara Kandung',
      data: data?.siblings?.map((sibling) => ({
        id: sibling.idSiblings ?? '-',
        jenisKelamin: sibling.gender ?? '-',
        tanggalLahir: sibling.dateOfBirth ?? '-',
        pekerjaanSekolah: sibling.occupation ?? '-',
        jenjangPendidikan: sibling.educationLevel ?? '-',
      })),
      columns: [
        { header: 'Jenis Kelamin', accessor: 'jenisKelamin' as const },
        { header: 'Tanggal Lahir', accessor: 'tanggalLahir' as const },
        { header: 'Pekerjaan/Sekolah', accessor: 'pekerjaanSekolah' as const },
        {
          header: 'Jenjang Pendidikan',
          accessor: 'jenjangPendidikan' as const,
        },
      ],
      secondTableTitle: 'Anggota Keluarga Dalam KK',
      secondData: data?.familyMembersInKk?.map((member) => ({
        id: member.idMember ?? '-',
        jenisKelamin: member.gender ?? '-',
        tanggalLahir: member.dateOfBirth ?? '-',
        pekerjaanSekolah: member.occupation ?? '-',
        jenjangPendidikan: member.education ?? '-',
        tahunMasuk: member?.yearJoined?.toString() ?? '-',
        jurusan: member.major ?? '-',
      })),
      secondColumns: [
        { header: 'Jenis Kelamin', accessor: 'jenisKelamin' as const },
        { header: 'Tanggal Lahir', accessor: 'tanggalLahir' as const },
        { header: 'Pekerjaan', accessor: 'pekerjaanSekolah' as const },
        { header: 'Pendidikan', accessor: 'jenjangPendidikan' as const },
        { header: 'Tahun Masuk', accessor: 'tahunMasuk' as const },
        { header: 'Jurusan', accessor: 'jurusan' as const },
      ],
    },
    {
      id: uuidv4(),
      title: 'Riwayat Pendidikan',
      tableTitle: 'Riwayat Pendidikan',
      data: data?.educationHistory?.map((education) => ({
        id: education.idEducation ?? '-',
        sekolahKampus: education.institutionName ?? '-',
        jenjang: education.jenjang ?? '-',
        kotaAsal: education.location ?? '-',
        tahunLulus: education?.year?.toString() ?? '-',
      })),
      columns: [
        { header: 'Nama Sekolah/Kampus', accessor: 'sekolahKampus' as const },
        { header: 'Jenjang', accessor: 'jenjang' as const },
        { header: 'Kota Asal Sekolah/Kampus', accessor: 'kotaAsal' as const },
        { header: 'Tahun Lulus', accessor: 'tahunLulus' as const },
      ],
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Kursus Atau Upgrading',
      tableTitle: 'Riwayat Pendidikan',
      data: data?.coursesOrUpgrading?.map((course) => ({
        id: course.idCourse ?? '-',
        jenis: course.type ?? '-',
        namaPelatihan: course.courseName ?? '-',
        tempat: course.city ?? '-',
        tanggal: course.date ?? '-',
        bulan: course.month ?? '-',
        tahun: course.year?.toString() ?? '-',
        lama: course.durationMonths?.toString() ?? '-',
        intansi: course.institution ?? '-',
        nomorSertifikat: course.certificateNumber ?? '-',
      })),
      columns: [
        { header: 'Jenis', accessor: 'jenis' as const },
        { header: 'Nama Pelatihan', accessor: 'namaPelatihan' as const },
        { header: 'Tempat', accessor: 'tempat' as const },
        { header: 'Tanggal', accessor: 'tanggal' as const },
        { header: 'Bulan', accessor: 'bulan' as const },
        { header: 'Tahun', accessor: 'tahun' as const },
        { header: 'Lamanya(Bulan)', accessor: 'lama' as const },
      ],
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Kehidupan Berorganisasi',
      tableTitle: 'Kehidupan Berorganisasi/Kemasyarakat',
      data: data?.organizationalLife?.map((organization) => ({
        id: organization.organizationId ?? '-',
        namaOrganisasi: organization.organizationName ?? '-',
        tahunJabat: organization.yearInPosition ?? '-',
        jabatan: organization.position ?? '-',
        jmlAnggota: organization.memberCount?.toString() ?? '-',
        tempat: organization.city ?? '-',
        lamanya: organization.durationMonths?.toString() ?? '-',
      })),
      columns: [
        { header: 'Nama Organisasi', accessor: 'namaOrganisasi' as const },
        { header: 'Tahun Menjabat', accessor: 'tahunJabat' as const },
        { header: 'Jabatan', accessor: 'jabatan' as const },
        { header: 'Jumlah Anggota', accessor: 'jmlAnggota' as const },
        { header: 'Tempat(Kota)', accessor: 'tempat' as const },
        { header: 'Lamanya', accessor: 'lamanya' as const },
      ],
    },
    {
      id: uuidv4(),
      title: 'Olahraga (Harus diisi 2 macam)',
      details: data?.sports?.map((sport, index) => ({
        label: `Olahraga ${index + 1}`,
        value: sport.sport ?? '-',
        activePassive: sport.activePassive ?? '-',
      })),
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Kesenian (Harus diisi 2 macam)',
      details: data?.art?.map((art, index) => ({
        label: `Kesenian ${index + 1}`,
        value: art ?? '-',
      })),
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Lainnya',
      details: [
        {
          label: 'Penguasaan Bahasa Asing',
          value:
            data?.other?.[0]?.foreignLanguageProficiency?.join(', ') ?? '-',
        },
        { label: 'Hobi', value: data?.other?.[0]?.hobbies?.join(', ') ?? '-' },
      ],
      showDivider: false,
    },
  ];

  return (
    <Box>
      {sections.map((section) => (
        <DetailSection key={section.id} {...section} />
      ))}
    </Box>
  );
};

export default IdentitasDiriContent;
