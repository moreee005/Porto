'use client';

import React, { useState } from 'react';
import Grid from '@mui/material/Grid2';
import { HmButton, HmChip, HmTypography } from '@/components/component';
import Image from 'next/image';
import { Box } from '@mui/material';
import colors from '@/components/colors';
import { FaListOl } from 'react-icons/fa';
import { PiNotePencilBold } from 'react-icons/pi';
import HistoryContract from '@/components/section/history-contract/HistoryContract';
import { useParams, useRouter } from 'next/navigation';
import { API } from '@/services/setupAxios';
import { useToast } from '@/context/toastContext';
import { differenceInMonths, parse } from 'date-fns';

interface EmployeeData {
  fullname: string | null;
  imageUrl: string | null;
  partyId: string | null;
  contractInformation: {
    statusName: string | null;
    contractStartDate: string | null;
    divisionName: string | null;
    jobPositionName: string | null;
  } | null;
  healthAndFinance: {
    nik: string | null;
  } | null;
}

const DetailKaryawanHeader = ({
                                employeeData,
                              }: {
  employeeData: EmployeeData;
}) => {
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const router = useRouter();
  const { karyawanId } = useParams();
  const { showToast } = useToast();
  const [employeeContractHistoryData, setEmployeeContractHistoryData] =
    useState([]);

  const employeeContractHistory = async () => {
    try {
      const response = await API(
        'employeeManagement.contractHistory',
        {
          query: { id: karyawanId },
        }
      );
      const data = response.data.data;
      console.log(data);
      setEmployeeContractHistoryData(data);
    } catch (error) {
      // showToast('error', (error as Error).message);
    }
  };

  const handleOpenHistoryModal = async () => {
    await employeeContractHistory();
    setIsHistoryModalOpen(true);
  };

  const handleCloseHistoryModal = () => {
    setIsHistoryModalOpen(false);
  };

  const navigateToEditProfile = () => {
    router.push(`/karyawan/edit-karyawan/${employeeData.partyId}`);
  };

  const imageUrl = employeeData.imageUrl ?? '/user-profile-sample.svg';
  const contractStartDate = employeeData.contractInformation?.contractStartDate;
  const startDate = contractStartDate ? parse(contractStartDate, 'dd/MM/yyyy', new Date()) : null;
  const currentDate = new Date();
  const monthsDifference = startDate ? differenceInMonths(currentDate, startDate) : '-';

  return (
    <Box sx={{ position: 'relative' }}>
      <Grid
        container
        alignItems="flex-start"
        justifyContent="space-between"
        spacing={2}
      >
        <Grid
          container
          alignItems="flex-start"
          justifyContent="space-between"
          spacing={2}
        >
          <Grid component="div">
            <Box
              sx={{
                width: 100,
                height: 100,
                borderRadius: '12px',
                backgroundImage: `url(${imageUrl})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
          </Grid>
          <Grid
            component="div"
            sx={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
            }}
          >
            <Grid sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <HmTypography big bold>
                {employeeData.fullname ?? ''}
              </HmTypography>
              <HmChip
                label={employeeData.contractInformation?.statusName ?? ''}
                backgroundColor={colors.palette.infoAccent}
                textColor={colors.palette.info}
              />
            </Grid>
            <Grid
              component="div"
              sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <Image
                src="/icons/check-calendar.svg"
                alt="Check Calendar"
                width={18}
                height={16}
              />
              <Grid>
                <HmTypography
                  variant="body1"
                  color={colors.palette.greyPrimary}
                >
                  {employeeData.contractInformation?.contractStartDate ?? ''}
                </HmTypography>
                <HmTypography
                  variant="body1"
                  color={colors.palette.greyPrimary}
                >
                  {` (${monthsDifference} Bulan)`}
                </HmTypography>
              </Grid>
            </Grid>
            <Grid
              component="div"
              sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <Image
                src="/icons/case.svg"
                alt="Check Calendar"
                width={18}
                height={16}
              />
              <Grid>
                <HmTypography
                  variant="body1"
                  color={colors.palette.greyPrimary}
                >
                  {employeeData.healthAndFinance?.nik ?? ''}
                </HmTypography>
                <HmTypography
                  variant="body1"
                  color={colors.palette.greyPrimary}
                >
                  {' '}
                  •{' '}
                </HmTypography>
                <HmTypography
                  variant="body1"
                  color={colors.palette.greyPrimary}
                >
                  {employeeData.contractInformation?.divisionName ?? ''}
                </HmTypography>
                <HmTypography
                  variant="body1"
                  color={colors.palette.greyPrimary}
                >
                  {' '}
                  •{' '}
                </HmTypography>
                <HmTypography variant="body1" color={colors.palette.primary}>
                  {employeeData.contractInformation?.jobPositionName ?? ''}
                </HmTypography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid sx={{ display: 'flex', gap: 1 }}>
          <HmButton
            variant="outlined"
            icon={<FaListOl size={16} />}
            label="Histori Kontrak"
            color="transparent"
            borderColor={colors.palette.brandSecondary}
            labelColor={colors.palette.brandSecondary}
            onClick={handleOpenHistoryModal}
          />
          <HmButton
            variant="outlined"
            icon={<PiNotePencilBold size={16} />}
            label="Edit Profil"
            color="transparent"
            borderColor={colors.palette.primary}
            labelColor={colors.palette.primary}
            onClick={navigateToEditProfile}
          />
        </Grid>
      </Grid>
      {isHistoryModalOpen && (
        <Box
          sx={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
        >
          <HistoryContract
            isModalOpen={isHistoryModalOpen}
            onClose={handleCloseHistoryModal}
            data={employeeContractHistoryData}
          />
        </Box>
      )}
    </Box>
  );
};

export default DetailKaryawanHeader;