import { Box } from '@mui/material';
import DetailSection from './DetailSection';
import { v4 as uuidv4 } from 'uuid';

interface DataKependudukanContentProps {
  data: {
    nik: string | null;
    npwp: string | null;
    ptkpStatus: string | null;
    bpjsNumber: string | null;
    bpjsClass: string | null;
    employmentBpjsNumber: string | null;
    bankName: string | null;
    accountNumber: string | null;
  } | null;
}

const DataKependudukanContent: React.FC<DataKependudukanContentProps> = ({
  data,
}) => {
  const sections = [
    {
      id: uuidv4(),
      title: 'Data NIK & NPWP',
      details: [
        { label: 'NIK', value: data?.nik ?? '' },
        { label: 'Nomor NPWP', value: data?.npwp ?? '' },
        { label: 'Status PTKP', value: data?.ptkpStatus ?? '' },
      ],
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Data BPJS',
      details: [
        { label: 'Nomor BPJS Kesehatan', value: data?.bpjsNumber ?? '' },
        { label: 'Kelas BPJS Kesehatan', value: data?.bpjsClass ?? '' },
        {
          label: 'Nomor BPJS Ketenagakerjaan',
          value: data?.employmentBpjsNumber ?? '',
        },
      ],
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Data Rekening',
      details: [
        { label: 'Nama Bank', value: data?.bankName ?? '' },
        { label: 'Nomor Rekening', value: data?.accountNumber ?? '' },
      ],
      showDivider: false,
    },
  ];

  return (
    <Box>
      {sections.map((section) => (
        <DetailSection key={section.id} {...section} />
      ))}
    </Box>
  );
};

export default DataKependudukanContent;
