import React from 'react';
import { Box } from '@mui/material';
import DetailSection from './DetailSection';
import { HmButton, HmLink } from '@/components/component/';
import colors from '@/components/colors';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import { v4 as uuidv4 } from 'uuid';

interface DocumentDetail {
  documentId: string;
  documentType: string;
  documentName: string;
  documentUrl: string;
}

interface SocialMediaDetail {
  socialMediaType: string;
  socialMediaLink: string;
}

interface DocumentContentProps {
  data: {
    documentEmployee: DocumentDetail[] | null;
    socialMedia: SocialMediaDetail[] | null;
  } | null;
}

const DocumentContent: React.FC<DocumentContentProps> = ({ data }) => {
  const sections = [
    {
      id: uuidv4(),
      title: 'Dokumen Karyawan',
      columns: [
        { header: 'Tipe', accessor: 'tipe' as const },
        { header: 'Download', accessor: 'download' as const },
        { header: 'Aksi', accessor: 'aksi' as const },
      ],
      data:
      // @ts-ignore
        data?.map((document: DocumentDetail) => ({
          id: document.documentId,
          tipe: document.documentType,
          download: (
            <a href={document.documentUrl} download={document.documentName}>
              <HmLink
                href={document.documentUrl}
                color={colors.palette.primary}
              >
                {document.documentName}
              </HmLink>
            </a>
          ),
          aksi: (
            <HmButton
              icon={<MdOutlineRemoveRedEye size={16} />}
              color={colors.palette.skyblue}
              onClick={() => window.open(document.documentUrl, '_blank')}
              sx={{
                minWidth: '38px',
                width: '38px',
                height: '38px',
              }}
            />
          ),
        })) ?? [],
      showDivider: false,
    },
    {
      id: uuidv4(),
      title: 'Social Media',
      columns: [
        { header: 'Social Media', accessor: 'socialMedia' as const },
        { header: 'Link', accessor: 'sMLink' as const },
      ],
      data:
        data?.socialMedia?.map((social, index) => ({
          id: index + 1,
          socialMedia: social.socialMediaType,
          sMLink: social.socialMediaLink,
        })) ?? [],
      showDivider: false,
    },
  ];

  return (
    <Box>
      {sections.map((section) => (
        // @ts-ignore
        <DetailSection key={section.id} {...section} />
      ))}
    </Box>
  );
};

export default DocumentContent;
