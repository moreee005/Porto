import React, { useState } from 'react';
import HmButton from '@/components/component/HmButton';
import HmTypography from '@/components/component/HmTypography';
import { Box } from '@mui/material';
import { MdOutlineRemoveRedEye, MdOutlineVisibilityOff } from 'react-icons/md';

export const columnsTunjanganPenempatan = [
  {
    header: 'Jenis Tunjangan',
    sortable: true,
    accessor: (row: any) => (
      <HmTypography fontSize={14} color="text.secondary">
        {row.jenisTunjangan}
      </HmTypography>
    ),
  },
  {
    header: 'Nominal',
    sortable: true,
    accessor: (row: any) => {
      const [isSalaryVisible, setIsSalaryVisible] = useState(false);

      const handleToggleSalary = () => {
        setIsSalaryVisible((prevState) => !prevState);
      };

      return (
        <Box style={{ display: 'flex' }}>
          <HmTypography fontSize={14} color="text.secondary">
            {isSalaryVisible ? `${row.nominal}` : 'Rp. ************'}
          </HmTypography>
          <HmButton
            icon={
              isSalaryVisible ? (
                <MdOutlineVisibilityOff size={16} style={{ color: 'grey' }} />
              ) : (
                <MdOutlineRemoveRedEye size={16} style={{ color: 'grey' }} />
              )
            }
            color="white"
            variant="text"
            onClick={handleToggleSalary}
          />
        </Box>
      );
    },
  },
];

export const columnsTunjanganLain = [
  {
    header: 'Jenis Tunjangan',
    sortable: true,
    accessor: (row: any) => (
      <HmTypography fontSize={14} color="text.secondary">
        {row.jenisTunjangan}
      </HmTypography>
    ),
  },
  {
    header: 'Nominal',
    sortable: true,
    accessor: (row: any) => {
      const [isSalaryVisible, setIsSalaryVisible] = useState(false);

      const handleToggleSalary = () => {
        setIsSalaryVisible((prevState) => !prevState);
      };

      return (
        <Box style={{ display: 'flex', alignItems: 'center' }}>
          <HmTypography fontSize={14} color="text.secondary">
            {isSalaryVisible ? ` ${row.nominal}` : 'Rp.************'}
          </HmTypography>
          <HmButton
            icon={
              isSalaryVisible ? (
                <MdOutlineVisibilityOff size={16} style={{ color: 'grey' }} />
              ) : (
                <MdOutlineRemoveRedEye size={16} style={{ color: 'grey' }} />
              )
            }
            color="white"
            variant="text"
            onClick={handleToggleSalary}
          />
        </Box>
      );
    },
  },
];
