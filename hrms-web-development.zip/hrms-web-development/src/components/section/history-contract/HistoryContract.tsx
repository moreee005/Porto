import React, { useState } from 'react';
import colors from '@/components/colors';
import HmButton from '@/components/component/HmButton';
import HmModal from '@/components/component/HmModal';
import HmTable from '@/components/component/HmTable';
import { Box, Tooltip } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import HmChip from '@/components/component/HmChip';
import {
  MdDownload,
  MdOutlineRemoveRedEye,
  MdOutlineVisibilityOff,
} from 'react-icons/md';
import {
  dataHistory,
  dataTunjanganLainLain,
  dataTunjanganPenempatan,
} from '@/data/dumyHistoryContract';
import { columnsTunjanganLain, columnsTunjanganPenempatan } from './Allowance';
import { formatDate } from '@/utils/date-formatter';
import { boolean } from 'yup';

type HistoryContractProps = {
  isModalOpen: boolean;
  onClose: () => void;
  data?: any[];
};

const HistoryContract = ({
  isModalOpen,
  onClose,
  data,
}: HistoryContractProps) => {
  const [modals, setModals] = useState({
    history: false,
    tunjangan: false,
  });
  const [isSalaryVisible, setIsSalaryVisible] = useState(false);

  // handler toggling modal
  const toggleModal = (modal: 'history' | 'tunjangan', isOpen: boolean) => {
    setModals((prev) => ({ ...prev, [modal]: isOpen }));
  };

  const toggleSalaryVisibility = () => {
    setIsSalaryVisible((prevState) => !prevState);
  };

  const columnsHistory = [
    {
      header: 'Kontrak',
      sortable: true,
      accessor: (row: any) => {
        const contractStyles = {
          Fulltime: {
            bgColor: 'rgb(227,242,250)',
            textColor: colors.palette.info,
          },
          Probation: {
            bgColor: 'rgb(228,247,231)',
            textColor: colors.palette.success,
          },
          OJT: {
            bgColor: 'rgb(255,246,227)',
            textColor: colors.palette.warning,
          },
          'Back to back': {
            bgColor: 'rgb(255,236,231)',
            textColor: colors.palette.orange,
          },
          Permanent: {
            bgColor: 'rgb(234,235,249)',
            textColor: colors.palette.primary,
          },
        };
        const { bgColor, textColor } = contractStyles[
          row.contractType as
            | 'Fulltime'
            | 'Probation'
            | 'OJT'
            | 'Back to back'
            | 'Permanent'
        ] || {
          bgColor: 'rgb(207,208,218)',
          textColor: colors.palette.secondary,
        };
        return (
          <HmChip
            label={row.contractType}
            backgroundColor={bgColor}
            textColor={textColor}
            fontSize="14px"
            sx={{
              fontWeight: 600,
              height: '24px',
            }}
          />
        );
      },
    },
    {
      header: 'Dok Kontrak',
      accessor: (row: any) => (
        <Box sx={{ display: 'flex', gap: 1 }}>
          <HmButton
            icon={
              <img
                src="/icons/eyes.svg"
                alt="View Details"
                width={16}
                height={16}
              />
            }
            labelColor={colors.palette.primary}
            color="rgb(234,235,249)"
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
          />
          <HmButton
            icon={<MdDownload size={16} />}
            labelColor={colors.palette.white}
            color={colors.palette.primary}
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
          />
        </Box>
      ),
    },
    {
      header: 'Start',
      sortable: true,
      accessor: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.start ? formatDate(new Date(row.start)) : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'End',
      sortable: true,
      accessor: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.end ? formatDate(new Date(row.end)) : '-'}
        </HmTypography>
      ),
    },
    {
      header: 'Gaji Pokok',
      sortable: true,
      accessor: (row: any) => (
        <Box style={{ display: 'flex', alignItems: 'center' }}>
          <HmTypography fontSize={14} color="text.secondary">
            {isSalaryVisible ? `Rp.${row.salary}` : 'Rp. *****'}
          </HmTypography>
          <HmButton
            icon={
              isSalaryVisible ? (
                <MdOutlineRemoveRedEye size={16} style={{ color: 'grey' }} />
              ) : (
                <MdOutlineVisibilityOff size={16} style={{ color: 'grey' }} />
              )
            }
            color="white"
            variant="text"
            onClick={toggleSalaryVisibility}
          />
        </Box>
      ),
    },
    {
      header: 'Bank',
      sortable: true,
      accessor: (row: any) => {
        const getBankIcon = (status: string) => {
          switch (status) {
            case 'Bersedia Ditempatkan DiBank':
              return {
                icon: '/icons/check-succes.svg',
                tooltipMessage: 'Bersedia ditempatkan di bank',
              };
            case 'Tidak Bersedia Ditempatkan DiBank':
              return {
                icon: '/icons/close-error.svg',
                tooltipMessage: 'Tidak bersedia ditempatkan di bank',
              };
            case 'Bersedia Ditempatkan DiBank Syariah':
              return {
                icon: '/icons/strip-green.svg',
                tooltipMessage: 'Bersedia di Tempatkan Dibank Syariah',
              };
            case 'Bersedia dibank selamat tidak core banking & loan':
              return {
                icon: '/icons/strip-orange.svg',
                tooltipMessage:
                  'Bersedia dibank selamat tidak core banking & loan',
              };
            default:
              return {
                icon: '/icons/close-error.svg',
                tooltipMessage: '',
              };
          }
        };
        const bankConfig = getBankIcon(row.bankIssurancePlacementAgreement);
        return (
          <Tooltip title={bankConfig.tooltipMessage} arrow placement="top">
            <img
              src={bankConfig.icon}
              alt={bankConfig.tooltipMessage}
              width={24}
              height={24}
              style={{
                verticalAlign: 'middle',
              }}
            />
          </Tooltip>
        );
      },
    },
    {
      header: 'Penempatan',
      sortable: true,
      accessor: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.placement}
        </HmTypography>
      ),
    },
    {
      header: 'Tunjangan',
      accessor: () => (
        <Box sx={{ display: 'flex', gap: 1 }}>
          <HmButton
            icon={
              <img
                src="/icons/eyes.svg"
                alt="View Details"
                width={16}
                height={16}
              />
            }
            labelColor={colors.palette.primary}
            color="rgb(230, 242, 255)"
            borderRadius="10"
            sx={{
              minWidth: '28px',
              width: '28px',
              height: '28px',
            }}
            onClick={() => toggleModal('tunjangan', true)}
          />
        </Box>
      ),
    },
  ];

  return (
    <Box sx={{ padding: 3 }}>
      {/* <HmButton
        icon={<img src="/icons/menu.svg" alt="menu" width={16} height={16} />}
        label={
          <HmTypography color="text.main" sx={{ marginLeft: 1 }}>
            Histori Kontrak
          </HmTypography>
        }
        labelColor={colors.palette.orange}
        color={colors.palette.white}
        borderRadius="10"
        borderColor={colors.palette.orange}
        onClick={() => toggleModal('history', true)}
        sx={{
          minWidth: '28px',
        }}
      /> */}

      <Box sx={{ width: '100%' }}>
        {/* modal history */}
        <HmModal
          isOpen={isModalOpen}
          onClose={onClose}
          title="History Kontrak - Name"
          zIndex={100}
          onClickAction={() => toggleModal('history', false)}
          maxWidth="lg"
        >
          <HmTable
            minWidth={1000}
            data={dataHistory}
            columns={columnsHistory}
            loading={false}
            page={0}
            rowsPerPage={10}
            totalItems={dataHistory.length}
            onPageChange={() => {}}
            handleRowsPerPageChange={() => {}}
            noPagination={true}
          />
        </HmModal>
      </Box>

      {/* modal tunjangan */}
      <HmModal
        isOpen={modals.tunjangan}
        onClose={() => toggleModal('tunjangan', false)}
        title="Tunjangan - Name - Date(21/12/2024)"
        zIndex={100}
        onClickAction={() => toggleModal('tunjangan', false)}
        maxWidth="md"
      >
        <Box
          sx={{
            width: '100%',
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
          }}
        >
          <HmTypography fontSize={14} color="text.secondary">
            Tunjangan Penempatan
          </HmTypography>
          <HmTable
            data={dataTunjanganPenempatan}
            columns={columnsTunjanganPenempatan}
            loading={false}
            page={0}
            rowsPerPage={10}
            totalItems={dataTunjanganPenempatan.length}
            onPageChange={() => {}}
            handleRowsPerPageChange={() => {}}
            noPagination={true}
            minWidth={400}
            showNumberColumn={true}
          />
          <HmTypography fontSize={14} color="text.secondary">
            Tunjangan Lain-Lain
          </HmTypography>
          <HmTable
            data={dataTunjanganLainLain}
            columns={columnsTunjanganLain}
            loading={false}
            page={0}
            rowsPerPage={10}
            totalItems={dataTunjanganLainLain.length}
            onPageChange={() => {}}
            handleRowsPerPageChange={() => {}}
            noPagination={true}
            minWidth={400}
            showNumberColumn={true}
          />
        </Box>
      </HmModal>
    </Box>
  );
};

export default HistoryContract;
