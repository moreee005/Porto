'use client';

import React from 'react';

import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import HmDivider from '@/components/component/HmDivider';
import colors from '@/components/colors';
import Grid from '@mui/material/Grid2';
import { HmTable } from '@/components/component';

interface InformasiKontrakProps {
    formDataKaryawanBaru: any;
}

const IdentitasDiri: React.FC<InformasiKontrakProps> = ({ formDataKaryawanBaru }) => {

    const siblings = formDataKaryawanBaru.siblings || [];
    const familyMembersInKk = formDataKaryawanBaru.familyMembersInKk || [];
    const educationHistory = formDataKaryawanBaru.educationHistory || [];
    const coursesOrUpgrading = formDataKaryawanBaru.coursesOrUpgrading || [];
    const workExperience = formDataKaryawanBaru.workExperience || [];
    const organizationalLife = formDataKaryawanBaru.organizationalLife || [];

    const renderField = (
        name: string,
        label: string,
        type: string,
        options?: {
            header: string;
            accessor: "id" | ((row: { id: string | number; }) => React.ReactNode);
            render?: (row: { id: string | number; }) => React.ReactNode;
            sortable?: boolean;
        }[],
        data?: [],
        showNumber?: boolean,
    ) => {
        if (type === 'table') {
            return (
                <HmTable
                    columns={options as {
                        header: string;
                        accessor: "id" | ((row: { id: string | number; }) => React.ReactNode);
                        render?: (row: { id: string | number; }) => React.ReactNode;
                        sortable?: boolean;
                    }[]}
                    data={data || []}
                    page={1}
                    rowsPerPage={0}
                    noPagination
                    showNumberColumn={showNumber}
                    totalItems={100}
                    onPageChange={() => { }}
                    handleRowsPerPageChange={(value) => { }}
                />
            );
        } else if (type === 'text') {
            return (
                <Box sx={{ display: 'flex', flexDirection: 'column', mb: 2, width: '100%' }}>
                    <HmTypography sx={{ marginBottom: '10px', }} color={colors.palette.secondary}>
                        {name}
                    </HmTypography>
                    <HmTypography fontSize={18} color={colors.palette.black} >
                        {label}
                    </HmTypography>
                </Box>
            );
        } else {
            return null;
        }
    };

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Diri
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nama Lengkap', formDataKaryawanBaru?.fullname || '-', 'text', [])}
                            {renderField('Tempat Lahir', formDataKaryawanBaru?.placeOfBirth || '-', 'text', [])}
                            {renderField('Suku Bangsa', formDataKaryawanBaru?.ethnicity || '-', 'text', [])}
                            {renderField('Golongan Darah', formDataKaryawanBaru?.bloodType || '-', 'text', [])}
                            {renderField('Email', formDataKaryawanBaru?.email || '-', 'text', [])}
                            {renderField('Kontak Darurat yang Dapat dihubungi', formDataKaryawanBaru.emergencyContact?.phoneNumber || '-', 'text', [])}
                            {renderField('Background (IT / Non IT)', formDataKaryawanBaru?.background || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Jenis Kelamin', formDataKaryawanBaru?.gender === 'M' ? 'Laki-laki' : formDataKaryawanBaru?.gender === 'F' ? 'Perempuan' : '-', 'text', [])}
                            {renderField('Tanggal Lahir', formDataKaryawanBaru?.dateOfBirth || '-', 'text', [])}
                            {renderField('Agama', formDataKaryawanBaru?.religion || '-', 'text', [])}
                            {renderField('Status Menikah', formDataKaryawanBaru?.maritalStatus || '-', 'text', [])}
                            {renderField('Nomor Telepon', formDataKaryawanBaru?.phoneNumber || '-', 'text', [])}
                            {renderField('Hubungan dengan Kontak Darurat', formDataKaryawanBaru.emergencyContact?.relationship || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Alamat Rumah
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Alamat Lengkap', formDataKaryawanBaru.homeAddress?.fullAddress || '-', 'text', [])}
                            {renderField('Kota/Kabupaten', formDataKaryawanBaru.homeAddress?.city || '-', 'text', [])}
                            {renderField('Kelurahan', formDataKaryawanBaru.homeAddress?.district || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Provinsi', formDataKaryawanBaru.homeAddress?.province || '-', 'text', [])}
                            {renderField('Kecamatan/Kota', formDataKaryawanBaru.homeAddress?.subDistrict || '-', 'text', [])}
                            {renderField('Kode Pos', formDataKaryawanBaru.homeAddress?.postalCode || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Orang Tua (Ibu)
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nama Ibu', formDataKaryawanBaru.motherIdentity?.name || '-', 'text', [])}
                            {renderField('Pendidikan Terakhir Ibu', formDataKaryawanBaru.motherIdentity?.highestEducation || '-', 'text', [])}
                            {renderField('Gaji Ibu', formDataKaryawanBaru.motherIdentity?.motherSalary || '-', 'text', [])}
                            {renderField('Status Hidup Ibu', formDataKaryawanBaru.motherIdentity?.statusAlive || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Tanggal Lahir Ibu', formDataKaryawanBaru.motherIdentity?.dateOfBirth || '-', 'text', [])}
                            {renderField('Pekerjaan Ibu', formDataKaryawanBaru.motherIdentity?.occupation || '-', 'text', [])}
                            {renderField('Nomor Telepon Ibu', formDataKaryawanBaru.motherIdentity?.phoneNumber || '-', 'text', [])}
                            {renderField('Alamat Ibu', formDataKaryawanBaru.motherIdentity?.address || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>

                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Orang Tua (Ayah)
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nama Ayah', formDataKaryawanBaru.fatherIdentity?.name || '-', 'text', [])}
                            {renderField('Pendidikan Terakhir Ayah', formDataKaryawanBaru.fatherIdentity?.highestEducation || '-', 'text', [])}
                            {renderField('Gaji Ayah', formDataKaryawanBaru.fatherIdentity?.salary || '-', 'text', [])}
                            {renderField('Status Hidup Ayah', formDataKaryawanBaru.fatherIdentity?.statusAlive || '-', 'text', [])}
                            {renderField('Alamat Lengkap Ayah', formDataKaryawanBaru.fatherIdentity?.address || '-', 'text', [])}
                            {renderField('Kota/Kabupaten', formDataKaryawanBaru.fatherIdentity?.city || '-', 'text', [])}
                            {renderField('Kelurahan', formDataKaryawanBaru.fatherIdentity?.district || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Tanggal Lahir Ayah', formDataKaryawanBaru.fatherIdentity?.dateOfBirth || '-', 'text', [])}
                            {renderField('Pekerjaan Ayah', formDataKaryawanBaru.fatherIdentity?.occupation || '-', 'text', [])}
                            {renderField('Nomor Telepon Ayah', formDataKaryawanBaru.fatherIdentity?.phoneNumber || '-', 'text', [])}
                            {renderField('Provinsi', formDataKaryawanBaru.fatherIdentity?.province || '-', 'text', [])}
                            {renderField('Kecamatan/Kota', formDataKaryawanBaru.fatherIdentity?.subdistrict || '-', 'text', [])}
                            {renderField('Kode Pos', formDataKaryawanBaru.fatherIdentity?.postalCode || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Suami/Istri
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nama Suami/Istri', formDataKaryawanBaru.spouseIdentity?.name || '-', 'text', [])}
                            {renderField('Pendidikan Terakhir Suami/Istri', formDataKaryawanBaru.spouseIdentity?.highestEducation || '-', 'text', [])}
                            {renderField('Gaji Suami/Istri', formDataKaryawanBaru.spouseIdentity?.salary || '-', 'text', [])}
                            {renderField('Alamat Suami/Istri', formDataKaryawanBaru.spouseIdentity?.address || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Tanggal Lahir Suami/Istri', formDataKaryawanBaru.spouseIdentity?.dateOfBirth || '-', 'text', [])}
                            {renderField('Pekerjaan Suami/Istri', formDataKaryawanBaru.spouseIdentity?.occupation || '-', 'text', [])}
                            {renderField('Status Pajak Suami/Istri', formDataKaryawanBaru.spouseIdentity?.taxStatus || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
            </Box>
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Urutan Keluarga
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                <Grid container spacing={4} >
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Saya anak ke?', formDataKaryawanBaru.familyOrder?.childNumber || '-', 'text', [])}
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Dari Berapa bersaudara?', formDataKaryawanBaru.familyOrder?.totalSiblings || '-', 'text', [])}
                    </Grid>
                </Grid>
                <Box>
                    {renderField('Sauradara Kandung', 'Sauradara Kandung', 'table', [
                        {
                            header: 'Jenis Kelamin',
                            accessor: (row: any) => row.gender !== null ? (row.gender === 'M' ? 'Laki-laki' : row.gender === 'F' ? 'Perempuan' : '-') : "-",
                        },
                        {
                            header: 'Tanggal lahir',
                            accessor: (row: any) => row.dateOfBirth !== null ? row.dateOfBirth : "-",
                        },
                        {
                            header: 'Pekerjaan/Sekolah',
                            accessor: (row: any) => row.occupation !== null ? row.occupation : "-",
                        },
                        {
                            header: 'Jenjang Pendidikan',
                            accessor: (row: any) => row.education !== null ? row.education : "-",
                        },
                    ],
                        siblings && siblings.length > 0 ? siblings : [{ gender: "-", dateOfBirth: "-", occupation: "-", education: "-" }],
                        !!siblings.length
                    )}
                </Box>
                <Box sx={{ mt: 4 }}>
                    {renderField('Anggota Keluarga dalam KK', 'Anggota Keluarga dalam KK', 'table', [
                        {
                            header: 'Jenis Kelamin',
                            accessor: (row: any) => row.gender !== null ? (row.gender === 'M' ? 'Laki-laki' : row.gender === 'F' ? 'Perempuan' : '-') : "-",
                        },
                        {
                            header: 'Tanggal Lahir',
                            accessor: (row: any) => row.dateOfBirth !== null ? row.dateOfBirth : "-",
                        },
                        {
                            header: 'Pekerjaan',
                            accessor: (row: any) => row.occupation !== null ? row.occupation : "-",
                        },
                        {
                            header: 'Pendidikan',
                            accessor: (row: any) => row.education !== null ? row.education : "-",
                        },
                        {
                            header: 'Tahun Masuk',
                            accessor: (row: any) => row.yearJoined !== null ? row.yearJoined : "-",
                        },
                        {
                            header: 'Jurusan',
                            accessor: (row: any) => row.major !== null ? row.major : "-",
                        },
                    ],
                        familyMembersInKk && familyMembersInKk.length > 0 ? familyMembersInKk : [{ gender: "-", dateOfBirth: "-", occupation: "-", education: "-", yearJoined: "-", major: "-" }],
                        !!familyMembersInKk.length
                    )}
                </Box>
            </Box>
            <HmDivider />
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Riwayat Pendidikan
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('Riwayat Pendidikan', 'Riwayat Pendidikan', 'table', [
                    {
                        header: 'Name sekolah /kampus',
                        accessor: (row: any) => row.institutionName !== null ? row.institutionName : "-",
                    },
                    {
                        header: 'jenjang',
                        accessor: (row: any) => row.jenjang !== null ? row.jenjang : "-",
                    },
                    {
                        header: 'Kota asal sekolah/kampus',
                        accessor: (row: any) => row.location !== null ? row.location : "-",
                    },
                    {
                        header: 'tahun lulus',
                        accessor: (row: any) => row.endDate !== null ? row.endDate : "-",
                    },
                ],
                    educationHistory && educationHistory.length > 0 ? educationHistory : [{ institutionName: "-", jenjang: "-", location: "-", endDate: "-" }],
                    !!educationHistory.length
                )}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Kursus Atau Upgrading
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('Kursus/Upgrading/Penataran yang telah diikuti', 'Kursus/Upgrading/Penataran yang telah diikuti', 'table', [
                    {
                        header: 'jenis',
                        accessor: (row: any) => row.type !== null ? row.type : "-",
                    },
                    {
                        header: 'nama pelatihan',
                        accessor: (row: any) => row.courseName !== null ? row.courseName : "-",
                    },
                    {
                        header: 'Tempat kota',
                        accessor: (row: any) => row.city !== null ? row.city : "-",
                    },
                    {
                        header: 'Tanggal',
                        accessor: (row: any) => row.date !== null ? row.date : "-",
                    },
                    {
                        header: 'Bulan',
                        accessor: (row: any) => row.month !== null ? row.month : "-",
                    },
                    {
                        header: 'Tahun',
                        accessor: (row: any) => row.year !== null ? row.year : "-",
                    },
                    {
                        header: 'Lamanya(Bulan)',
                        accessor: (row: any) => row.durationMonths !== null ? row.durationMonths : "-",
                    },
                    {
                        header: 'Instansi',
                        accessor: (row: any) => row.institution !== null ? row.institution : "-",
                    },
                    {
                        header: 'Nomor sertifikat',
                        accessor: (row: any) => row.certificateNumber !== null ? row.certificateNumber : "-",
                    },
                ], coursesOrUpgrading && coursesOrUpgrading.length > 0 ? coursesOrUpgrading : [{ type: "-", courseName: "-", city: "-", date: "-", month: "-", year: "-", durationMonths: "-", institution: "-", certificateNumber: "-" }], !!coursesOrUpgrading.length)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Pengalaman Kerja
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('Pengalaman Kerja', 'Pengalaman Kerja', 'table', [
                    {
                        header: 'Nama instansi',
                        accessor: (row: any) => row.companyName !== null ? row.companyName : "-",
                    },
                    {
                        header: 'Jabatan',
                        accessor: (row: any) => row.position !== null ? row.position : "-",
                    },
                    {
                        header: 'Tempat(kota)',
                        accessor: (row: any) => row.city !== null ? row.city : "-",
                    },
                    {
                        header: 'Tahun mulai',
                        accessor: (row: any) => row.startYear !== null ? row.startYear : "-",
                    },
                    {
                        header: 'Tahun selesai',
                        accessor: (row: any) => row.endYear !== null ? row.endYear : "-",
                    },
                    {
                        header: 'Lamanya',
                        accessor: (row: any) => row.durationMonths !== null ? row.durationMonths : "-",
                    },
                ], workExperience && workExperience.length > 0 ? workExperience : [{ companyName: "-", position: "-", city: "-", startYear: "-", endYear: "-", durationMonths: "-" }], !!workExperience.length)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Kehidupan berorganisasi
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('Kehidupan berorganisasi/Kemasyarakatan', 'Kehidupan berorganisasi/Kemasyarakatan', 'table', [
                    {
                        header: 'Nama organisasi',
                        accessor: (row: any) => row.organizationName !== null ? row.organizationName : "-",
                    },
                    {
                        header: 'Tahun menjabat',
                        accessor: (row: any) => row.yearInPosition !== null ? row.yearInPosition : "-",
                    },
                    {
                        header: 'Jabatan',
                        accessor: (row: any) => row.position !== null ? row.position : "-",
                    },
                    {
                        header: 'Jumlah Anggota',
                        accessor: (row: any) => row.memberCount !== null ? row.memberCount : "-",
                    },
                    {
                        header: 'Tempat(Kota)',
                        accessor: (row: any) => row.city !== null ? row.city : "-",
                    },
                    {
                        header: 'Lamanya',
                        accessor: (row: any) => row.durationMonths !== null ? row.durationMonths : "-",
                    },
                ], organizationalLife && organizationalLife.length > 0 ? organizationalLife : [{ organizationName: "-", yearInPosition: "-", position: "-", memberCount: "-", city: "-", durationMonths: "-" }], !!organizationalLife.length)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Olahraga
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                <Grid container spacing={4} >
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Olahraga ', formDataKaryawanBaru.sports?.name || '-', 'text', [])}
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Aktif/Pasif(Olahraga)', formDataKaryawanBaru.sports?.activePassive || '-', 'text', [])}
                    </Grid>
                </Grid>
            </Box>
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Kesenian
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                <Grid container spacing={4} >
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Kesenian', formDataKaryawanBaru.art?.name || '-', 'text', [])}
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Aktif/Pasif(Kesenian)', formDataKaryawanBaru.art?.activePassive || '-', 'text', [])}
                    </Grid>
                </Grid>
            </Box>
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Lainnya
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                <Grid container spacing={4}>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Penguasaan Bahasa Asing', formDataKaryawanBaru.other?.foreignLanguageProficiency.join(', ') || '-', 'text', [])}
                        {renderField('Hobi', formDataKaryawanBaru.other?.hobbies.join(', ') || '-', 'text', [])}
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('Minat karir', formDataKaryawanBaru.other?.careerInterest || '-', 'text', [])}
                    </Grid>
                </Grid>
            </Box>
        </Box >
    );
}

export default IdentitasDiri;
