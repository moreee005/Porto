'use client';

import React from 'react';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import colors from '@/components/colors';
import Grid from '@mui/material/Grid2';

interface InformasiKontrakProps {
    formDataKaryawanBaru: any;
}
const DataKependudukan: React.FC<InformasiKontrakProps> = ({ formDataKaryawanBaru }) => {

    const renderField = (
        name: string,
        label: string,
        type: string,
        options?: {
            header: string;
            accessor: "id" | ((row: { id: string | number; }) => React.ReactNode);
            render?: (row: { id: string | number; }) => React.ReactNode;
            sortable?: boolean;
        }[],
    ) => {
        if (type === 'text') {
            return (
                <Box sx={{ display: 'flex', flexDirection: 'column', mb: 2, width: '100%' }}>
                    <HmTypography sx={{ marginBottom: '10px', }} color={colors.palette.secondary}>
                        {name}
                    </HmTypography>
                    <HmTypography fontSize={18} color={colors.palette.black} >
                        {label}
                    </HmTypography>
                </Box>
            );
        } else {
            return null;
        }
    };

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Data NIK & NPWP
                </HmTypography>
                <Box sx={{ px: 2, mt: 2 }}>
                    <Grid container spacing={4}>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('NIK', formDataKaryawanBaru.healthAndFinance.nik || '-', 'text', [])}
                            {renderField('Status PTKP', formDataKaryawanBaru.healthAndFinance.ptkpStatus || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nomor NPWP', formDataKaryawanBaru.healthAndFinance.npwp || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Data BPJS
                </HmTypography>
                <Box sx={{ px: 2, mt: 2 }}>
                    <Grid container spacing={4}>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nomor BPJS Kesehatan', formDataKaryawanBaru.healthAndFinance.bpjsNumber || '-', 'text', [])}
                            {renderField('Nomor BPJS Ketenagakerjaan', formDataKaryawanBaru.healthAndFinance.employmentBpjsNumber || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Kelas BPJS Kesehatan', formDataKaryawanBaru.healthAndFinance.bpjsClass || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Data Rekening
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nama Bank', formDataKaryawanBaru.healthAndFinance.bankName || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Nomor Rekening', formDataKaryawanBaru.healthAndFinance.accountNumber || '-', 'text', [])}
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Box>
    );
};

export default DataKependudukan;



