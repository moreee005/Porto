
import React, { useEffect, useState } from 'react';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import colors from '@/components/colors';
import { HmButton, HmTable } from '@/components/component';
import Checkbox from '@mui/material/Checkbox';
import { styled } from '@mui/material/styles';

interface InformasiKontrakProps {
    formDataKaryawanBaru: any;
    onAllDocsChecked?: () => void;
}
const PurpleCheckbox = styled(Checkbox)(({ theme }) => ({
    color: '#FFFFF',
    '&.Mui-checked': {
        color: '#FFFFF',
    },
    '&.MuiCheckbox-root': {
        borderRadius: '8px',
        width: '24px',
        height: '24px',
    },
}));

const UnggahDokumen: React.FC<InformasiKontrakProps> = ({ formDataKaryawanBaru, onAllDocsChecked }) => {
    const documentsData = formDataKaryawanBaru.documents || [];
    const socialMediaData = formDataKaryawanBaru.socialMedia || [];
    const [checkedDocuments, setCheckedDocuments] = useState<{ [key: string]: boolean }>({});

    useEffect(() => {
        if (documentsData.length > 0) {
            const initialCheckedState = documentsData.reduce((acc: any, doc: any) => {
                acc[doc.documentId] = false; // Gunakan documentId sebagai key
                return acc;
            }, {});
            setCheckedDocuments(initialCheckedState);
        }
    }, [documentsData]);

    useEffect(() => {
        if (Object.keys(checkedDocuments).length === documentsData.length) {
            const allChecked = Object.values(checkedDocuments).every((checked) => checked);
            if (allChecked && onAllDocsChecked) {
                onAllDocsChecked();
            }
        }
    }, [checkedDocuments, documentsData, onAllDocsChecked]);


    const handleCheckboxChange = (documentId: string) => {
        setCheckedDocuments((prev) => ({ ...prev, [documentId]: !prev[documentId] }));
    };

    useEffect(() => {
        console.log("Checked Documents:", checkedDocuments);
        console.log("Documents Data:", documentsData);
    }, [checkedDocuments, documentsData]);

    const renderField = (
        name: string,
        label: string,
        type: string,
        options?: {
            header: string;
            accessor: "id" | ((row: { id: string | number; }) => React.ReactNode);
            render?: (row: { id: string | number; }) => React.ReactNode;
            sortable?: boolean;
        }[],
        data?: [],
        showNumber?: boolean,
    ) => {
        if (type === 'table') {
            return (
                <HmTable
                    columns={options as {
                        header: string;
                        accessor: "id" | ((row: { id: string | number; }) => React.ReactNode);
                        render?: (row: { id: string | number; }) => React.ReactNode;
                        sortable?: boolean;
                    }[]}
                    data={data || []}
                    page={1}
                    rowsPerPage={0}
                    showNumberColumn={showNumber}
                    noPagination
                    totalItems={100}
                    onPageChange={() => { }}
                    handleRowsPerPageChange={(value) => { }}
                />
            );
        }
    };

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Dokumen Employee
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    {renderField('Dokumen karyawan', 'Dokumen karyawan', 'table', [
                        {
                            header: 'Type',
                            accessor: (row: any) => row.documentType,
                            render: (row: any) => (
                                <HmTypography fontSize={14} color="text.black">
                                    {row.documentType}
                                </HmTypography>
                            ),
                        },
                        {
                            header: 'Download',
                            accessor: (row: any) => row.documentName,
                            render: (row: any) => (
                                <a href={row.documentUrl} target="_blank" rel="noopener noreferrer">
                                    <HmTypography fontSize={14} color={colors.palette.primary}>
                                        {row.documentName}
                                    </HmTypography>
                                </a>
                            ),
                        },
                        {
                            header: 'Aksi',
                            accessor: (row: any) => row.documentUrl,
                            render: (row: any) => (
                                <HmButton
                                    icon={
                                        <img
                                            src="/icons/eyes.svg"
                                            alt="View Details"
                                            width={16}
                                            height={16}
                                            style={{ display: 'block', margin: 'auto', marginLeft: 3 }}
                                        />
                                    }
                                    labelColor={colors.palette.primary}
                                    color="rgb(230, 242, 255)"
                                    borderRadius="10"
                                    sx={{
                                        minWidth: '38px',
                                        width: '28px',
                                        height: '28px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                    }}
                                    onClick={() => window.open(row.documentUrl, '_blank')}
                                />
                            ),
                        },
                        {
                            header: 'Cek Dokumen',
                            accessor: (row: any) => row.documentId,
                            render: (row: any,) => (
                                <Box>
                                    <PurpleCheckbox
                                        checked={checkedDocuments[row.documentId] || false}
                                        onChange={() => handleCheckboxChange(row.documentId)}
                                    />
                                    <HmTypography fontSize={16} color="text.secondary" sx={{ marginLeft: 1 }}>Done</HmTypography>
                                </Box>

                            ),
                        },
                    ], documentsData && documentsData.length > 0 ? documentsData : [],
                        !!documentsData.length)}
                </Box>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Social Media
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    {renderField('Dokumen karyawan', 'Dokumen karyawan', 'table', [
                        {
                            header: 'Social Media',
                            accessor: (row: any) => row.socialMediaType !== null ? row.socialMediaType : "-",
                            render: (row: any) => (
                                <HmTypography fontSize={14} color="text.black">
                                    {row.socialMediaType !== null ? row.socialMediaType : "-"}
                                </HmTypography>
                            ),
                        },
                        {
                            header: 'Link Sosmed',
                            accessor: (row: any) => row.socialMediaLink !== null ? row.socialMediaLink : "-",
                            render: (row: any) => (
                                <a href={row.socialMediaLink !== null ? row.socialMediaLink : "-"} target="_blank" rel="noopener noreferrer">
                                    <HmTypography fontSize={14} color={colors.palette.primary}>
                                        {row.socialMediaLink !== null ? row.socialMediaLink : "-"}
                                    </HmTypography>
                                </a>
                            ),
                        },
                    ], socialMediaData && socialMediaData.length > 0 ? socialMediaData : [{ socialMediaType: "-", socialMediaLink: "-" }], !!socialMediaData.length)}

                </Box>
            </Box>
        </Box>
    );
};

export default UnggahDokumen;