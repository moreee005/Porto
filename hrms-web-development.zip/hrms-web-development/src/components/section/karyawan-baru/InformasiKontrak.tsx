'use client';

import React from 'react';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import colors from '@/components/colors';
import Grid from '@mui/material/Grid2';
import { HmButton, HmDivider } from '@/components/component';
import DownloadIcon from '@mui/icons-material/Download';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import theme from '@/utils/theme';

interface InformasiKontrakProps {
    formDataKaryawanBaru: any;
}
const InformasiKontrak: React.FC<InformasiKontrakProps> = ({ formDataKaryawanBaru }) => {

    const handleDownload = () => {
        console.log('Download');
        alert('Download');
    }

    const renderField = (
        name: string,
        label: string,
        type: string,
        options?: {
            header: string;
            accessor: "id" | ((row: { id: string | number; }) => React.ReactNode);
            render?: (row: { id: string | number; }) => React.ReactNode;
            sortable?: boolean;
        }[],
    ) => {
        if (type === 'text') {
            return (
                <Box sx={{ display: 'flex', flexDirection: 'column', mb: 2, width: '100%' }}>
                    <HmTypography sx={{ marginBottom: '10px', }} color={colors.palette.secondary}>
                        {name}
                    </HmTypography>
                    <HmTypography fontSize={18} color={colors.palette.black} >
                        {label}
                    </HmTypography>
                </Box>
            );
        }
    };

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Informasi Kontrak
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Status Kontrak', formDataKaryawanBaru.contractInformation.statusName || '-', 'text', [])}
                            {renderField('Jenis Karyawan', formDataKaryawanBaru.contractInformation.employeTypeName || '-', 'text', [])}
                            {renderField('Divisi', formDataKaryawanBaru.contractInformation.divisionName || '-', 'text', [])}
                            {renderField('Tanggal Mulai Kontrak', formDataKaryawanBaru.contractInformation.contractStartDate || '-', 'text', [])}
                            {renderField('Generasi', formDataKaryawanBaru.contractInformation.generation || '-', 'text', [])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('Jenis Penempatan', formDataKaryawanBaru.contractInformation.placementTypeName || '-', 'text', [])}
                            {renderField('Bersedia Ditempatkan di Bank/insurance', formDataKaryawanBaru.contractInformation.willingToBePlaceInBankOrInsurance || '-', 'text', [])}
                            {renderField('Jabatan', formDataKaryawanBaru.contractInformation.jobPositionName || '-', 'text', [])}
                            {renderField('Tanggal Akhir Kontrak', formDataKaryawanBaru.contractInformation.contractEndDate || '-', 'text', [])}
                            <Box sx={{ display: 'flex', gap: 1 }}>
                                <HmButton
                                    gapIcon={'0.2rem'}
                                    icon={<DownloadIcon fontSize="small" />}
                                    label={
                                        <HmTypography small semiBold>
                                            Download Dokumen
                                        </HmTypography>
                                    }
                                    labelColor="white"
                                    sx={{ paddingX: '12px', paddingY: '6px' }}
                                    onClick={handleDownload}
                                />
                                <HmButton
                                    icon={<MdOutlineRemoveRedEye size={17} style={{ marginLeft: 3 }} />}
                                    labelColor={theme.palette.info.main}
                                    color={theme.palette.info.light}
                                    borderRadius="10"
                                    sx={{
                                        marginX: '8px',
                                        minWidth: '38px',
                                        width: '38px',
                                        height: '38px',
                                    }}
                                    onClick={() => window.open(formDataKaryawanBaru.contractInformation.contractDocument.documentUrl, '_blank')}
                                />
                            </Box>
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Box>
    );
};

export default InformasiKontrak;

