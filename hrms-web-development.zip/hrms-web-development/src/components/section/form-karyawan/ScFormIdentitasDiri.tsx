'use client';

import React, { useEffect, useState } from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import HmPhotoUploader from '@/components/component/HmPhotoUploader';
import { FieldComponent, HmDynamicForm } from '@/components/component';
import HmDivider from '@/components/component/HmDivider';
import colors from '@/components/colors';
import Grid from '@mui/material/Grid2';
import { artDynamic, backgroundOptions, birthPlaceOptions, cityOptions, coursesDynamic, districtOptions, educationDynamic, bloodTypeOptions, educationOptions, emergencyContactRelation, EmployeeFormData, ethnicityOptions, familyMembersDynamic, genderOptions, IdentitasDiriInputs, maritalStatusOptions, motherStatusOptions, organizationsDynamic, foreignLanguageProficiencyOptions, postalCodeOptions, provinceOptions, rangeSalaryOptions, religionOptions, siblingDynamic, sportsDynamic, subdistrictOptions, workExperienceDynamic } from './data-and-validation/form-data';
import { MdOutlineEmail } from 'react-icons/md';
import { FiPhone } from 'react-icons/fi';
import useFetchDropdown from '@/hooks/useFetchDropdown';


interface ScFormIdentitasDiriProps {
    onImageUpload?: (file: File | null) => void; // Callback send file images
}

const ScFormIdentitasDiri: React.FC<ScFormIdentitasDiriProps> = ({ onImageUpload }) => {
    const { control } = useFormContext<IdentitasDiriInputs>();
    const [uploadedImage, setUploadedImage] = useState<File | null>(null);

    useEffect(() => {
        // send image callback
        if (onImageUpload) {
            onImageUpload(uploadedImage);
        }
    }, [uploadedImage, onImageUpload]);

    // agama
    const { options: religionOptions } = useFetchDropdown(
        'master.religion',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // status menikah
    const { options: maritalStatusOptions } = useFetchDropdown(
        'master.marital-status',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // suku bangsa
    const { options: ethnicityOptions } = useFetchDropdown(
        'master.ethnicity',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // gol darah
    const { options: bloodTypeOptions } = useFetchDropdown(
        'master.blood-type',
        (item) => ({
            id: item.bloodId,
            value: item.bloodType,
            label: item.bloodType,
        })
    );
    // jurusan
    const { options: majorOptions } = useFetchDropdown(
        'master.major',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.bloodType,
        })
    );

    // pendidikan
    const { options: educationOptions } = useFetchDropdown(
        'master.education-level',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // hubungan kontrak darurat
    const { options: emergencyContactRelationOptions } = useFetchDropdown(
        'master.contact-emergency',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );

    // range gaji
    const { options: rangeSalaryOptions } = useFetchDropdown(
        'master.salary-range',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );

    // kota asal
    const { options: cityOptions } = useFetchDropdown(
        'master.list-city',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // tipe kursus
    const { options: courseTypeOptions } = useFetchDropdown(
        'master.course-type',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // organisasi member count
    const { options: organizationMemberCountOptions } = useFetchDropdown(
        'master.organization',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );

    // olahraga
    const { options: sportOptions } = useFetchDropdown(
        'master.sport',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // kesenian
    const { options: artOptions } = useFetchDropdown(
        'master.art',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );
    // penguasaan bahasa
    const { options: foreignLanguageProficiencyOptions } = useFetchDropdown(
        'master.foreign-language',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );


    // mapping dynamic table form
    // saurdara kandung
    const siblingDynamicMap = siblingDynamic.map(field => {
        if (field.field === 'educationLevel') {
            return {
                ...field,
                options: educationOptions,
            };
        }
        return field;
    });

    // anggota keluarga
    const familyMembersDynamicMap = familyMembersDynamic.map(field => {
        if (field.field === 'education') {
            return {
                ...field,
                options: educationOptions,
            };
        }
        return field;
    });



    // riwayat pendidikan
    const educationDynamicMap = educationDynamic.map(field => {
        if (field.field === 'jenjang') {
            return {
                ...field,
                options: educationOptions,
            };
        } else if (field.field === 'major') {
            return {
                ...field,
                options: majorOptions,
            };
        } else if (field.field === 'location') {
            return {
                ...field,
                options: cityOptions,
            };
        }
        return field;
    });

    // kursus/upgrading
    const coursesDynamicMap = coursesDynamic.map(field => {
        if (field.field === 'type') {
            return {
                ...field,
                options: courseTypeOptions,
            };
        } else if (field.field === 'city') {
            return {
                ...field,
                options: cityOptions,
            };
        }
        return field;
    });

    // pengalaman kerja

    const workExperienceDynamicMap = workExperienceDynamic.map(field => {
        if (field.field === 'city') {
            return {
                ...field,
                options: cityOptions,
            };
        }
        return field;
    });

    // kehidupan organisasi
    const organizationsDynamicMap = organizationsDynamic.map(field => {
        if (field.field === 'memberCount') {
            return {
                ...field,
                options: organizationMemberCountOptions,
            };
        } else if (field.field === 'city') {
            return {
                ...field,
                options: cityOptions,
            };
        }
        return field;
    });


    // art
    const sportsDynamicMap = sportsDynamic.map(field => {
        if (field.field === 'sport') {
            return {
                ...field,
                options: sportOptions,
            };
        }
        return field;
    });

    // art
    const artDynamicMap = artDynamic.map(field => {
        if (field.field === 'art') {
            return {
                ...field,
                options: artOptions,
            };
        }
        return field;
    });


    const renderField = (
        name: keyof EmployeeFormData,
        label: string,
        type: string,
        placeholder: string,
        required: boolean,
        options?: { id: string | number; value: string; label: string }[],
        startIcon?: React.ReactNode,
        buttonDynamic?: string,
        dynamicColumns?: {
            header: string; field: string; type: string; placeholder: string; size: 'small' | 'medium'; hideLabel: boolean; fullWidth: boolean; options: any[]
        }[] //For dynamic table form
    ) => (
        <Box sx={{ mb: 2 }}>
            <Controller
                name={name as keyof IdentitasDiriInputs}
                control={control}
                defaultValue=""
                render={({ field }) =>
                    type === 'dropdown' ? (
                        <FieldComponent
                            {...field}
                            type="dropdown"
                            label={label}
                            name={name}
                            options={options || []}
                            placeholder={placeholder}
                            control={control}
                            size="small"
                            required={required}
                        />
                    ) : type === 'date' ? (
                        <FieldComponent
                            {...field}
                            type="date"
                            label={label}
                            name={name}
                            fullWidth
                            control={control}
                            size="small"
                            required={required}
                        />
                    ) : type === 'radio' ? (
                        <FieldComponent
                            {...field}
                            type="radio"
                            fieldLabel={label}
                            label={label}
                            name={name}
                            options={options || []}
                            control={control}
                            flex
                            required={required}
                        />
                    ) : type === 'checkbox' ? (
                        <FieldComponent
                            {...field}
                            type="checkbox"
                            fieldLabel={label}
                            label={label}
                            name={name}
                            options={options || []}
                            control={control}
                            flex
                            required={required}
                        />
                    ) : type === 'textarea' ? (
                        <FieldComponent
                            {...field}
                            label={label} name={name}
                            placeholder={placeholder}
                            fullWidth
                            type='textarea'
                            control={control}
                            required={required}
                        />
                    ) : type === 'dynamic' ? (
                        <HmDynamicForm
                            {...field}
                            label={label}
                            name={name}
                            required={required}
                            columns={dynamicColumns || []}
                            buttonText={buttonDynamic ?? 'Add'}
                            control={control}
                        />
                    ) : (
                        <FieldComponent
                            {...field}
                            label={label}
                            name={name}
                            placeholder={placeholder}
                            fullWidth
                            control={control}
                            required={required}
                            startIcon={startIcon}
                        />
                    )
                }
            />
        </Box>
    );

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Diri
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <HmTypography semiBold>
                        Foto Karyawan
                    </HmTypography>
                    <Controller
                        name="imageUrl"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                            <HmPhotoUploader
                                onFileUpload={(file) => {
                                    setUploadedImage(file);
                                    field.onChange(file?.name ?? '');
                                }}
                                initialPreview={uploadedImage ? URL.createObjectURL(uploadedImage) : undefined}
                                width="100px"
                                height="100px"
                                borderRadius="10%"
                            />
                        )}
                    />
                    <Grid container spacing={4} sx={{ mt: 2 }}>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.fullname' as keyof EmployeeFormData, 'Nama Lengkap', 'text', 'Masukkan nama lengkap', true,)}
                            {renderField('personalIdentity.placeOfBirth' as keyof EmployeeFormData, 'Tempat Lahir', 'dropdown', 'Masukkan tempat lahir', true, cityOptions)}
                            {renderField('personalIdentity.ethnicity' as keyof EmployeeFormData, 'Suku Bangsa', 'dropdown', 'Pilih suku bangsa', false, ethnicityOptions)}
                            {renderField('personalIdentity.bloodType' as keyof EmployeeFormData, 'Golongan Darah', 'dropdown', 'Pilih golongan darah', false, bloodTypeOptions)}
                            {renderField('personalIdentity.email' as keyof EmployeeFormData, 'Email', 'email', 'Masukkan email', true, [], <MdOutlineEmail size={17} />)}
                            {renderField('personalIdentity.emergencyContact.phoneNumber' as keyof EmployeeFormData, 'Kontak Darurat yang Dapat dihubungi', 'text', 'Masukkan kontak darurat', true, [], <React.Fragment><FiPhone size={17} style={{ marginRight: 3 }} /> +62</React.Fragment>)}
                            {renderField('personalIdentity.background' as keyof EmployeeFormData, 'Background (IT / Non IT)', 'radio', 'Pilih Background (IT / Non IT)', false, backgroundOptions)}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.gender' as keyof EmployeeFormData, 'Jenis Kelamin', 'dropdown', 'Pilih jenis kelamin', true, genderOptions)}
                            {renderField('personalIdentity.dateOfBirth' as keyof EmployeeFormData, 'Tanggal Lahir', 'date', 'Masukkan Tanggal Lahir', true,)}
                            {renderField('personalIdentity.religion' as keyof EmployeeFormData, 'Agama', 'dropdown', 'Pilih agama', true, religionOptions)}
                            {renderField('personalIdentity.maritalStatus' as keyof EmployeeFormData, 'Status Menikah', 'dropdown', 'Pilih status nikah', true, maritalStatusOptions)}
                            {renderField('personalIdentity.phoneNumber' as keyof EmployeeFormData, 'Nomor Telepon', 'number', 'Masukkan nomor telepon', true, [], <React.Fragment><FiPhone size={17} style={{ marginRight: 3 }} /> +62</React.Fragment>)}
                            {renderField('personalIdentity.emergencyContact.relationship' as keyof EmployeeFormData, 'Hubungan dengan Kontak Darurat', 'dropdown', 'Masukkan hubungan', true, emergencyContactRelationOptions)}
                            <HmTypography color={colors.palette.grey} semiBold fontSize={12} >
                                Kontak darurat bukan satu alamat dengan orangtua
                            </HmTypography>
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Alamat Rumah
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.homeAddress.fullAddress' as keyof EmployeeFormData, 'Alamat Lengkap', 'textarea', 'Masukkan alamat lengkap', true)}
                            {renderField('personalIdentity.homeAddress.city' as keyof EmployeeFormData, 'Kota/Kabupaten', 'dropdown', 'Pilih kota/kabupaten', true, cityOptions)}
                            {renderField('personalIdentity.homeAddress.district' as keyof EmployeeFormData, 'Kelurahan', 'dropdown', 'Pilih kelurahan', true, districtOptions)}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.homeAddress.province' as keyof EmployeeFormData, 'Provinsi', 'dropdown', 'Pilih provinsi', true, provinceOptions)}
                            {renderField('personalIdentity.homeAddress.subdistrict' as keyof EmployeeFormData, 'Kecamatan', 'dropdown', 'Pilih kecamatan', true, subdistrictOptions)}
                            {renderField('personalIdentity.homeAddress.postalCode' as keyof EmployeeFormData, 'Kode Pos', 'dropdown', 'Pilih kode pos', true, postalCodeOptions)}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Orang Tua (Ibu)
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.motherIdentity.name' as keyof EmployeeFormData, 'Nama Ibu', 'text', 'Masukkan nama ibu', true)}
                            {renderField('personalIdentity.motherIdentity.highestEducation' as keyof EmployeeFormData, 'Pendidikan Terakhir Ibu', 'dropdown', 'Pilih pendidikan ibu', true, educationOptions)}
                            {renderField('personalIdentity.motherIdentity.motherSalary' as keyof EmployeeFormData, 'Gaji Ibu', 'dropdown', 'Masukkan gaji ibu', true, rangeSalaryOptions)}
                            {renderField('personalIdentity.motherIdentity.statusAlive' as keyof EmployeeFormData, 'Status Hidup Ibu', 'radio', 'Pilih status', true, motherStatusOptions)}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.motherIdentity.dateOfBirth' as keyof EmployeeFormData, 'Tanggal Lahir  Ibu', 'date', 'Masukkan Tanggal Lahir ibu', true)}
                            {renderField('personalIdentity.motherIdentity.occupation' as keyof EmployeeFormData, 'Pekerjaan Ibu', 'text', 'Masukkan pekerjaan ibu', true)}
                            {renderField('personalIdentity.motherIdentity.phoneNumber' as keyof EmployeeFormData, 'Nomor Telepon Ibu', 'text', 'Masukkan nomor telepon ibu', true, [], <React.Fragment><FiPhone size={17} style={{ marginRight: 3 }} /> +62</React.Fragment>)}
                            {renderField('personalIdentity.motherIdentity.address' as keyof EmployeeFormData, 'Alamat Ibu', 'checkbox', 'Pilih status', true,
                                [
                                    { id: 1, value: 'Alamat Ibu sama seperti  Alamat rumah saya ', label: 'Alamat Ibu sama seperti  Alamat rumah saya ' },
                                ])}
                        </Grid>
                    </Grid>
                </Box>

                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Orang Tua (Ayah)
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.fatherIdentity.name' as keyof EmployeeFormData, 'Nama Ayah', 'text', 'Masukkan nama Ayah', true)}
                            {renderField('personalIdentity.fatherIdentity.highestEducation' as keyof EmployeeFormData, 'Pendidikan Terakhir Ayah', 'dropdown', 'Pilih pendidikan Ayah', true, educationOptions)}
                            {renderField('personalIdentity.fatherIdentity.salary' as keyof EmployeeFormData, 'Gaji Ayah', 'dropdown', 'Masukkan gaji Ayah', true, rangeSalaryOptions)}
                            {renderField('personalIdentity.fatherIdentity.statusAlive' as keyof EmployeeFormData, 'Status Hidup Ayah', 'radio', 'Pilih status', true, [
                                { id: 0, value: 'Ya', label: 'Ya' },
                                { id: 1, value: 'Tidak', label: 'Tidak' }
                            ])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.fatherIdentity.dateOfBirth' as keyof EmployeeFormData, 'Tanggal Lahir Ayah', 'date', 'Masukkan Tanggal Lahir Ayah', true)}
                            {renderField('personalIdentity.fatherIdentity.occupation' as keyof EmployeeFormData, 'Pekerjaan Ayah', 'text', 'Masukkan pekerjaan Ayah', true)}
                            {renderField('personalIdentity.fatherIdentity.phoneNumber' as keyof EmployeeFormData, 'Nomor Telepon Ayah', 'text', 'Masukkan nomor telepon Ayah', true, [], <React.Fragment><FiPhone size={17} style={{ marginRight: 3 }} /> +62</React.Fragment>)}
                            {renderField('personalIdentity.fatherIdentity.address' as keyof EmployeeFormData, 'Alamat Ayah', 'checkbox', 'Alamat Ayah sama seperti Alamat rumah saya', true, [
                                { id: 1, value: 'Alamat ayah sama seperti alamat Ibu', label: 'Alamat ayah sama seperti alamat Ibu' },
                                { id: 2, value: 'Alamat ayah sama seperti alamat Saya', label: 'Alamat ayah sama seperti alamat Saya' },
                            ])}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Identitas Suami/Istri
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.spouseIdentity.partnerName' as keyof EmployeeFormData, 'Nama Suami/Istri', 'text', 'Masukkan nama Suami/Istri', false)}
                            {renderField('personalIdentity.spouseIdentity.partnerHighestEducation' as keyof EmployeeFormData, 'Pendidikan Terakhir Suami/Istri', 'dropdown', 'Pilih pendidikan Suami/Istri', false, educationOptions)}
                            {renderField('personalIdentity.spouseIdentity.partnerSalary' as keyof EmployeeFormData, 'Gaji Suami/Istri', 'dropdown', 'Masukkan gaji Suami/Istri', true, rangeSalaryOptions)}
                            {renderField('personalIdentity.spouseIdentity.partnerAddress' as keyof EmployeeFormData, 'Alamat Suami/Istri', 'checkbox', 'Alamat Suami/Istri sama seperti Alamat rumah saya', true, [
                                { id: 1, value: 'Alamat Pasangan sama seperti rumah saya', label: 'Alamat Pasangan sama seperti rumah saya' },

                            ])}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('personalIdentity.spouseIdentity.partnerAge' as keyof EmployeeFormData, 'Tanggal Lahir Suami/Istri', 'date', 'Masukkan Tanggal Lahir Suami/Istri', false)}
                            {renderField('personalIdentity.spouseIdentity.partnerOccupation' as keyof EmployeeFormData, 'Pekerjaan Suami/Istri', 'text', 'Masukkan pekerjaan Suami/Istri', false)}
                            {renderField('personalIdentity.spouseIdentity.separateTax' as keyof EmployeeFormData, 'Status Pajak  Suami/Istri', 'checkbox', 'Masukkan Status Pajak Suami/Istri', false, [
                                { id: 1, value: 'Pasangan Pisah Pajak dengan saya', label: 'Pasangan Pisah Pajak dengan saya' },
                            ])}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
            </Box>
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Urutan Keluarga
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                <Grid container spacing={4}  >
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('personalIdentity.familyOrder.childNumber' as keyof EmployeeFormData, 'Saya anak ke?', 'text', 'Masukan anak ke berapa', true)}
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('personalIdentity.familyOrder.totalSiblings' as keyof EmployeeFormData, 'Dari Berapa bersaudara?', 'text', 'Masukan anak ke berapa', true)}
                    </Grid>
                </Grid>
                <Box>
                    {renderField('personalIdentity.siblings' as keyof EmployeeFormData, 'Saudara Kandung', 'dynamic', '', true, undefined, undefined, 'Tambah Saudara Kandung', siblingDynamicMap)}
                </Box>
                <Box sx={{ mt: 4 }}>
                    {renderField('personalIdentity.familyMembersInKk' as keyof EmployeeFormData, 'Anggota Keluarga dalam KK', 'dynamic', '', true, undefined, undefined, 'Tambah Anggota Keluarga', familyMembersDynamicMap)}
                </Box>
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Riwayat Pendidikan
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('personalIdentity.educationHistory' as keyof EmployeeFormData, 'Riwayat Pendidikan', 'dynamic', '', true, undefined, undefined, 'Tambah Riwayat Pendidikan', educationDynamicMap)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Kursus Atau Upgrading
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('personalIdentity.coursesOrUpgrading' as keyof EmployeeFormData, 'Kursus/Upgrading/Penataran yang telah diikuti', 'dynamic', '', false, undefined, undefined, 'Tambah Kursus/Upgrading', coursesDynamicMap)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Pengalaman Kerja
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('personalIdentity.workExperience' as keyof EmployeeFormData, 'Pengalaman Kerja', 'dynamic', '', false, undefined, undefined, 'Tambah Pengalaman Kerja', workExperienceDynamicMap)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Kehidupan berorganisasi
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('personalIdentity.organizationalLife' as keyof EmployeeFormData, 'Kehidupan berorganisasi/Kemasyarakatan', 'dynamic', '', false, undefined, undefined, 'Tambah Organisasi', organizationsDynamicMap)}
            </Box>
            <HmDivider />
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Olahraga
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('personalIdentity.sports' as keyof EmployeeFormData, 'Olahraga Yang disukai', 'dynamic', '', false, undefined, undefined, 'Tambah Olahraga', sportsDynamicMap)}
            </Box>
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Kesenian
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                {renderField('personalIdentity.art' as keyof EmployeeFormData, 'Kesenian Yang disukai', 'dynamic', '', false, undefined, undefined, 'Tambah kesenian', artDynamicMap)}
            </Box>
            <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                Lainnya
            </HmTypography>
            <Box sx={{ px: 2, mt: 2 }}>
                <Grid container spacing={4}>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('personalIdentity.other[0].foreignLanguageProficiency' as keyof EmployeeFormData, 'Penguasaan Bahasa Asing', 'dropdown', 'Masukkan Bahasa asing Anda', true, foreignLanguageProficiencyOptions)}
                        {renderField('personalIdentity.other[0].hobbies' as keyof EmployeeFormData, 'Hobi', 'text', 'Masukkan Hobby Anda', true)}
                        <HmTypography color={colors.palette.grey} semiBold fontSize={12} >
                            Contoh Jawaban: Musik, Basket, Nonton Film
                        </HmTypography>
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                        {renderField('personalIdentity.other[0].careerInterests' as keyof EmployeeFormData, 'Minat karir', 'text', 'Masukkan Minat karir Anda', true)}
                    </Grid>
                </Grid>
            </Box>
        </Box >
    );
}

export default ScFormIdentitasDiri;
