// Steps
export const steps = [
    { id: 'step-1', label: 'Identitas Diri' },
    { id: 'step-2', label: 'Informasi Kontrak' },
    { id: 'step-3', label: 'Data Kependudukan' },
    { id: 'step-4', label: 'Unggah Dokumen' },
];

// interface form input data
// identitas diri
export interface IdentitasDiriInputs {
  imageUrl: string;
  fullname: string;
  gender: string;
  placeOfBirth: string;
  dateOfBirth: string;
  ethnicity: string;
  religion: string;
  bloodType: string;
  maritalStatus: string;
  email: string;
  phoneNumber: string;
  emergencyContact: {
    name: string;
    phoneNumber: string;
    relationship: string;
  };
  background: string;
  homeAddress: {
    fullAddress: string;
    province: string;
    city: string;
    district: string;
    subdistrict: string;
    postalCode: string;
  };
  motherIdentity: {
    name: string;
    dateOfBirth: string;
    highestEducation: string;
    occupation: string;
    motherSalary: string;
    phoneNumber: string;
    statusAlive: string;
    address: number;
  };
  fatherIdentity: {
    name: string;
    dateOfBirth: string;
    highestEducation: string;
    occupation: string;
    salary: string;
    phoneNumber: string;
    statusAlive: string;
    address: number;
    province: string;
    city: string;
    district: string;
    subdistrict: string;
    postalCode: string;
  };
  spouseIdentity: {
    partnerName: string;
    partnerAge: string;
    partnerHighestEducation: string;
    partnerOccupation: string;
    partnerSalary: string;
    separateTax: string;
    partnerAddress: number;
  };
  familyOrder: {
    childNumber: number;
    totalSiblings: number;
  };
  siblings: Array<{
    gender: string;
    dateOfBirth: string;
    occupation: string;
    educationLevel: string;
  }>;
  familyMembersInKk: Array<{
    gender: string;
    dateOfBirth: string;
    occupation: string;
    education: string;
    graduationYear: number;
  }>;
  educationHistory: Array<{
    jenjang: string;
    institutionName: string;
    location: string;
    startDate: string;
    major : string
    endDate: string;
  }>;
  coursesOrUpgrading: Array<{ 
    type: string;
    courseName: string;
    city: string;
    date: string;
    month: string;
    year: number;
    durationMonths: number;
    institution: string;
    certificateNumber: string;
  }>;
  workExperience: Array<{
    companyName: string;
    position: string;
    city: string;
    startYear: number;
    endYear: number;
    durationMonths: number;
  }>;
  organizationalLife: Array<{
    organizationName: string;
    yearInPosition: string;
    position: string;
    memberCount: number;
    city: string;
    durationMonths: number;
  }>;
  sports: Array<{
    sport: string;
    activePassive: string;
  }>;
  art: Array<{
    art: string;
    activePassive: string;
  }>;
  other: Array<{
    foreignLanguageProficiency: string;
    hobbies: string; 
    careerInterests: string;
  }>;
}

export interface KontrakInputs {
  statusId: string;
  placementTypeId: string;
  employeeTypeId: string;
  willingToBePlacedInBankOrInsurance: string;
  divisionId: string;
  jobPositionId: string;
  contractStartDate: string;
  contractEndDate: string;
  contractDocument: {
    documentName: string;
    documentUrl: string;
  };
  generation: string;
  baseSalary: number;
  allowances: {
    placementAllowances: Array<{
      typeId: string;
      amount: number;
    }>;
    otherAllowances: Array<{
      typeId: string;
      amount: number;
    }>;
  };
} 

export interface DataKependudukanInputs {
  nik: string;
  npwp: string;
  ptkpStatus: string;
  bpjsNumber: string;
  bpjsClass: string;
  employmentBpjsNumber: string;
  bankId: string;
  accountNumber: string;
}

export interface UnggahDokumenInputs {
  documentEmployee: Array<{
    documentType: string;
    documentId: string;
    documentName: string;
    documentUrl: string;
  }>;
  socialMedia: Array<{
    socialMediaType: string;
    socialMediaLink: string;
  }>;
}


export interface EmployeeFormData {
  personalIdentity: IdentitasDiriInputs;
  contractInformation: KontrakInputs;
  healthAndFinance: DataKependudukanInputs;
  documents: UnggahDokumenInputs;
}

export const initialDefaultValues : EmployeeFormData = {
  personalIdentity: {
    imageUrl: '',
    fullname: '',
    gender: '',
    placeOfBirth: '',
    dateOfBirth: '',
    ethnicity: '',
    religion: '',
    bloodType: '',
    maritalStatus: '',
    email: '',
    phoneNumber: '',
    emergencyContact: {
      name: '',
      phoneNumber: '',
      relationship: ''
    },
    background: '',
    homeAddress: {
      fullAddress: '',
      province: '',
      city: '',
      district: '',
      subdistrict: '',
      postalCode: ''
    },
    motherIdentity: {
      name: '',
      dateOfBirth: '',
      highestEducation: '',
      occupation: '',
      motherSalary: '',
      phoneNumber: '',
      statusAlive: '',
      address: 0,
    },
    fatherIdentity: {
      name: '',
      dateOfBirth: '',
      highestEducation: '',
      occupation: '',
      salary: '',
      phoneNumber: '',
      statusAlive: '',
      address: 0,
      province: '',
      city: '',
      district: '',
      subdistrict: '',
      postalCode: ''
    },
    spouseIdentity: {
      partnerName: '',
      partnerAge: '',
      partnerHighestEducation: '',
      partnerOccupation: '',
      partnerSalary: '',
      separateTax: '',
      partnerAddress: 0
    },
    familyOrder: {
      childNumber: 0,
      totalSiblings: 0
    },
    siblings: [],
    familyMembersInKk: [],
    educationHistory: [],
    coursesOrUpgrading: [],
    workExperience: [],
    organizationalLife: [],
    sports: [],
    art: [],
    other: [],
  },
  contractInformation: {
    statusId: '',
    placementTypeId: '',
    employeeTypeId: '',
    willingToBePlacedInBankOrInsurance: '',
    divisionId: '',
    jobPositionId: '',
    contractStartDate: '',
    contractEndDate: '',
    contractDocument: {
      documentName: '',
      documentUrl: ''
    },
    generation: '',
    baseSalary: 0,
    allowances: {
      placementAllowances: [],
      otherAllowances: []
    }
  },
  healthAndFinance: {
    nik: '',
    npwp: '',
    ptkpStatus: '',
    bpjsNumber: '',
    bpjsClass: '',
    employmentBpjsNumber: '',
    bankId: '',
    accountNumber: ''
  },
  documents: {
    documentEmployee: [],
    socialMedia: []
  }
};



export const birthPlaceOptions = [
  { id: 'Jakarta', value: 'Jakarta', label: 'Jakarta' },
  { id: 'Surabaya', value: 'Surabaya', label: 'Surabaya' },
  { id: 'Bandung', value: 'Bandung', label: 'Bandung' },
  { id: 'Lain-lain', value: 'Lain-lain', label: 'Lain-lain' }
];

export const ethnicityOptions = [
  { id: 1, value: 'Jawa', label: 'Jawa' },
  { id: 2, value: 'Sunda', label: 'Sunda' },
  { id: 3, value: 'Melayu', label: 'Melayu' },
  { id: 4, value: 'Batak', label: 'Batak' },
  { id: 5, value: 'Lain-lain', label: 'Lain-lain' }
];

export const bloodTypeOptions = [
  { id: 1, value: 'A', label: 'A' },
  { id: 2, value: 'B', label: 'B' },
  { id: 3, value: 'AB', label: 'AB' },
  { id: 4, value: 'O', label: 'O' }
];

export const backgroundOptions = [
  { id: 1, value: 'IT', label: 'IT' },
  { id: 2, value: 'Non-IT', label: 'Non-IT' }
];

export const genderOptions = [
  { id: "M", value: 'Laki-laki', label: 'Laki-laki' },
  { id: "F", value: 'Perempuan', label: 'Perempuan' }
];

export const religionOptions = [
  { id: 1, value: 'Islam', label: 'Islam' },
  { id: 2, value: 'Kristen', label: 'Kristen' },
  { id: 3, value: 'Katolik', label: 'Katolik' },
  { id: 4, value: 'Hindu', label: 'Hindu' },
  { id: 5, value: 'Buddha', label: 'Buddha' },
  { id: 6, value: 'Konghucu', label: 'Konghucu' }
];

export const maritalStatusOptions = [
  { id: 1, value: 'Belum Menikah', label: 'Belum Menikah' },
  { id: 2, value: 'Menikah', label: 'Menikah' },
  { id: 3, value: 'Cerai', label: 'Cerai' }
];

export const cityOptions = [
  { id: 1, value: 'Jakarta', label: 'Jakarta' },
  { id: 2, value: 'Surabaya', label: 'Surabaya' }
];

export const districtOptions = [
  { id: 1, value: 'Kelurahan 1', label: 'Kelurahan 1' },
  { id: 2, value: 'Kelurahan 2', label: 'Kelurahan 2' }
];

export const provinceOptions = [
  { id: 1, value: 'Jawa Barat', label: 'Jawa Barat' },
  { id: 2, value: 'Jawa Tengah', label: 'Jawa Tengah' }
];

export const subdistrictOptions = [
  { id: 1, value: 'Kecamatan 1', label: 'Kecamatan 1' },
  { id: 2, value: 'Kecamatan 2', label: 'Kecamatan 2' }
];

export const postalCodeOptions = [
  { id: 1, value: '12345', label: '12345' },
  { id: 2, value: '67890', label: '67890' }
];

export const educationOptions = [
  { id: 1, value: 'SD', label: 'SD' },
  { id: 2, value: 'SMP', label: 'SMP' },
  { id: 3, value: 'SMA', label: 'SMA' },
  { id: 4, value: 'D3', label: 'D3' },
  { id: 5, value: 'S1', label: 'S1' },
  { id: 6, value: 'S2', label: 'S2' },
  { id: 7, value: 'S3', label: 'S3' }
];

export const motherStatusOptions = [
  { id: 1, value: 'Ya', label: 'Ya' },
  { id: 0, value: 'Tidak', label: 'Tidak' }
];

export const jenisKelaminOptions = [
  { id: 1, value: 'Laki-laki' },
  { id: 2, value: 'Perempuan' },
];

export const pendidikanTerakhirOptions = [
  { id: 1, value: 'SD' },
  { id: 2, value: 'SMP' },
  { id: 3, value: 'SMA' },
  { id: 4, value: 'Diploma' },
  { id: 5, value: 'Sarjana' },
];

export const jabatanOptions = [
  { id: 1, value: 'Manager' },
  { id: 2, value: 'Supervisor' },
  { id: 3, value: 'Staff' },
];

// dynamic table form
type DynamicField = {
  header: string; field: string; type: string; placeholder: string; size: 'small' | 'medium'; hideLabel: boolean; fullWidth: boolean; options: any[];
};
export const siblingDynamic: DynamicField[] = [
  {
    header: 'Jenis Kelamin',
    field: 'gender',
    type: 'dropdown',
    placeholder: 'Jenis Kelamin',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Laki-laki' },
      { id: 2, value: 'Perempuan' },
    ],
  },
  {
    header: 'Tanggal Lahir',
    field: 'dateOfBirth',
    type: 'date',
    placeholder: 'Tanggal Lahir',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Pekerjaan',
    field: 'occupation',
    type: 'textfield',
    placeholder: 'Pekerjaan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Pendidikan Terakhir',
    field: 'educationLevel',
    type: 'dropdown',
    placeholder: 'Pendidikan Terakhir',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'SD' },
      { id: 2, value: 'SMP' },
      { id: 3, value: 'SMA' },
      { id: 4, value: 'Diploma' },
      { id: 5, value: 'Sarjana' },
    ],
  },
];


export const familyMembersDynamic: DynamicField[] = [
  {
    header: 'Jenis Kelamin',
    field: 'gender',
    type: 'dropdown',
    placeholder: 'Jenis Kelamin',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Perempuan' },
      { id: 2, value: 'Laki-laki' }, 
    ],
  },
  {
    header: 'Tanggal Lahir',
    field: 'dateOfBirth',
    type: 'date',
    placeholder: 'Tanggal Lahir',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Pekerjaan',
    field: 'occupation',
    type: 'textfield',
    placeholder: 'Pekerjaan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Pendidikan Terakhir',
    field: 'education',
    type: 'dropdown',
    placeholder: 'Pendidikan Terakhir',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'SD' },
      { id: 2, value: 'SMP' },
      { id: 3, value: 'SMA' },
      { id: 4, value: 'Diploma' },
      { id: 5, value: 'Sarjana' },
    ],
  },
  {
    header: 'Tahun Lulus',
    field: 'graduationYear',
    type: 'textfield',
    placeholder: 'Tahun Lulus',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
];


export const educationDynamic: DynamicField[] = [
  {
    header: 'Nama Sekolah',
    field: 'institutionName',
    type: 'textfield',
    placeholder: 'Nama Sekolah',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Jenjang',
    field: 'jenjang',
    type: 'dropdown',
    placeholder: 'Pilih Jenjang',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'SD' },
      { id: 2, value: 'SMP' },
      { id: 3, value: 'SMA' },
      { id: 4, value: 'D3' },
      { id: 5, value: 'S1' },
      { id: 6, value: 'S2' },
      { id: 7, value: 'S3' },
    ],
  },
  {
    header: 'Jurusan',
    field: 'major',
    type: 'dropdown',
    placeholder: 'Pilih Jurusan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Informatika' },
      { id: 2, value: 'Sistem Informasi' },
     
    ],
  },
  {
    header: 'Kota Asal',
    field: 'location',
    type: 'dropdown',
    placeholder: 'Pilih Kota Asal',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Bandung' },
      { id: 2, value: 'Jakarta' },
     
    ]
  },
  {
    header: 'Tahun Masuk',
    field: 'startDate',
    type: 'textfield',
    placeholder: 'Tahun Masuk',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Tahun Lulus',
    field: 'endDate',
    type: 'textfield',
    placeholder: 'Tahun Lulus',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
];

export const coursesDynamic: DynamicField[] = [
  {
    header: 'Jenis',
    field: 'type',
    type: 'dropdown',
    placeholder: 'Pilih Jenis',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Coding' },
      { id: 2, value: 'Entertainment' },
    ]
  },
  {
    header: 'Nama Kursus',
    field: 'courseName',
    type: 'textfield',
    placeholder: 'Nama Kursus',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Tempat(KOTA)',
    field: 'city',
    type: 'dropdown',
    placeholder: 'Pilih Kota',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Bandung' },
      { id: 2, value: 'Jakarta' },
    ]
  },
  {
    header: 'Tanggal',
    field: 'date',
    type: 'textfield',
    placeholder: 'Tanggal',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Bulan',
    field: 'month',
    type: 'textfield',
    placeholder: 'Bulan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Tahun',
    field: 'year',
    type: 'textfield',
    placeholder: 'Tahun',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Lamanya (Bulan)',
    field: 'durationMonths',
    type: 'textfield',
    placeholder: 'Lamanya (Bulan)',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Instansi',
    field: 'institution',
    type: 'textfield',
    placeholder: 'Instansi',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'No Sertifikat',
    field: 'certificateNumber',
    type: 'textfield',
    placeholder: 'No Sertifikat',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
];

export const workExperienceDynamic: DynamicField[] = [
  {
    header: 'Nama Instansi',
    field: 'companyName',
    type: 'textfield',
    placeholder: 'Nama Instansi',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Jabatan',
    field: 'position',
    type: 'textfield',
    placeholder: 'Jabatan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Tempat(KOTA)',
    field: 'city',
    type: 'dropdown',
    placeholder: 'Tempat (Kota)',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Bandung' },
      { id: 2, value: 'Jakarta' },
    ]
  },
  {
    header: 'Tahun Mulai',
    field: 'startYear',
    type: 'textfield',
    placeholder: 'Tahun Mulai',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Tahun Selesai',
    field: 'endYear',
    type: 'textfield',
    placeholder: 'Tahun Selesai',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Lamanya (Bulan)',
    field: 'durationMonths',
    type: 'textfield',
    placeholder: 'Lamanya (Bulan)',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
];

export const organizationsDynamic: DynamicField[] = [
  {
    header: 'Nama Organisasi',
    field: 'organizationName',
    type: 'textfield',
    placeholder: 'Nama Organisasi',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Tahun Menjabat',
    field: 'yearInPosition',
    type: 'textfield',
    placeholder: 'Tahun Menjabat',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Jabatan',
    field: 'position',
    type: 'textfield',
    placeholder: 'Jabatan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
  {
    header: 'Jumlah Anggota',
    field: 'memberCount',
    type: 'dropdown',
    placeholder: 'Jumlah Anggota',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: '10-15', value: '10-15' },
      { id: '20-50', value: '20-50' },
    ]
  },
  {
    header: 'Tempat(KOTA)',
    field: 'city',
    type: 'dropdown',
    placeholder: 'Tempat (Kota)',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Bandung' },
      { id: 2, value: 'Jakarta' },
    ]
  },
  {
    header: 'Lamanya (Bulan)',
    field: 'durationMonths',
    type: 'textfield',
    placeholder: 'Lamanya (Bulan)',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
];

export const sportsDynamic: DynamicField[] = [
  {
    header: 'Jenis Olahraga',
    field: 'sport',
    type: 'dropdown',
    placeholder: 'Jenis Olahraga',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Renang', label: 'Renang' },
      { id: 2, value: 'Sepak bola', label: 'Sepak bola' }
    ],
  },
  {
    header: 'Status Olahraga',
    field: 'activePassive',
    type: 'radio',
    placeholder: 'Status Olahraga',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Aktif', label: 'Aktif' },
      { id: 2, value: 'Pasif', label: 'Pasif' }
    ],
  },
];


export const artDynamic: DynamicField[] = [
  {
    header: 'Jenis Kesenian',
    field: 'art',
    type: 'dropdown',
    placeholder: 'Jenis Kesenian',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Design', label: 'Design' },
      { id: 2, value: 'Photography', label: 'Photography' }
    ], 
  },
  {
    header: 'Status Kesenian',
    field: 'activePassive',
    type: 'radio',
    placeholder: 'Status Kesenian',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Aktif', label: 'Aktif' },
      { id: 2, value: 'Pasif', label: 'Pasif' }
    ], 
  },
];

export const tunjanganPenempatanDynamic: DynamicField[] = [
  {
    header: 'Jenis Tunjangan',
    field: 'Jenis',
    type: 'dropdown',
    placeholder: 'Pilih Jenis Tunjangan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Tunjangan Bandung', label: 'Tunjangan Bandung' },
      { id: 2, value: 'Tunjangan Jakarta', label: 'Tunjangan Jakarta' },
      { id: 3, value: 'Tunjangan Hybrid', label: 'Tunjangan Hybrid' }
    ],
  },
  {
    header: 'Nominal',
    field: 'Nominal',
    type: 'radiobutton',
    placeholder: 'Nominal',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [], 
  },
];
export const tunjanganLainLainDynamic: DynamicField[] = [
  {
    header: 'Jenis Tunjangan',
    field: 'Jenis',
    type: 'dropdown',
    placeholder: 'Pilih Jenis Tunjangan',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Tunjangan Bandung', label: 'Tunjangan Bandung' },
      { id: 2, value: 'Tunjangan Jakarta', label: 'Tunjangan Jakarta' },
      { id: 3, value: 'Tunjangan Hybrid', label: 'Tunjangan Hybrid' }
    ],
  },
  {
    header: 'Nominal',
    field: 'Nominal',
    type: 'radiobutton',
    placeholder: 'Nominal',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [], 
  },
];


export const documentEmployeeDynamic: DynamicField[] = [
  {
    header: 'Type ',
    field: 'documentType',
    type: 'dropdown',
    placeholder: 'Pilih jenis dokumen',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'CV' },
      { id: 2, value: 'NPWP' },
    ],
  },
  {
    header: 'Dokumen',
    field: 'document',
    type: 'Text',
    placeholder: 'Dokumen',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
];


export const socialMediaDynamic: DynamicField[] = [
  {
    header: 'Social Media',
    field: 'socialMediaType',
    type: 'dropdown',
    placeholder: 'Pilih Social Media',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [
      { id: 1, value: 'Linked in' },
      { id: 2, value: 'X' },
      { id: 4, value: 'Tiktok' },
    ],
  },
  
  {
    header: 'Link Sosmed',
    field: 'socialMediaLink',
    type: 'textfield',
    placeholder: 'Pilih Jenis social media',
    size: 'small',
    hideLabel: true,
    fullWidth: true,
    options: [],
  },
 
];

export const foreignLanguageProficiencyOptions = [
    { id: 1, value: 'English', label: ' English' },
    { id: 2, value: 'German', label: ' German' },
];

export const stateContractOptions = [
    { id: 1, value: 'Fulltime', label: 'Karyawan Fulltime' },
    { id: 2, value: 'Kontrak', label: 'Karyawan Kontrak' },
    { id: 3, value: 'Internship', label: 'Internship' },
];
export const emergencyContactRelation = [
    { id: 1, value: 'Tetangga', label: 'Tetangga' },
    { id: 2, value: 'Other', label: 'Other' },
   
];

export const employeeTypeOptions = [
    { id: 1, value: 'Talent', label: 'Talent' },
    { id: 2, value: 'Hc', label: 'Hc' },
];
export const divisiOptions = [
    { id: 1, value: 'KTI', label: 'KTI' },
    { id: 2, value: 'Talent', label: 'Talent' },
    { id: 3, value: 'Bizdev', label: 'Bizdev' },
];
export const generationOptions = [
    { id: 1, value: 'JTK', label: 'JTK' },
    { id: 2, value: 'KT', label: 'KT' },
];

export const placementTypeOptions = [
    { id: 1, value: 'Bandung', label: 'Bandung' },
    { id: 2, value: 'Jakarta', label: 'Jakarta' },
];
export const bankPlacementOptions = [
    { id: 1, value: 'Bersedia', label: 'Bersedia' },
    { id: 2, value: 'Tidak Bersedia', label: 'Tidak Bersedia' },
];
export const jobPositionOption = [
    { id: 1, value: 'UI/UX Designer', label: 'UI/UX Designer' },
    { id: 2, value: 'FrontEnd', label: 'FrontEnd' },
];

export const statusPtkpOptions = [
    { id: 1, value: 'Sudah Menikah (K/1)', label: 'Sudah Menikah (K/1)' },
    { id: 2, value: 'Sudah Menikah (K/2)', label: 'Sudah Menikah (K/2)' },
  
];

export const rangeSalaryOptions = [
    { id: 1, value: '1-3 juta', label: '1-3 juta' },
    { id: 2, value: '3-5 juta', label: '3-5 juta' },
    { id: 3, value: '5-7 juta', label: '5-7 juta' },
    { id: 4, value: '7-10 juta', label: '7-10 juta' },
    { id: 5, value: '10 juta ke atas', label: '10 juta ke atas' },
];

export const kelasBpjsOptions = [
    { id: 1, value: 'Kelas 1', label: 'Kelas 1' },
    { id: 2, value: 'Kelas 2', label: 'Kelas 2' },
  
];
export const bankNameOptions = [
    { id: 1, value: 'Mandiri', label: 'Mandiri' },
    { id: 2, value: 'BRI', label: 'BRI' },
    { id: 3, value: 'BNI', label: 'BNI' },
];

