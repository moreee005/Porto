import * as yup from 'yup';

// identitas diri
export const identitasDiriSchema = yup.object().shape({
personalIdentity: yup.object().shape({
//   imageUrl: yup.string().required('Image URL is required'),
  fullname: yup.string()
    .required('Nama Lengkap is required')
    .matches(/^[a-zA-Z\s]*$/, 'Nama Lengkap is not valid')
    .min(3, 'Nama Lengkap must be at least 3 characters'),
  gender: yup.string().required('Jenis Kelamin is required'),
  placeOfBirth: yup.string()
    .required('Tempat Lahir is required'),
  dateOfBirth: yup.date().nullable()
    .typeError('Date is not invalid')
    .required('Tanggal Lahir is required') 
    .max(new Date(), 'Tanggal Lahir cannot be in the future'),
//   ethnicity: yup.string()
//     .required('Suku Bangsa is required'),
  religion: yup.string().required('Agama is required'),
//   bloodType: yup.string().required('Golongan Darah is required'),
  maritalStatus: yup.string().required('Status Nikah is required'),
  email: yup.string()
    .email('Invalid email format')
    .required('Email is required')
    .matches(/@.*\.com$/, 'Email must end with .com'),
  phoneNumber: yup.string()
    .required('Nomor Telepon is required')
    .matches(/^8\d{9,}$/, 'Nomor Telepon format is not valid')
    .min(9, 'Nomor Telepon must be at least 9 digits')
    .max(12, 'Nomor Telepon must be at most 12 digits'),
  emergencyContact: yup.object().shape({
    phoneNumber: yup.string()
    .required('Kontak Darurat is required')
    .matches(/^8\d{9,}$/, 'Kontak Darurat format is not valid')
    .min(9, 'Kontak Darurat must be at least 9 digits')
    .max(12, 'Kontak Darurat must be at most 12 digits'),
    relationship: yup.string().required('Hubungan dengan Kontak Darurat is required'),
  }),
//   background: yup.string().required('Background is required'),
  homeAddress: yup.object().shape({
    fullAddress: yup.string()
      .required('Alamat Lengkap is required')
      .min(10, 'Address must be at least 10 characters')
      .max(255, 'Address must not exceed 255 characters'),
    province: yup.string().required('Provinsi is required'),
    city: yup.string().required('Kota/Kabupaten is required'),
    district: yup.string().required('Kelurahan is required'),
    subdistrict: yup.string().required('Kecamatan is required'),
    postalCode: yup.string()
      .required('Kode Pos is required')
    //   .matches(/^[0-9]+$/, 'Kode Pos must be numeric')
    //   .min(5, 'Kode Pos must be at least 5 digits'),
  }),
  motherIdentity: yup.object().shape({
    name: yup.string().required('Nama Ibu is required'),
    dateOfBirth: yup.date().nullable()
      .typeError('Date is not invalid')
      .required('Tanggal Lahir Ibu is required')
      .max(new Date(), 'Tanggal Lahir Ibu cannot be in the future'),
    highestEducation: yup.string().required('Pendidikan Terakhir Ibu is required'),
    occupation: yup.string().required('Pekerjaan Ibu is required'),
    motherSalary: yup.number()
      .typeError('Gaji Ibu must be a number')
      .required('Gaji Ibu is required')
      .min(0, 'Gaji Ibu must be a positive number'),
    phoneNumber: yup.string()
      .required('Nomor Telepon Ibu is required')
      .matches(/^8\d{9,}$/, 'Nomor Telepon Ibu format is not valid')
      .min(9, 'Nomor Telepon Ibu must be at least 9 digits')
      .max(12, 'Nomor Telepon Ibu must be at most 12 digits'),
    statusAlive: yup.string().required('Status Hidup Ibu is required'),
    address: yup.number()
      .typeError('Alamat Ibu must be a number')
      .required('Alamat Ibu is required')
      .test('Alamat Ibu Required', 'Alamat Ibu is required', (value) => value !== 0 || (value === null && !yup.array().of(yup.number()).isValidSync([]))),
  }),
  fatherIdentity: yup.object().shape({
    name: yup.string().required('Nama Ayah is required'),
    dateOfBirth: yup.date().nullable()
      .typeError('Date is not invalid')
      .required('Tanggal Lahir Ayah is required')
      .max(new Date(), 'Tanggal Lahir Ayah cannot be in the future'),
    highestEducation: yup.string().required('Pendidikan Terakhir Ayah is required'),
    occupation: yup.string().required('Pekerjaan Ayah is required'),
    salary: yup.number()
      .typeError('Gaji Ayah must be a number')
      .required('Gaji Ayah is required')
      .min(0, 'Gaji Ayah must be a positive number'),
    phoneNumber: yup.string()
      .required('Nomor Telepon Ayah is required')
      .matches(/^[0-9]+$/, 'Nomor Telepon Ayah must be numeric')
      .min(10, 'Nomor Telepon Ayah must be at least 10 digits'),
    statusAlive: yup.string().required('Status Hidup Ayah is required'),
    address: yup.number()
      .typeError('Alamat ayah must be a number')
      .required('Alamat ayah is required')
      .test('alamat ayah Required', 'Alamat ayah is required', (value) => value !== 0 || (value === null && !yup.array().of(yup.number()).isValidSync([]))),
  
  }),
  spouseIdentity: yup.object().shape({
    partnerSalary: yup.number()
      .typeError('Gaji Suami/Istri must be a number')
      .required('Gaji Suami/Istri is required')
      .min(0, 'Gaji Suami/Istri must be a positive number'),
  //  partnerAge: yup.date().nullable()
  //     .max(new Date(), 'Tanggal Lahir Ayah cannot be in the future')
  //     .optional(),
    // separateTax: yup.string().required('Pisah Pajak is required'),
    partnerAddress: yup.number()
      .typeError('Partner Address must be a number')
      .required('Partner Address is required')
      .test('partnerAddressRequired', 'Partner Address is required', (value) => value !== 0 || (value === null && !yup.array().of(yup.number()).isValidSync([]))),
  }),
  familyOrder: yup.object().shape({
    childNumber: yup.number()
      .typeError('Saya anak ke must be a number')
      .required('Saya anak ke is required')
      .positive('Saya anak ke must be a positive number')
      .max(20, 'Saya anak ke must be less than or equal to 20'),
    totalSiblings: yup.number()
      .typeError('Dari berapa bersaudara must be a number')
      .required('Dari berapa bersaudara is required')
      .positive('Dari berapa bersaudara must be a positive number')
      .max(20, 'Dari berapa bersaudara must be less than or equal to 20'),
  }),


  siblings: yup.array().of(
    yup.object().shape({
      gender: yup.string().required('Gender is required'),
      dateOfBirth: yup.date()
        .typeError('Date is not invalid')
        .required('Birth Date is required')
        .max(new Date(), 'Birth Date cannot be in the future'),
      occupation: yup.string().required('Occupation is required'),
      educationLevel: yup.string().required('Education Level is required'),
    })
  ).min(1, 'At least one saudara kandung is required'),
  familyMembersInKk: yup.array().of(
    yup.object().shape({
      gender: yup.string().required('Gender is required'),
      dateOfBirth: yup.date()
        .typeError('Date is not invalid')
        .required('Birth Date is required')
        .max(new Date(), 'Birth Date cannot be in the future'),
      occupation: yup.string().required('Occupation is required'),
      education: yup.string().required('Education is required'),
      graduationYear: yup.number()
        .required('Year Joined is required')
        .integer('Year Joined harus berupa tahun 4 angka')
        .min(1900, 'Year Joined harus lebih besar dari 1900')
        .max(new Date().getFullYear(), 'Year Joined harus lebih kecil dari tahun sekarang'),
            
    })
  ).min(1, 'At least one anggota keluarga dalam KK is required'),
  educationHistory: yup.array().of(
    yup.object().shape({
      jenjang: yup.string().required('Jenjang is required'),
      institutionName: yup.string().required('Institution Name is required'),
      location: yup.string().required('Location is required'),
      startDate: yup.string()
        .required('Start Date is required')
        .matches(/^\d{4}$/, 'Start Date harus berupa tahun 4 angka'),
      major: yup.string().required('Major is required'),
      endDate: yup.string()
        .required('End Date is required')
        .matches(/^\d{4}$/, 'End Date harus berupa tahun 4 angka'),
    })
  ).min(1, 'At least one riwayat pendidikan is required'),
 
  
  other: yup.array().of(
    yup.object().shape({
      foreignLanguageProficiency: yup.string().required('Penguasaan Bahasa Asing is required'),
     hobbies: yup.string()
      .required('Hobi is required')
      .min(3, 'Hobbies must be at least 3 characters')
      .max(200, 'Hobbies must be at most 200 characters'),
    careerInterests: yup.string()
      .required('Minat karir is required')
      .min(3, 'Minat karir must be at least 3 characters')
      .max(200, 'Minat karir must be at most 200 characters'),
  })
  ).min(1, 'At least one entry in other is required'),

  } )
});


export const kontrakSchema = yup.object().shape({
    // data kontrak
    contractInformation: yup.object().shape({
        statusId :yup.string()
            .required('Status Kontrak is required'),
        placementTypeId :yup.string()
            .required('Jenis Penempatan is required'),
        employeeTypeId :yup.string()
            .required('Jenis Karyawan is required'),
        willingToBePlacedInBankOrInsurance :yup.string()
            .required('Bersedia ditempatkan di bank/insurance is required'),
        divisionId :yup.string()
            .required('Divisi is required'),
        jobPositionId :yup.string()
            .required('Jabatan is required'),
        contractStartDate :yup.date()
            .required('Tanggal mulai kontrak is required'),
        contractEndDate: yup.date()
            .required('Tanggal akhir Kontrak is required')
            .min(new Date(), 'Tanggal akhir Kontrak must be in the future'),
        contractDocument: yup.object().shape({
            documentName: yup.string().required('Document contract is required'),
            documentUrl: yup.string().optional(),
        }).required('Dokumen Kontrak is required'),
       generation: yup.string().nullable().max(10, 'Generasi cannot exceed 10 characters'),
       baseSalary: yup.number()
          .required('Gaji pokok is required')
          .max(99999999, 'Gaji pokok cannot exceed 8 digits')
          .positive('Gaji pokok must be a positive number')
          .typeError('Invalid input. Please enter a number.')
          .integer('Gaji pokok must be an integer')
          

    })
});

export const kependudukanSchema = yup.object().shape({
    // data kependudukan
    healthAndFinance: yup.object().shape({
        nik :yup.string()
            .required('Nik is required')
            .length(16, 'NIK must be 16 digits'),
        npwp: yup.string()
            .required('NPWP is required')
            .matches(/^\d{2}\.\d{3}\.\d{3}\.\d-\d{3}\.\d{3}$/, 'NPWP must be in the format XX.XXX.XXX.X-XXX.XXX'),
        ptkpStatus :yup.string()
            .required('Status PTKP is required'),
        bankId :yup.string()
            .required('Nama Bank is required'),
        accountNumber :yup.string()
            .required('Nomor Rekening required')
            .min(6, 'Nomor Rekening must be more than 5 digits'),
   })
});
 

export const unggahDokumenSchema = yup.object().shape({

    //unggah dokumen
    documents : yup.object().shape({
     documentEmployee: yup.array().of(
        yup.object().shape({
            // documentType: yup.string().required('Type Dokumen is required'),
            document: yup.string().required('dokumen is required'),
        })
    ).min(1, 'At least dokumen employee  is required'),

     socialMedia: yup.array().of(
        yup.object().shape({
            socialMediaType: yup.string().required('Social media is required'),
            socialMediaLink: yup.string()
            .required('Link Sosial Media is required')
            .url('Link Sosial Media harus berbentuk link yang valid')
        })
    ).min(1, 'At least social media is required'),

   })
});