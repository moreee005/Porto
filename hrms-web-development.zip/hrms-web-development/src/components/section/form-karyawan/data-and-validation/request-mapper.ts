import { calculateAge } from "@/utils/truncate";

interface RequestBody {
  personalIdentity: any;
  contractInformation: any;
  civilRegistrationData: any;
  documents: any;
}
const mapRequestBody = (formData: any): RequestBody => {
  return {
   // Mapping request 
        personalIdentity: {
          imageFileName: formData[3].personalIdentity.imageUrl || null,
          fullName: formData[3].personalIdentity.fullname || null,
          gender: formData[3].personalIdentity.gender == 1 ? 'M' : 'F',
          placeOfBirth: formData[3]?.personalIdentity?.placeOfBirth == 1 ? "Jakarta" : " Bandung",
          dateOfBirth: formData[3].personalIdentity.dateOfBirth || null,
          ethnicity: formData[3].personalIdentity.ethnicity || 1,
          religion: formData[3].personalIdentity.religion || null,
          bloodType: formData[3].personalIdentity.bloodType  || 1,
          maritalStatus: formData[3].personalIdentity.maritalStatus || null,
          email: formData[3].personalIdentity.email || null,
          phoneNumber: `+62${formData[3].personalIdentity.phoneNumber}` || null,
          emergencyContact: {
            name: formData[3].personalIdentity.emergencyContact?.name || "",
            phoneNumber: `+62${formData[3].personalIdentity.emergencyContact?.phoneNumber}` || null,
            relationship: formData[3].personalIdentity.emergencyContact?.relationship || 1,
          },
          background: formData[3].personalIdentity.background == 1 ? 'IT' : 'Non IT' ,
          homeAddress: {
            fullAddress: formData[3].personalIdentity.homeAddress?.fullAddress || null,
            geoId: formData[3].personalIdentity.homeAddress?.geoId || 31355,
            province: formData[3].personalIdentity.homeAddress?.province || null,
            city: formData[3].personalIdentity.homeAddress?.city || null,
            district: formData[3].personalIdentity.homeAddress?.district || null,
            subdistrict: formData[3].personalIdentity.homeAddress?.subdistrict || null,
            postalCode: formData[3].personalIdentity.homeAddress?.postalCode || null,
          },
          motherIdentity: {
            name: formData[3].personalIdentity.motherIdentity?.name || null,
            dateOfBirth: formData[3].personalIdentity.motherIdentity?.dateOfBirth || null,
            highestEducation: formData[3].personalIdentity.motherIdentity?.highestEducation || 1,
            occupation: formData[3].personalIdentity.motherIdentity?.occupation || null,
            salary: formData[3].personalIdentity.motherIdentity?.motherSalary || null,
            phoneNumber: `+62${formData[3].personalIdentity.motherIdentity?.phoneNumber}` || null,
            statusAlive: formData[3].personalIdentity.motherIdentity?.statusAlive === 1 ? true : false,
            address: formData[3].personalIdentity.motherIdentity?.address === 1 ? formData[3].personalIdentity.homeAddress?.fullAddress : "Jln. banda 323",
            geoId: formData[3].personalIdentity.motherIdentity?.geoId || 31355,
          },
          fatherIdentity: {
            name: formData[3].personalIdentity.fatherIdentity?.name || null,
            dateOfBirth: formData[3].personalIdentity.fatherIdentity?.dateOfBirth || null,
            highestEducation: formData[3].personalIdentity.fatherIdentity?.highestEducation || 1,
            occupation: formData[3].personalIdentity.fatherIdentity?.occupation || null,
            salary: formData[3].personalIdentity.fatherIdentity?.salary || 1,
            phoneNumber: `+62${formData[3].personalIdentity.fatherIdentity?.phoneNumber}` || null,
            statusAlive: formData[3].personalIdentity.fatherIdentity?.statusAlive === 1 ? true : false,
            address: formData[3].personalIdentity.fatherIdentity?.address  === 1 ? formData[3].motherIdentity.homeAddress?.address : formData[3].personalIdentity.homeAddress?.fullAddress || null,//CATATAN
            geoId: formData[3].personalIdentity.fatherIdentity?.geoId || 31355,
          },
          spouseIdentity: {
            partnerName: formData[3].personalIdentity.spouseIdentity?.partnerName || null,
            partnerDateOfBirth: formData[3].personalIdentity.spouseIdentity?.partnerAge || "",
            partnerHighestEducation: formData[3].personalIdentity.spouseIdentity?.partnerHighestEducation || 1,
            partnerOccupation: formData[3].personalIdentity.spouseIdentity?.partnerOccupation || null,
            salary: formData[3].personalIdentity.spouseIdentity?.salary || 1,
            separateTax: !!formData[3].personalIdentity.spouseIdentity?.separateTax,
            partnerAddress: formData[3].personalIdentity.spouseIdentity?.partnerAddress === 1 ? formData[3].personalIdentity.homeAddress?.fullAddress : "Jln. banda 323",//CATATAN
            geoId: formData[3].personalIdentity.spouseIdentity?.geoId || 31355,
          },
          familyOrder: {
            childNumber: formData[3].personalIdentity.familyOrder?.childNumber || 1,
            totalSiblings: formData[3].personalIdentity.familyOrder?.totalSiblings || 0,
          },
          siblings: formData[3].personalIdentity.siblings?.map((sibling: any) => ({
            gender: formData[3].personalIdentity.siblings?.gender == 1 ? "M" : "F",
            dateOfBirth: sibling.dateOfBirth || null,
            occupation: sibling.occupation || null,
            educationLevel: sibling.educationLevel || 1,
          })) || [],
          familyMembersInKk: formData[3].personalIdentity.familyMembersInKk?.map((member :any) => ({
            gender: member.gender == 1 ? "M" : "F",
            dateOfBirth: member.dateOfBirth || null,
            occupation: member.occupation || null,
            educationLevel: member.education || 1,
            graduationYear:  member.graduationYear || null,
          })) || [],
          educationHistory: formData[3].personalIdentity.educationHistory?.map((education :any) => ({
            institutionName: education.institutionName || "",
            highestEducationLevelType: education.jenjang || 1,
            majorType: education.majors || 1,
            cityType: education.locations || 1,
            yearStart: education.startDate || null,
            yearEnd: education.endDate || null,
          })) || [],
          courseOrUpgrading: formData[3].personalIdentity.coursesOrUpgrading?.map((course :any) => ({
            courseType: course.type || 1,
            courseName: course.courseName || null,
            cityType: course.citys || 1,
            day: course.date || 1,
            month: course.month || 1,
            year: course.year || null,
            durationMonths: course.durationMonths || 1,
            institution: course.institution || null,
            certificationId: course.certificateNumber || null,
          })) || [],
          workExperienceRequest: formData[3].personalIdentity.workExperience?.map((work :any)=> ({
            companyName: work.companyName || "",
            position: work.position || "",
            cityType: work.citys || 1,
            startYear: work.startYear || "",
            endYear: work.endYear || "",
            durationMonths: work.durationMonths || 0,
          })) || [],
          organizationExperience: formData[3].personalIdentity.organizationalLife?.map((org :any) => ({
            organizationName: org.organizationName || "",
            startYear: org.yearInPosition || "",
            position: org.position || "",
            cityType: org.citys || 1,
            memberCountRange: org.memberCount || "1-10",
            durationMonths: org.durationMonths || 0,
          })) || [],
          sports: formData[3].personalIdentity.sports?.map((sport :any)=> ({
            sportType: sport.sport || 1,
            isActive: !!sport.activePassive,
          })) || [],
          arts: formData[3].personalIdentity.art?.map((art :any) => ({
            art: art.art || 1,
            isActive: !!art.activePassive,
          })) || [],
          otherRequest: {
            foreignLanguageProficiency: formData[3].personalIdentity.other?.foreignLanguageProficiency == 1 ? "English " : "German",
            hobbies: formData[3].personalIdentity.other?.hobbies || "Sepakbola",
            careerInterests: formData[3].personalIdentity.other?.careerInterests || "CEO",
          },
        },

        // Mapping contractInformation
        contractInformation: {
          details: {
            contractStatusType: formData[3].contractInformation.statusId == "active" ? 1 : 2,
            placementType: formData[3].contractInformation.placementTypeId || 1,
            employeeType: formData[3].contractInformation.employeeTypeId || 1,
            bankOrIssuranceAgreementType: formData[3].contractInformation.willingToBePlacedInBankOrInsurance || 1,
            divisionType: formData[3].contractInformation.divisionId || 1,
            positionType: formData[3].contractInformation.jobPositionId || 1,
            contractStartDate: formData[3].contractInformation.contractStartDate || null,
            contractEndDate: formData[3].contractInformation.contractEndDate || null,
            generationType: formData[3].contractInformation.generation || null,
            documentContractNameFile: formData[3].contractInformation.contractDocument?.documentUrl || "documentContractNameFile",
            currentSalary: parseFloat(formData[3].contractInformation.baseSalary).toFixed(2) || 0,
          },
          allowance: {
            placementAllowances: formData[3].contractInformation.allowances?.placementAllowances?.map((allowance :any) => ({
              allowanceType: allowance.allowanceType || 1,
              nominal: parseFloat(allowance.nominal) || 0,
            })) || [],
            otherAllowances: formData[3].contractInformation.allowances?.otherAllowances?.map((allowance :any) => ({
              allowanceType: allowance.allowanceType || 1,
              nominal: parseFloat(allowance.nominal) || 0,
            })) || [],
          },
        },

        civilRegistrationData: {
          civilData: {
            nik: formData[3]?.healthAndFinance?.nik || null,
            npwp: formData[3]?.healthAndFinance?.npwp || null,
            statusPtkp: formData[3]?.healthAndFinance?.ptkpStatus || null,
          },
          bpjsData: {
            healthBpjsNumber: formData[3]?.healthAndFinance?.bpjsNumber || null,
            employmentBpjsNumber: formData[3]?.healthAndFinance?.employmentBpjsNumber || null,
            healthBpjsClassType: formData[3]?.healthAndFinance?.bpjsClass || null,
          },
          accountBank: {
            bankType: formData[3]?.healthAndFinance?.bankId || null,
            accountNumber: formData[3]?.healthAndFinance?.accountNumber || null,
          },
        },
        documents: {
          // documentEmployee: formData[3]?.documents?.documentEmployee?.map((doc:any) => ({
          //   documentType: doc.documentType || 1,
          //   docName: doc.docName || "https://example.com/document1.pdf",
          //      document: doc.document[0] || null,
          // })) || [],
          socialMedia: formData[3]?.documents?.socialMedia?.map((social:any) => ({
            socialMediaType: social.socialMediaType || null,
            linkSocmed: social.socialMediaLink || 0,
          })) || [],
        },
      };
  };


export default mapRequestBody;