'use client';

import React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import { FieldComponent, HmDivider, HmDynamicForm } from '@/components/component';
import colors from '@/components/colors';
import Grid from '@mui/material/Grid2';
import { KontrakInputs, stateContractOptions, placementTypeOptions, employeeTypeOptions, divisiOptions, generationOptions, bankPlacementOptions, jobPositionOption, tunjanganPenempatanDynamic, EmployeeFormData, tunjanganLainLainDynamic } from './data-and-validation/form-data';
import useFetchDropdown from '@/hooks/useFetchDropdown';


const ScFormKontrak: React.FC = () => {
    const { control } = useFormContext<KontrakInputs>();

    // tipe kontrak
    const { options: stateContractOptions } = useFetchDropdown(
        'master.contract-type',
        (item) => ({
            id: item.contractTypeId,
            value: item.name,
            label: item.name,
        })
    );

    // tipe karyawan
    const { options: employeeTypeOptions } = useFetchDropdown(
        'master.employe-type',
        (item) => ({
            id: item.partyTypeId,
            value: item.name,
            label: item.name,
        })
    );

    // divisi
    const { options: divisiOptions } = useFetchDropdown(
        'master.division',
        (item) => ({
            id: item.divisionId,
            value: item.name,
            label: item.name,
        })
    );

    // penempatan
    const { options: placementTypeOptions } = useFetchDropdown(
        'master.placement-type',
        (item) => ({
            id: item.placementTypeId,
            value: item.name,
            label: item.name,
        })
    );

    // jabatan
    const { options: jobPositionOption } = useFetchDropdown(
        'master.job-position',
        (item) => ({
            id: item.positionId,
            value: item.name,
            label: item.name,
        })
    );

    // bank placemenet
    const { options: bankPlacementOptions } = useFetchDropdown(
        'master.bank-placement',
        (item) => ({
            id: item.id,
            value: item.value,
            label: item.value,
        })
    );

    // tunjangan
    const { options: allowanceTypeOptions } = useFetchDropdown(
        'master.allowance-type',
        (item) => ({
            id: item.allowanceTypeId,
            value: item.name,
            label: item.name,
        })
    );

    // dynamic table mapping
    // tunjangan penempatan
    const tunjanganPenempatanDynamicMap = tunjanganPenempatanDynamic.map(field => {
        if (field.field === 'Jenis') {
            return {
                ...field,
                options: allowanceTypeOptions,
            };
        }
        return field;
    });

    //  tunjangan lain
    const tunjanganLainLainDynamicMap = tunjanganLainLainDynamic.map(field => {
        if (field.field === 'Jenis') {
            return {
                ...field,
                options: allowanceTypeOptions,
            };
        }
        return field;
    });


    const renderField = (
        name: keyof EmployeeFormData,
        label: string,
        type: string,
        placeholder: string,
        required: boolean,
        options?: { id: string | number; value: string; label: string }[],
        startIcon?: React.ReactNode,
        buttonDynamic?: string,
        dynamicColumns?: {
            header: string; field: string; type: string; placeholder: string; size: 'small' | 'medium'; hideLabel: boolean; fullWidth: boolean; options: any[]
        }[] //For dynamic table form
    ) => (
        <Box sx={{ mb: 2 }}>
            <Controller
                name={name as keyof KontrakInputs}
                control={control}
                defaultValue=""
                render={({ field }) =>
                    type === 'dropdown' ? (
                        <FieldComponent
                            {...field}
                            type="dropdown"
                            label={label}
                            name={name}
                            options={options || []}
                            placeholder={placeholder}
                            control={control}
                            size="small"
                            required={required}
                        />
                    ) : type === 'file' ? (
                        <FieldComponent
                            {...field}
                            type="file"
                            label={label}
                            name={name}
                            required={required}
                            fullWidth={false}
                            control={control}
                        />
                    ) : type === 'date' ? (
                        <FieldComponent
                            {...field}
                            type="date"
                            label={label}
                            name={name}
                            fullWidth
                            control={control}
                            size="small"
                            required={required}
                        />
                    ) : type === 'dynamic' ? (
                        <HmDynamicForm
                            {...field}
                            label={label}
                            name={name}
                            required={required}
                            columns={dynamicColumns || []}
                            buttonText={buttonDynamic ?? 'Add'}
                            control={control}
                        />
                    ) : (
                        <FieldComponent
                            {...field}
                            label={label}
                            name={name}
                            placeholder={placeholder}
                            fullWidth
                            control={control}
                            required={required}
                            startIcon={startIcon}
                        />
                    )
                }
            />
        </Box>
    );

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Informasi Kontrak
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('contractInformation.statusId' as keyof EmployeeFormData, 'Status Kontrak', 'dropdown', 'Pilih status kontrak', true, stateContractOptions)}
                            {renderField('contractInformation.employeeTypeId' as keyof EmployeeFormData, 'Jenis Karyawan', 'dropdown', 'Pilih Jenis Karyawan', true, employeeTypeOptions)}
                            {renderField('contractInformation.divisionId' as keyof EmployeeFormData, 'Divisi', 'dropdown', 'Pilih Divisi', true, divisiOptions)}
                            {renderField('contractInformation.contractStartDate' as keyof EmployeeFormData, 'Tanggal Mulai Kontrak', 'date', 'Masukan tanggal mulai kontrak', true)}
                            {renderField('contractInformation.generation' as keyof EmployeeFormData, 'Generasi', 'text', 'Masukan generasi', false)}
                            {renderField('contractInformation.baseSalary' as keyof EmployeeFormData, 'Gaji Pokok', 'number', 'Masukan gaji pokok', true, [], <React.Fragment>Rp.</React.Fragment>)}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('contractInformation.placementTypeId' as keyof EmployeeFormData, 'Jenis Penempatan', 'dropdown', 'Pilih jenis penempatan', true, placementTypeOptions)}
                            {renderField('contractInformation.willingToBePlacedInBankOrInsurance' as keyof EmployeeFormData, 'Bersedia Ditempatkan di Bank/insurance', 'dropdown', 'Pilih bersedia ditempatkan di bank/insurance', true, bankPlacementOptions)}
                            {renderField('contractInformation.jobPositionId' as keyof EmployeeFormData, 'Jabatan', 'dropdown', 'Pilih Jabatan', true, jobPositionOption)}
                            {renderField('contractInformation.contractEndDate' as keyof EmployeeFormData, 'Tanggal Akhir Kontrak', 'date', 'Masukan tanggal akhir kontrak', true,)}
                            {renderField('contractInformation.contractDocument.documentName' as keyof EmployeeFormData, 'Dokumen Kontrak', 'file', '', true,)}
                        </Grid>
                    </Grid>
                </Box>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Tunjangan
                </HmTypography>
                <Box sx={{ px: 2, }}>
                    {renderField('contractInformation.allowances.placementAllowances' as keyof EmployeeFormData, 'Tunjangan Penempatan', 'dynamic', '', false, undefined, undefined, 'Tambah Tunjangan', tunjanganPenempatanDynamicMap)}
                    {renderField('contractInformation.allowances.otherAllowances' as keyof EmployeeFormData, 'Tunjangan Lain Lain', 'dynamic', '', false, undefined, undefined, 'Tambah Tunjangan', tunjanganLainLainDynamicMap)}
                </Box>
                <HmDivider />
            </Box>
        </Box>
    );
};

export default ScFormKontrak;

