'use client';

import React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import { FieldComponent, HmDynamicForm } from '@/components/component';
import colors from '@/components/colors';
import { EmployeeFormData, UnggahDokumenInputs, documentEmployeeDynamic, socialMediaDynamic } from './data-and-validation/form-data';
import useFetchDropdown from '@/hooks/useFetchDropdown';

const ScFormUnggahDokumen: React.FC = () => {
    const { control } = useFormContext<UnggahDokumenInputs>();

    // tipe dokumen
    const { options: documentTypeOptions } = useFetchDropdown(
        'master.document-type',
        (item) => ({
            id: item.documentTypeId,
            value: item.name,
            label: item.name,
        })
    );
    // sosial media
    const { options: socialMediaOptions } = useFetchDropdown(
        'master.social-media',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );

    // dynamic table mapping
    // dokumen karyawan
    const documentEmployeeDynamicMap = documentEmployeeDynamic.map(field => {
        if (field.field === 'documentType') {
            return {
                ...field,
                options: documentTypeOptions,
            };
        }
        return field;
    });

    //  sosial media
    const socialMediaDynamicMap = socialMediaDynamic.map(field => {
        if (field.field === 'socialMediaType') {
            return {
                ...field,
                options: socialMediaOptions,
            };
        }
        return field;
    });


    const renderField = (
        name: keyof EmployeeFormData,
        label: string,
        type: string,
        placeholder: string,
        required: boolean,
        options?: { id: string | number; value: string; label: string }[],
        upload?: boolean,
        buttonDynamic?: string,
        dynamicColumns?: {
            header: string; field: string; type: string; placeholder: string; size: 'small' | 'medium'; hideLabel: boolean; fullWidth: boolean; options: any[]
        }[] //For dynamic table form
    ) => (
        <Box sx={{ mb: 2 }}>
            <Controller
                name={name as keyof UnggahDokumenInputs}
                control={control}
                defaultValue={[]}
                render={({ field }) =>
                    type === 'dynamic' ? (
                        <HmDynamicForm
                            {...field}
                            label={label}
                            name={name}
                            required={required}
                            columns={dynamicColumns || []}
                            buttonText={buttonDynamic ?? 'Add'}
                            control={control}
                            upload={upload}

                        />
                    ) : (
                        <FieldComponent
                            {...field}
                            label={label}
                            name={name}
                            placeholder={placeholder}
                            fullWidth
                            control={control}
                            required={required}
                        />
                    )
                }
            />
        </Box>
    );

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Dokumen Employee
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    {renderField('documents.documentEmployee' as keyof EmployeeFormData, 'Dokumen', 'dynamic', '', true, undefined, true, 'Tambah Dokumen', documentEmployeeDynamicMap)}
                </Box>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Social Media
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    {renderField('documents.socialMedia' as keyof EmployeeFormData, 'Sosial media', 'dynamic', '', true, undefined, false, 'Tambah Social Media', socialMediaDynamicMap)}
                </Box>
            </Box>
        </Box>
    );
};

export default ScFormUnggahDokumen;

