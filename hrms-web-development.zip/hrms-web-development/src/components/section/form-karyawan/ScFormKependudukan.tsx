'use client';

import React, { useEffect, useState } from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { Box } from '@mui/material';
import HmTypography from '@/components/component/HmTypography';
import { FieldComponent, HmDivider } from '@/components/component';
import colors from '@/components/colors';
import Grid from '@mui/material/Grid2';
import { bankNameOptions, DataKependudukanInputs, EmployeeFormData, kelasBpjsOptions, statusPtkpOptions } from './data-and-validation/form-data';

import useFetchDropdown from '@/hooks/useFetchDropdown';

const ScFormKependudukan: React.FC = () => {
    const { control } = useFormContext<DataKependudukanInputs>();

    // ptkp status
    const { options: statusPtkpOptions } = useFetchDropdown(
        'master.ptkp-state',
        (item) => ({
            id: item.id,
            value: item.value,
            label: item.value,
        })
    );

    // kelas bpjs
    const { options: kelasBpjsOptions } = useFetchDropdown(
        'master.bpjs-class',
        (item) => ({
            id: item.id,
            value: item.name,
            label: item.name,
        })
    );

    // nama bank
    const { options: bankNameOptions } = useFetchDropdown(
        'master.bank-name',
        (item) => ({
            id: item.bankId,
            value: item.name,
            label: item.name,
        })
    );


    const renderField = (
        name: keyof EmployeeFormData,
        label: string,
        type: string,
        placeholder: string,
        required: boolean,
        options?: { id: string | number; value: string; label: string }[],

    ) => (
        <Box sx={{ mb: 2 }}>
            <Controller
                name={name as keyof DataKependudukanInputs}
                control={control}
                defaultValue=""
                render={({ field }) =>
                    type === 'dropdown' ? (
                        <FieldComponent
                            {...field}
                            type="dropdown"
                            label={label}
                            name={name}
                            options={options || []}
                            placeholder={placeholder}
                            control={control}
                            size="small"
                            required={required}
                        />
                    ) : (
                        <FieldComponent
                            {...field}
                            label={label}
                            name={name}
                            placeholder={placeholder}
                            fullWidth
                            control={control}
                            required={required}
                        />
                    )
                }
            />
        </Box>
    )

    return (
        <Box sx={{ width: '100%', margin: 'auto', mt: 5 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Data NIK & NPWP
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('healthAndFinance.nik' as keyof EmployeeFormData, 'NIK', 'text', 'Masukkan NIK', true)}
                            {renderField('healthAndFinance.ptkpStatus' as keyof EmployeeFormData, 'Status PTKP', 'dropdown', 'Pilih jenis status ptkp', true, statusPtkpOptions)}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('healthAndFinance.npwp' as keyof EmployeeFormData, 'NPWP', 'text', 'Masukkan NPWP', true)}
                        </Grid>
                    </Grid>
                </Box>
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Data Bpjs
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('healthAndFinance.bpjsNumber' as keyof EmployeeFormData, 'Nomor BPJS Kesehatan', 'text', 'Masukkan nomor bpjs kesehatan', false)}
                            {renderField('healthAndFinance.employmentBpjsNumber' as keyof EmployeeFormData, 'Nomor BPJS Ketenagakerjaan', 'text', 'Masukkan nomor bpjs ketenagarkerjaan', false)}

                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('healthAndFinance.bpjsClass' as keyof EmployeeFormData, 'Kelas BPJS Kesehatan', 'dropdown', 'Pilih Kelas Bpjs Kesehatan', false, kelasBpjsOptions)}
                        </Grid>
                    </Grid>
                </Box>
                <HmDivider />
                <HmTypography color={colors.palette.grey} semiBold sx={{ textTransform: 'uppercase' }}>
                    Data Rekening
                </HmTypography>
                <Box sx={{ px: 2 }}>
                    <Grid container spacing={4} >
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('healthAndFinance.bankId' as keyof EmployeeFormData, 'Nama Bank', 'dropdown', 'Masukkan nama bank', true, bankNameOptions)}
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            {renderField('healthAndFinance.accountNumber' as keyof EmployeeFormData, 'Nomor Rekening', 'text', 'Masukan Nomor Rekening', true)}
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Box>
    );
};

export default ScFormKependudukan;



