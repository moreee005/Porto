'use client';

import React, { useState, useEffect, FC } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { FieldComponent, HmTypography } from '@/components/component';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Box } from '@mui/material';
import Grid from '@mui/material/Grid2';
import { DetailEmployeeHeader } from '@/components/section';
import colors from '@/components/colors';
import TableTunjangan from './TableTunjangan'
import { API } from '@/services/setupAxios'
import { DataContract, Datas } from './DataContractContext';

interface FormValues {
    status: string;
    placementType?: string;
    employeeType: string;
    bankPlacement?: string;
    division: string;
    position: string;
    contractStartDate: Date;
    contractEndDate: Date;
    generation?: string;
    salary: number;
    contractDocumentName: string;
}

interface CardContractProps {
    data: DataContract;
    onSuccess: () => void;
}

const schema = Yup.object().shape({
    status: Yup.string().required('Status Kontrak Wajib diisi'),
    employeeType: Yup.string().required('Jenis Karyawan Wajib diisi'),
    division: Yup.string().required('Divisi Wajib diisi'),
    position: Yup.string().required('Jabatan Wajib diisi'),
    contractStartDate: Yup.date().required('Tanggal Mulai Kontrak Wajib diisi'),
    contractEndDate: Yup.date().required('Tanggal Akhir Kontrak Wajib diisi'),
    contractDocumentName: Yup.string().required('Dokumen Wajib diisi'),
    salary: Yup.number().required('Gaji Pokok Wajib diisi'),
});

const CardContract: FC<CardContractProps> = ({ data, onSuccess }) => {
    const { contractInfo } = data;
    const [contractStatus, setContractStatus] = useState<Datas[]>([]);
    const [placementTypes, setPlacementTypes] = useState<Datas[]>([]);
    const [employeeTypes, setEmployeeTypes] = useState<Datas[]>([]);
    const [bankPlacements, setBankPlacements] = useState<Datas[]>([]);
    const [divisions, setDivisions] = useState<Datas[]>([]);
    const [jobPosition, setJobPosition] = useState<Datas[]>([]);
    const [uploadKontrak, setUploadKontrak] = useState<File | null>(null);

    const getContractStatus = async () => {
        try {
            const response = await API('master.contract-status');
            const data = response?.data?.data.map((item: any) => ({
                id: item.contractStatusId,
                value: item.name,
            }));
            setContractStatus(data);
        } catch (error) {
            console.error('Failed to fetch contract data:', error);
        }
    };
    const getPlacementTypes = async () => {
        try {
            const response = await API('master.placement-type');
            const data = response?.data?.data.map((item: any) => ({
                id: item.placementTypeId,
                value: item.name,
            }));
            setPlacementTypes(data);
        } catch (error) {
            console.error('Failed to fetch contract data:', error);
        }
    };
    const getEmployeeTypes = async () => {
        try {
            const response = await API('master.employee-type');
            const data = response?.data?.data.map((item: any) => ({
                id: item.employeeTypeId,
                value: item.name,
            }));
            setEmployeeTypes(data);
        } catch (error) {
            console.error('Failed to fetch contract data:', error);
        }
    };
    const getBankPlacement = async () => {
        try {
            const response = await API('master.bank-placement');
            const data = response?.data?.data.map((item: any) => ({
                id: item.bankPlacementId,
                value: item.name,
            }));
            setBankPlacements(data);
        } catch (error) {
            console.error('Failed to fetch contract data:', error);
        }
    };
    const getDivisions = async () => {
        try {
            const response = await API('master.division');
            const data = response?.data?.data.map((item: any) => ({
                id: item.divisionId,
                value: item.name,
            }));
            setDivisions(data);
        } catch (error) {
            console.error('Failed to fetch contract data:', error);
        }
    };
    const getJobPosition = async () => {
        try {
            const response = await API('master.job-position');
            const data = response?.data?.data.map((item: any) => ({
                id: item.positionId,
                value: item.name,
            }));
            setJobPosition(data);
        } catch (error) {
            console.error('Failed to fetch contract data:', error);
        }
    };

    useEffect(() => {
        getContractStatus();
        getPlacementTypes();
        getEmployeeTypes();
        getBankPlacement();
        getDivisions();
        getJobPosition();
        if (contractInfo) {
            methods.reset({
                status: contractInfo.status || '',
                employeeType: contractInfo.employeeType || '',
                division: contractInfo.division || '',
                position: contractInfo.position || '',
                contractStartDate: contractInfo.contractStartDate ? new Date(contractInfo.contractStartDate) : new Date(),
                contractEndDate: contractInfo.contractEndDate ? new Date(contractInfo.contractEndDate) : new Date(),
                salary: contractInfo.salary || 0,
                contractDocumentName: contractInfo.contractDocumentName || '',
            });
        }
    }, []);


    console.log("data contractInfo: ", contractInfo)
    const methods = useForm<FormValues>({
        resolver: yupResolver(schema),
        defaultValues: {
            status: contractInfo?.status,
            employeeType: contractInfo?.employeeType,
            division: contractInfo?.division,
            position: contractInfo?.position,
            contractStartDate: contractInfo?.contractStartDate ? new Date(contractInfo.contractStartDate) : new Date(),
            contractEndDate: contractInfo?.contractEndDate ? new Date(contractInfo.contractStartDate) : new Date(),
            salary: contractInfo?.salary,
            contractDocumentName: contractInfo?.contractDocumentName,
        },
    });

    const placementAllowance = data?.placementAllowance;
    const otherAllowance = data?.otherAllowance;

    const onSubmit = async (values: FormValues) => {
        const payload = {
            employeeDetail: data.employeeDetail,
            contractInfo: {
                ...values,
                contractStartDate: values.contractStartDate.toISOString(),
                contractEndDate: values.contractEndDate.toISOString(),
            }
        };
        try {
            const response = await API('dataContract.addendum', {
                method: 'POST',
                data: payload,
            });
            console.log('Success:', response.data);
        } catch (error) {
            console.error('Failed to submit data:', error);
        }
    };

    return (
        <Box>
            <FormProvider {...methods}>
                <form onSubmit={methods.handleSubmit(onSubmit)}>
                    <DetailEmployeeHeader {...data.employeeDetail} />
                    <Grid size={{ xs: 6, md: 8 }}>
                        <HmTypography
                            variant="h1"
                            color={colors.palette.greyPrimary}
                            sx={{ marginLeft: '20px' }}
                            fontSize="18px"
                        >
                            INFORMASI KONTRAK
                        </HmTypography>
                    </Grid>
                    <div style={{ marginLeft: '20px', marginTop: '20px' }}>

                        <Grid container spacing={2} sx={{ marginLeft: '20px' }}>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    type="dropdown"
                                    name="data.contractInfo.status"
                                    label=" Status Kontrak"
                                    options={contractStatus || []}
                                    required
                                    onChange={(newValue) => {
                                        console.log('New Value:', newValue);
                                        methods.setValue('status', newValue);
                                    }}
                                    placeholder="Pilih Status Kontrak"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    type="dropdown"
                                    name="contractInfo.placementType"
                                    label="Jenis Penempatan"
                                    options={placementTypes}
                                    onChange={(newValue) => {
                                        methods.setValue('placementType', newValue);
                                    }}
                                    placeholder="Pilih Jenis Penempatan"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    type="dropdown"
                                    name="contractInfo.employeeType"
                                    label=" Jenis Karyawan"
                                    options={employeeTypes}
                                    required
                                    onChange={(newValue) => {
                                        methods.setValue('employeeType', newValue);
                                    }}
                                    placeholder="Pilih Jenis Karyawan"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    type="dropdown"
                                    name="bankPlacement"
                                    label="Bersedia Ditempatkan di Bank/Insurance"
                                    options={bankPlacements}
                                    onChange={(newValue) => {
                                        methods.setValue('bankPlacement', newValue);
                                    }}
                                    placeholder="Pilih Bersedia/Tidak"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    type="dropdown"
                                    name="contractInfo.division"
                                    label="Divisi"
                                    options={divisions}
                                    required
                                    onChange={(newValue) => {
                                        methods.setValue('division', newValue);
                                    }}
                                    placeholder="Pilih Divisi"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    type="dropdown"
                                    name="contractInfo.position"
                                    label="Jabatan"
                                    options={jobPosition}
                                    required
                                    onChange={(newValue) => {
                                        methods.setValue('position', newValue);
                                    }}
                                    placeholder="Pilih Jabatan"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    name="contractStartDate"
                                    label="Tanggal Mulai Kontrak"
                                    type="date"
                                    required
                                    size="small"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    name="contractEndDate"
                                    label="Tanggal Akhir Kontrak"
                                    type="date"
                                    required
                                    size="small"
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    name="contractInfo.generation"
                                    label="Generasi"
                                    placeholder="Isi Generasi"
                                    fullWidth
                                    control={methods.control}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    name="document"
                                    label="Dokumen Kontrak"
                                    type="file"
                                    required
                                    fullWidth={false}
                                    control={methods.control}
                                    sx={{
                                        display: 'flex',
                                        fontSize: '14px',
                                        color: '#3f51b5',
                                        '&:hover': {
                                            backgroundColor: '#3f51b5',
                                            borderRadius: '20px',
                                            color: '#3f51b5',
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid size={{ xs: 12, sm: 6 }} >
                                <FieldComponent
                                    startIcon={<span style={{ color: '#000' }}>Rp</span>}
                                    name="salary"
                                    label="Salary"
                                    required
                                    placeholder="Isi Gaji Pokok"
                                    fullWidth
                                    control={methods.control}
                                />
                            </Grid>
                        </Grid>
                        {/* <button type="submit">Submit</button> */}
                    </div>
                    <Grid size={{ xs: 6, md: 8 }} sx={{ marginTop: '20px' }}>
                        <HmTypography variant="h1" color={colors.palette.greyPrimary} sx={{ marginLeft: '20px' }} fontSize="18px">
                            TUNJANGAN
                        </HmTypography>
                    </Grid>
                    <Grid container sx={{ padding: '20px 40px' }}>
                        <Grid size={12} >
                            <HmTypography semiBold fontSize="18px"> Tunjangan Penempatan </HmTypography>
                            <TableTunjangan allowances={placementAllowance} />
                        </Grid>
                        <Grid size={12} sx={{ marginTop: '20px' }} >
                            <HmTypography semiBold fontSize="18px"> Tunjangan Lain-lain </HmTypography>
                            <TableTunjangan allowances={otherAllowance} />
                        </Grid>
                    </Grid>
                    <button type="submit" style={{ display: 'none' }} id="submit-button"></button>
                </form>
            </FormProvider>
        </Box >
    );
};


export default CardContract;
