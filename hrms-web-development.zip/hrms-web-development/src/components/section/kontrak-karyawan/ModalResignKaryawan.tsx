import {
  FieldComponent,
  HmButton,
  HmModal,
  HmTextField,
  HmTypography,
} from '@/components/component';
import { useToast } from '@/context/toastContext';
import { API } from '@/services/setupAxios';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { Grid2 } from '@mui/material';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';

interface ResignKaryawanProps {
  isOpen: boolean;
  onClose: any;
  employeeId: string;
}

interface DataResponse {
  employeeDetail: EmployeeDetail;
  contractInfo: ContractInfo;
  placementAllowance: Allowance[];
  otherAllowance: Allowance[];
}

interface EmployeeDetail {
  id: string;
  fullName: string;
  division: string;
  contractStatus: string;
  position: string;
}

interface ContractInfo {
  status: string;
  placementType: string;
  employeeType: string;
  bankPlacement: string;
  division: string;
  position: string;
  contractStartDate: string;
  contractEndDate: string;
  generation: string;
  contractDocument: string;
  contractDocumentName: string;
  salary: string;
}

interface Allowance {
  allowanceType: string;
  amount: number;
}

interface APIResponse {
  status: number;
  message: string;
  data: DataResponse;
}

interface ListItemProps {
  label?: string;
  value?: any;
  size?: { xs?: number; sm?: number; md?: number; lg?: number; xl?: number };
}

const ListItem: React.FC<ListItemProps> = ({
  label = 'label',
  value = 'value',
  size = { xs: 12, md: 6 },
}) => {
  return (
    <Grid2 size={size}>
      <HmTypography
        semiBold
        color="#586A84"
        sx={{ display: 'block', marginBottom: '3px' }}
      >
        {label}
      </HmTypography>
      {typeof value === 'string' ? (
        <HmTypography semiBold>{value}</HmTypography>
      ) : (
        value
      )}
    </Grid2>
  );
};

const ModalResignKaryawan: React.FC<ResignKaryawanProps> = ({
  isOpen,
  onClose,
  employeeId,
}) => {
  const [employeeDetails, setEmployeeDetails] = useState<APIResponse | null>(
    null
  );
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isDisableButton, setIsDisableButton] = useState(true);
  const { showToast } = useToast();
  const router = useRouter();

  const schema = Yup.object().shape({
    resignDate: Yup.date().required('Tanggal resign is required'),
    reason: Yup.string().required('Alasan is required'),
    resignDocument: Yup.mixed()
      .required('File is required')
      .test('fileRequired', 'File is required', (value) => value && length > 0),
  });

  const methods = useForm({
    resolver: yupResolver(schema),
  });

  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (!isOpen && !employeeId) return;

    const fetchData = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await API('employeeManagement.detailContract', {
          params: employeeId,
        });

        const data: APIResponse = response?.data;
        console.log('response detail employee kontrak', data);
        setEmployeeDetails(data);
      } catch (error: any) {
        showToast('error', error?.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [isOpen, employeeId, showToast]);

  const handleActionButton = async () => {
    const resignDate = methods.watch('resignDate');
    const resignDocument = methods.watch('resignDocument');
    const reason = methods.watch('reason');

    if (!reason || !resignDate || !employeeId) {
      showToast('error', 'Pastikan semua data telah diisi.');
      return;
    }

    try {
      const response = await API('employeeManagement.resignContract', {
        params: employeeId,
        data: {
          resignDate,
          reason,
          resignDocument,
        },
      });
      if (response?.status == 200) {
        showToast('success', 'Contract Ended Successfully');
        router.push('/kontrak');
      }
    } catch (error: any) {
      showToast('error', error?.message || 'error while ending the contract');
    }
  };

  return (
    <FormProvider {...methods}>
      <form ref={formRef} onSubmit={methods.handleSubmit(handleActionButton)}>
        <HmModal
          isOpen={isOpen}
          onClose={onClose}
          title="Resign Karyawan"
          zIndex={1}
          isAction={true}
          onClickAction={() =>
            formRef.current?.dispatchEvent(
              new Event('submit', { cancelable: true, bubbles: true })
            )
          }
          labelAction="Action"
          isDisableButton={isDisableButton}
          maxWidth="md"
        >
          {loading ? (
            <div>loading</div>
          ) : error ? (
            <div>error</div>
          ) : (
            <Grid2 container spacing={2} padding={0}>
              <ListItem
                size={{ xs: 12, md: 6 }}
                label="Nama Lengkap"
                value={employeeDetails?.data?.employeeDetail?.fullName}
              />
              <ListItem
                size={{ xs: 12, md: 6 }}
                label="Status Kontrak"
                value={employeeDetails?.data?.employeeDetail?.contractStatus}
              />
              <ListItem
                size={{ xs: 12, md: 6 }}
                label="Divisi"
                value={employeeDetails?.data?.contractInfo?.division}
              />
              <ListItem
                size={{ xs: 12, md: 6 }}
                label="Jabatan"
                value={employeeDetails?.data?.contractInfo?.position}
              />
              <ListItem
                size={{ xs: 12, md: 6 }}
                label="Tanggal Mulai Status Kontrak"
                value={employeeDetails?.data?.contractInfo?.contractStartDate}
              />
              <ListItem
                size={{ xs: 12, md: 6 }}
                label="Tanggal Akhir Status Kontrak"
                value={employeeDetails?.data?.contractInfo?.contractEndDate}
              />
            </Grid2>
          )}
          <Grid2 container spacing={2} padding={0}>
            <Grid2 size={{ xs: 12, sm: 6, md: 6 }}>
              <FieldComponent
                control={methods?.control}
                name="resignDate"
                label="Tanggal Resign"
                type="date"
                required
                size="small"
              />
            </Grid2>
            <Grid2 size={{ xs: 12, sm: 6, md: 6 }}>
              <FieldComponent
                name="resignDocument"
                control={methods?.control}
                label="Dokumen Resign"
                type="file"
                fullWidth={false}
                required
                size="small"
              />
            </Grid2>
            <Grid2 size={{ xs: 12, sm: 12, md: 12 }}>
              <FieldComponent
                control={methods.control}
                name="reason"
                label="Alasan"
                required
                type="textarea"
                placeholder="Alasan.."
                fullWidth
              />
            </Grid2>
          </Grid2>
        </HmModal>
      </form>
    </FormProvider>
  );
};

export default ModalResignKaryawan;
