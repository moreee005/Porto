'use client';

import React, { FC } from 'react';
import { Box } from '@mui/material';
import { HmTypography } from '@/components/component';
import Grid from '@mui/material/Grid2';
import colors from '@/components/colors';
interface EmployeeDetailProps {
  employeeId: string;
  fullName: string;
  division: string;
  contractStatus: string;
  position: string;
}

const DetailEmployeeHeader: FC<EmployeeDetailProps> = ({
  employeeId,
  fullName,
  division,
  contractStatus,
  position
}) => {
  return (
    <Box>
      <Grid size={{ xs: 6, md: 8 }}>
        <HmTypography
          variant="h1"
          color={colors.palette.greyPrimary}
          sx={{ marginLeft: '20px' }}
          fontSize="18px"
        >
          DETAIL KARYAWAN
        </HmTypography>
      </Grid>
      <Grid container sx={{ padding: '20px 40px' }} spacing={2}>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="16px">
            Nama Lengkap
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="16px">
            Status Kontrak
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography sx={{ marginBottom: '8px' }} fontSize="16px">
            {fullName}
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography sx={{ marginBottom: '8px' }} fontSize="16px">
            {contractStatus}
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="16px">
            Divisi
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="16px">
            Jabatan
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography sx={{ marginBottom: '8px' }} fontSize="16px">
            {division}
          </HmTypography>
        </Grid>
        <Grid size={{ xs: 6, sm: 6 }}>
          <HmTypography sx={{ marginBottom: '8px' }} fontSize="16px">
            {position}
          </HmTypography>
        </Grid>
      </Grid>
    </Box>
  );
};
export default DetailEmployeeHeader;
