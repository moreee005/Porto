import React from 'react';
import {
  Dialog,
  DialogActions,
  DialogTitle,
  Divider,
  DialogContent,
} from '@mui/material';
import { HmButton, HmTypography } from '@/components/component';
import { ThemeProvider } from '@emotion/react';
import CloseIcon from '@mui/icons-material/Close';
import { useTheme } from '@mui/material/styles';
import Grid from '@mui/material/Grid2';

interface ExtendDialogProps {
  open: boolean;
  onClose: () => void;
  employeeDetail: {
    fullName: string;
    division: string;
    contractStatus: string;
    position: string;
  };
  contractInfo: {
    contractStartDate: Date;
    contractEndDate: Date;
  };
}

const ExtendDialog: React.FC<ExtendDialogProps> = ({ open, onClose, employeeDetail, contractInfo }) => {
  const theme = useTheme();

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogActions
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontStyle: 'bold',
        }}
      >
        <DialogTitle sx={{ fontWeight: 'bold' }}>Addendum Kontrak</DialogTitle>
        <HmButton
          icon={<CloseIcon style={{ color: '#000000' }} />}
          color="#ffffff"
          sx={{
            textAlign: 'right',
          }}
          onClick={onClose}
        />
      </DialogActions>
      <Divider />
      <DialogContent>
        <Grid container spacing={2} sx={{ marginBottom: '20px' }}>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              Nama Lengkap{' '}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              Status Kontrak
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              {employeeDetail.fullName}{' '}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              {employeeDetail.contractStatus}{' '}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              Divisi
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="18px">
              Jabatan{' '}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              {employeeDetail.division}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography sx={{ marginBottom: '8px' }} fontSize="18px">
              {' '}
              {employeeDetail.position}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="18px">
              Tanggal Mulai Status Kontrak{' '}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography semiBold sx={{ marginBottom: '8px' }} fontSize="18px">
              Tanggal Mulai Selesai Kontrak{' '}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography sx={{ marginBottom: '8px' }} fontSize="18px">
              {contractInfo.contractStartDate.toLocaleDateString()}
            </HmTypography>
          </Grid>
          <Grid size={{ xs: 6, sm: 6 }}>
            <HmTypography sx={{ marginBottom: '8px' }} fontSize="18px">
              {contractInfo.contractEndDate.toLocaleDateString()}
            </HmTypography>
          </Grid>
        </Grid>
        <Divider />
        <Grid container spacing={3}>
          <Grid
            size={{ xs: 6 }}
            sx={{
              display: 'flex',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}
          >
            <ThemeProvider theme={theme}>
              <HmButton
                label="Batal"
                borderRadius="1"
                variant="contained"
                labelColor="#3f51b5"
                color="#ffffff"
                borderColor="#3f51b5"
                sx={{
                  width: '100%',
                  padding: '12px',
                  fontSize: '14px',
                  '&:hover': { backgroundColor: '#514bcf' },
                }}
                onClick={onClose}
              />
            </ThemeProvider>
          </Grid>
          <Grid
            size={{ xs: 6 }}
            sx={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}
          >
            <ThemeProvider theme={theme}>
              <HmButton
                label="Kirim"
                borderRadius="10"
                labelColor="white"
                sx={{
                  width: '100%',
                  padding: '12px',
                  fontSize: '14px',
                }}
              />
            </ThemeProvider>
          </Grid>
        </Grid>
      </DialogContent>
    </Dialog>
  );
};

export default ExtendDialog;
