import { HmModal, HmTextField, HmTypography } from '@/components/component';
import { useToast } from '@/context/toastContext';
import { API } from '@/services/setupAxios';
import { Grid2 } from '@mui/material';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

interface EndContractProps {
  isOpen: any;
  onClose: any;
  employeeId: string;
}

interface DataResponse {
  employeeDetail: EmployeeDetail;
  contractInfo: ContractInfo;
  placementAllowance: Allowance[];
  otherAllowance: Allowance[];
}

interface EmployeeDetail {
  id: string;
  fullName: string;
  division: string;
  contractStatus: string;
  position: string;
}

interface ContractInfo {
  status: string;
  placementType: string;
  employeeType: string;
  bankPlacement: string;
  division: string;
  position: string;
  contractStartDate: string;
  contractEndDate: string;
  generation: string;
  contractDocument: string;
  contractDocumentName: string;
  salary: string;
}

interface Allowance {
  allowanceType: string;
  amount: number;
}

interface APIResponse {
  status: number;
  message: string;
  data: DataResponse;
}

interface ListItemProps {
  label?: string;
  value?: any;
  size?: { xs?: number; sm?: number; md?: number; lg?: number; xl?: number };
}

const ListItem: React.FC<ListItemProps> = ({
  label = 'label',
  value = 'value',
  size = { xs: 12, md: 6 },
}) => {
  return (
    <Grid2 size={size}>
      <HmTypography
        semiBold
        color="#586A84"
        sx={{ display: 'block', marginBottom: '3px' }}
      >
        {label}
      </HmTypography>
      {typeof value === 'string' ? (
        <HmTypography semiBold>{value}</HmTypography>
      ) : (
        value
      )}
    </Grid2>
  );
};

const ModalEndContract: React.FC<EndContractProps> = ({
  isOpen,
  onClose,
  employeeId,
}) => {
  const [employeeDetails, setEmployeeDetails] = useState<APIResponse | null>(
    null
  );
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [reason, setReason] = useState<string>('');
  const [isDisableButton, setIsDisableButton] = useState(true);
  const { showToast } = useToast();
  const router = useRouter();

  useEffect(() => {
    // if (!isOpen && !employeeId) return;

    const fetchData = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await API('employeeManagement.detailContract', {
          params: employeeId,
        });

        const data: APIResponse = response?.data;
        console.log('response detail employee kontrak', data);
        setEmployeeDetails(data);
      } catch (error: any) {
        showToast('error', error?.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [isOpen, employeeId]);

  const handleInputChange = (value: string) => {
    setReason(value);
    setIsDisableButton(value.trim() === '');
  };

  const handleActionButton = async () => {
    if (!reason || !employeeId) return;
    try {
      const response = await API('employeeManagement.endContract', {
        params: employeeId,
        data: {
          reason: reason,
        },
      });
      if (response?.status == 200) {
        showToast('success', 'Contract Ended Successfully');
        router.push('/kontrak');
      }
    } catch (error: any) {
      showToast('error', error?.message || 'error while ending the contract');
    }
  };

  return (
    <HmModal
      isOpen={isOpen}
      onClose={onClose}
      title="End Kontrak"
      zIndex={1}
      isAction={true}
      labelAction="Action"
      onClickAction={handleActionButton}
      isDisableButton={isDisableButton}
      maxWidth="md"
    >
      {loading ? (
        <div>loading</div>
      ) : error ? (
        <div>error</div>
      ) : (
        <Grid2 container spacing={2} padding={0}>
          <ListItem
            size={{ xs: 12, md: 6 }}
            label="Nama Lengkap"
            value={employeeDetails?.data?.employeeDetail?.fullName}
          />
          <ListItem
            size={{ xs: 12, md: 6 }}
            label="Status Kontrak"
            value={employeeDetails?.data?.employeeDetail?.contractStatus}
          />
          <ListItem
            size={{ xs: 12, md: 6 }}
            label="Divisi"
            value={employeeDetails?.data?.contractInfo?.division}
          />
          <ListItem
            size={{ xs: 12, md: 6 }}
            label="Jabatan"
            value={employeeDetails?.data?.contractInfo?.position}
          />
          <ListItem
            size={{ xs: 12, md: 6 }}
            label="Tanggal Mulai Status Kontrak"
            value={employeeDetails?.data?.contractInfo?.contractStartDate}
          />
          <ListItem
            size={{ xs: 12, md: 6 }}
            label="Tanggal Akhir Status Kontrak"
            value={employeeDetails?.data?.contractInfo?.contractEndDate}
          />
        </Grid2>
      )}
      <HmTextField
        placeholder="Alasan"
        value={reason}
        onChange={handleInputChange}
      />
    </HmModal>
  );
};

export default ModalEndContract;
