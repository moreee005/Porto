export interface DataContract {
    employeeDetail: {
        employeeId: string;
        fullName: string;
        division: string;
        contractStatus: string;
        position: string;
    };
    contractInfo: {
        status: string;
        placementType: string;
        employeeType: string;
        bankPlacement: string;
        division: string;
        position: string;
        contractStartDate: string;
        contractEndDate: string;
        generation: string;
        contractDocument: string; // url minio
        contractDocumentName: string;
        salary: number;
    };
    placementAllowance: {
        id: number;
        allowanceType: string;
        amount: number;
    }[];
    otherAllowance: {
        id: number;
        allowanceType: string;
        amount: number;
    }[];
}
export interface Datas {
    id: number;
    value: string;
}


