import React, { useState, useEffect, FC } from 'react';
import {
  HmTable,
  HmTypography,
  HmButton,
  HmTextField,
  FieldComponent
} from '@/components/component';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import { Box } from '@mui/material';
import { ControlPoint } from '@mui/icons-material';
import { useForm } from 'react-hook-form';
import { API } from '@/services/setupAxios'
import { Datas } from './DataContractContext';

interface Allowance {
  allowanceType: string;
  amount: number;
}
interface TableTunjanganProps {
  allowances: Allowance[];
}

const TableTunjangan: FC<TableTunjanganProps> = ({ allowances }) => {
  const [allowanceTypes, setAllowanceTypes] = useState<Datas[]>([]);
  const [data, setData] = useState(
    allowances.map((allowance, index) => ({
      id: index + 1,
      jenisTunjangan: allowance.allowanceType,
      nominal: allowance.amount.toString(),
    }))
  );

  const methods = useForm();

  const getAllowanceTypes = async () => {
    try {
      const response = await API('master.allowance-type');
      const data = response?.data?.data.map((item: any) => ({
        id: item.allowanceTypeId,
        value: item.name,
      }));
      setAllowanceTypes(data);
    } catch (error) {
      console.error('Failed to fetch contract data:', error);
    }
  };

  useEffect(() => {
    getAllowanceTypes();
  }, [])

  const handleAddRow = () => {
    const newId = data.length + 1;
    const newRow = { id: newId, jenisTunjangan: '', nominal: '' };
    setData((prevData) => [...prevData, newRow]);
  };

  const handleUpdateRow = (id: number, field: string, value: string | number) => {
    const sanitizedValue =
      field === 'nominal' ? value.toString().replace(/[^0-9]/g, '') : value;
    setData((prevData) =>
      prevData.map((row) =>
        row.id === id ? { ...row, [field]: sanitizedValue } : row
      )
    );
  };

  const columns = [
    {
      header: 'No',
      accessor: (row: any) => (
        <HmTypography fontSize={14} color="text.secondary">
          {row.id}
        </HmTypography>
      ),
    },
    {
      header: 'Jenis Tunjangan',
      accessor: (row: any) => (
        <Box sx={{ width: '100%' }}>
          <FieldComponent
            type="dropdown"
            name="status"
            options={allowanceTypes}
            onChange={(event) =>
              handleUpdateRow(row.id, 'jenisTunjangan', event.target.value)
            }
            placeholder="Pilih Jenis Tunjangan"
            control={methods.control}
          />
        </Box>
      ),
    },
    {
      header: 'Nominal',
      accessor: (row: any) => (
        <HmTextField
          startIcon={<span style={{ color: '#000' }}>Rp</span>}
          value={row.nominal}
          onChange={(event: any) => {
            const selectedValue = event?.target?.value ?? event;
            handleUpdateRow(row.id, 'nominal', selectedValue);
          }}
          placeholder="Masukkan Nominal"
          type="text"
          fullWidth
        />
      ),
    }
  ];

  return (
    <Box>
      <HmTable
        data={data}
        columns={columns}
        page={0}
        rowsPerPage={data.length}
        totalItems={data.length}
        onPageChange={() => { }}
        handleRowsPerPageChange={() => { }}
        noPagination={true}
        showNumberColumn={false}
        loading={false}
      />

      <div style={{ marginTop: '16px', textAlign: 'right' }}>
        <ThemeProvider theme={theme}>
          <HmButton
            label="Tambah Tunjangan"
            icon={<ControlPoint />}
            labelColor={theme.palette.success.main}
            color="#ffffff"
            borderColor={theme.palette.success.main}
            variant="contained"
            borderRadius="10"
            onClick={handleAddRow}
            sx={{
              width: '100%',
              marginTop: '16px',
              padding: '12px',
              fontSize: '14px',
            }}
          />
        </ThemeProvider>
      </div>
    </Box>
  );
};

export default TableTunjangan;
