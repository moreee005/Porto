import * as React from 'react';
import { useDropzone } from 'react-dropzone';
import { Box, CardMedia } from '@mui/material';
import { HmButton } from '@/components/component';
import DeleteForeverOutlinedIcon from '@mui/icons-material/DeleteForeverOutlined';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';

interface HmPhotoUploaderProps {
  readonly onFileUpload: (file: File | null) => void;
  readonly initialPreview?: string;
  readonly width?: string;
  readonly height?: string;
  readonly borderRadius?: string;
}

const DeleteButtons = ({ handleDelete }: { handleDelete: () => void }) => (
  <Box
    sx={{
      position: 'absolute',
      top: 8,
      right: 8,
      display: 'flex',
      gap: 1,
    }}
  >
    <HmButton
      color="#FDFDFD"
      sx={{
        minWidth: '20px',
        width: '20px',
        aspectRatio: '1',
      }}
      borderRadius="4"
      label={
        <DeleteForeverOutlinedIcon
          style={{ color: '#CF1D1D', fontSize: '18px' }}
        />
      }
      onClick={(e) => {
        e.stopPropagation();
        handleDelete();
      }}
    />
  </Box>
);

export default function HmPhotoUploader({
  onFileUpload,
  initialPreview,
  width,
  height,
  borderRadius,
}: HmPhotoUploaderProps) {
  const [preview, setPreview] = React.useState<string | null>(
    initialPreview ?? null
  );
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    setPreview(
      initialPreview === '/thumbnail-default.png'
        ? null
        : (initialPreview ?? null)
    );
  }, [initialPreview]);

  const handleFileChange = (file: File | null) => {
    if (file) {
      setPreview(URL.createObjectURL(file));
      onFileUpload(file);
      setError(null);
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
    },
    onDrop: (acceptedFiles) => handleFileChange(acceptedFiles[0]),
  });

  const handleDelete = () => {
    setPreview(null);
    setError(null);
    onFileUpload(null);
  };

  return (
    <ThemeProvider theme={theme}>
      <Box
        sx={{
          width: width,
          height: height,
          position: 'relative',
          cursor: 'pointer',
          textAlign: 'center',
          backgroundColor: theme.palette.primary.light,
          borderRadius: borderRadius,
        }}
        {...getRootProps({
          onClick: (e) => {
            e.preventDefault();
          },
        })}
      >
        <input
          {...getInputProps({
            onChange: (event) => {
              const files = event.currentTarget.files;
              handleFileChange(files ? files[0] : null);
            },
          })}
        />

        {preview ? (
          <>
            <CardMedia
              component="img"
              image={preview}
              alt="Uploaded"
              sx={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                borderRadius: { borderRadius },
              }}
            />
            <DeleteButtons handleDelete={handleDelete} />
          </>
        ) : (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
            }}
          >
            {error ? (
              <>
                <p style={{ color: 'red' }}>{error}</p>
                <DeleteButtons handleDelete={handleDelete} />
              </>
            ) : (
              <>
                <img
                  src="/upload-image.svg"
                  alt="upload-placeholder"
                  width={40}
                  height={40}
                />
              </>
            )}
          </Box>
        )}
      </Box>
    </ThemeProvider>
  );
}
