import * as React from 'react';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import colors from '../colors';
import HmTypography from './HmTypography';
import { formatBreadcrumb } from '@/utils/truncate';

interface HmBreadcrumbsProps {
  pathname: string;
}

const HmBreadcrumbs: React.FC<HmBreadcrumbsProps> = ({ pathname }) => {
  let formattedBreadcrumb = formatBreadcrumb(pathname);

  // Remove the last element from the array if the length is more than 1
  if (formattedBreadcrumb.length > 1) {
    formattedBreadcrumb.pop();
  }

  const getColor = (index: number, length: number) => {
    if (length === 1) {
      return colors.palette.grey;
    } else if (length >= 1) {
      return index === 0 ? colors.palette.primary : colors.palette.grey;
    }

    return colors.palette.grey;
  };

  return (
    <Breadcrumbs
      aria-label="breadcrumb"
      separator={
        <HmTypography color={colors.palette.grey} fontSize={14}>
          /
        </HmTypography>
      }
      sx={{
        backgroundColor: colors.palette.white,
        height: 40,
        borderRadius: '8px',
        padding: '0 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Link
        underline="hover"
        sx={{ display: 'flex', alignItems: 'center' }}
        color="inherit"
      >
        <HomeIcon sx={{ width: 16, color: colors.palette.primary }} />
      </Link>

      {formattedBreadcrumb.map((segment, index) => (
        <HmTypography
          key={`${segment}-${index}`}
          fontSize={14}
          fontWeight={400}
          color={getColor(index, formattedBreadcrumb.length)}
        >
          {segment}
        </HmTypography>
      ))}
    </Breadcrumbs>
  );
};

export default HmBreadcrumbs;
