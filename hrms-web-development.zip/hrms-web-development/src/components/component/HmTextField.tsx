import { Visibility, VisibilityOff } from '@mui/icons-material';
import { IconButton, InputAdornment, TextField } from '@mui/material';
import React, { FC, KeyboardEventHandler } from 'react';

interface HmTextFieldProps {
  disabled?: boolean;
  endIcon?: React.ReactNode;
  error?: boolean;
  fullWidth?: boolean;
  width?: string;
  helperText?: string;
  isTextArea?: boolean;
  label?: string;
  maxLength?: number;
  name?: string;
  numberOnly?: boolean;
  placeholder?: string;
  required?: boolean;
  size?: 'small' | 'medium';
  startIcon?: React.ReactNode;
  type?: string;
  value?: string;
  variant?: 'outlined' | 'filled' | 'standard';
  onBlur?: () => void;
  onChange?: (value: string) => void;
  onEnter?: () => void;
  [key: string]: any;
  sx?: any;
}

const HmTextField: FC<HmTextFieldProps> = ({
  disabled = false,
  endIcon,
  error = false,
  fullWidth = true,
  width,
  helperText = '',
  isTextArea = false,
  label,
  maxLength = 1000,
  name,
  numberOnly = false,
  placeholder,
  required,
  size = 'small',
  startIcon,
  type,
  value = '',
  variant = 'outlined',
  onBlur = () => {},
  onChange = () => {},
  onEnter = () => {},
  sx = {},
  ...props
}): React.ReactElement => {
  const [showPassword, setShowPassword] = React.useState(false);

  const handleTogglePassword = () => {
    setShowPassword((prev) => !prev);
  };
  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ): void => {
    const tempValue = event.target.value;
    if (maxLength) {
      onChange(tempValue.toString().slice(0, maxLength));
    } else {
      onChange(event.target.value);
    }
  };

  const handleEnter: KeyboardEventHandler<HTMLDivElement> = (ev) => {
    if (ev.key === 'Enter') {
      return onEnter();
    }

    const allowKey: string[] = [
      'Backspace',
      'Delete',
      'ArrowDown',
      'ArrowUp',
      'ArrowRight',
      'ArrowLeft',
    ];
    if (allowKey.includes(ev?.key)) {
      return;
    }

    if (props?.type === 'number') {
      const NUMBER_REGEX: RegExp = numberOnly ? /^\d+$/ : /^[0-9,]+$/;
      if (!NUMBER_REGEX.test(ev?.key)) {
        ev?.preventDefault();
      }
    } else if (numberOnly) {
      const NUMBER_REGEX: RegExp = /^\d+$/;
      if (!NUMBER_REGEX.test(ev?.key)) {
        ev?.preventDefault();
      }
    }
  };

  return (
    <TextField
      label=""
      className="HmTextField"
      rows={4}
      id={name}
      name={name}
      type={type === 'password' && showPassword ? 'text' : type}
      size={size}
      error={error}
      variant={variant}
      disabled={disabled}
      value={value || ''}
      fullWidth={fullWidth}
      multiline={isTextArea}
      helperText={helperText}
      sx={{
        ...sx,
        width: width,
      }}
      {...props}
      slotProps={{
        input: {
          placeholder,
          startAdornment: startIcon && (
            <InputAdornment position="start">{startIcon}</InputAdornment>
          ),
          endAdornment: type === 'password' && (
            <InputAdornment position="end">
              <IconButton onClick={handleTogglePassword} edge="end">
                {showPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </InputAdornment>
          ),

          ...props?.slotProps?.input,
          ...props?.slotProps?.InputProps,
        },
        ...props?.slotProps,
      }}
      onBlur={onBlur}
      onChange={handleChange}
      onKeyDown={handleEnter}
    />
  );
};

export default HmTextField;
