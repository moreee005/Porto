import {
  Avatar,
  Box,
  Divider,
  Grid2,
  Stack,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import HmTypography from './HmTypography';

interface Notification {
  id: string;
  title: string;
  date: string;
  description: string;
  image: string;
  width?: string;
}

interface HmNotificationProps {
  itemProps: Notification[];
  total?: number;
  width?: string;
}

const HmNotification: React.FC<HmNotificationProps> = ({
  itemProps,
  total,
  width = '-webkit-fill-available',
}) => {
  const theme = useTheme();
  const isMd = useMediaQuery(theme.breakpoints.up('md'));
  return (
    <Box
      sx={{
        width: width,
        bgColor: 'white',
        borderRadius: 2,
        boxShadow: 3,
        p: 3,
      }}
    >
      <Stack>
        <HmTypography
          fontWeight={700}
          fontSize={16}
          bold
          sx={{ marginBottom: '25px' }}
        >
          Anda memiliki {total} notifikasi
        </HmTypography>
      </Stack>
      <Stack spacing={2}>
        {itemProps?.map((item) => (
          <Grid2
            key={item?.id}
            sx={{
              display: 'flex',
            }}
          >
            <Avatar
              src={item?.image}
              alt={item?.title}
              sx={{ width: 48, height: 48, mr: 2 }}
            />
            <Stack
              sx={{
                width: '100%',
              }}
            >
              <Grid2 container>
                <Grid2 size={{ xs: 12, md: 10 }}>
                  <HmTypography variant="subtitle1" bold>
                    {item?.title}
                  </HmTypography>
                </Grid2>
                <Grid2 size={{ xs: 12, md: 2 }}>
                  <HmTypography variant="body2" color="text.secondary">
                    {item?.date}
                  </HmTypography>
                </Grid2>
              </Grid2>
              <HmTypography variant="body2" color="text.secondary">
                {item?.description}
              </HmTypography>
            </Stack>
          </Grid2>
        ))}
      </Stack>
    </Box>
  );
};

export default HmNotification;
