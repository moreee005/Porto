import React, { useState } from 'react';
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  Pagination,
  TableRow,
  Skeleton,
  Button,
} from '@mui/material';
import { v4 as uuidv4 } from 'uuid';
import HmTypography from './HmTypography';

interface HmTableProps<T extends { id: string | number }> {
  readonly data: T[];
  readonly columns: {
    header: string;
    accessor: keyof T | ((row: T) => React.ReactNode);
    render?: (row: T) => React.ReactNode;
    sortable?: boolean;
  }[];
  readonly loading?: boolean;
  readonly page: number;
  readonly rowsPerPage: number;
  readonly totalItems: number;
  readonly onPageChange: (event: unknown, newPage: number) => void;
  readonly handleRowsPerPageChange: (value: number) => void;
  readonly noPagination?: boolean;
  readonly showNumberColumn?: boolean;
  readonly minWidth?: string | number;
  readonly onSort?: (column: keyof T) => void;
}

function HmTable<T extends { id: string | number }>({
  data,
  columns,
  loading = false,
  page,
  rowsPerPage,
  totalItems,
  onPageChange,
  handleRowsPerPageChange,
  noPagination = false,
  showNumberColumn = false,
  minWidth = '900px',
  onSort,
}: HmTableProps<T>) {
  const [sortConfig, setSortConfig] = useState<{
    key: keyof T | null;
    direction: 'asc' | 'desc' | null;
  }>({
    key: null,
    direction: null,
  });

  const handleSort = (column: keyof T) => {
    onSort?.(column);
    setSortConfig((prevConfig) => {
      if (prevConfig.key === column) {
        // Toggle direction
        const nextDirection = prevConfig.direction === 'asc' ? 'desc' : null;
        return { key: nextDirection ? column : null, direction: nextDirection };
      }
      return { key: column, direction: 'asc' };
    });
  };

  const totalPage = Math.ceil(totalItems / rowsPerPage);
  return (
    <ThemeProvider theme={theme}>
      <Box
        style={{
          overflowX: 'auto',
          width: '100%',
          marginTop: '1rem',
          marginBottom: '1rem',
        }}
      >
        <Table sx={{ minWidth }}>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#F6F9FC' }}>
              {showNumberColumn && <TableCell>No</TableCell>}
              {columns.map((column) => (
                <TableCell key={column.header}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      cursor: column.sortable ? 'pointer' : 'default',
                    }}
                    onClick={() =>
                      column.sortable && handleSort(column.accessor as keyof T)
                    }
                  >
                    <HmTypography
                      color="#989BB3"
                      small
                      semiBold
                      sx={{ textTransform: 'uppercase', whiteSpace: 'nowrap' }}
                    >
                      {column.header}
                    </HmTypography>
                    {/* Diamond-shaped sorting button */}
                    {column.sortable && (
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          cursor: 'pointer',
                        }}
                      >
                        <div
                          style={{
                            width: 0,
                            height: 0,
                            borderLeft: '6px solid transparent',
                            borderRight: '6px solid transparent',
                            borderBottom: `10px solid ${
                              sortConfig.key === column.accessor &&
                              sortConfig.direction === 'asc'
                                ? '#24283E'
                                : '#989BB3'
                            }`,
                          }}
                        />
                        <div
                          style={{
                            width: 0,
                            height: 0,
                            borderLeft: '6px solid transparent',
                            borderRight: '6px solid transparent',
                            borderTop: `10px solid ${
                              sortConfig.key === column.accessor &&
                              sortConfig.direction === 'desc'
                                ? '#24283E'
                                : '#989BB3'
                            }`,
                          }}
                        />
                      </div>
                    )}
                  </div>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {loading
              ? Array.from(new Array(rowsPerPage)).map(() => (
                  <TableRow key={uuidv4()}>
                    {showNumberColumn && (
                      <TableCell>
                        <Skeleton variant="text" />
                      </TableCell>
                    )}
                    {columns.map(() => (
                      <TableCell key={uuidv4()}>
                        <Skeleton variant="text" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              : data.map((row, index) => (
                  <TableRow key={row.id || index+'id'}>
                    {showNumberColumn && (
                      <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                    )}
                    {/* Menampilkan nomor urut */}
                    {columns.map((column) => (
                      <TableCell key={column.header}>
                        {column.render
                          ? column.render(row)
                          : typeof column.accessor === 'function'
                            ? column.accessor(row)
                            : (row[column.accessor] as React.ReactNode)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
          </TableBody>

          {!noPagination && ( // Sembunyikan footer jika noPagination adalah true
            <TableFooter>
              <TableRow>
                <TableCell colSpan={columns.length} sx={{ border: 'none' }}>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}
                  >
                    <div>
                      <HmTypography color="#24283E">Entries</HmTypography>
                      <Button
                        variant={rowsPerPage === 10 ? 'contained' : 'text'}
                        onClick={() => handleRowsPerPageChange(10)}
                        style={{
                          borderRadius: '50%',
                          width: '36px',
                          height: '36px',
                          minWidth: '36px',
                          marginLeft: '2rem',
                          boxShadow: 'none',
                          backgroundColor:
                            rowsPerPage === 10 ? '#E7E8EC' : 'white',
                          color: rowsPerPage === 10 ? '#24283E' : '#989BB3',
                        }}
                      >
                        10
                      </Button>
                      <Button
                        variant={rowsPerPage === 25 ? 'contained' : 'text'}
                        onClick={() => handleRowsPerPageChange(25)}
                        style={{
                          borderRadius: '50%',
                          width: '36px',
                          height: '36px',
                          minWidth: '36px',
                          margin: '0 5px',
                          boxShadow: 'none',
                          backgroundColor:
                            rowsPerPage === 25 ? '#E7E8EC' : 'white',
                          color: rowsPerPage === 25 ? '#24283E' : '#989BB3',
                        }}
                      >
                        25
                      </Button>
                      <Button
                        variant={rowsPerPage === 50 ? 'contained' : 'text'}
                        onClick={() => handleRowsPerPageChange(50)}
                        style={{
                          borderRadius: '50%',
                          width: '36px',
                          height: '36px',
                          minWidth: '36px',
                          margin: '0 5px',
                          boxShadow: 'none',
                          backgroundColor:
                            rowsPerPage === 50 ? '#E7E8EC' : 'white',
                          color: rowsPerPage === 50 ? '#24283E' : '#989BB3',
                        }}
                      >
                        50
                      </Button>
                    </div>
                    <div>
                      <Pagination
                        color="primary"
                        count={totalPage}
                        page={page + 1}
                        onChange={onPageChange}
                        showFirstButton
                        showLastButton
                      />
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            </TableFooter>
          )}
        </Table>
      </Box>
    </ThemeProvider>
  );
}

export default HmTable;
