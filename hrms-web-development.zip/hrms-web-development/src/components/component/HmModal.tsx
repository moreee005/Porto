import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Box,
} from '@mui/material';
import HmButton from './HmButton';
import colors from '../colors';
import Image from 'next/image';
import NoteWithPenIconWhite from '@public/icons/note-pen-white.svg';
import HmTypography from './HmTypography';
import CloseIcon from '@public/icons/close.svg';
interface HmModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  zIndex: number;
  maxWidth?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  isAction?: boolean;
  onClickAction?: () => void;
  labelAction?: string;
  colorActionButton?: string;
  isDisableButton?: boolean;
  isIconActionButton?: boolean;
  children: React.ReactNode;
}

const HmModal: React.FC<HmModalProps> = ({
  isOpen,
  onClose,
  title,
  zIndex,
  maxWidth = 'sm',
  isAction = false,
  onClickAction,
  labelAction = 'action',
  colorActionButton = colors.palette.primary,
  isDisableButton = false,
  isIconActionButton = false,
  children,
}) => {
  return (
    <Dialog
      open={isOpen}
      fullWidth
      maxWidth={maxWidth}
      aria-labelledby="title"
      sx={{
        '& .MuiDialog-paper': {
          borderRadius: '8 px',
          zIndex: zIndex,
        },
      }}
    >
      {title && (
        <DialogTitle fontWeight={600} fontSize={20} fontFamily={'unset'}>
          {title}
        </DialogTitle>
      )}
      <IconButton
        sx={{ position: 'absolute', top: 12, right: 8 }}
        onClick={onClose}
      >
        <Image
          src={CloseIcon}
          alt="close-icon"
          priority
          height={24}
          width={24}
        />
      </IconButton>
      <DialogContent dividers>{children}</DialogContent>
      {isAction && (
        <DialogActions>
          <HmButton
            fullWidth
            onClick={onClose}
            color={colors.palette.white}
            label={
              <HmTypography fontWeight={600} fontSize={16}>
                {'Batal'}
              </HmTypography>
            }
            borderColor={colors.palette.primary}
            labelColor={colors.palette.primary}
          />
          {!isIconActionButton && (
            <HmButton
              type="submit"
              fullWidth
              onClick={onClickAction}
              color={colorActionButton}
              label={
                <HmTypography
                  fontWeight={600}
                  fontSize={16}
                  style={{ color: 'white' }}
                >
                  {labelAction}
                </HmTypography>
              }
              disabled={isDisableButton}
            />
          )}
          {isIconActionButton && (
            <HmButton
              fullWidth
              onClick={onClickAction}
              color={colorActionButton}
              label={
                <Box
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.2rem',
                  }}
                >
                  {
                    <Image
                      src={NoteWithPenIconWhite}
                      alt="note-icon"
                      priority
                      height={12}
                      width={11.99}
                    />
                  }
                  <HmTypography fontWeight={600} fontSize={16}>
                    {labelAction}
                  </HmTypography>
                </Box>
              }
              disabled={isDisableButton}
            />
          )}
        </DialogActions>
      )}
    </Dialog>
  );
};

export default HmModal;
