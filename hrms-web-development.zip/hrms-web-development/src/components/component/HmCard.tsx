import React, { ReactNode } from 'react';
import { Card, CardContent, Divider, SxProps } from '@mui/material';

interface HmCardProps {
  headerContent?: ReactNode;
  bodyContent: ReactNode;
  cardStyles?: SxProps;
  headerStyles?: SxProps;
  bodyStyles?: SxProps;
  noDivider?: boolean;
  bodyOnly?: boolean;
}

const HmCard: React.FC<HmCardProps> = ({
  headerContent,
  bodyContent,
  cardStyles = {},
  headerStyles = {},
  bodyStyles = {},
  noDivider = false,
  bodyOnly = false,
}) => {
  return (
    <Card sx={{ margin: 'auto', borderRadius: '6px', ...cardStyles }}>
      {bodyOnly ? (
        <CardContent sx={{ ...bodyStyles }}>{bodyContent}</CardContent>
      ) : (
        <>
          {headerContent && (
            <CardContent sx={{ ...headerStyles }}>{headerContent}</CardContent>
          )}

          {!noDivider && headerContent && <Divider sx={{ marginX: 0 }} />}

          <CardContent sx={{ ...bodyStyles }}>{bodyContent}</CardContent>
        </>
      )}
    </Card>
  );
};

export default HmCard;
