import React from 'react';
import dayjs from 'dayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { FormControl } from '@mui/material';

interface HmDatePickerProps {
  name: string;
  value: any;
  onChange: (date: any) => void;
  error?: boolean;
  helperText?: string;
  disabled?: boolean;
  fullWidth?: boolean;
  format?: string;
}

const HmDatePicker: React.FC<HmDatePickerProps> = ({
  name,
  value,
  onChange,
  error = false,
  helperText = '',
  disabled = false,
  fullWidth = false,
  format = 'DD-MM-YYYY',
}) => {
  //   const formattedValue = value ? dayjs(value, format) : null;

  return (
    <FormControl fullWidth={fullWidth}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          name={name}
          format={'DD-MM-YYYY'}
          value={dayjs(value)}
          onChange={(date) => {
            onChange(date);
          }}
          disabled={disabled}
          slotProps={{
            textField: {
              variant: 'outlined',
              error: error,
              helperText: helperText,
              sx: {
                width: fullWidth ? '100%' : 'fit-content',
                '& .MuiInputBase-input': {
                  display: 'flex',
                  alignItems: 'center',
                  padding: '10px',
                },
              },
            },
          }}
          sx={{ width: '100%' }}
        />
      </LocalizationProvider>
    </FormControl>
  );
};

export default HmDatePicker;
