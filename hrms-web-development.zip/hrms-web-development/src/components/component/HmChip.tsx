import React from 'react';
import { Chip, SxProps } from '@mui/material';

interface HmChipProps {
  label: string;
  backgroundColor?: string;
  textColor?: string;
  fontSize?: string;
  sx?: SxProps;
}

const HmChip: React.FC<HmChipProps> = ({
  label,
  backgroundColor,
  textColor,
  fontSize = '14px',
  sx,
}) => {
  return (
    <Chip
      label={label}
      sx={{
        backgroundColor: backgroundColor ?? 'default',
        color: textColor ?? 'default',
        fontSize: fontSize,
        fontWeight: 600,
        ...sx,
      }}
    />
  );
};

export default HmChip;
