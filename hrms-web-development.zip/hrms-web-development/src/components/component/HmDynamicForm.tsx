'use client';

import React, { useState, useEffect } from 'react';
import { Box, FormHelperText } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import HmTable from './HmTable';
import HmButton from './HmButton'; // Pastikan HmButton diimport
import { FiTrash } from 'react-icons/fi'; // Ikon untuk tombol delete
import { ThemeProvider } from '@emotion/react';
import theme from '@/utils/theme';
import HmTypography from './HmTypography';
import { FieldComponent } from '@/components/component';
import { Control, useController } from 'react-hook-form';
import colors from '../colors';

interface Option {
  id: string | number; // id bisa berupa string atau number
  value: string;
}
interface Column {
  header: string;
  field: string; // Nama properti data untuk form
  type: string; // Tipe input (textfield, select, autocomplete, dll)
  options: Option[];
  placeholder?: string; // Placeholder untuk input
  flex?: boolean;
  size?: 'small' | 'medium' | undefined;
  inputType?: string;
  visibilityToggle?: boolean;
  hideLabel?: boolean;
  sx?: React.CSSProperties;
  fullWidth?: boolean;
}

interface RowData {
  id: string; // ID unik untuk setiap baris
  [key: string]: string; // Properti dinamis lainnya
}

interface DynamicFormTableProps {
  name: string;
  label: string;
  required: boolean;
  columns: Column[];
  buttonText: string;
  control: Control<any>;
  upload?: boolean;
}

const DynamicFormTable: React.FC<DynamicFormTableProps> = ({
  columns,
  buttonText,
  control,
  name,
  label,
  required,
  upload = false,
}) => {
  const [rows, setRows] = useState<RowData[]>(() => {
    if (upload) {
      return [
        { id: 'ktp', documentType: 'KTP', document: '' },
        { id: 'kk', documentType: 'KK', document: '' }
      ];
    }
    return [];
  });

  const {
    fieldState: { error },
  } = useController({
    name,
    control,
  });

  useEffect(() => {
    if (upload && rows.length < 2) {
      setRows([
        { id: 'ktp', documentType: 'KTP', document: '' },
        { id: 'kk', documentType: 'KK', document: '' }
      ]);
    }
  }, [upload]);

  const addRow = () => {
    if (upload) {
      const newRow: RowData = {
        id: Date.now().toString(),
        documentType: '',
        document: ''
      };
      setRows([...rows, newRow]);
    } else {
      const newRow: RowData = columns.reduce(
        (acc, column) => {
          acc[column.field] = ''; // Inisialisasi dengan string kosong
          return acc;
        },
        { id: Date.now().toString() } as RowData // Tambahkan ID unik
      );
      setRows([...rows, newRow]);
    }
  };

  const handleDelete = (rowId: string) => {
    if (upload && (rowId === 'ktp' || rowId === 'kk')) {
      return; // Prevent deletion of KTP and kk rows when upload is true
    }
    setRows(rows.filter((row) => row.id !== rowId));
  };

  const renderActionCell = (row: RowData, column: Column) => {
    if (upload) {
      const isDefaultRow = row.id === 'ktp' || row.id === 'kk';

      if (column.field === 'documentType') {
        if (isDefaultRow) {
          return <HmTypography>{row.documentType}</HmTypography>;
        } else {
          return (
            <FieldComponent
              name={`${name}[${rows.findIndex((r) => r.id === row.id)}].${column.field}`}
              label={column.header}
              type="dropdown"
              options={column.options}
              required={true}
              control={control}
              placeholder={column.placeholder}
              size={column.size}
              hideLabel={column.hideLabel}
              fullWidth={column.fullWidth}
            />
          );
        }
      } else if (column.field === 'document') {
        return (
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <HmTypography color={colors.palette.primary}>{row.document || "-"}</HmTypography>
          </Box>
        );
      }
    }

    return (
      <FieldComponent
        name={`${name}[${rows.findIndex((r) => r.id === row.id)}].${column.field}`}
        label={column.header}
        type={column.type}
        options={column.options}
        placeholder={column.placeholder}
        required={true} // Atur sesuai kebutuhan
        control={control}
        flex={column.flex}
        size={column.size}
        inputType={column.inputType}
        visibilityToggle={column.visibilityToggle}
        hideLabel={column.hideLabel}
        sx={column.sx}
        fullWidth={column.fullWidth}
      />
    );
  };

  const renderActionButton = (
    rowId: string,
    onDelete: (id: string) => void
  ) => (
    <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
      {upload && (
        <FieldComponent
          name={`${name}[${rows.findIndex((r) => r.id === rowId)}].document`}
          type="document"
          fullWidth={false}
          fieldLabel='Upload Dokumen'
          control={control}
          onFileNameChange={fileName => {
            const updatedRows = rows.map(row =>
              row.id === rowId ? { ...row, document: fileName } : row
            );
            setRows(updatedRows);
          }}
        />
      )}
      <HmButton
        icon={<FiTrash size={16} />}
        labelColor={theme.palette.error.main}
        color={theme.palette.error.light}
        borderRadius="10"
        sx={{
          minWidth: '28px',
          width: '28px',
          height: '28px',
        }}
        onClick={() => onDelete(rowId)}
        disabled={upload && (rowId === 'ktp' || rowId === 'kk')}
      />
    </Box>
  );

  const tableColumns = [
    ...columns.map((column) => ({
      header: column.header,
      accessor: (row: RowData) => renderActionCell(row, column),
    })),
    {
      header: 'Aksi',
      accessor: (row: RowData) => renderActionButton(row.id, handleDelete),
    },
  ];

  return (
    <ThemeProvider theme={theme}>
      <Box>
        {label && (
          <HmTypography sx={{ marginBottom: '4px' }}>
            {label} {required && <span style={{ color: 'red' }}>*</span>}
          </HmTypography>
        )}
        <HmTable
          data={rows}
          columns={tableColumns}
          page={0}
          rowsPerPage={rows.length}
          totalItems={rows.length}
          onPageChange={() => { }}
          handleRowsPerPageChange={() => { }}
          noPagination={true}
          showNumberColumn={true}
        />

        <HmButton
          variant="outlined"
          color="white"
          borderColor={theme.palette.success.main}
          labelColor={theme.palette.success.main}
          icon={<AddCircleOutlineIcon />}
          onClick={addRow}
          sx={{ marginTop: '1rem' }}
          fullWidth
          label={<HmTypography bold>{buttonText}</HmTypography>}
          gapIcon="1rem"
        />
        <FormHelperText
          sx={{
            overflowWrap: 'break-word',
            visibility: error ? 'visible' : 'hidden',
            color: error ? 'red' : 'black',
            marginLeft: '16px !important',
          }}
        >
          {error?.message ?? ''}
        </FormHelperText>
      </Box>
    </ThemeProvider>
  );
};

export default DynamicFormTable;
