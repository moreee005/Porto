import * as React from 'react';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

interface Option {
  id: string | number;
  value: string;
}

interface HmDropdownProps {
  options: Option[];
  value: string | number;
  onChange: (event: SelectChangeEvent<string | number>) => void;
  disabled?: boolean;
  size?: 'small' | 'medium';
  sx?: any;
  placeholder?: string;
}

const HmDropdown: React.FC<HmDropdownProps> = ({
  options,
  value,
  onChange,
  disabled = false,
  size = 'small',
  sx = {},
  placeholder = 'Select an option',
}) => {
  return (
    <Select
      value={value || ''}
      onChange={onChange}
      displayEmpty
      disabled={disabled}
      sx={sx}
      size={size}
    >
      <MenuItem value="" disabled>
        {placeholder}
      </MenuItem>
      {options.map((option) => (
        <MenuItem key={option.id} value={option.id}>
          {option.value}
        </MenuItem>
      ))}
    </Select>
  );
};

export default HmDropdown;
