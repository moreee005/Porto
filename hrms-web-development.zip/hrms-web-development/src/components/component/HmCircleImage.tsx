import React from 'react';

interface ImageComponentProps {
  src: string;
  alt: string;
  size?: string | number;
  className?: string;
}

const ImageComponent: React.FC<ImageComponentProps> = ({
  src,
  alt,
  size = 100,
  className,
}) => {
  return (
    <img
      src={src}
      alt={alt}
      width={size}
      height={size}
      className={className}
      style={{
        borderRadius: '50%',
        objectFit: 'cover',
        width: size,
        height: size,
      }}
    />
  );
};

export default ImageComponent;
