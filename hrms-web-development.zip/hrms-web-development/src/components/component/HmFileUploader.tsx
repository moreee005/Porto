import * as React from 'react';
import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import UploadIcon from '@mui/icons-material/Upload';
import { HmTypography } from '@/components/component';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

type HmFileUploaderProps = {
  readonly onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  readonly nameUpload?: React.ReactNode;
};

export default function HmFileUploader({ onChange, nameUpload }: HmFileUploaderProps) {
  return (
    <React.Fragment>
      {nameUpload ? (
        <Button
          component="label"
          role={undefined}
          variant="contained"
          tabIndex={-1}
        >
          <HmTypography semiBold small>
            {nameUpload || 'Upload Dokumen'}
          </HmTypography>
          <VisuallyHiddenInput type="file" onChange={onChange} multiple />
        </Button>
      ) : (
        <Button
          component="label"
          role={undefined}
          variant="contained"
          tabIndex={-1}
          startIcon={<UploadIcon />}
          sx={{
            backgroundColor: '#5557CD',
            color: 'white',
            '&:hover': {
              backgroundColor: '#5557CD',
            },
          }}

        >
          <HmTypography semiBold small>
            Upload Dokumen Kontrak
          </HmTypography>

          <VisuallyHiddenInput type="file" onChange={onChange} multiple />
        </Button>
      )}
    </React.Fragment >
  );
}
