import React, { useEffect, useState } from 'react';
import { InputAdornment, TextField } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

interface HmSearchProps {
  searchValue: string;
  onSearchChange: (value: string) => void;
  size?: 'small' | 'medium';
  sx?: any;
  width?: string;
  borderRadius?: string;
  placeholder?: string;
  fullWidth?: boolean;
  debounceTime?: number; // milidetik
}

const HmSearch: React.FC<HmSearchProps> = ({
  searchValue,
  onSearchChange,
  size = 'small',
  width,
  borderRadius = '8px',
  sx = {},
  placeholder = 'Cari..',
  fullWidth = false,
  debounceTime = 275,
}) => {
  const [localValue, setLocalValue] = useState(searchValue);

  
  useEffect(() => {
    setLocalValue(searchValue);
  }, [searchValue]);

  // Debounce
  useEffect(() => {
    const handler = setTimeout(() => {
      onSearchChange(localValue);
    }, debounceTime);

    return () => {
      clearTimeout(handler);
    };
  }, [localValue, debounceTime]);
  
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <TextField
        variant="outlined"
        placeholder={placeholder}
        size={size}
        fullWidth={fullWidth}
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon style={{ marginRight: '8px' }} />
              </InputAdornment>
            ),
          },
        }}
        value={localValue}
        onChange={(event) => setLocalValue(event.target.value)}
        sx={{
          ...sx,
          width: width,
          '& .MuiOutlinedInput-root': {
            borderRadius: borderRadius,
          },
        }}
      />
    </div>
  );
};

export default HmSearch;
