import * as React from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import { TextField } from '@mui/material';

interface Option {
  id: string | number;
  value: string;
}

interface HmAutoCompleteProps {
  options: Option[];
  label?: string;
  placeholder?: string;
  onChange?: (event: React.SyntheticEvent, value: number | null) => void;
  size?: 'small' | 'medium';
  width?: string;
  borderRadius?: string;
  sx?: any;
  value?: number | null;
  disableClearable?: boolean;
}

const HmAutoComplete: React.FC<HmAutoCompleteProps> = ({
  options,
  label,
  placeholder,
  onChange,
  size = 'small',
  width,
  borderRadius = '8px',
  sx = {},
  value = null,
  disableClearable = false,
}) => {
  return (
    <Autocomplete
      disablePortal
      options={options}
      getOptionLabel={(option) => option.value} // Menggunakan `value` sebagai label
      disableClearable={disableClearable}
      value={options.find((option) => option.id === value) || null} // Cocokkan `id` dengan nilai
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={placeholder}
          size={size}
          sx={{
            ...sx,
            width: width,
            '& .MuiOutlinedInput-root': {
              borderRadius: borderRadius,
              fontWeight: 'normal',
            },
            '& .MuiInputLabel-root': {
              fontWeight: 'normal',
            },
          }}
        />
      )}
      renderOption={(props, option) => (
        <li {...props} key={option.id}>
          {option.value}
        </li>
      )}
      onChange={(event, newValue) => {
        const id = typeof newValue?.id === 'number' ? newValue.id : null;
        onChange?.(event, id);
      }}
    />
  );
};

export default HmAutoComplete;
