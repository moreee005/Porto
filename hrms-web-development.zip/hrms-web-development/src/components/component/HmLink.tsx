import React, { FC } from 'react';
import HmTypography from './HmTypography';

interface HmLinkProps {
  href: string;
  children: React.ReactNode;
  color?: string;
  onClick?: () => void;
}

const HmLink: FC<HmLinkProps> = ({
  href,
  children,
  color = 'blue',
  onClick,
}) => {
  return (
    <a
      href={href}
      onClick={onClick}
      style={{
        textDecoration: 'none',
        color: color,
        cursor: 'pointer',
        fontSize: '14px',
      }}
    >
      <HmTypography color={color}>{children}</HmTypography>
    </a>
  );
};

export default HmLink;
