'use client';

import React, { useState } from 'react';
import { Tabs, Tab, Box, Divider } from '@mui/material';
import colors from '@/components/colors';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

interface HmTabsProps {
  tabs: {
    label: string;
    content: React.ReactNode;
    icon?: React.ReactElement;
  }[];
}

const HmTabs: React.FC<HmTabsProps> = ({ tabs }) => {
  const [value, setValue] = useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Tabs
        value={value}
        onChange={handleChange}
        aria-label="basic tabs example"
        variant="scrollable"
        scrollButtons="auto"
        sx={{
          px: '2%',
          overflowX: 'auto',
          whiteSpace: 'nowrap',
          '& .MuiTabs-indicator': {
            backgroundColor: colors.palette.primary,
          },
        }}
      >
        {tabs.map((tab, index) => (
          <Tab
            key={index}
            label={tab.label}
            icon={
              tab.icon
                ? React.cloneElement(tab.icon, { sx: { fontSize: 16 } })
                : undefined
            }
            iconPosition="start"
            sx={{
              '&.Mui-selected': {
                color: colors.palette.primary,
              },
              fontSize: 16,
            }}
          />
        ))}
      </Tabs>
      <Divider sx={{ mx: 0 }} />
      {tabs.map((tab, index) => (
        <TabPanel key={index} value={value} index={index}>
          {tab.content}
        </TabPanel>
      ))}
    </Box>
  );
};

export default HmTabs;
