import React from 'react';

interface HmDividerProps {
  sx?: React.CSSProperties;
}

const HmDivider: React.FC<HmDividerProps> = ({ sx }) => {
  return (
    <div
      style={{
        width: '100%',
        height: '1px',
        backgroundColor: '#ccc',
        margin: '16px 0',
        ...sx,
      }}
    ></div>
  );
};

export default HmDivider;
