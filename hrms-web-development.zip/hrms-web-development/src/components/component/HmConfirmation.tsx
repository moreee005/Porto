import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid2';
import HmButton from './HmButton';
import HmTypography from './HmTypography';
import { IoMdClose } from 'react-icons/io';

interface ConfirmationProps {
  readonly open: boolean;
  readonly onClose: () => void;
  readonly onConfirm: () => void;
  readonly title: React.ReactNode;
  readonly content: React.ReactNode;
  readonly rightContent?: React.ReactNode;
  readonly confirmLabel?: React.ReactNode;
  readonly cancelLabel?: React.ReactNode;
  readonly fullWidth?: boolean;
  readonly split?: boolean;
  readonly centeredTitle?: boolean;
  readonly centeredContent?: boolean;
  readonly icon?: React.ReactNode;
  readonly fixedWidth?: string;
  readonly confirmDisabled?: boolean;
  readonly onCloseX?: () => void;
  readonly noCloseX?: boolean;
  readonly confirmationLoading?: boolean;
}

export default function Confirmation({
  open,
  onClose,
  onConfirm,
  title,
  content,
  rightContent,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  fullWidth = false,
  split = false,
  centeredTitle = false,
  centeredContent = false,
  icon,
  fixedWidth,
  confirmDisabled = false,
  onCloseX,
  noCloseX,
  confirmationLoading = false,
}: ConfirmationProps) {
  const handleConfirm = () => {
    onConfirm();
  };

  return (
    <Dialog
      open={open}
      onClose={() => {}}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      PaperProps={{
        sx: {
          borderRadius: '8px',
          maxWidth: '80%',
          width: fixedWidth ?? 'auto',
          overflow: 'hidden',
        },
      }}
    >
      <DialogTitle
        id="alert-dialog-title"
        sx={{
          padding: '1.5rem 2rem',
          textAlign: centeredTitle ? 'center' : 'left',
        }}
      >
        <Grid container spacing={2}>
          <Grid size={{ md: noCloseX ? 12 : 11, xs: noCloseX ? 12 : 10 }}>
            {icon && <span style={{ marginRight: '0.5rem' }}>{icon}</span>}
            {title}
          </Grid>
          {!noCloseX && (
            <Grid size={{ md: 1, xs: 2 }}>
              <HmButton
                color="inherit"
                label={
                  <HmTypography big>
                    <IoMdClose />
                  </HmTypography>
                }
                variant="text"
                onClick={onCloseX ?? onClose}
              />
            </Grid>
          )}
        </Grid>
      </DialogTitle>
      {<Divider />}
      <DialogContent
        sx={{
          padding: '1.5rem 2rem',
          textAlign: centeredContent ? 'center' : 'left',
        }}
      >
        {split ? (
          //menampilkan kontent jika konten perlu dibagi 2
          <Grid container spacing={2}>
            <Grid size={6}>
              <div>{content}</div>
            </Grid>
            <Grid size={5}>
              <div>{rightContent}</div>
            </Grid>
          </Grid>
        ) : (
          <div>{content}</div>
        )}
      </DialogContent>
      {<Divider />}
      <DialogActions sx={{ justifyContent: 'center', padding: '1.5rem 2rem' }}>
        <Grid
          container
          spacing={2}
          direction={{ xs: 'column', sm: 'row' }}
          justifyContent="center"
        >
          {cancelLabel && (
            <Grid size={{ xs: 12, sm: 6 }} order={{ xs: 1, sm: 0 }}>
              <HmButton
                onClick={onClose}
                color="inherit"
                variant="outlined"
                label={cancelLabel}
                fullWidth={fullWidth}
                sx={{ padding: '0.7rem 2rem', minWidth: '240px' }}
              />
            </Grid>
          )}
          {confirmLabel && (
            <Grid size={{ xs: 12, sm: 6 }} order={{ xs: 0, sm: 1 }}>
              <HmButton
                onClick={handleConfirm}
                color="primary"
                variant="contained"
                label={confirmLabel}
                fullWidth={fullWidth}
                disabled={confirmDisabled}
                sx={{ padding: '0.7rem 2rem', minWidth: '240px' }}
                loading={confirmationLoading}
              />
            </Grid>
          )}
        </Grid>
      </DialogActions>
    </Dialog>
  );
}
