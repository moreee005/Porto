'use client';

import React from 'react';
import { Box, Stepper, Step, StepLabel, Typography, StepConnector } from '@mui/material';
import { styled } from '@mui/system';
import HmTypography from './HmTypography';

interface HmStepperProps {
    activeStep: number;
    steps: { id: string; label: string }[];
}

// Styled component
const CustomStep = styled(Step)(({ theme }) => ({
    '& .MuiStepIcon-root': {
        color: 'grey',
        fontSize: '2rem',
        '&.Mui-active': {
            color: '#5557CD',
        },
        '&.Mui-completed': {
            color: '#5557CD',
        },
    },
}));

// Styled component fot sizing
const CustomStepConnector = styled(StepConnector)(({ theme }) => ({

    backgroundColor: 'grey',
    width: '40%',
    margin: '0 auto',
    transform: 'translateY(10px)',
    '&.Mui-active': {
        backgroundColor: 'black',
    },
    '&.Mui-completed': {
        backgroundColor: 'black',
    },
}));

const HmStepper: React.FC<HmStepperProps> = ({ activeStep, steps }) => {
    return (
        <Box sx={{ width: '100%', margin: 'auto', my: 4 }}>
            <Stepper activeStep={activeStep} alternativeLabel connector={<CustomStepConnector />}>
                {steps.map((step) => (
                    <CustomStep key={step.id}>
                        <StepLabel>
                            <HmTypography
                                sx={{
                                    fontWeight:
                                        activeStep === steps.indexOf(step) ? 'bold' : 'normal',
                                }}
                            >
                                {step.label}
                            </HmTypography>
                        </StepLabel>
                    </CustomStep>
                ))}
            </Stepper>
        </Box>
    );
};

export default HmStepper;
