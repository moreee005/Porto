import { API } from '@/services/setupAxios';
import { useState, useEffect, useRef } from 'react';

interface DropdownOption {
    id: number | string;
    value: string;
    label: string;
}

// Cache to store fetched data from API
const cache = new Map<string, DropdownOption[]>();

function useFetchDropdown(endpoint: string, customMapper?: (item: any) => DropdownOption) {
    const [options, setOptions] = useState<DropdownOption[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const didFetch = useRef(false); // Prevent multiple fetches

    useEffect(() => {
        const fetchData = async () => {
            if (didFetch.current) return; // Prevent multiple calls
            didFetch.current = true;

            // Check if data already exists in cache
            if (cache.has(endpoint)) {
                setOptions(cache.get(endpoint)!);
                return;
            }

            setLoading(true);
            setError(null);

            try {
                // Call the API using the provided endpoint
                const result = await API(endpoint);

                // map data
                const data = result.data?.data;
                if (Array.isArray(data)) {
                    const formattedOptions = data.map(customMapper || defaultMapper);
                    setOptions(formattedOptions);

                    // Save result to cache
                    cache.set(endpoint, formattedOptions);
                } else {
                    throw new Error('Invalid response format: data is not an array');
                }
            } catch (err) {
                console.error('Error fetching data:', err);
                setError('Network error or server is unreachable');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [endpoint, customMapper]);

    const defaultMapper = (item: any): DropdownOption => ({
        id: item.contractTypeId || item.id,
        value: item.name || item.label || String(item.id),
        label: item.name || item.label || String(item.value),
    });

    return { options, loading, error };
}

export default useFetchDropdown;
