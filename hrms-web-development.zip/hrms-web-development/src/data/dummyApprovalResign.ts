import { UUIDTypes } from 'uuid/dist/cjs/types';

interface ContractExtendDetailData {
  status: number;
  message: string;
  errorCode: string;
  data: {
    approvalId: UUIDTypes;
    employeeDetail: {
      id: number;
      fullName: string;
      division: string;
      contractStatus: string;
      position: string;
    };
    contractInfo: {
      status: string;
      placementType: string;
      employeeType: string;
      bankPlacement: string;
      division: string;
      position: string;
      contractStartDate: string;
      contractEndDate: string;
      generation: string;
      contractDocument: string; // url minio
      contractDocumentName: string;
      salary: number;
    };
    placementAllowance: {
      id: number;
      allowanceType: string;
      amount: number;
    }[];
    otherAllowance: {
      id: number;
      allowanceType: string;
      amount: number;
    }[];
  };
}

export const contractExtendDetailData: ContractExtendDetailData = {
  status: 200,
  message: 'Success',
  errorCode: '',
  data: {
    approvalId: '123e4567-e89b-12d3-a456-426614174000' as UUIDTypes,  // Contoh UUID
    employeeDetail: {
      id: 1,
      fullName: 'Afdal Ramdan',
      division: 'KTI',
      contractStatus: 'Fulltime',
      position: 'UI/UX Designer',
    },
    contractInfo: {
      status: 'Fulltime',
      placementType: 'Bandung',
      employeeType: 'Talent',
      bankPlacement: 'Bersedia',
      division: 'KTI',
      position: 'UI/UX Designer',
      contractStartDate: '17/07/1996',
      contractEndDate: '17/07/1997',
      generation: 'JTK',
      contractDocument: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      contractDocumentName: 'contract-document.pdf',
      salary: 5000000,
    },
    placementAllowance: [
      {
        id: 1,
        allowanceType: 'Tunjangan Bandung',
        amount: 1000000,
      },
      {
        id: 2,
        allowanceType: 'Tunjangan Jakarta',
        amount: 1000000,
      },
      {
        id: 3,
        allowanceType: 'Tunjangan Hybrid',
        amount: 500000,
      },
    ],
    otherAllowance: [
      {
        id: 1,
        allowanceType: 'Tunjangan Akhir Kontrak',
        amount: 5000000,
      },
      {
        id: 2,
        allowanceType: 'Tunjangan Resign',
        amount: 200000,
      },
    ],
  },
};
