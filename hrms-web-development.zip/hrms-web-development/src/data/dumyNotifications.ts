export const DummyNotification = {
  data: [
    {
      id: 1,
      title: 'New Message',
      message: 'Hello, You have a new message from a friend',
      time: 'Just Now',
      icon: 'message',
    },
    {
      id: 2,
      title: 'New Order',
      message: 'A new order has been placed',
      time: 'Just Now',
      icon: 'order',
    },
    {
      id: 3,
      title: 'New Customer',
      message: 'New customer has registered',
      time: 'Just Now',
      icon: 'customer',
    },
    {
      id: 4,
      title: 'New Review',
      message: 'New Review has been received',
      time: 'Just Now',
      icon: 'review',
    },
  ],
};

export const DummyNotificationPersetujuan = {
  data: [],
  total: 8,
};

export const DummyNotificationContract = {
  data: [],
  total: 4,
};
