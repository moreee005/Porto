import { UUIDTypes } from 'uuid/dist/cjs/types';

interface DummyApprovalKaryawanBaru {
  status: number;
  message: string;
  errorCode: string;
  data: {
    approvalId: UUIDTypes;
    employeeDetail: {
      id: number;
      fullName: string;
      gender: string;
      placeOfBirth: string;
      dateOfBirth: string;
      ethnicity: string;
      religion: string;
      bloodType: string;
      maritalStatus: string;
      email: string;
      phoneNumber: string;
      emergencyContact: {
        name: string;
        phoneNumber: string;
        relationship: string;
      };
      background: string;
      homeAddress: {
        fullAddress: string;
        province: string;
        city: string;
        district: string;
        subdistrict: string;
        postalCode: string;
      };
      motherIdentity: {
        name: string;
        dateOfBirth: string;
        highestEducation: string;
        occupation: string;
        salary: string;
        phoneNumber: string;
        statusAlive: string;
        address: string;
      };
      fatherIdentity: {
        name: string;
        dateOfBirth: string;
        highestEducation: string;
        occupation: string;
        salary: string;
        phoneNumber: string;
        statusAlive: string;
        address: string;
        province: string;
        city: string;
        district: string;
        subdistrict: string;
        postalCode: string;
      };
      spouseIdentity: {
        partnerName: string;
        partnerAge: number;
        partnerHighestEducation: string;
        partnerOccupation: string;
        partnerSalary: string;
        separateTax: string;
        partnerAddress: string;
      };
      familyOrder: {
        childNumber: number;
        totalSiblings: number;
      };
      siblings: {
        id: number;
        gender: string;
        dateOfBirth: string;
        occupation: string;
        educationLevel: string;
      }[];
      familyMembersInKK: {
        idMember: number;
        gender: string;
        dateOfBirth: string;
        occupation: string;
        education: string;
        yearJoined: number;
        major: string;
      }[];
      educationHistory: {
        idEducation: number;
        jenjang: string;
        institutionName: string;
        location: string;
        startDate: string;
        month: string;
        year: number;
        endDate: string;
      }[];
      coursesOrUpgrading: {
        idCourse: number;
        type: string;
        courseName: string;
        city: string;
        date: string;
        month: string;
        year: number;
        durationMonths: number;
        institution: string;
        certificateNumber: string;
      }[];
      workExperience: {
        idWorkExperience: number;
        companyName: string;
        position: string;
        city: string;
        startYear: number;
        endYear: number;
        durationMonths: number;
      }[];
      organizationalLife: {
        organizationId: number;
        organizationName: string;
        yearInPosition: string;
        position: string;
        memberCount: number;
        city: string;
        durationMonths: number;
      }[];
      sports: {
        sport: string;
        activePassive: string;
      }[];
      art: string[];
      other: {
        foreignLanguageProficiency: string[];
        hobbies: string[];
        active: string;
      }[];
    };
    contractInfo: {
      status: string;
      placementType: string;
      employeeType: string;
      bankPlacement: string;
      division: string;
      position: string;
      contractStartDate: string;
      contractEndDate: string;
      generation: string;
      contractDocument: string; // url minio
      contractDocumentName: string;
      salary: number;
    };
    placementAllowance: {
      id: number;
      allowanceType: string;
      amount: number;
    }[];
    otherAllowance: {
      id: number;
      allowanceType: string;
      amount: number;
    }[];
  };
}

export const dummyApprovalKaryawanBaru: DummyApprovalKaryawanBaru = {
  status: 200,
  message: 'Data retrieved successfully',
  errorCode: '',
  data: {
    approvalId: '123456',
    employeeDetail: {
      id: 1,
      fullName: 'John Doe',
      gender: 'Laki-laki',
      placeOfBirth: 'Jakarta',
      dateOfBirth: '1990-01-15',
      ethnicity: 'Jawa',
      religion: 'Islam',
      bloodType: 'O',
      maritalStatus: 'Menikah',
      email: 'johndoe@example.com',
      phoneNumber: '081234567890',
      emergencyContact: {
        name: 'Jane Doe',
        phoneNumber: '082345678901',
        relationship: 'Istri',
      },
      background: 'IT',
      homeAddress: {
        fullAddress: 'Jl. Merdeka No. 10',
        province: 'DKI Jakarta',
        city: 'Jakarta Selatan',
        district: 'Kebayoran Baru',
        subdistrict: 'Kebayoran Lama',
        postalCode: '12130',
      },
      motherIdentity: {
        name: 'Siti Aminah',
        dateOfBirth: '1965-05-22',
        highestEducation: 'S1',
        occupation: 'Guru',
        salary: '5000000',
        phoneNumber: '081234567891',
        statusAlive: 'Hidup',
        address: 'Jl. Melati No. 5, Jakarta',
      },
      fatherIdentity: {
        name: 'Ahmad Yani',
        dateOfBirth: '1960-11-10',
        highestEducation: 'S2',
        occupation: 'Pengusaha',
        salary: '10000000',
        phoneNumber: '081234567892',
        statusAlive: 'Hidup',
        address: 'Jl. Melati No. 5, Jakarta',
        province: 'DKI Jakarta',
        city: 'Jakarta Selatan',
        district: 'Kebayoran Baru',
        subdistrict: 'Kebayoran Lama',
        postalCode: '12130',
      },
      spouseIdentity: {
        partnerName: 'Anna Maria',
        partnerAge: 28,
        partnerHighestEducation: 'S1',
        partnerOccupation: 'Dokter',
        partnerSalary: '15000000',
        separateTax: 'Tidak',
        partnerAddress: 'Jl. Mawar No. 3, Jakarta',
      },
      familyOrder: {
        childNumber: 1,
        totalSiblings: 3,
      },
      siblings: [
        {
          id: 1,
          gender: 'Perempuan',
          dateOfBirth: '1995-08-18',
          occupation: 'Mahasiswa',
          educationLevel: 'S1',
        },
        {
          id: 2,
          gender: 'Perempuan',
          dateOfBirth: '1995-08-18',
          occupation: 'Mahasiswa',
          educationLevel: 'S1',
        },
      ],
      familyMembersInKK: [
        {
          idMember: 1,
          gender: 'Laki-laki',
          dateOfBirth: '2020-10-25',
          occupation: 'Tidak Bekerja',
          education: 'Belum Sekolah',
          yearJoined: 2020,
          major: 'N/A',
        },
        {
          idMember: 2,
          gender: 'Laki-laki',
          dateOfBirth: '2020-10-25',
          occupation: 'Tidak Bekerja',
          education: 'Belum Sekolah',
          yearJoined: 2020,
          major: 'N/A',
        },
      ],
      educationHistory: [
        {
          idEducation: 1,
          jenjang: 'kuliah',
          institutionName: 'Universitas Indonesia',
          location: 'Jakarta',
          startDate: '2010-08-01',
          month: 'August',
          year: 2014,
          endDate: '2014-12-01',
        },
        {
          idEducation: 2,
          jenjang: 'sma',
          institutionName: 'SMA Indonesia',
          location: 'Jakarta',
          startDate: '2006-08-01',
          month: 'August',
          year: 2006,
          endDate: '2009-06-01',
        },
      ],
      coursesOrUpgrading: [
        {
          idCourse: 1,
          type: 'Kursus',
          courseName: 'Web Programming',
          city: 'Jakarta',
          date: '2018-05-10',
          month: 'May',
          year: 2018,
          durationMonths: 6,
          institution: 'Tech Academy',
          certificateNumber: 'TA123456',
        },
        {
          idCourse: 2,
          type: 'Kursus',
          courseName: 'Data Science',
          city: 'Bandung',
          date: '2019-08-15',
          month: 'August',
          year: 2019,
          durationMonths: 4,
          institution: 'Data Academy',
          certificateNumber: 'DA654321',
        },
      ],
      workExperience: [
        {
          idWorkExperience: 1,
          companyName: 'Tech Solutions',
          position: 'Backend Developer',
          city: 'Jakarta',
          startYear: 2015,
          endYear: 2020,
          durationMonths: 60,
        },
        {
          idWorkExperience: 2,
          companyName: 'Tech Solutions',
          position: 'Backend Developer',
          city: 'Jakarta',
          startYear: 2015,
          endYear: 2020,
          durationMonths: 60,
        },
      ],
      organizationalLife: [
        {
          organizationId: 1,
          organizationName: 'OSIS SMA',
          yearInPosition: '2010',
          position: 'Ketua',
          memberCount: 50,
          city: 'Jakarta',
          durationMonths: 12,
        },
        {
          organizationId: 2,
          organizationName: 'Pramuka',
          yearInPosition: '2011',
          position: 'Anggota',
          memberCount: 30,
          city: 'Jakarta',
          durationMonths: 24,
        },
        {
          organizationId: 3,
          organizationName: 'Klub Debat',
          yearInPosition: '2012',
          position: 'Sekretaris',
          memberCount: 20,
          city: 'Jakarta',
          durationMonths: 18,
        },
      ],
      sports: [
        {
          sport: 'Sepak Bola',
          activePassive: 'Aktif',
        },
      ],
      art: ['Menggambar'],
      other: [
        {
          foreignLanguageProficiency: ['Inggris', 'Jerman'],
          hobbies: ['Menggambar', 'Melukis'],
          active: 'Lead Backend',
        },
      ],
    },
    contractInfo: {
      status: 'Fulltime',
      placementType: 'Bandung',
      employeeType: 'Talent',
      bankPlacement: '',
      division: 'KTI',
      position: 'UI/UX Designer',
      contractStartDate: '17/07/1996',
      contractEndDate: '17/07/1997',
      generation: 'JTK',
      contractDocument: 'https://minio.cloudias79.com/object/fakeimage?AWSAccessKeyId=FakeAccessKey&Expires=1700000000&Signature=FakeSignature',
      contractDocumentName: 'Kontrak_Melati.pdf',
      salary: 5000000,
    },
    placementAllowance: [
      {
        id: 1,
        allowanceType: 'Tunjangan Bandung',
        amount: 1000000,
      },
      {
        id: 2,
        allowanceType: 'Tunjangan Jakarta',
        amount: 1000000,
      },
      {
        id: 3,
        allowanceType: 'Tunjangan Hybrid',
        amount: 500000,
      },
    ],
    otherAllowance: [
      {
        id: 1,
        allowanceType: 'Tunjangan Akhir Kontrak',
        amount: 5000000,
      },
      {
        id: 2,
        allowanceType: 'Tunjangan Resign',
        amount: 200000,
      },
    ],
  },
};
