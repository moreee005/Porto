export const initialEditData = {
  personalIdentity: {
    imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8sReGdZmLgDIJIaecf3uihREm-YpHMU4aOA&s",
    fullname: "John Doe",
    gender: 1,
    placeOfBirth: 1,
    dateOfBirth: "1990-01-01",
    ethnicity: 1,
    religion: 1,
    bloodType: 1,
    maritalStatus: 3,
    email: "johndoe@example.com",
    phoneNumber: "081234567890",
    emergencyContact: {
      name: "Jane Doe",
      phoneNumber: "081987654321",
      relationship: 1
    },
    background: 1,
    homeAddress: {
      fullAddress: "Jl. Sudirman No. 123, Jakarta",
      province: 1,
      city: 2,
      district: 1,
      subdistrict: 1,
      postalCode: 1
    },
    motherIdentity: {
      name: "Maria Doe",
      dateOfBirth: "1965-05-10",
      highestEducation: 1,
      occupation: "Teacher",
      motherSalary: 1,
      phoneNumber: "081234567891",
      statusAlive: 0,
      address: 1
    },
    fatherIdentity: {
      name: "John Doe Sr.",
      dateOfBirth: "1960-03-15",
      highestEducation: 2,
      occupation: "Engineer",
      salary: 2,
      phoneNumber: "081234567892",
      statusAlive: "Ya",
      address: "Jl. Kebon Jeruk No. 45, Jakarta",
      province: 1,
      city: "Jakarta Barat",
      district: "Kebon Jeruk",
      subdistrict: "Duri Kepa",
      postalCode: "11510"
    },
    spouseIdentity: {
      partnerName: "Deny",
      partnerAge: "",
      partnerHighestEducation: "",
      partnerOccupation: "",
      partnerSalary: 1,
      separateTax: "",
      partnerAddress: ""
    },
    familyOrder: {
      childNumber: 1,
      totalSiblings: 2
    },
    siblings: [
      {
        name: "Jane Doe",
        age: 25,
        relationship: "Sister"
      }
    ],
    familyMembersInKk: [
      {
        name: "Maria Doe",
        relationship: "Mother"
      },
      {
        name: "John Doe Sr.",
        relationship: "Father"
      }
    ],
    educationHistory: [
      {
        schoolName: "SMA Negeri 1 Jakarta",
        yearGraduated: 2008,
        major: "Science"
      }
    ],
    coursesOrUpgrading: [
      {
        courseName: "Web Development",
        year: 2020
      }
    ],
    workExperience: [
      {
        companyName: "TechCorp",
        position: "Software Engineer",
        yearsWorked: 3
      }
    ],
    organizationalLife: [
      {
        organizationName: "Programming Club",
        role: "President"
      }
    ],
    sports: ["Football", "Badminton"],
    art: ["Painting", "Photography"],
    other: ["Volunteering"]
  },
  contractInformation: {
    statusId: "1",
    placementTypeId: "2",
    employeeTypeId: "3",
    willingToBePlacedInBankOrInsurance: "Yes",
    divisionId: "IT",
    jobPositionId: "Software Engineer",
    contractStartDate: "2024-01-01",
    contractEndDate: "2025-01-01",
    contractDocument: {
      documentName: "Contract.pdf",
      documentUrl: "https://example.com/contracts/contract.pdf"
    },
    generation: "Millennial",
    baseSalary: 15000000,
    allowances: {
      placementAllowances: [{ type: "Housing", amount: 2000000 }],
      otherAllowances: [{ type: "Transportation", amount: 1000000 }]
    }
  },
  healthAndFinance: {
    nik: "1234567890123456",
    npwp: "123456789012345",
    ptkpStatus: "TK0",
    bpjsNumber: "1234567890",
    bpjsClass: "1",
    employmentBpjsNumber: "0987654321",
    bankId: "BCA",
    accountNumber: "1234567890"
  },
  documents: {
    documentEmployee: [
      { documentName: "KTP.pdf", documentUrl: "https://example.com/documents/ktp.pdf" }
    ],
    socialMedia: [
      { platform: "LinkedIn", url: "https://linkedin.com/in/johndoe" }
    ]
  }
};