interface ApprovalData {
  status: number;
  message: string;
  errorCode: string;
  data: {
    employee: {
      name: string;
      profileImage: string;
    };
    contract: string;
    start: string;
    end: string;
    phase: string;
    note: string;
  }[];
  currentPage?: number;
  pageSize?: number;
  totalCount?: number;
  totalPages?: number;
}

interface FilterData {
  id: number;
  value: string;
}

export const contractFilterData: FilterData[] = [
  {
    id: 1,
    value: 'Fulltime',
  },
  {
    id: 2,
    value: 'Probation',
  },
  {
    id: 3,
    value: 'Back to back',
  },
  {
    id: 4,
    value: 'Permanent',
  },
  {
    id: 5,
    value: 'Fulltime',
  },
];

export const transformedApprovalData: ApprovalData = {
  status: 200,
  message: 'Data fetched successfully',
  errorCode: '',
  data: [
    {
      employee: {
        name: 'Rizki Kurniawan',
        profileImage: '',
      },
      contract: 'Fulltime',
      start: '21 Nov 2024',
      end: '22 Nov 2024',
      phase: 'CEO',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Anisa Putri',
        profileImage: '',
      },
      contract: 'Probation',
      start: '01 Dec 2024',
      end: '31 Dec 2024',
      phase: 'General HC',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Budi Santoso',
        profileImage: '',
      },
      contract: 'Back to back',
      start: '15 Jan 2025',
      end: '15 Feb 2025',
      phase: 'General HC',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Joko Sutrisno',
        profileImage: '',
      },
      contract: 'Fulltime',
      start: '10 Nov 2024',
      end: '10 Nov 2025',
      phase: 'CEO',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Dewi Lestari',
        profileImage: '',
      },
      contract: 'Probation',
      start: '01 Oct 2024',
      end: '31 Oct 2024',
      phase: 'General HC',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Taufik Rahman',
        profileImage: '',
      },
      contract: 'Permanent',
      start: '01 Nov 2024',
      end: '30 Nov 2024',
      phase: 'General HC',
      note: 'Perpanjang Kontrak',
    },
    {
      employee: {
        name: 'Siti Aminah',
        profileImage: '',
      },
      contract: 'Fulltime',
      start: '01 Jan 2025',
      end: '01 Jan 2026',
      phase: 'General HC',
      note: 'Perpanjang Kontrak',
    },
    {
      employee: {
        name: 'Lia Putri',
        profileImage: '',
      },
      contract: 'Fulltime',
      start: '10 Dec 2024',
      end: '10 Dec 2025',
      phase: 'CEO',
      note: 'Perpanjang Kontrak',
    },
    {
      employee: {
        name: 'Andi Wijaya',
        profileImage: '',
      },
      contract: 'Permanent',
      start: '01 Feb 2025',
      end: '01 Aug 2025',
      phase: 'General HC',
      note: 'Perpanjang Kontrak',
    },
    {
      employee: {
        name: 'Beni Hartono',
        profileImage: '',
      },
      contract: 'Fulltime',
      start: '21 Dec 2024',
      end: '21 Dec 2025',
      phase: 'General HC',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Rina Sari',
        profileImage: '',
      },
      contract: 'Probation',
      start: '10 Oct 2024',
      end: '10 Jan 2025',
      phase: 'General HC',
      note: 'Karyawan Baru',
    },
    {
      employee: {
        name: 'Fajar Pratama',
        profileImage: '',
      },
      contract: 'Back to back',
      start: '05 Nov 2024',
      end: '05 Dec 2024',
      phase: 'CEO',
      note: 'Resign',
    },
    {
      employee: {
        name: 'Rudi Arifin',
        profileImage: '',
      },
      contract: 'Permanent',
      start: '15 Dec 2024',
      end: '15 Mar 2025',
      phase: 'General HC',
      note: 'Perpanjang Kontrak',
    },
  ],
};
