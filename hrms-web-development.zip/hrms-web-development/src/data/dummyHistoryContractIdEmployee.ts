interface HistoryContractIdEmployeeData {
  status: number;
  message: string;
  errorCode: string;
  data: {
    contract: string;
    contract_document: string; // url minio
    start_date: string;
    end_date: string;
    bank_insurance_agreement: string;
    placement: string;
    allowances: {
      allowance_id: number;
      allowance_type: string;
      nominal: number;
    }[];
  }[];
}

export const historyContractIdEmployeeData: HistoryContractIdEmployeeData = {
  status: 200,
  message: 'Success',
  errorCode: '',
  data: [
    {
      contract: 'fulltime',
      contract_document:
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', // url minio
      start_date: '17/07/1996',
      end_date: '17/07/1997',
      bank_insurance_agreement: 'Bersedia',
      placement: 'Jakarta',
      allowances: [
        {
          allowance_id: 1,
          allowance_type: 'Tunjangan Bandung',
          nominal: 1000000,
        },
        {
          allowance_id: 2,
          allowance_type: 'Tunjangan Jakarta',
          nominal: 1000000,
        },
      ],
    },
    {
      contract: 'contract',
      contract_document:
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', // url minio
      start_date: '17/07/1998',
      end_date: '17/07/1999',
      bank_insurance_agreement: 'Tidak Bersedia',
      placement: 'Bandung',
      allowances: [
        {
          allowance_id: 1,
          allowance_type: 'Tunjangan Bandung',
          nominal: 1000000,
        },
        {
          allowance_id: 2,
          allowance_type: 'Tunjangan Jakarta',
          nominal: 1000000,
        },
      ],
    },
  ],
};
