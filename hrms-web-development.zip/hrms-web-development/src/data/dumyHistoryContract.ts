export const dataHistory = [
  {
    id: 1,
    contractType: 'Fulltime',
    start: '1990-05-15',
    end: '1992-05-15',
    salary: '2.000.000',
    placement: 'Jakarta',
    bankIssurancePlacementAgreement: 'Bersedia Ditempatkan DiBank',
  },
  {
    id: 2,
    contractType: 'Probation',
    start: '1990-05-25',
    end: '1992-11-01',
    salary: '1.000.000',
    placement: 'Surabaya',
    bankIssurancePlacementAgreement: 'Tidak Bersedia Ditempatkan DiBank',
  },
];
export const dataTunjanganPenempatan = [
  {
    id: 1,
    jenisTunjangan: 'Tunjangan Bandung',
    nominal: 'Rp. 4.000.000',
  },
  {
    id: 2,
    jenisTunjangan: 'Tunjangan Jakarta',
    nominal: 'Rp. 3.000.000',
  },
];
export const dataTunjanganLainLain = [
  {
    id: 1,
    jenisTunjangan: 'Tunjangan Akhir Kontrak',
    nominal: 'Rp. 2.000.000',
  },
  {
    id: 2,
    jenisTunjangan: 'Tunjangan Resign',
    nominal: 'Rp. 1.000.000',
  },
];
