/**
 * mockup login
 *
 * Request	Body
 *
 * {
 *  "email": "expample@mail.com",
 *  "password": "Example@123"
 * }
 *
 * Response success
 * {
 *  "code" : 200
 *  "data" :
 *          {
 *              "userId": "userId",
 *              "accessToken": "Token",
 *          // if multi role
 *              "roles":
 *                          [
 *                              {
 *                                  "roleName" : "Admin",
 *                                  "roleId"   : 1
 *                               },
 *                               {
 *                                   "roleName" : "Human Capital",
 *                                   "roleId"   : 2
 *                                },
 *                           ]
 *         // children item can't show with parent
 *              "menuItem:
 *                          [
 *                              {
 *                                  "id" : "data-karyawan"
 *                              },
 *                              {
 *                                  "id" : "kontrak"
 *                                  "children" :
 *                                                  [
 *                                                      { id: 'data-kontrak' },
 *                                                      { id: 'button' }
 *                                                  ]
 *                              },
 *                          ]
 *          }
 *  "message" : "You have logged in successfully"
 *  "success" : true
 *  }
 *
 * Response failed
 * {
 *  "code" :401
 *  "message" : "Email or password is incorrect. Please try again."
 *  "success" :false
 * }
 *
 */

interface userData {
  email: string;
  password: string;
}

interface responseLoginData {
  code: number;
  data?: {
    userId: string;
    accessToken: string;
    roles: {
      roleName: string;
      roleId: number;
    }[];
    menuItem: {
      id: string;
      children?: { id: string }[];
    }[];
  };
  message: string;
  success: boolean;
}

export const userLoginData: userData = {
  email: 'example@mail.com',
  password: 'Example@123',
};

export const responseLoginSuccess = {
  code: 200,
  data: {
    userId: 'userId', // token
    accessToken: 'Token',
    roles: [
      {
        roleName: 'Admin',
      },
      {
        roleName: 'Human Capital',
      },
    ],
    menuItem: [
      {
        id: 'data-karyawan',
      },
      {
        id: 'kontrak',
        children: [{ id: 'data-kontrak' }, { id: 'button' }],
      },
    ],
  },
  message: 'You have logged in successfully',
  success: true,
};

export const responseLoginFailed = {
  code: 401,
  message: 'Email or password is incorrect. Please try again.',
  success: false,
};
