import { UUIDTypes } from 'uuid/dist/cjs/types';

interface PersetujuanPerpanjangContractData {
  status: number;
  message: string;
  errorCode: string;
  data: {
    approvalId: UUIDTypes;
    employeeDetail: {
      id: number;
      fullName: string;
      date: string;
      resignDate: string;
      resignDocument: File;
      resignReason: string;
    };
    contractInfo: {
      status: string;
      placementType: string;
      employeeType: string;
      bankPlacement: string;
      division: string;
      position: string;
      contractStartDate: string;
      contractEndDate: string;
      generation: string;
      contractDocuments: {
        name: string;
        url: string;
        date: string;
      }[];
      contractDocumentName: string;
      salary: number;
    };
    placementAllowance: {
      id: number;
      allowanceType: string;
      amount: number;
    }[];
    otherAllowance: {
      id: number;
      allowanceType: string;
      amount: number;
    }[];
  };
}

const dummyResignDocument = new File(
  ['Resign document content'],
  'resign-document.pdf',
  { type: 'application/pdf' }
);

export const persetujuanPerpanjangContractData: PersetujuanPerpanjangContractData =
  {
    status: 200,
    message: 'Success',
    errorCode: '',
    data: {
      approvalId: '1',
      employeeDetail: {
        id: 1,
        fullName: 'Afdal Ramdan',
        date: '19 Desember 2024',
        resignDate: '01-05-2026',
        resignDocument: dummyResignDocument,
        resignReason: 'Kepentingan keluarga',
      },
      contractInfo: {
        status: 'Fulltime',
        placementType: 'Bandung',
        employeeType: 'Talent',
        bankPlacement: 'Bersedia',
        division: 'KTI',
        position: 'UI/UX Designer',
        contractStartDate: '17/07/1996',
        contractEndDate: '17/07/1997',
        generation: 'JTK',
        contractDocuments: [
          {
            name: 'File 1',
            url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
            date: '10-12-2022',
          },
          {
            name: 'File 2',
            url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
            date: '10-12-2024',
          },
        ],
        contractDocumentName: 'contract-document.pdf',
        salary: 5000000,
      },
      placementAllowance: [
        {
          id: 1,
          allowanceType: 'Tunjangan Bandung',
          amount: 1000000,
        },
        {
          id: 2,
          allowanceType: 'Tunjangan Jakarta',
          amount: 1000000,
        },
        {
          id: 3,
          allowanceType: 'Tunjangan Hybrid',
          amount: 500000,
        },
      ],
      otherAllowance: [
        {
          id: 1,
          allowanceType: 'Tunjangan Akhir Kontrak',
          amount: 5000000,
        },
        {
          id: 2,
          allowanceType: 'Tunjangan Resign',
          amount: 200000,
        },
      ],
    },
  };
