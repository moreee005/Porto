export const VARIABLES = {
  KARYAWAN_TITLE: 'Karyawan',
  TABLE_KARYAWAN: 'Table Karyawan',
  KONTRAK_TITLE: 'Kontrak',
  KONTRAK_LIST: 'Kontrak List',
  PERSETUJUAN_PAGE: 'Persetujuan',
  DOC_TYPE_KTP :1,
  DOC_TYPE_KK :2,
};
