import java.util.Scanner;

public class Main7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Baca input anggaran, jumlah keyboard, dan jumlah USB drive
        int b = sc.nextInt();
        int n = sc.nextInt();
        int m = sc.nextInt();

        // Baca harga keyboard
        int[] keyboards = new int[n];
        for (int i = 0; i < n; i++) {
            keyboards[i] = sc.nextInt();
        }

        // Baca harga USB drive
        int[] drives = new int[m];
        for (int i = 0; i < m; i++) {
            drives[i] = sc.nextInt();
        }

        int maxSpent = -1; // Nilai awal untuk maksimum yang valid

        // Cari kombinasi maksimum yang sesuai dengan anggaran
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                int total = keyboards[i] + drives[j];
                if (total <= b && total > maxSpent) {
                    maxSpent = total; // Perbarui maksimum yang valid
                }
            }
        }

        // Cetak hasil
        System.out.println(maxSpent);

        sc.close(); // Tutup scanner
    }
}
