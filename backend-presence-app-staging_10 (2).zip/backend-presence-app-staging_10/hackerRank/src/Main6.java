import java.util.Scanner;

public class Main6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Baca jumlah langkah
        int n = sc.nextInt();
        sc.nextLine(); // Konsumsi newline setelah membaca angka

        // Baca jalur pendakian
        String path = sc.nextLine();

        int seaLevel = 0; // Ketinggian saat ini
        int valleys = 0;  // Jumlah lembah

        for (int i = 0; i < n; i++) {
            char step = path.charAt(i);

            // Perbarui ketinggian
            if (step == 'U') {
                seaLevel++;
                // Keluar dari lembah
                if (seaLevel == 0) {
                    valleys++;
                }
            } else if (step == 'D') {
                seaLevel--;
            }
        }

        // Cetak jumlah lembah
        System.out.println(valleys);

        sc.close(); // Tutup Scanner
    }
}
