import java.util.Scanner;

public class MathUtils {

    // Fungsi untuk menghitung FPB (Faktor Persekutuan Terbesar)
    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Fungsi untuk menghitung KPK (Kelipatan Persekutuan Terkecil)
    public static int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input jumlah elemen array a
        int n = scanner.nextInt();
        int m = scanner.nextInt();

        // Input elemen-elemen array a
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }

        // Input elemen-elemen array b
        int[] b = new int[m];
        for (int i = 0; i < m; i++) {
            b[i] = scanner.nextInt();
        }

        // Hitung KPK dari array a
        int lcm_a = a[0];
        for (int i = 1; i < n; i++) {
            lcm_a = lcm(lcm_a, a[i]);
        }

        // Hitung FPB dari array b
        int gcd_b = b[0];
        for (int i = 1; i < m; i++) {
            gcd_b = gcd(gcd_b, b[i]);
        }

        // Hitung bilangan di antara array a dan b
        int count = 0;
        for (int i = lcm_a; i <= gcd_b; i += lcm_a) {
            if (gcd_b % i == 0) {
                count++;
            }
        }

        // Cetak hasil
        System.out.println(count);

        scanner.close();
    }
}
