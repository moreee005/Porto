import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GradingStudent {

    public static List<Integer> gradingStudents(List<Integer> grades) {
        List<Integer> roundedGrades = new ArrayList<>();

        for (int grade : grades) {
            // Jika nilai kurang dari 38, tidak dibulatkan
            if (grade < 38) {
                roundedGrades.add(grade);
            } else {
                // Hitung kelipatan 5 berikutnya
                int nextMultipleOf5 = ((grade / 5) + 1) * 5;
                // Jika selisih kurang dari 3, bulatkan
                if (nextMultipleOf5 - grade < 3) {
                    roundedGrades.add(nextMultipleOf5);
                } else {
                    roundedGrades.add(grade);
                }
            }
        }
        return roundedGrades;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();

        List<Integer> grades = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            grades.add(scanner.nextInt());
        }

        // Panggil fungsi gradingStudents
        List<Integer> result = gradingStudents(grades);

        // Cetak hasil
        for (int grade : result) {
            System.out.println(grade);
        }

        scanner.close();
    }
}
