import java.util.Scanner;

public class Kangaroo {

    public static String kangaroo(int x1, int v1, int x2, int v2) {
        // Jika kanguru pertama melompat lebih lambat dan sudah di belakang, tidak akan pernah bertemu
        if (v1 <= v2 && x1 < x2) {
            return "NO";
        }

        // Hitung apakah mereka dapat bertemu
        if ((x2 - x1) % (v1 - v2) == 0) {
            return "YES";
        }

        return "NO";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Baca input
        int x1 = scanner.nextInt();
        int v1 = scanner.nextInt();
        int x2 = scanner.nextInt();
        int v2 = scanner.nextInt();

        // Panggil fungsi dan cetak hasil
        String result = kangaroo(x1, v1, x2, v2);
        System.out.println(result);

        scanner.close();
    }
}
