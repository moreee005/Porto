import java.util.Scanner;

public class BirthdayCakeCandle {

    public static int birthdayCakeCandles(int[] candles) {
        int max = 0;
        int count = 0;

        for (int height : candles) {
            if (height > max) {
                max = height;
                count = 1;
            } else if (height == max) {
                count++;
            }
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();

        int[] candles = new int[n];
        for (int i = 0; i < n; i++) {
            candles[i] = scanner.nextInt();
        }

        int result = birthdayCakeCandles(candles);
        System.out.println(result);

        scanner.close();
    }
}
