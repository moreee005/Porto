import java.util.*;

public class tiga {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[3];
        int[] arr2 = new int[3];
        for (int i = 0; i < 3; i++){
            arr[i] = sc.nextInt();

        }
        for (int i = 0; i < 3; i++){
            arr2[i] = sc.nextInt();
        }
        int a = 0;
        int b = 0;

        for (int i = 0; i < 3; i++){
            if (arr[i] > arr2[i]){
                a += 1;
            }
            else if (arr[i] < arr2[i]){
                b += 1;
            }
        }
        System.out.println(a +" "+ b);

    }
}