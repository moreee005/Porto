import java.util.Scanner;

public class PlusMinus {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++){
            arr[i] = sc.nextInt();
        }

        double minus = 0;
        double plus = 0;
        double nol = 0;
        for (int i = 0; i < n; i++){

                if (arr[i] == 0){
                    nol += 1;
                }
                else if (arr[i] > 0){
                    plus += 1;
                }
                else if (arr[i] < 0){
                    minus += 1;
                }

        }
        System.out.printf("%.6f%n", plus/n);
        System.out.printf("%.6f%n", minus/n);
        System.out.printf("%.6f%n", nol/n);
    }
}
