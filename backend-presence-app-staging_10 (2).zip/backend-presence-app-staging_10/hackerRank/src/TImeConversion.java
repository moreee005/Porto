import java.util.Scanner;

public class TImeConversion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine().toUpperCase();

        String period = input.substring(input.length()-2);
        int hour = Integer.parseInt(input.substring(0,2));
        String minute = input.substring(2,input.length() - 2);
        String thisTime = "";
        if (period.equals("AM")) {
            if (hour == 12) {
                thisTime = "00"+minute;

            }else {
                thisTime = String.format("%02d", hour) + minute;
            }
        }else {
            if (hour != 12) {
                thisTime = (hour+12)+minute;
            }else {
                thisTime = String.format("%02d", hour) + minute;
            }
        }
        System.out.println(thisTime);
    }
}
