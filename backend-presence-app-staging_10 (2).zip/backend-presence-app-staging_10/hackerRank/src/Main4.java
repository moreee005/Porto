import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt();
       int k = sc.nextInt();
       int[] arr = new int[n];
       for (int i = 0; i < n; i++){
           arr[i] = sc.nextInt();
       }
       int arri= 0;
       int arrj= 0;
       int count = 0;

       for (int i = 0; i < n; i++){
           for (int j = i + 1; j < n; j++){
               arri = arr[i];
               arrj = arr[j];
               if((arri+arrj)%k == 0){
                   count++;
               }
           }
       }
       System.out.println(count);
    }
}