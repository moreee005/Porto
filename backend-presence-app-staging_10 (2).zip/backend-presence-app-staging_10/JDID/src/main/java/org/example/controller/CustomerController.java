package org.example.controller;

import org.example.response.MessageResponse;
import org.example.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping
    public MessageResponse getAllCustomers() {
        return customerService.getAllCustomers();
    }

    @GetMapping("/{qrCode}")
    public MessageResponse getCustomerById(@PathVariable String qrCode) {
        return customerService.getCustomerById(qrCode);
    }
}
