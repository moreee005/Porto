package org.example.response;

// File path: src/main/java/org/example/dto/TransactionResponse.java


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionResponse {
    private String id;
    private String qrCode;
    private String rfId;
    private Integer price;
    private Integer totalPrice;
    private LocalDateTime date;
}
