// File path: src/main/java/org/example/service/ProductService.java

package org.example.service;

import org.example.models.Product;
import org.example.repositori.ProductRepository;
import org.example.response.MessageResponse;
import org.example.response.ProductResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public MessageResponse getAllProducts() {
        try {
            List<ProductResponse> products = productRepository.findAll().stream()
                    .map(product -> ProductResponse.builder()
                            .rfId(product.getRfId())
                            .productName(product.getProductName())
                            .price(product.getPrice())
                            .build())
                    .collect(Collectors.toList());

            return MessageResponse.builder()
                    .message("Products retrieved successfully")
                    .statusCode(200)
                    .status("success")
                    .data(products)
                    .build();

        } catch (Exception e) {
            e.printStackTrace();
            return MessageResponse.builder()
                    .message("An error occurred while retrieving products")
                    .statusCode(500)
                    .status("error")
                    .data(null)
                    .build();
        }
    }
}
