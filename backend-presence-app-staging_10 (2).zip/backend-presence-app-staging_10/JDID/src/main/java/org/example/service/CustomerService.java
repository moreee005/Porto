package org.example.service;



import org.example.response.CustomerResponse;
import org.example.models.Customer;
import org.example.repositori.CustomerRepository;
import org.example.response.MessageResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public MessageResponse getAllCustomers() {
        try {
            List<CustomerResponse> customers = customerRepository.findAll().stream()
                    .map(customer -> CustomerResponse.builder()
                            .qrCode(customer.getQrCode())
                            .name(customer.getName())
                            .wallet(customer.getWallet())
                            .build())
                    .collect(Collectors.toList());

            return MessageResponse.builder()
                    .message("Customers retrieved successfully")
                    .statusCode(200)
                    .status("success")
                    .data(customers)
                    .build();

        } catch (Exception e) {
            e.printStackTrace();
            return MessageResponse.builder()
                    .message("An error occurred while retrieving customers")
                    .statusCode(500)
                    .status("error")
                    .data(null)
                    .build();
        }
    }

    public MessageResponse getCustomerById(String qrCode) {
        Customer customer = customerRepository.findById(qrCode).orElse(null);
        if (customer == null) {
            return MessageResponse.builder()
                    .message("Customer not found")
                    .statusCode(404)
                    .status("error")
                    .data(null)
                    .build();
        }
        CustomerResponse customerResponse = CustomerResponse.builder()
                .qrCode(customer.getQrCode())
                .name(customer.getName())
                .wallet(customer.getWallet())
                .build();

        return MessageResponse.builder()
                .message("Customer retrieved successfully")
                .statusCode(200)
                .status("success")
                .data(customerResponse)
                .build();
    }
}
