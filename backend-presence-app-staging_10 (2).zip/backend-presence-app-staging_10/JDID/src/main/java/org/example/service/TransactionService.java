
package org.example.service;

import org.example.response.TransactionResponse;
import org.example.models.Transaction;
import org.example.repositori.TransactionRepository;
import org.example.response.MessageResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    public MessageResponse getAllTransactions() {
        try {
            List<TransactionResponse> transactions = transactionRepository.findAll().stream()
                    .map(transaction -> TransactionResponse.builder()
                            .id(transaction.getId())
                            .qrCode(transaction.getCustomer().getQrCode())
                            .rfId(transaction.getProduct().getRfId())
                            .price(transaction.getPrice())
                            .totalPrice(transaction.getTotalPrice())
                            .date(transaction.getDate())
                            .build())
                    .collect(Collectors.toList());

            return MessageResponse.builder()
                    .message("Transactions retrieved successfully")
                    .statusCode(200)
                    .status("success")
                    .data(transactions)
                    .build();

        } catch (Exception e) {
            e.printStackTrace();
            return MessageResponse.builder()
                    .message("An error occurred while retrieving transactions")
                    .statusCode(500)
                    .status("error")
                    .data(null)
                    .build();
        }
    }

    public MessageResponse getTransactionById(String id) {
        Transaction transaction = transactionRepository.findById(id).orElse(null);
        if (transaction == null) {
            return MessageResponse.builder()
                    .message("Transaction not found")
                    .statusCode(404)
                    .status("error")
                    .data(null)
                    .build();
        }
        TransactionResponse transactionResponse = TransactionResponse.builder()
                .id(transaction.getId())
                .qrCode(transaction.getCustomer().getQrCode())
                .rfId(transaction.getProduct().getRfId())
                .price(transaction.getPrice())
                .totalPrice(transaction.getTotalPrice())
                .date(transaction.getDate())
                .build();

        return MessageResponse.builder()
                .message("Transaction retrieved successfully")
                .statusCode(200)
                .status("success")
                .data(transactionResponse)
                .build();
    }
}
