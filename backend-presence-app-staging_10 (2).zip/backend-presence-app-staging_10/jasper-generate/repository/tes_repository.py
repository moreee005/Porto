import json
from datetime import datetime
from typing import List, Dict, Any
from decimal import Decimal
from dataclasses import asdict
import oracledb
from config import config
from model.model_tes import TesModel, InvestorModel

# Variabel global untuk koneksi Oracle
connection = None

def connect():
    """Menghubungkan ke database Oracle jika belum terhubung."""
    global connection
    if connection is None:
        connection = oracledb.connect(
            user=config.DB_USER,
            password=config.DB_PASSWORD,
            dsn=config.DB_DSN
        )

def close():
    """Menutup koneksi ke database Oracle."""
    global connection
    if connection:
        connection.close()
        connection = None

def get_all_data() -> List[TesModel]:
    """Mengambil semua data dari tabel PEGAWAI."""
    connect()
    cursor = connection.cursor()
    query = "SELECT ID, NAME, CREATED_DATE, STATUS, DESCRIPTION FROM C##KSEI.PEGAWAI"
    cursor.execute(query)

    results = []
    for row in cursor.fetchall():
        data = TesModel(
            ID=Decimal(row[0]),
            NAME=row[1],
            CREATED_DATE=row[2],
            STATUS=row[3],
            DESCRIPTION=row[4]
        )
        results.append(data)

    cursor.close()
    return results

def get_all_data_invs() -> List[InvestorModel]:
    """Mengambil semua data dari tabel INVESTOR_DATA."""
    connect()
    cursor = connection.cursor()
    query = "SELECT * FROM C##KSEI.INVESTOR_DATA"
    cursor.execute(query)

    results = []
    for row in cursor.fetchall():
        data = InvestorModel(
            acct_desc=row[0],
            invs_npwp_num=row[1],
            invs_ktp_num=row[2],
            invs_passport_num=row[3],
            addr_1=row[4],
            addr_2=row[5],
            addr_3=row[6],
            address4=row[7],
            rec_bal=row[8],
            rec_dt=row[9],
            eff_dt=row[10],
            next_day=row[11]
        )
        results.append(data)

    cursor.close()
    return results

def get_data_by_id(data_id: Decimal) -> TesModel:
    """Mengambil data PEGAWAI berdasarkan ID."""
    connect()
    cursor = connection.cursor()
    query = "SELECT ID, NAME, CREATED_DATE, STATUS, DESCRIPTION FROM C##KSEI.PEGAWAI WHERE ID = :id"
    cursor.execute(query, [data_id])

    row = cursor.fetchone()
    cursor.close()
    if row:
        return TesModel(
            ID=Decimal(row[0]),
            NAME=row[1],
            CREATED_DATE=row[2],
            STATUS=row[3],
            DESCRIPTION=row[4]
        )
    return None

def get_json_report_data() -> Dict[str, Any]:
    """Mengambil data dari database dan mengonversinya menjadi JSON-friendly dictionary."""
    all_data = get_all_data_invs()

    data_list = []
    for data in all_data:
        data_dict = asdict(data)
        data_list.append(data_dict)

    report_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "report_data": data_list
    }
    return report_data

# Example usage
if __name__ == "__main__":
    json_data = get_all_data_invs()
    print(json.dumps(json_data, indent=4, default=str))
    close()  # Pastikan koneksi ditutup setelah selesai
