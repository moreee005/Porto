import json
from datetime import datetime
from decimal import Decimal
from typing import List, Dict, Any
from dataclasses import asdict
from model.model_tes import TesModel

# repository/tes_repository.py

import oracledb
from config import config
from model.model_tes import TesModel  # Pastikan impor ini benar

class TesRepository:
    def __init__(self):
        self.connection = None

    def connect(self):
        if not self.connection:
            self.connection = oracledb.connect(
                user=config.DB_USER,
                password=config.DB_PASSWORD,
                dsn=config.DB_DSN
            )

    def close(self):
        if self.connection:
            self.connection.close()
            self.connection = None

    def get_all_data(self) -> List[TesModel]:
        self.connect()
        cursor = self.connection.cursor()
        query = "SELECT ID, NAME, CREATED_DATE, STATUS, DESCRIPTION FROM C##KSEI.PEGAWAI"
        cursor.execute(query)

        results = []
        for row in cursor.fetchall():
            data = TesModel(
                ID=Decimal(row[0]),
                NAME=row[1],
                CREATED_DATE=row[2],
                STATUS=row[3],
                DESCRIPTION=row[4]
            )
            results.append(data)

        cursor.close()
        return results

    def get_data_by_id(self, data_id: Decimal) -> TesModel:
        self.connect()
        cursor = self.connection.cursor()
        query = "SELECT ID, NAME, CREATED_DATE, STATUS, DESCRIPTION FROM C##KSEI.PEGAWAI WHERE ID = :id"
        cursor.execute(query, [data_id])

        row = cursor.fetchone()
        cursor.close()
        if row:
            return TesModel(
                ID=Decimal(row[0]),
                NAME=row[1],
                CREATED_DATE=row[2],
                STATUS=row[3],
                DESCRIPTION=row[4]
            )
        return None

    def get_json_report_data(self) -> Dict[str, Any]:
        """Mengambil data dari database dan mengonversinya menjadi JSON-friendly dictionary dengan field yang disesuaikan."""

        # Step 1: Get all data
        all_data = self.get_all_data()

        # Step 2: Process and map data into dictionary with custom field names
        data_list = []
        for data in all_data:
            # Manual mapping to rename fields
            data_dict = {
                "id_karyawan": str(data.ID),  # Rename from "ID" to "id_karyawan"
                "nama": data.NAME,            # Rename from "NAME" to "nama"
                "tanggal_dibuat": data.CREATED_DATE.strftime("%Y-%m-%d %H:%M:%S"),  # Rename from "CREATED_DATE" to "tanggal_dibuat"
                "status_kerja": data.STATUS,  # Rename from "STATUS" to "status_kerja"
                "deskripsi": data.DESCRIPTION # Rename from "DESCRIPTION" to "deskripsi"
            }
            data_list.append(data_dict)

        # # Step 3: Create RootData structure for JSON report
        # report_data = {
        #     "waktu_pembuatan": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),  # Rename timestamp to "waktu_pembuatan"
        #     "data_laporan": data_list  # Rename report_data to "data_laporan"
        # }

        # Step 4: Return JSON dictionary
        return data_list

# Example usage
if __name__ == "__main__":
    repo = TesRepository()
    json_data = repo.get_json_report_data()
    print(json.dumps(json_data, indent=4, default=str))
