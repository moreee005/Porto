import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import config

def send_email(subject, html_body, receiver_email):
    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = config.SENDER_EMAIL
    message["To"] = receiver_email

    body = MIMEText(html_body, 'html')

    message.attach(body)

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(config.SMTP_HOST, int(config.SMTP_PORT), context=context) as server:
        server.login(config.USERNAME_EMAIL, config.PASSWORD_EMAIL) # login if necessary
        server.sendmail(config.SENDER_EMAIL, config.RECEIVER_EMAIL, message.as_string())

