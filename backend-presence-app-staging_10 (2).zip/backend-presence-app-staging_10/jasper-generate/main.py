# src/main.py

from repository.tes_repository import get_all_data
from utils.email import send_email  # Import fungsi send_email
import json
from config import config

# Inisialisasi repository

try:
    # Mengambil semua data
    all_data = get_all_data()

    # Konversi data menjadi list of dictionaries
    all_data_dict = [data.to_dict for data in all_data]

    # Simpan ke file JSON
    with open("pegawai_data.json", "w") as json_file:
        json.dump(all_data_dict, json_file, indent=4)

    print("Data berhasil disimpan dalam file pegawai_data.json")

    # Mengirim email konfirmasi jika penyimpanan berhasil
    subject = "Data Pegawai Tersimpan"
    html_body = """
        <html>
            <body>
                <h2>Data Pegawai Berhasil Tersimpan</h2>
                <p>File pegawai_data.json telah berhasil dibuat dan disimpan.</p>
            </body>
        </html>
    """
    send_email(subject, html_body, config.RECEIVER_EMAIL)

except Exception as e:
    print(f"Gagal menyimpan data: {e}")
