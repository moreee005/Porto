# config/config.py

import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()  # Memuat variabel dari file .env ke dalam os.environ

# Ambil variabel dari environment
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_DSN = os.getenv("DB_DSN")
SENDER_EMAIL = os.getenv("SENDER_EMAIL")

RECEIVER_EMAIL = os.getenv("RECEIVER_EMAIL")

USERNAME_EMAIL = os.getenv("USERNAME_EMAIL")

PASSWORD_EMAIL = os.getenv("PASSWORD_EMAIL")

SMTP_HOST = os.getenv("SMTP_HOST")

SMTP_PORT = os.getenv("SMTP_PORT")

MONGO_URI = os.getenv("MONGO_URI")

MONGO_DB_NAME = os.getenv("MONGO_DB_NAME")

MONGO_COLLECTION_NAME = os.getenv("MONGO_COLLECTION_NAME")

URL_DATA_COLLECTOR = os.getenv("URL_DATA_COLLECTOR")