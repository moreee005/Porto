import oracledb
from pymongo import MongoClient
import config

# Fungsi untuk koneksi ke Oracle
def get_connection_db():
    return oracledb.connect(user=config.DB_USER, password=config.DB_PASSWORD, dsn=config.DB_DSN)

# Fungsi untuk koneksi ke MongoDB
def get_connection_mongo():
    client = MongoClient(config.MONGO_URI)  # Koneksi ke MongoDB menggunakan URI
    db = client[config.MONGO_DB_NAME]       # Pilih database berdasarkan konfigurasi
    return db                               # Mengembalikan objek database MongoDB

if __name__ == "__main__":
    # Koneksi ke Oracle
    oracle_connection = get_connection_db()
    if oracle_connection:
        print("Successfully connected to Oracle Database")
        oracle_connection.close()

    # Koneksi ke MongoDB
    mongo_db = get_connection_mongo()
    if mongo_db is not None:
        print(f"Successfully connected to MongoDB Database: {config.MONGO_DB_NAME}")
