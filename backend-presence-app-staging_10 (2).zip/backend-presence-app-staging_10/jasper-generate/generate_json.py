from repository.tes_repository import get_all_data_invs, connect, close
from utils.email import send_email  # Pastikan fungsi send_email tersedia di utils.email
import json
from config import config
from dataclasses import asdict
from decimal import Decimal
from datetime import datetime

def custom_converter(obj):
    """Konverter untuk tipe data yang tidak dapat di-serialisasi oleh JSON."""
    if isinstance(obj, datetime):
        return obj.strftime("%Y-%m-%d %H:%M:%S")
    elif isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

def convert_keys_to_uppercase(data_dict):
    """Mengubah semua kunci dalam dictionary menjadi huruf besar."""
    return {key.upper(): value for key, value in data_dict.items()}

def export_data_invs_to_json():
    try:
        # Buka koneksi ke database
        connect()

        # Mengambil semua data dari database
        all_data = get_all_data_invs()

        # Konversi data menjadi list of dictionaries dengan kunci uppercase
        all_data_dict = [convert_keys_to_uppercase(asdict(data)) for data in all_data]

        # Simpan ke file JSON dengan konverter khusus
        with open("invs_data.json", "w") as json_file:
            json.dump(all_data_dict, json_file, indent=4, default=custom_converter)

        print("Data berhasil disimpan dalam file invs_data.json")

    finally:
        # Pastikan koneksi ditutup setelah selesai
        close()

if __name__ == "__main__":
    export_data_invs_to_json()
