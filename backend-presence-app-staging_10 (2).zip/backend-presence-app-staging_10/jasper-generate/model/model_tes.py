# model/model_tes.py

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional
from datetime import datetime

@dataclass
class TesModel:
    ID: Decimal
    NAME: str
    CREATED_DATE: datetime
    STATUS: str
    DESCRIPTION: Optional[str] = None  # Ubah ke Optional agar bisa menerima None

@dataclass
class InvestorModel:
    acct_desc: str
    invs_npwp_num: str
    invs_ktp_num: str
    invs_passport_num: str
    addr_1: str
    rec_bal: Decimal
    rec_dt: datetime
    eff_dt: datetime
    next_day: datetime
    addr_2: Optional[str] = None  # Menjadikan kolom ini opsional
    addr_3: Optional[str] = None  # Menjadikan kolom ini opsional
    address4: Optional[str] = None  # Menjadikan kolom ini opsional

    def to_dict(self):
        """Mengonversi instance ke dictionary untuk serialisasi JSON."""
        return {
            "ID": str(self.ID),
            "NAME": self.NAME,
            "CREATED_DATE": self.CREATED_DATE.strftime('%Y-%m-%d %H:%M:%S'),
            "STATUS": self.STATUS,
            "DESCRIPTION": self.DESCRIPTION.read() if hasattr(self.DESCRIPTION, "read") else self.DESCRIPTION
        }
