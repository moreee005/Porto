from flask import Flask, jsonify
import oracledb
from pymongo import MongoClient
from config import config
from model.model_tes import TesModel
from typing import List
from decimal import Decimal
from dataclasses import asdict
from repository.tes_repository import close, get_all_data, get_all_data_invs
from flask_cors import CORS

app = Flask(__name__)
CORS(app)


# Fungsi untuk mengonversi TesModel ke dictionary dengan Decimal menjadi float
def model_to_dict(model):
    data = asdict(model)
    for key, value in data.items():
        if isinstance(value, Decimal):
            data[key] = float(value)  # Mengonversi Decimal ke float
    return data


# Fungsi untuk menyimpan data ke MongoDB
def save_data_to_mongodb(data):
    client = MongoClient(config.MONGO_URI)
    db = client[config.MONGO_DB_NAME]
    collection = db[config.MONGO_COLLECTION_NAME]

    # Konversi data ke dictionary dan ubah Decimal menjadi float
    formatted_data = [model_to_dict(item) for item in data]
    result = collection.insert_many(formatted_data)
    client.close()
    return result.inserted_ids

# Endpoint API untuk mendapatkan data dari Oracle dan menyimpannya ke MongoDB
@app.route('/get-data-report', methods=['GET'])
def get_data_report():
    try:
        # Step 1: Ambil data dari Oracle
        oracle_data = get_all_data_invs()

        # Step 2: Simpan data ke MongoDB
        mongo_ids = save_data_to_mongodb(oracle_data)

        # Step 3: Kembalikan respons JSON dengan data yang disimpan
        response = {
            "status": "success",
            "message": "Data berhasil disimpan ke MongoDB",
            "data_count": len(mongo_ids),
            "data": [model_to_dict(data) for data in oracle_data]
        }
        return jsonify(response), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        close()  # Tutup koneksi Oracle

if __name__ == '__main__':
    app.run(debug=True)
