import json
import time
import urllib.request
#from jasper_generate import generate_pdf_report
from config import config
from pyreportjasper import PyReportJasper
import os

def to_uppercase_keys(data):
    """Recursively convert all keys in a dictionary to uppercase."""
    if isinstance(data, dict):
        return {k.upper(): to_uppercase_keys(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [to_uppercase_keys(i) for i in data]
    else:
        return data

def generate_pdf_report(json_data):
    if not json_data:
        print("Data tidak tersedia.")
        return

    # Convert keys to uppercase
    json_data_upper = to_uppercase_keys(json_data)

    # Convert to bytes
    json_str = json.dumps(json_data_upper)
    bytes_data = json_str.encode("utf-8")

    # Configure PyReportJasper
    input_file = os.path.join(os.path.dirname(__file__), "Invitation_Letter_KSEI_KTUR_NonCorpBond.jrxml")
    output_file = "output_report"

    pyreportjasper = PyReportJasper()
    pyreportjasper.config(
        input_file,
        output_file,
        output_formats=["pdf"],
        db_connection={
            "driver": "json",
            "data_file": bytes_data,
            "json_query": "DATA"
        }
    )
    pyreportjasper.process_report()
    print(f"Laporan berhasil dibuat: {output_file}.pdf")

def get_data_collector():
    start_time = time.time()
    url = f"{config.URL_DATA_COLLECTOR}/get-data-report"
    request = urllib.request.Request(url)

    try:
        response = urllib.request.urlopen(request).read()
        end_time = time.time()
        print(f"Request selesai dalam {end_time - start_time} detik")
        return json.loads(response.decode("utf-8"))
    except urllib.error.URLError as e:
        print(f"Eror saat request: {e.reason}")
        return None


if __name__ == "__main__":
    json_data = get_data_collector()

    generate_pdf_report(json_data)