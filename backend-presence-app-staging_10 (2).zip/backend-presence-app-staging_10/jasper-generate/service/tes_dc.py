import json
import time
import urllib.request
import os
import multiprocessing
from pyreportjasper import PyReportJasper
from config import config
import zipfile

def to_uppercase_keys(data):
    """Recursively convert all keys in a dictionary to uppercase."""
    if isinstance(data, dict):
        return {k.upper(): to_uppercase_keys(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [to_uppercase_keys(i) for i in data]
    else:
        return data

def generate_pdf_report(data):
    if not data:
        print("Data tidak tersedia.")
        return None

    # Convert keys to uppercase
    json_data_upper = to_uppercase_keys(data)

    # Convert to bytes
    json_str = json.dumps(json_data_upper)
    bytes_data = json_str.encode("utf-8")

    # Configure PyReportJasper
    input_file = os.path.join(os.path.dirname(__file__), "Invitation_Letter_KSEI_KTUR_NonCorpBond.jrxml")
    output_file = f"output_report_{json_data_upper['INVS_NPWP_NUM']}.pdf"  # Unique filename per data

    pyreportjasper = PyReportJasper()
    pyreportjasper.config(
        input_file,
        output_file,
        output_formats=["pdf"],
        db_connection={
            "driver": "json",
            "data_file": bytes_data,
            "json_query": ""
        }
    )
    pyreportjasper.process_report()
    print(f"Laporan berhasil dibuat: {output_file}")
    return output_file

def get_data_collector():
    start_time = time.time()
    url = f"{config.URL_DATA_COLLECTOR}/get-data-report"
    request = urllib.request.Request(url)

    try:
        response = urllib.request.urlopen(request).read()
        end_time = time.time()
        print(f"Request selesai dalam {end_time - start_time} detik")
        return json.loads(response.decode("utf-8"))
    except urllib.error.URLError as e:
        print(f"Eror saat request: {e.reason}")
        return None

def process_data(data):
    # Convert data keys to uppercase before generating report
    data_upper = to_uppercase_keys(data)
    return generate_pdf_report(data_upper)

def zip_reports(pdf_files, zip_filename="output_reports.zip"):
    """Zip all PDF files into a single ZIP file."""
    with zipfile.ZipFile(zip_filename, 'w') as zipf:
        for pdf_file in pdf_files:
            if os.path.isfile(pdf_file):
                zipf.write(pdf_file, os.path.basename(pdf_file))
                os.remove(pdf_file)  # Optionally, delete each PDF after adding to ZIP
    print(f"Semua laporan berhasil diarsipkan ke dalam file ZIP: {zip_filename}")

def noncorpbond_maker_multi_data_collector():
    json_data = get_data_collector()

    if json_data and 'data' in json_data:  # Access the 'data' key from API response
        data_list = json_data['data']
        num_process = min(len(data_list), multiprocessing.cpu_count())
        print(f"Total CPU: {num_process}")

        with multiprocessing.Pool(processes=num_process) as pool:
            pdf_files = pool.map(process_data, data_list)  # Collect the paths of generated PDF files

        # Filter out any None values in case some PDFs were not created
        pdf_files = [pdf_file for pdf_file in pdf_files if pdf_file]

        # Create a ZIP file containing all PDFs
        zip_reports(pdf_files)
    else:
        print("Data tidak tersedia atau tidak valid.")

if __name__ == "__main__":
    noncorpbond_maker_multi_data_collector()
