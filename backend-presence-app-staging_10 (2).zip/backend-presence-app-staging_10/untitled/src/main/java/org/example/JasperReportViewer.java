package org.example;


import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

public class JasperReportViewer {
    public static void main(String[] args) {
        try {
            // Load file laporan
            JasperReport jasperReport = JasperCompileManager.compileReport("C:/DataDummyReport/Invitation_Letter_KSEI_KTUR_NonCorpBond.jrxml");

            // (Opsional) Parameter dan sumber data
            JRDataSource dataSource = new JREmptyDataSource();

            // Isi laporan
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, dataSource);

            // Tampilkan laporan di JasperViewer
            JasperViewer.viewReport(jasperPrint, false);
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
}