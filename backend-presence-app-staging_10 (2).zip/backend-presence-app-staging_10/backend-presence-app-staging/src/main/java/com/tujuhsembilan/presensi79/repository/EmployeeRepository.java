package com.tujuhsembilan.presensi79.repository;

import com.tujuhsembilan.presensi79.model.Account;
import com.tujuhsembilan.presensi79.model.Employee;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
        Employee findByAccount(Account account);

        List<Employee> findAllByCompany_IdCompany(Integer idCompany);

        Page<Employee> findByDepartment_IdDepartment(Integer idDepartment, Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.company.idCompany = :companyId " +
                    "AND e.isDeleted = false " +
                    "AND (:keyword IS NULL OR (LOWER(e.firstName) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
                    "OR LOWER(e.lastName) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
                    "OR LOWER(e.department.departmentName) LIKE LOWER(CONCAT('%', :keyword, '%'))))")
    Page<Employee> findAllByCompanyIdAndKeywordAndIsDeletedFalse(
                    @Param("companyId") Integer companyId,
                    @Param("keyword") String keyword,
                    Pageable pageable);

        List<Employee> findTop5ByDepartment_IdDepartmentOrderByEmployeeNumber(Integer departmentId);

        Employee findByAccount_Username(String username);

        List<Employee> findByCompany_IdCompanyAndIsDeletedFalse(Integer companyId);

        List<Employee> findByCompany_IdCompanyAndDepartment_IdDepartmentAndIsDeletedFalse(Integer companyId,
                        Integer departmentId);

        @Query("SELECT e FROM Employee e WHERE e.department.idDepartment = :idDepartment " +
                        "AND (e.firstName LIKE %:keyword% " +
                        "OR e.lastName LIKE %:keyword% " +
                        "OR e.email LIKE %:keyword%)")
        Page<Employee> findByDepartmentAndKeyword(
                        @Param("idDepartment") Integer idDepartment,
                        @Param("keyword") String keyword,
                        Pageable pageable);

        // Menghitung jumlah total karyawan berdasarkan companyId
        @Query("SELECT COUNT(e) FROM Employee e WHERE e.company.idCompany = :companyId")
        long countByCompanyId(@Param("companyId") Integer companyId);

        Optional<Employee> findByEmployeeNumber(String employeeNumber);

    List<Employee> findAllByIsDeletedFalse();
}
