package com.tujuhsembilan.presensi79.dto.response;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AllAttendanceResponse {

    @JsonProperty("id_department")
    private Integer idDepartment;

    @JsonProperty("department_name")
    private String departmentName;

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("status")
    private String status;

    @JsonProperty("check_in")
    private LocalDateTime checkIn;

    @JsonProperty("check_out")
    private LocalDateTime checkOut;

    @JsonProperty("total_working_hours")
    private LocalTime totalWorkingHours;

    @JsonProperty("profile_picture")
    private String profilePicture;

    @JsonProperty("date_attendance")
    private LocalDate dateAttendance;

}
