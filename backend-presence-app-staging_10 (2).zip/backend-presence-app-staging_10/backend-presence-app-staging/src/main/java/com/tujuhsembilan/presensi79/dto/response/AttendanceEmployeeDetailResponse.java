package com.tujuhsembilan.presensi79.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceEmployeeDetailResponse {

    @JsonProperty("id_employee")
    private Integer idEmployee;

    @JsonProperty("date_attendance")
    private LocalDate dateAttendance;

    @JsonProperty("check_in")
    private Timestamp checkIn;

    @JsonProperty("check_out")
    private Timestamp checkOut;

    @JsonProperty("check_out_note")
    private String checkOutNote;

    @JsonProperty("total_working_hours")
    private LocalTime totalWorkingHours;

    @JsonProperty("status")
    private String status;

    @JsonProperty("message")
    private String message;
}
