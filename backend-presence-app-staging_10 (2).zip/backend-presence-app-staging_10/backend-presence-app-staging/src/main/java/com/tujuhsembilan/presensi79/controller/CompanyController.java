package com.tujuhsembilan.presensi79.controller;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.response.CompanyDto;
import com.tujuhsembilan.presensi79.security.jwt.JwtUtils;
import com.tujuhsembilan.presensi79.service.CompanyService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

import com.tujuhsembilan.presensi79.util.MessageUtil;
import com.tujuhsembilan.presensi79.util.Messages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "Company", description = Messages.TAG_COMPANY_DESCRIPTION)
@RestController
@RequestMapping("/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private MessageUtil messageUtil;

    @GetMapping(
        path = "/logo",
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<MessageResponse> getCompanyLogo(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization").substring(7);
        Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
        MessageResponse response = companyService.getCompanyLogo(idCompany);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @PatchMapping(path = "/logo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> changeCompanyLogo(
            @RequestParam("file") MultipartFile file, HttpServletRequest request) {
        try {
            // Extract the company ID from the JWT token
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);

            // Call the service method to change the company logo
            MessageResponse response = companyService.patchCompanyPhoto(idCompany, file);

            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping(
        path = "/coordinates",
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<MessageResponse> getCompanyCoordinates(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization").substring(7);
        Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
        MessageResponse response = companyService.getCompanyCoordinates(idCompany);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @PatchMapping(
        path = "/company-profile",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<MessageResponse> updateCompanyProfile(
        @Valid @RequestBody CompanyDto companyDto,
        HttpServletRequest request) {
        
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            
            MessageResponse response = companyService.updateCompanyProfile(idCompany, companyDto);
            
            if (response.getStatusCode() == HttpStatus.CREATED.value()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(new MessageResponse(
                    messageUtil.get("application.success.update", "Company profile"),
                    HttpStatus.CREATED.value(),
                    messageUtil.get("application.status.created"),
                    response.getData()
                ));
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    response.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    response.getErrorMessage()
                ));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                messageUtil.get("application.error.internal"),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                messageUtil.get("application.status.error"),
                e.getMessage()
            ));
        }
    }

    @GetMapping(
        path = "/company-profile",
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<MessageResponse> getCompanyInfo(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization").substring(7);
        Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
        MessageResponse response = companyService.getCompanyInfo(idCompany);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }
}
