package com.tujuhsembilan.presensi79.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class ChangePasswordByAdminRequest {
    @NotEmpty(message = "New password is required")
    @JsonProperty("new_password")
    private String newPassword;

    @NotEmpty(message = "Retype new password is required")
    @JsonProperty("retype_new_password")
    private String retypeNewPassword;
}