package com.tujuhsembilan.presensi79.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CompanyDTO {
    private Integer idCompany;
    private String companyName;
}
