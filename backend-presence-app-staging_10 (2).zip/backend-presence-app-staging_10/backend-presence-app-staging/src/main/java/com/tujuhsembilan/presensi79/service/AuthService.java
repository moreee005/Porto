package com.tujuhsembilan.presensi79.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.LoginRequest;
import com.tujuhsembilan.presensi79.dto.response.LoginResponse;
import com.tujuhsembilan.presensi79.model.Account;
import com.tujuhsembilan.presensi79.model.Admin;
import com.tujuhsembilan.presensi79.model.Employee;
import com.tujuhsembilan.presensi79.model.Superadmin;
import com.tujuhsembilan.presensi79.repository.AccountRepository;
import com.tujuhsembilan.presensi79.repository.AdminRepository;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.repository.SuperadminRepository;
import com.tujuhsembilan.presensi79.security.jwt.JwtUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AuthService {
    private final AccountRepository accountRepository;
    private final AdminRepository adminRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final SuperadminRepository superadminRepository;
    private final EmployeeRepository employeeRepository;
    private final JwtUtils jwtUtils;

    @Transactional
    public MessageResponse loginAll(LoginRequest request) {
        try {
            // Cari akun berdasarkan username
            Optional<Account> accountOptional = accountRepository.findByUsername(request.getUsername());

            // Validasi akun dan password
            if (!accountOptional.isPresent()) {
                return new MessageResponse(
                        "Login gagal: username atau password salah",
                        HttpStatus.UNAUTHORIZED.value(),
                        "UNAUTHORIZED");
            }

            // Ambil akun dari Optional
            Account account = accountOptional.get();

            // Cek apakah akun telah dihapus
            if (account.getIsDeleted()) {
                return new MessageResponse(
                        "Login gagal: akun telah dihapus",
                        HttpStatus.UNAUTHORIZED.value(),
                        "UNAUTHORIZED");
            }

            // Validasi password
            if (!passwordEncoder.matches(request.getPassword(), account.getPassword())) {
                return new MessageResponse(
                        "Login gagal: username atau password salah",
                        HttpStatus.UNAUTHORIZED.value(),
                        "UNAUTHORIZED");
            }

            // Jika sampai sini, akun valid dan password cocok
            Map<String, Object> claims = new HashMap<>();
            LoginResponse loginResponse = null;
            String role = account.getRole().toUpperCase();

            // Periksa role pengguna
            switch (role) {
                case "ADMIN":
                    Admin admin = adminRepository.findByAccount(account);
                    if (admin == null || admin.getIsDeleted()) { // Cek apakah admin telah dihapus
                        return new MessageResponse(
                                "Login gagal: admin tidak ditemukan atau telah dihapus",
                                HttpStatus.FORBIDDEN.value(),
                                "FORBIDDEN");
                    }
                    claims.put("id_account", account.getIdAccount());
                    claims.put("id_admin", admin.getIdAdmin());
                    claims.put("id_company", admin.getCompany().getIdCompany());

                    loginResponse = LoginResponse.builder()
                            .idAccount(account.getIdAccount())
                            .idAdmin(admin.getIdAdmin())
                            .idCompany(admin.getCompany().getIdCompany())
                            .token(jwtUtils.generateJwtToken(account.getUsername(), claims))
                            .type("Bearer")
                            .username(account.getUsername())
                            .role(account.getRole())
                            .build();
                    break;

                case "EMPLOYEE":
                    Employee employee = employeeRepository.findByAccount(account);
                    if (employee == null || employee.getIsDeleted()) { // Cek apakah employee telah dihapus
                        return new MessageResponse(
                                "Login gagal: employee tidak ditemukan atau telah dihapus",
                                HttpStatus.FORBIDDEN.value(),
                                "FORBIDDEN");
                    }
                    claims.put("id_account", account.getIdAccount());
                    claims.put("id_employee", employee.getIdEmployee());
                    claims.put("id_company", employee.getCompany().getIdCompany());

                    loginResponse = LoginResponse.builder()
                            .idAccount(account.getIdAccount())
                            .idEmployee(employee.getIdEmployee())
                            .idCompany(employee.getCompany().getIdCompany())
                            .token(jwtUtils.generateJwtToken(account.getUsername(), claims))
                            .type("Bearer")
                            .username(account.getUsername())
                            .role(account.getRole())
                            .build();
                    break;

                case "SUPERADMIN":
                    Optional<Superadmin> superadminOptional = superadminRepository.findByAccount(account);
                    if (!superadminOptional.isPresent() || superadminOptional.get().getIsDeleted()) {
                        return new MessageResponse(
                                "Login gagal: superadmin tidak ditemukan atau telah dihapus",
                                HttpStatus.UNAUTHORIZED.value(),
                                "UNAUTHORIZED");
                    }
                    Superadmin superadmin = superadminOptional.get();
                    claims.put("id_account", account.getIdAccount());
                    claims.put("id_superadmin", superadmin.getIdSuperadmin());

                    loginResponse = LoginResponse.builder()
                            .idAccount(account.getIdAccount())
                            .idSuperadmin(superadmin.getIdSuperadmin())
                            .token(jwtUtils.generateJwtToken(account.getUsername(), claims))
                            .type("Bearer")
                            .username(account.getUsername())
                            .role(account.getRole())
                            .build();
                    break;

                default:
                    return new MessageResponse(
                            "Login gagal: role tidak valid",
                            HttpStatus.FORBIDDEN.value(),
                            "FORBIDDEN");
            }

            // Mengembalikan respons sukses
            return new MessageResponse(
                    "Login berhasil",
                    HttpStatus.OK.value(),
                    "OK",
                    loginResponse);

        } catch (Exception e) {
            return new MessageResponse(
                    "Terjadi kesalahan internal",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage());
        }
    }
}
