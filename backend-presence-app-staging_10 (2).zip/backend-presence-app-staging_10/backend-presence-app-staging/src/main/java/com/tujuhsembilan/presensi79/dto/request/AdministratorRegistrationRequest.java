package com.tujuhsembilan.presensi79.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdministratorRegistrationRequest {

    @JsonProperty("first_name")
    @NotEmpty(message = "application.error.firstname.empty")
    @Size(min = 1, max = 255, message = "application.error.firstname.invalid")
    private String firstName;

    @JsonProperty("last_name")
    @NotEmpty(message = "application.error.lastname.empty")
    @Size(min = 1, max = 255, message = "application.error.lastname.invalid")
    private String lastName;

    @JsonProperty("username")
    @NotEmpty(message = "application.error.username.empty")
    @Size(min = 7, max = 20, message = "application.error.username.invalid")
    private String username;

    @JsonProperty("email")
    @NotEmpty(message = "application.error.email.empty")
    @Size(min = 1, max = 255, message = "application.error.email.invalid")
    private String email;

    @JsonProperty("password")
    @NotEmpty(message = "application.error.password.empty")
    @Size(min = 7, max = 20, message = "application.error.password.invalid")
    private String password;

    @JsonProperty("id_company")
    @NotNull(message = "application.error.companyid.empty")
    private Integer idCompany;

}
