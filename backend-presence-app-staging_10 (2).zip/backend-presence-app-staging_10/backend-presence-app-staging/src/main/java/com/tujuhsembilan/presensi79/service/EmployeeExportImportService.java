package com.tujuhsembilan.presensi79.service;

import com.tujuhsembilan.presensi79.dto.EmployeeRegistrationDTO;
import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.model.Account;
import com.tujuhsembilan.presensi79.model.Company;
import com.tujuhsembilan.presensi79.model.Department;
import com.tujuhsembilan.presensi79.model.Employee;
import com.tujuhsembilan.presensi79.repository.AccountRepository;
import com.tujuhsembilan.presensi79.repository.CompanyRepository;
import com.tujuhsembilan.presensi79.repository.DepartmentRepository;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.util.MessageUtil;
import jakarta.transaction.Transactional;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EmployeeExportImportService {

    private final EmployeeRepository employeeRepository;

    private final AccountRepository accountRepository;

    private final CompanyRepository companyRepository;

    private final DepartmentRepository departmentRepository;

    private final BCryptPasswordEncoder passwordEncoder;

    private final Validator validator;

    private final MessageUtil messageUtil;

    @Transactional
    public MessageResponse importEmployees(MultipartFile file, Integer companyId) {
        Set<String> errors = new HashSet<>();

        try (InputStream inputStream = file.getInputStream();
                Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row.getRowNum() == 0) {
                    continue; 
                }

                try {
                    String firstName = row.getCell(0) != null ? row.getCell(0).getStringCellValue().trim() : "";
                    String lastName = row.getCell(1) != null ? row.getCell(1).getStringCellValue().trim() : "";
                    String username = row.getCell(2) != null ? row.getCell(2).getStringCellValue().trim() : "";
                    String password = row.getCell(3) != null ? row.getCell(3).getStringCellValue().trim() : "";
                    String email = row.getCell(4) != null ? row.getCell(4).getStringCellValue().trim() : "";
                    String employeeNumber = row.getCell(5) != null ? row.getCell(5).getStringCellValue().trim() : "";
                    Integer departmentId = row.getCell(6) != null ? (int) row.getCell(6).getNumericCellValue() : null;
                    String roleCurrentCompany = row.getCell(7) != null ? row.getCell(7).getStringCellValue().trim()
                            : "";

                    EmployeeRegistrationDTO request = new EmployeeRegistrationDTO(
                            firstName, lastName, username, password, email,
                            employeeNumber, departmentId, roleCurrentCompany, companyId);

                    Set<ConstraintViolation<EmployeeRegistrationDTO>> violations = validator.validate(request);
                    if (!violations.isEmpty()) {
                        StringBuilder errorMsg = new StringBuilder("Validation errors: ");
                        for (ConstraintViolation<EmployeeRegistrationDTO> violation : violations) {
                            errorMsg.append(violation.getPropertyPath()).append(": ").append(violation.getMessage())
                                    .append("; ");
                        }
                        errors.add(errorMsg.toString());
                        continue; 
                    }

                    if (accountRepository.existsByUsername(username)) {
                        errors.add(messageUtil.get("application.error.already.exists", "Username") + ": " + username + " at row " + (row.getRowNum() + 1));
                        continue; 
                    }

                    Optional<Department> optionalDepartment = departmentRepository.findById(departmentId);
                    if (!optionalDepartment.isPresent()) {
                        continue;
                    }

                    Optional<Company> optionalCompany = companyRepository.findById(companyId);
                    if (!optionalCompany.isPresent()) {
                        continue;
                    }

                    Account account = Account.builder()
                            .username(username)
                            .password(passwordEncoder.encode(password))
                            .role("Employee")
                            .createdBy("Admin")
                            .createdDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                            .modifiedBy("Admin")
                            .modifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                            .build();
                    Account savedAccount = accountRepository.save(account);

                    Employee employee = Employee.builder()
                            .firstName(firstName)
                            .lastName(lastName)
                            .email(email)
                            .employeeNumber(employeeNumber)
                            .company(optionalCompany.get())
                            .department(optionalDepartment.get())
                            .roleCurrentCompany(roleCurrentCompany)
                            .joiningDate(LocalDate.now(ZoneId.of("Asia/Jakarta")))
                            .createdBy("Admin")
                            .createdDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                            .modifiedBy("Admin")
                            .modifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                            .account(savedAccount)
                            .build();
                    employeeRepository.save(employee);

                } catch (Exception e) {
                    log.error("Error processing row {}: {}", row.getRowNum(), e.getMessage());
                    errors.add(messageUtil.get("application.error.internal") + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            log.error("Error processing file: {}", e.getMessage());
            return new MessageResponse(
                    messageUtil.get("application.error.internal") + ": " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"));
        }

        if (errors.isEmpty()) {
            return new MessageResponse(
                    messageUtil.get("application.success.import", "Employee"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"));
        } else {
            return new MessageResponse(
                    messageUtil.get("application.error.import", "Employee") + ": " + errors.toString(),
                    HttpStatus.BAD_REQUEST.value(),
                    messageUtil.get("application.status.error"));
        }
    }

    public InputStream exportEmployeesByCompanyToXlsx(Integer companyId) {
        List<Employee> employees = employeeRepository.findByCompany_IdCompanyAndIsDeletedFalse(companyId);

        Workbook workbook = new XSSFWorkbook();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        Sheet sheet = workbook.createSheet("Employees");

        Row headerRow = sheet.createRow(0);
        String[] headers = { "Employee Number", "First Name", "Last Name", "Date of Birth", "Mobile Number", "Gender",
                "Marital Status", "Nationality", "Address", "Province", "City", "District", "Zip Code", "Status",
                "Email", "Role Current Company", "Role In Client", "Joining Date" };
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        int rowIdx = 1;
        for (Employee employee : employees) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(employee.getEmployeeNumber());
            row.createCell(1).setCellValue(employee.getFirstName());
            row.createCell(2).setCellValue(employee.getLastName());
            row.createCell(3)
                    .setCellValue(employee.getDateOfBirth() != null ? employee.getDateOfBirth().toString() : "");
            row.createCell(4).setCellValue(employee.getMobileNumber() != null ? employee.getMobileNumber() : "");
            row.createCell(5).setCellValue(employee.getGender() != null ? employee.getGender() : "");
            row.createCell(6).setCellValue(employee.getMaritalStatus() != null ? employee.getMaritalStatus() : "");
            row.createCell(7).setCellValue(employee.getNationality() != null ? employee.getNationality() : "");
            row.createCell(8).setCellValue(employee.getAddress() != null ? employee.getAddress() : "");
            row.createCell(9).setCellValue(employee.getProvince() != null ? employee.getProvince() : "");
            row.createCell(10).setCellValue(employee.getCity() != null ? employee.getCity() : "");
            row.createCell(11).setCellValue(employee.getDistrict() != null ? employee.getDistrict() : "");
            row.createCell(12).setCellValue(employee.getZipCode() != null ? employee.getZipCode() : "");
            row.createCell(13).setCellValue(employee.getStatus() != null ? employee.getStatus() : "");
            row.createCell(14).setCellValue(employee.getEmail());
            row.createCell(15).setCellValue(employee.getRoleCurrentCompany());
            row.createCell(16).setCellValue(employee.getRoleInClient() != null ? employee.getRoleInClient() : "");
            row.createCell(17).setCellValue(employee.getJoiningDate().toString());
        }

        try {
            workbook.write(out);
            workbook.close();
        } catch (Exception e) {
            e.getMessage();
        }

        return new ByteArrayInputStream(out.toByteArray());
    }

    public InputStream exportEmployeesByDepartmentToXlsx(Integer companyId, Integer departmentId) {
        List<Employee> employees = employeeRepository
                .findByCompany_IdCompanyAndDepartment_IdDepartmentAndIsDeletedFalse(companyId, departmentId);

        Workbook workbook = new XSSFWorkbook();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Sheet sheet = workbook.createSheet("Employees");

        Row headerRow = sheet.createRow(0);
        String[] headers = { "Employee Number", "First Name", "Last Name", "Date of Birth", "Mobile Number", "Gender",
                "Marital Status", "Nationality", "Address", "Province", "City", "District", "Zip Code", "Status",
                "Email", "Role Current Company", "Role In Client", "Joining Date" };
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        int rowIdx = 1;
        for (Employee employee : employees) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(employee.getEmployeeNumber());
            row.createCell(1).setCellValue(employee.getFirstName());
            row.createCell(2).setCellValue(employee.getLastName());
            row.createCell(3)
                    .setCellValue(employee.getDateOfBirth() != null ? employee.getDateOfBirth().toString() : "");
            row.createCell(4).setCellValue(employee.getMobileNumber() != null ? employee.getMobileNumber() : "");
            row.createCell(5).setCellValue(employee.getGender() != null ? employee.getGender() : "");
            row.createCell(6).setCellValue(employee.getMaritalStatus() != null ? employee.getMaritalStatus() : "");
            row.createCell(7).setCellValue(employee.getNationality() != null ? employee.getNationality() : "");
            row.createCell(8).setCellValue(employee.getAddress() != null ? employee.getAddress() : "");
            row.createCell(9).setCellValue(employee.getProvince() != null ? employee.getProvince() : "");
            row.createCell(10).setCellValue(employee.getCity() != null ? employee.getCity() : "");
            row.createCell(11).setCellValue(employee.getDistrict() != null ? employee.getDistrict() : "");
            row.createCell(12).setCellValue(employee.getZipCode() != null ? employee.getZipCode() : "");
            row.createCell(13).setCellValue(employee.getStatus() != null ? employee.getStatus() : "");
            row.createCell(14).setCellValue(employee.getEmail());
            row.createCell(15).setCellValue(employee.getRoleCurrentCompany());
            row.createCell(16).setCellValue(employee.getRoleInClient() != null ? employee.getRoleInClient() : "");
            row.createCell(17).setCellValue(employee.getJoiningDate().toString());
        }

        try {
            workbook.write(out);
            workbook.close();
        } catch (Exception e) {
            e.getMessage();
        }

        return new ByteArrayInputStream(out.toByteArray());
    }

}
