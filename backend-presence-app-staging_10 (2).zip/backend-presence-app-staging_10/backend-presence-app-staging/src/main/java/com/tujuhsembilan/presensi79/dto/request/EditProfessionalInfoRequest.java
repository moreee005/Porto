package com.tujuhsembilan.presensi79.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class EditProfessionalInfoRequest {
    @JsonProperty("employee_number")
    private String employeeNumber;

    @JsonProperty("username")
    private String username;

    @JsonProperty("status")
    private String status;

    @JsonProperty("email")
    private String email;

    @JsonProperty("id_department")
    private Integer idDepartment;

    @NotNull
    @JsonProperty("role_current_company") 
    private String roleCurrentCompany;

    @JsonProperty("role_in_client")
    private String roleInClient;

    @JsonProperty("joining_date")
    private LocalDate joiningDate;
}
