package com.tujuhsembilan.presensi79.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentDetailsResponse {
    private Integer idDepartment;
    private String departmentName;
    private List<TopEmployeeResponse> topEmployees;
    private Integer totalEmployees;
}
