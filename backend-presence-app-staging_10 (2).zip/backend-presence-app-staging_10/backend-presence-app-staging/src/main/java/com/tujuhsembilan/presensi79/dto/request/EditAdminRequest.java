package com.tujuhsembilan.presensi79.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EditAdminRequest {
    @NotNull(message = "'first_name' field is required")
    @JsonProperty("first_name")
    private String firstName;

    @NotNull(message = "'last_name' field is required")
    @JsonProperty("last_name")
    private String lastName;

    @NotNull(message = "'username' field is required")
    @JsonProperty("username")
    private String username;

    @NotNull(message = "'email' field is required")
    @Email(message = "'email' should be valid")
    @JsonProperty("email")
    private String email;
}
