package com.tujuhsembilan.presensi79.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRegistrationDTO {

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("last_name")
    private String lastName;

    private String username;

    private String password;

    private String email;

    @JsonProperty("employee_number")
    private String employeeNumber;

    @JsonProperty("id_department")
    private Integer idDepartment;

    @JsonProperty("role_current_company")
    private String roleCurrentCompany;

    @JsonProperty("id_company")
    private Integer idCompany;
}
