package com.tujuhsembilan.presensi79.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LeaveCardDepartmentResponse {

    @JsonProperty("id_leave")
    private Integer idLeave;

    @JsonProperty("id_employee")
    private Integer idEmployee;

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("id_department")
    private Integer idDepartment;

    @JsonProperty("department_name")
    private String departmentName;

    @JsonProperty("profile_picture")
    private String profilePicture;

    @JsonProperty("leave_title")
    private String leaveTitle;

    @JsonProperty("leave_type")
    private String leaveType;

    @JsonProperty("start_date")
    private LocalDate startDate;

    @JsonProperty("end_date")
    private LocalDate endDate;

    @JsonProperty("reason")
    private String reason;

    @JsonProperty("attachment")
    private String attachment;

    @JsonProperty("status")
    private String status;

    @JsonProperty("created_by")
    private String createdBy;

    @JsonProperty("created_date")
    private Timestamp createdDate;

    @JsonProperty("modified_by")
    private String modifiedBy;

    @JsonProperty("modified_date")
    private Timestamp modifiedDate;
}
