package com.tujuhsembilan.presensi79.service;

import com.tujuhsembilan.presensi79.config.minio.MinioService;
import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.AddDepartmentRequest;
import com.tujuhsembilan.presensi79.dto.response.DepartmentDetailsResponse;
import com.tujuhsembilan.presensi79.dto.response.DepartmentResponse;
import com.tujuhsembilan.presensi79.dto.response.TopEmployeeResponse;
import com.tujuhsembilan.presensi79.model.Company;
import com.tujuhsembilan.presensi79.model.Department;
import com.tujuhsembilan.presensi79.repository.CompanyRepository;
import com.tujuhsembilan.presensi79.repository.DepartmentRepository;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.util.MessageUtil;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final MessageUtil messageUtil;
    private final EmployeeRepository employeeRepository;
    private final CompanyRepository companyRepository;
    private final MinioService minioService;

    @Transactional
    public MessageResponse getDepartmentsByCompany(Integer idCompany) {
        try {
            List<Department> departments = departmentRepository.findByCompany_IdCompanyAndIsDeletedFalseOrderByIdDepartmentAsc(idCompany);
            if (departments.isEmpty()) {
                return new MessageResponse(
                    messageUtil.get("application.error.notfound", "Departments"),
                    HttpStatus.NOT_FOUND.value(),
                    messageUtil.get("application.status.notfound")
                );
            } else {
                List<DepartmentResponse> departmentResponses = departments.stream()
                    .map(department -> DepartmentResponse.builder()
                        .idDepartment(department.getIdDepartment())
                        .departmentName(department.getDepartmentName())
                        .build()
                    ).collect(Collectors.toList());

                return new MessageResponse(
                    messageUtil.get("application.success.retrieve", "Departments"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    departmentResponses
                );
            }
        } catch (Exception e) {
            return new MessageResponse(
                messageUtil.get("application.error.internal"),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                messageUtil.get("application.status.error"),
                e.getMessage()
            );
        }
    }
    
        public List<DepartmentDetailsResponse> getAllDepartmentsByCompany(Integer companyId) {
        List<Department> departments = departmentRepository
                .findByCompany_IdCompanyAndIsDeletedFalseOrderByIdDepartmentAsc(companyId);

        return departments.stream().map(department -> {
            List<TopEmployeeResponse> topEmployees = employeeRepository
                    .findTop5ByDepartment_IdDepartmentOrderByEmployeeNumber(department.getIdDepartment())
                    .stream()
                    .map(employee -> {
                        // Mendapatkan URL gambar profil dari Minio jika tersedia
                        String profilePictureUrl = employee.getProfilePicture() != null
                                ? minioService.getPublicLink(employee.getProfilePicture())
                                : null;

                        // Tambahkan pengecekan null untuk employee.getAccount()
                        String username = (employee.getAccount() != null) 
                                ? employee.getAccount().getUsername() 
                                : "No Account";

                        // Mengembalikan response karyawan dengan pengecekan null
                        return new TopEmployeeResponse(
                                employee.getIdEmployee(),
                                employee.getFirstName() + " " + employee.getLastName(),
                                profilePictureUrl,
                                username,
                                employee.getRoleCurrentCompany()
                        );
                    })
                    .collect(Collectors.toList());

            return new DepartmentDetailsResponse(
                    department.getIdDepartment(),
                    department.getDepartmentName(),
                    topEmployees,
                    topEmployees.size()
            );
        }).collect(Collectors.toList());
    }



    @Transactional
    public Department addDepartment(AddDepartmentRequest departmentRequest, Integer idCompany) {
        // Validasi idCompany dan departmentName jika perlu
        Optional<Company> company = companyRepository.findById(idCompany);
        if (!company.isPresent()) {
            throw new RuntimeException(messageUtil.get("application.error.notfound", "Company"));
        }

       Optional<Department> existingDepartment = departmentRepository.findByDepartmentNameAndCompany_IdCompany(departmentRequest.getDepartmentName(), idCompany);
        if (existingDepartment.isPresent()) {
            throw new DataIntegrityViolationException(
                messageUtil.get("application.error.already.exists", "Department"));
        }

        Department department = Department.builder()
                .departmentName(departmentRequest.getDepartmentName())
                .company(company.get())
                .createdDate(new Timestamp(System.currentTimeMillis()))
                .build();

        return departmentRepository.save(department);
    }

    @Transactional
    public MessageResponse importDepartments(MultipartFile file, Integer idCompany) {
        Set<String> errors = new HashSet<>();

        try (InputStream inputStream = file.getInputStream();
                Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row.getRowNum() == 0) {
                    continue; // Skip header row
                }

                try {
                    String departmentName = row.getCell(0) != null ? row.getCell(0).getStringCellValue().trim() : "";

                    if (departmentName.isEmpty()) {
                        continue;
                    }

                    // Check if the company exists
                    Optional<Company> optionalCompany = companyRepository.findById(idCompany);
                    if (!optionalCompany.isPresent()) {
                        continue;
                    }

                    // Check if the department already exists
                    Optional<Department> existingDepartment = departmentRepository
                            .findByDepartmentNameAndCompany_IdCompany(departmentName, idCompany);
                    if (existingDepartment.isPresent()) {
                        String errorMsg = "Department already exists: " + departmentName + " at row "
                                + (row.getRowNum() + 1);
                        log.error(errorMsg);
                        errors.add(errorMsg);
                        continue;
                    }

                    // Create and save the department
                    Department department = Department.builder()
                            .departmentName(departmentName)
                            .company(optionalCompany.get())
                            .createdDate(new Timestamp(System.currentTimeMillis()))
                            .build();
                    departmentRepository.save(department);

                } catch (Exception e) {
                    log.error("Error processing row {}: {}", row.getRowNum(), e.getMessage());
                    errors.add(messageUtil.get("application.error.internal") + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            log.error("Error processing file: ", e);
            return new MessageResponse(
                    messageUtil.get("application.error.internal") + ": " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"));
        }

        if (errors.isEmpty()) {
            return new MessageResponse(
                    messageUtil.get("application.success.import", "Departments"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"));
        } else {
            return new MessageResponse(
                    messageUtil.get("application.error.import", "Departments") + "with some errors: "
                            + errors.toString(),
                    HttpStatus.BAD_REQUEST.value(),
                    messageUtil.get("application.status.error"));
        }
    }


    @Transactional
    public void editDepartment(Integer idDepartment, Integer idCompany, String departmentName) {
        Optional<Company> company = companyRepository.findById(idCompany);
        if (!company.isPresent()) {
            throw new RuntimeException(messageUtil.get("application.error.notfound", "Company"));
        }

        Optional<Department> departmentOpt = departmentRepository.findById(idDepartment);
        if (!departmentOpt.isPresent()) {
            throw new RuntimeException(messageUtil.get("application.error.notfound", "Department"));
        }

        Department department = departmentOpt.get();

        Optional<Department> existingDepartment = departmentRepository
                .findByDepartmentNameAndCompany_IdCompany(departmentName, idCompany);
        if (existingDepartment.isPresent() && !existingDepartment.get().getIdDepartment().equals(idDepartment)) {
            throw new DataIntegrityViolationException(
                messageUtil.get("application.error.already.exists", "Department"));

        }

        // Update nama department
        department.setDepartmentName(departmentName);
        department.setModifiedDate(new Timestamp(System.currentTimeMillis()));

        departmentRepository.save(department);
    }

    @Transactional
    public MessageResponse softDeleteDepartment(Integer idDepartment) {
        try {
            Optional<Department> departmentOpt = departmentRepository.findById(idDepartment);
            if (!departmentOpt.isPresent()) {
                return new MessageResponse(
                    messageUtil.get("application.error.notfound", "Department"),
                    HttpStatus.NOT_FOUND.value(),
                    messageUtil.get("application.status.notfound"));
            }

            Department department = departmentOpt.get();
            department.setIsDeleted(true);
            departmentRepository.save(department);

            return new MessageResponse(
                messageUtil.get("application.success.update", "Department"),
                HttpStatus.OK.value(),
                messageUtil.get("application.status.ok"));

        } catch (Exception e) {
            return new MessageResponse(
                messageUtil.get("application.error.internal"),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                messageUtil.get("application.status.error"),
                e.getMessage());
        }
    }

}
