package com.tujuhsembilan.presensi79.repository;

import com.tujuhsembilan.presensi79.model.Leave;

import java.util.Optional;
import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeaveRepository extends JpaRepository<Leave, Integer> {
        Page<Leave> findByEmployee_IdEmployee(Integer idEmployee, Pageable pageable);

        @Query("SELECT l FROM Leave l " +
                        "WHERE l.employee.company.idCompany = :idCompany " +
                        "AND (:keyword IS NULL OR " +
                        "(LOWER(l.employee.firstName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
                        "LOWER(l.employee.lastName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
                        "LOWER(l.employee.department.departmentName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
                        "LOWER(l.leaveType) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
                        "LOWER(l.status) LIKE LOWER(CONCAT('%', :keyword, '%')))) " +
                        "AND (COALESCE(:startDate, l.startDate) <= l.startDate) " +
                        "AND (COALESCE(:endDate, l.endDate) >= l.endDate)")
        Page<Leave> findByCompanyAndMultipleFilters(@Param("idCompany") Integer idCompany,
                        @Param("keyword") String keyword,
                        @Param("startDate") LocalDate startDate,
                        @Param("endDate") LocalDate endDate,
                        Pageable pageable);

        Optional<Leave> findByIdLeaveAndEmployee_IdEmployee(Integer idLeave, Integer idEmployee);

        Page<Leave> findAll(Pageable pageable);

        List<Leave> findByEmployee_Company_IdCompany(Integer idCompany);

        Page<Leave> findByEmployee_Company_IdCompany(Integer idCompany, Pageable pageable);

        List<Leave> findByEmployee_Company_IdCompanyAndIsDeletedFalse(Integer idCompany);

        // Menghitung jumlah cuti hari ini
        @Query("SELECT COUNT(l) FROM Leave l WHERE l.employee.company.idCompany = :companyId AND :today BETWEEN l.startDate AND l.endDate")
        long countTodayLeaveByCompanyId(@Param("companyId") Integer companyId, @Param("today") LocalDate today);

        // Menghitung jumlah cuti minggu ini (mulai dari hari Senin)
        @Query("SELECT COUNT(l) FROM Leave l WHERE l.employee.company.idCompany = :companyId AND l.startDate >= :startOfWeek")
        long countThisWeekLeaveByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfWeek") LocalDate startOfWeek);

        // Menghitung jumlah cuti bulan ini (mulai dari tanggal 1)
        @Query("SELECT COUNT(l) FROM Leave l WHERE l.employee.company.idCompany = :companyId AND l.startDate >= :startOfMonth")
        long countThisMonthLeaveByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfMonth") LocalDate startOfMonth);

        // Menghitung jumlah karyawan yang cuti berdasarkan departmentId dan
        // tanggal
        @Query("SELECT COUNT(l) FROM Leave l WHERE l.employee.department.idDepartment = :departmentId AND :date BETWEEN l.startDate AND l.endDate")
        long countTodayLeaveByDepartmentId(@Param("departmentId") Integer departmentId, @Param("date") LocalDate date);

}
