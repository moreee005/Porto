package com.tujuhsembilan.presensi79.dto.response;

import com.tujuhsembilan.presensi79.dto.DepartmentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceListResponse {

    private DepartmentDTO department;
    private Integer idEmployee;
    private String employeeName;
    private String status;
    private String checkIn;
    private String totalWorkingHours;
    private String profilePicture;
}