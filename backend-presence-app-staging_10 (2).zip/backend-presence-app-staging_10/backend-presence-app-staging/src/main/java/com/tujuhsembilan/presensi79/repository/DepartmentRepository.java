package com.tujuhsembilan.presensi79.repository;

import com.tujuhsembilan.presensi79.model.Department;

import java.util.Optional;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {
    Optional<Department> findById(Integer idDepartment);

    // Mengambil semua departemen berdasarkan companyId
    List<Department> findAllByCompany_IdCompany(Integer companyId);

    // Mengambil daftar departemen untuk perusahaan tertentu dan mengurutkan
    // berdasarkan idDepartment secara ascending
    List<Department> findByCompany_IdCompanyAndIsDeletedFalseOrderByIdDepartmentAsc(Integer idCompany);

    Optional<Department> findByDepartmentNameAndCompany_IdCompany(String departmentName, Integer idCompany);
}
