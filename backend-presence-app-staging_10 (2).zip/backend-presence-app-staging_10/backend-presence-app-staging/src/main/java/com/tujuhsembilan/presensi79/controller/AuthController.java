package com.tujuhsembilan.presensi79.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.LoginRequest;
import com.tujuhsembilan.presensi79.service.AuthService;
import com.tujuhsembilan.presensi79.util.Messages;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "Auth", description = Messages.TAG_AUTH_DESCRIPTION)
@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private AuthService authService;

    @PostMapping(path = "/login", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> loginAll(@Valid @RequestBody LoginRequest request) {
        MessageResponse response = authService.loginAll(request);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }
}
