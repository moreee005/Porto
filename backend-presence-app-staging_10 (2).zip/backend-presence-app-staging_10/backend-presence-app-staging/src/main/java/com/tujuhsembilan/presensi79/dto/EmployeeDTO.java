package com.tujuhsembilan.presensi79.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmployeeDTO {
    private Integer idEmployee;
    private String employeeNumber;
    private String employeeName;
    private String username;
    private DepartmentDTO department;
    private String status;
    private String roleCurrentCompany;
    private String roleInClient;
    private CompanyDTO company;
    private String profilePicture;
}
