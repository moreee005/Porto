package com.tujuhsembilan.presensi79.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.tujuhsembilan.presensi79.dto.EmployeeDTO;
import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.EditPersonalInfoRequest;
import com.tujuhsembilan.presensi79.dto.request.EditProfessionalInfoRequest;
import com.tujuhsembilan.presensi79.dto.request.AddDepartmentRequest;
import com.tujuhsembilan.presensi79.dto.request.AdministratorRegistrationRequest;
import com.tujuhsembilan.presensi79.dto.request.ChangePasswordByAdminRequest;
import com.tujuhsembilan.presensi79.dto.request.CompanyConfigRequest;
import com.tujuhsembilan.presensi79.dto.request.EditAdminRequest;
import com.tujuhsembilan.presensi79.dto.request.EmployeeRegistrationRequest;
import com.tujuhsembilan.presensi79.dto.request.UpdateLeaveStatusRequest;
import com.tujuhsembilan.presensi79.dto.response.AttendanceOverviewResponse;
import com.tujuhsembilan.presensi79.dto.response.DashboardSummaryResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeePersonalInformationResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeeProfessionalInformationResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeeProfileResponse;
import com.tujuhsembilan.presensi79.exception.CustomErrorWithStatusException;
import com.tujuhsembilan.presensi79.security.jwt.JwtUtils;
import com.tujuhsembilan.presensi79.service.EmployeeService;
import com.tujuhsembilan.presensi79.service.LeaveService;
import com.tujuhsembilan.presensi79.service.AdminManagementService;
import com.tujuhsembilan.presensi79.service.AttendanceService;
import com.tujuhsembilan.presensi79.service.CompanyConfigService;
import com.tujuhsembilan.presensi79.service.DepartmentService;
import com.tujuhsembilan.presensi79.service.EmployeeExportImportService;
import com.tujuhsembilan.presensi79.util.MessageUtil;
import com.tujuhsembilan.presensi79.service.SuperAdminService;
import com.tujuhsembilan.presensi79.util.Messages;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Tag(name = "Admin", description = Messages.TAG_SUPER_ADMIN_DESCRIPTION)
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdminController {

    private final EmployeeService employeeService;
    private final EmployeeExportImportService employeeExportImportService;
    private final DepartmentService departmentService;
    private final AdminManagementService adminService;
    private final AttendanceService attendanceService;
    private final LeaveService leaveService;
    private final MessageUtil messageUtil;
    private final CompanyConfigService companyConfigService;
    private final AdminManagementService adminManagementService;
    private final JwtUtils jwtUtils;
    private final SuperAdminService superAdminService;

    @PatchMapping(path = "/change-profile-picture", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> changeAdminProfilePicture(
            @RequestParam("file") MultipartFile file, HttpServletRequest request) {
        try {
            // Extract the admin ID from the JWT token
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idAdmin = jwtUtils.getAdminIdFromJwtToken(authToken);

            // Call the service method to change the profile picture
            MessageResponse response = adminManagementService.changeAdminProfilePicture(idAdmin, file);

            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/employee")
    public ResponseEntity<?> getAllEmployeesByCompanyId(
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            HttpServletRequest request) {

        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            Pageable pageable = PageRequest.of(page, size, Sort.by("idEmployee").ascending());
            Page<EmployeeDTO> employeePage = employeeService.getAllEmployeesByCompanyIdAndKeyword(
                    idCompany, keyword,
                    pageable);
            List<EmployeeDTO> employees = employeePage.getContent();
            long totalData = employeePage.getTotalElements();
            int totalPage = employeePage.getTotalPages();

            MessageResponse response = new MessageResponse(
                    messageUtil.get("application.success.retrieve.all", "employees"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    employees,
                    totalData,
                    totalPage,
                    size);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @PostMapping(path = "/create-employee", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> createEmployee(
            @Valid @RequestBody EmployeeRegistrationRequest employeeRequest,
            HttpServletRequest request) {
        String authToken = request.getHeader("Authorization").substring(7);
        Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
        MessageResponse response = employeeService.registerEmployee(employeeRequest, idCompany);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @PostMapping(path = "/import-employees", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> importEmployees(
            @RequestParam("file") MultipartFile file,
            HttpServletRequest request) {
        try {
            // Extract the company ID from the JWT token
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);

            // Pass the company ID to the service method
            MessageResponse response = employeeExportImportService.importEmployees(file, idCompany);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/company/employees/export")
    public ResponseEntity<?> exportEmployeesToCsv(HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            InputStream is = employeeExportImportService.exportEmployeesByCompanyToXlsx(companyId);

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=employees.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(is));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @PatchMapping("/employee/{id_employee}/personal-info")
    public ResponseEntity<?> updateEmployeePersonalInfo(
            @PathVariable("id_employee") Integer idEmployee,
            @Valid @RequestBody EditPersonalInfoRequest infoRequest, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = employeeService.updateEmployeePersonalInfo(idEmployee, infoRequest);

            return ResponseEntity.status(HttpStatus.OK).body(new MessageResponse(
                    messageUtil.get("application.success.update", "Personal information"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    response.getData()));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/employee/{id_employee}/professional-info")
    public ResponseEntity<?> updateEmployeeProfessionalInfo(
            @PathVariable("id_employee") Integer idEmployee,
            @Valid @RequestBody EditProfessionalInfoRequest infoRequest, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = employeeService.updateEmployeeProfessionalInfo(idEmployee, infoRequest);

            return ResponseEntity.status(HttpStatus.OK).body(new MessageResponse(
                    messageUtil.get("application.success.update", "Professional information"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    response.getData()));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PostMapping(path = "/employees", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> createAdministrator(@RequestBody AdministratorRegistrationRequest request) {

        MessageResponse response;
        try {
            response = superAdminService.registerAdministratorTransactional(request);
        } catch (CustomErrorWithStatusException e) {
            response = new MessageResponse();
            response.setStatusCode(e.getStatus().value());
            response.setStatus(e.getStatus().getReasonPhrase());
            response.setErrorMessage(e.getErrorMessage());
            response.setMessage(e.getMessage());
        }
        return ResponseEntity.status(response.getStatusCode()).body(response);

    }

    @PatchMapping(path = "/employee/{id_employee}/change-password", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> changeEmployeePassword(
            @PathVariable("id_employee") Integer idEmployee,
            @Valid @RequestBody ChangePasswordByAdminRequest changePasswordRequest, HttpServletRequest request) {

        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = employeeService.changeEmployeePassword(idEmployee, changePasswordRequest);

            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/employee/username/{username}")
    public ResponseEntity<MessageResponse> getEmployeeIdByUsername(@PathVariable("username") String username) {
        MessageResponse response = employeeService.getEmployeeIdByUsername(username);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/employee/{id_employee}/profile")
    public ResponseEntity<MessageResponse> getEmployeeProfileOverview(@PathVariable("id_employee") Integer idEmployee,
            HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            EmployeeProfileResponse profileResponse = employeeService.getEmployeeProfileResponse(idEmployee);

            if (profileResponse == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(
                        messageUtil.get("application.error.notfound", "Employee"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound")));
            }

            return ResponseEntity.ok(new MessageResponse(
                    messageUtil.get("application.success.retrieve", "profile overview"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    profileResponse));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/employee/{id_employee}/personal-info")
    public ResponseEntity<MessageResponse> getEmployeePersonalInformation(
            @PathVariable("id_employee") Integer idEmployee, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            EmployeePersonalInformationResponse personalInfoResponse = employeeService
                    .getEmployeePersonalInformationrResponse(idEmployee);

            if (personalInfoResponse == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(
                        messageUtil.get("application.error.notfound", "Employee"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound")));
            }

            return ResponseEntity.ok(new MessageResponse(
                    messageUtil.get("application.success.retrieve", "personal information"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    personalInfoResponse));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/employee/{id_employee}/professional-info")
    public ResponseEntity<MessageResponse> getEmployeeProfessionalInformation(
            @PathVariable("id_employee") Integer idEmployee, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            EmployeeProfessionalInformationResponse professionalInfoResponse = employeeService
                    .getEmployeeProfessionalInformationResponse(idEmployee);

            if (professionalInfoResponse == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(
                        messageUtil.get("application.error.notfound", "Employee"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound")));
            }

            return ResponseEntity.ok(new MessageResponse(
                    messageUtil.get("application.success.retrieve", "professional information"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    professionalInfoResponse));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping(path = "/employee/{id_employee}/change-profile-picture", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> changeEmployeeProfilePicture(
            @PathVariable("id_employee") Integer idEmployee,
            @RequestParam("file") MultipartFile file, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = employeeService.changeProfilePicture(idEmployee, file);

            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/employee/{id_employee}/delete-employee")
    public ResponseEntity<MessageResponse> softDeleteEmployee(
            @PathVariable("id_employee") Integer idEmployee, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = employeeService.softDeleteEmployee(idEmployee);

            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/employee/{id_employee}/attendances/{id_attendance}")
    public ResponseEntity<MessageResponse> softDeleteEmployeeAttendance(
            @PathVariable("id_employee") Integer idEmployee,
            @PathVariable("id_attendance") Integer idAttendance, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = attendanceService.softDeleteEmployeeAttendance(idEmployee, idAttendance);

            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PostMapping(path = "/department/add", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> addDepartment(
            @Valid @RequestBody AddDepartmentRequest departmentRequest, HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            departmentService.addDepartment(departmentRequest, idCompany);
            MessageResponse response = new MessageResponse(
                    messageUtil.get("application.success.create", "Department"),
                    HttpStatus.CREATED.value(),
                    messageUtil.get("application.status.created"));
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (DataIntegrityViolationException e) {
            MessageResponse response = new MessageResponse(
                    messageUtil.get("application.error.already.exists", "Department"),
                    HttpStatus.CONFLICT.value(),
                    messageUtil.get("application.status.conflict"),
                    e.getMessage());
            return ResponseEntity.status(409).body(response);
        } catch (Exception e) {
            MessageResponse response = new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    @PostMapping(path = "/department/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> importDepartments(
            @RequestParam("file") MultipartFile file,
            HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            log.debug("Authorization Header: " + authToken);
            MessageResponse response = departmentService.importDepartments(file, idCompany);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error occurred while importing departments", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping(path = "/department/{id_department}/edit-department", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> editDepartment(
            @PathVariable("id_department") Integer idDepartment,
            @Valid @RequestBody Map<String, String> requestBody,
            HttpServletRequest request) {

        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            String departmentName = requestBody.get("department_name");

            if (departmentName == null || departmentName.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(
                        messageUtil.get("application.error.missing", "Department name"),
                        HttpStatus.BAD_REQUEST.value(),
                        messageUtil.get("application.status.badrequest")));
            }

            departmentService.editDepartment(idDepartment, idCompany, departmentName);

            return ResponseEntity.ok(new MessageResponse(
                    messageUtil.get("application.success.update", "Department"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok")));

        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(new MessageResponse(
                    messageUtil.get("application.error.already.exists", "Department"),
                    HttpStatus.CONFLICT.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/department/{id_department}/delete-department")
    public ResponseEntity<MessageResponse> softDeleteDepartment(
            @PathVariable("id_department") Integer idDepartment, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = departmentService.softDeleteDepartment(idDepartment);

            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/information")
    public ResponseEntity<MessageResponse> getAdminInformation(HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idAdmin = jwtUtils.getAdminIdFromJwtToken(authToken);
            MessageResponse response = adminService.getAdminInformation(idAdmin);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/information")
    public ResponseEntity<MessageResponse> updateAdminInformation(
            HttpServletRequest request,
            @Valid @RequestBody EditAdminRequest editAdminRequest) {

        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idAdmin = jwtUtils.getAdminIdFromJwtToken(authToken);
            MessageResponse response = adminService.updateAdminInformation(idAdmin, editAdminRequest);
            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/change-password")
    public ResponseEntity<MessageResponse> changeAdminPassword(
            HttpServletRequest request,
            @Valid @RequestBody ChangePasswordByAdminRequest changePasswordByAdminRequest) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idAdmin = jwtUtils.getAdminIdFromJwtToken(authToken);
            MessageResponse response = adminService.changeAdminPassword(idAdmin, changePasswordByAdminRequest);
            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping("/dashboard/attendance-list")
    public ResponseEntity<MessageResponse> getTopAttendanceList(HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = adminService.getTopAttendanceList();
            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @PatchMapping("/employee/{id_employee}/leaves/{id_leave}")
    public ResponseEntity<MessageResponse> softDeleteEmployeeLeave(
            @PathVariable("id_employee") Integer idEmployee,
            @PathVariable("id_leave") Integer idLeave, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = leaveService.softDeleteEmployeeLeave(idEmployee, idLeave);

            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping(path = "/attendance", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAttendanceByCompany(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "") String keyword, // Menambahkan keyword
            HttpServletRequest request) {
        try {
            // Mengambil token dari header Authorization
            String authToken = request.getHeader("Authorization").substring(7);

            // Mendapatkan ID perusahaan dari token JWT
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);

            // Memanggil service untuk mendapatkan data kehadiran berdasarkan idCompany dan
            // keyword
            MessageResponse response = attendanceService.getAttendanceByCompany(idCompany, page, pageSize, keyword);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new MessageResponse("T-ATT-ERR-001", HttpStatus.INTERNAL_SERVER_ERROR.value(), "ERROR",
                            e.getMessage()));
        }
    }

    @PostMapping(path = "/company/attendance/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> importAttendance(
            @RequestParam("file") MultipartFile file,
            HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            log.debug("Authorization Header: " + authToken);
            MessageResponse response = attendanceService.importAttendance(file, idCompany);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error occurred while importing attendance", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()));
        }
    }

    @GetMapping(path = "/department/{id_department}/employees", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getEmployeesByDepartment(
            @PathVariable("id_department") Integer idDepartment,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "") String keyword, HttpServletRequest request) {
        try {
            request.getHeader("Authorization").substring(7);
            MessageResponse response = employeeService.getEmployeesByDepartment(idDepartment, page, size, keyword);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new MessageResponse("T-EMP-ERR-001", HttpStatus.INTERNAL_SERVER_ERROR.value(), "ERROR",
                            e.getMessage()));
        }
    }

    @GetMapping(path = "/company/leaves", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> getAllLeavesForCompany(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
            // Menggunakan parameter tambahan dalam pemanggilan metode
            MessageResponse response = leaveService.getAllLeavesByCompanyId(idCompany, page, size, keyword, from, to);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new MessageResponse("Error fetching all company leaves", HttpStatus.INTERNAL_SERVER_ERROR.value(),
                            "ERROR", e.getMessage()));
        }
    }

    @GetMapping(path = "/company/{id_company}/config", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getCompanyConfig(@PathVariable("id_company") Integer idCompany,
            HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            // Validasi apakah idCompany yang dimasukkan sama dengan companyId dari token
            // JWT
            if (!idCompany.equals(companyId)) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(
                        messageUtil.get("application.error.notfound", "Configuration"),
                        HttpStatus.NOT_FOUND.value(),
                        "NOT_FOUND"));
            }

            MessageResponse response = companyConfigService.getCompanyConfig(idCompany);
            return ResponseEntity.status(response.getStatusCode()).body(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @Operation(summary = "Get Employee Attendance", description = "Retrieve attendance details of an employee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved attendance details", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "404", description = "Employee not found", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(schema = @Schema(implementation = MessageResponse.class)))
    })
    @GetMapping(path = "/employee/{id_employee}/attendances", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getEmployeeAttendances(
            @PathVariable("id_employee") Integer idEmployee) {
        try {
            MessageResponse response = attendanceService.getAttendanceDetailsByEmployee(idEmployee);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new MessageResponse("T-SDT-ERR-001", HttpStatus.INTERNAL_SERVER_ERROR.value(), "ERROR",
                            e.getMessage()));
        }
    }

    @Operation(summary = "Get Employee Leave", description = "Retrieve leave details of an employee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved leave details", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "403", description = "Forbidden access", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "404", description = "Employee not found", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(schema = @Schema(implementation = MessageResponse.class)))
    })
    @GetMapping(path = "/employee/{id_employee}/leaves", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getEmployeeLeaves(
            @PathVariable("id_employee") Integer idEmployee,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            HttpServletRequest request) {
        try {
            // Mendapatkan token otorisasi dari header
            String authToken = request.getHeader("Authorization");

            // Memeriksa apakah token ada dan valid
            if (authToken == null || !jwtUtils.validateJwtToken(authToken.substring(7))) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(
                        new MessageResponse("Forbidden access", HttpStatus.FORBIDDEN.value(), "FORBIDDEN"));
            }

            // Mengambil data cuti
            MessageResponse response = leaveService.getAllLeaves(idEmployee, page, size);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new MessageResponse("T-SDT-ERR-001", HttpStatus.INTERNAL_SERVER_ERROR.value(), "ERROR",
                            e.getMessage()));
        }
    }

    @PatchMapping(path = "/company/config", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> editCompanyConfig(
            @Valid @RequestBody CompanyConfigRequest request,
            HttpServletRequest httpServletRequest) {

        String authToken = httpServletRequest.getHeader("Authorization").substring(7);
        Integer companyIdFromToken = jwtUtils.getCompanyIdFromJwtToken(authToken);

        // Proceed with updating the company configuration using the company ID from the
        // token
        MessageResponse response = companyConfigService.updateCompanyConfig(companyIdFromToken, request);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping("/company/leaves/{id_leave}/detail")
    public ResponseEntity<?> getLeaveDetailById(
            @PathVariable Integer id_leave) {

        try {
            MessageResponse response = leaveService.getLeaveDetailById(id_leave);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @Operation(summary = "Update Leave Status", description = "Update the status of a leave request by leave ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully updated leave status", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "404", description = "Leave not found", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(schema = @Schema(implementation = MessageResponse.class)))
    })
    @PatchMapping(path = "/company/leaves/{id_leave}/status", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> updateLeaveStatus(
            @PathVariable("id_leave") Integer idLeave,
            @Valid @RequestBody UpdateLeaveStatusRequest request) {

        try {
            MessageResponse response = leaveService.updateLeaveStatus(idLeave, request);
            return ResponseEntity.status(response.getStatusCode()).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new MessageResponse("T-LEA-ERR-001", HttpStatus.INTERNAL_SERVER_ERROR.value(), "ERROR",
                            e.getMessage()));
        }
    }

    @GetMapping("/export-leaves")
    public ResponseEntity<?> exportLeavesToXlsx(HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            InputStream is = leaveService.exportLeavesToXlsx(companyId);

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=leaves.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(is));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error exporting data: " + e.getMessage());
        }
    }

    @GetMapping("/company/department/{id_department}/employees/export")
    public ResponseEntity<?> exportEmployeesByDepartmentToCsv(
            @PathVariable("id_department") Integer departmentId, HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            InputStream is = employeeExportImportService.exportEmployeesByDepartmentToXlsx(companyId, departmentId);

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=employees.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(is));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @GetMapping("/company/attendance/export")
    public ResponseEntity<?> exportAttendanceToCsv(HttpServletRequest request) {
        try {
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            InputStream is = attendanceService.exportAttendanceToXlsx(companyId);

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=attendance.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(is));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @GetMapping("/employee/{id_employee}/attendances/export")
    public ResponseEntity<?> exportEmployeeAttendanceToCsv(@PathVariable("id_employee") Integer idEmployee) {
        try {
            InputStream is = attendanceService.exportEmployeeAttendanceToXlsx(idEmployee);

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=employee_" + idEmployee + "_attendance.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(is));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    "Gagal mengekspor data kehadiran untuk karyawan dengan ID: " + idEmployee,
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @GetMapping("/dashboard/summary")
    public ResponseEntity<?> getDashboardSummary(HttpServletRequest request) {
        try {
            // Mendapatkan company ID dari JWT token
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            // Mendapatkan data summary dashboard
            DashboardSummaryResponse response = adminManagementService.getDashboardSummary(companyId);

            // Response sukses
            return ResponseEntity.ok(new MessageResponse(
                    "Berhasil mendapatkan data dashboard summary",
                    HttpStatus.OK.value(),
                    "OK",
                    response));
        } catch (Exception e) {
            // Response error
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    "Gagal mendapatkan data dashboard summary",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }

    @GetMapping("/dashboard/attendance-overview")
    public ResponseEntity<?> getAttendanceOverview(HttpServletRequest request) {
        try {
            // Mendapatkan company ID dari JWT token
            String authToken = request.getHeader("Authorization").substring(7);
            Integer companyId = jwtUtils.getCompanyIdFromJwtToken(authToken);

            // Mendapatkan data attendance overview
            AttendanceOverviewResponse response = adminManagementService.getAttendanceOverview(companyId);

            // Response sukses
            return ResponseEntity.ok(new MessageResponse(
                    "Berhasil mendapatkan data untuk menampilkan grafik attendance overview dan department attendance overview",
                    HttpStatus.OK.value(),
                    "OK",
                    response));
        } catch (Exception e) {
            // Response error
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new MessageResponse(
                    "Gagal mendapatkan data untuk menampilkan grafik attendance overview dan department attendance overview",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage()));
        }
    }
}
