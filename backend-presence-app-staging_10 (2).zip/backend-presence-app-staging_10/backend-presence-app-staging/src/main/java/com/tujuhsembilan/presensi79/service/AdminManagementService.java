package com.tujuhsembilan.presensi79.service;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.tujuhsembilan.presensi79.config.minio.MinioService;
import com.tujuhsembilan.presensi79.dto.CompanyDTO;
import com.tujuhsembilan.presensi79.dto.DepartmentDTO;
import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.AdminManagementRequest;
import com.tujuhsembilan.presensi79.dto.request.ChangePasswordByAdminRequest;
import com.tujuhsembilan.presensi79.dto.request.EditAdminRequest;
import com.tujuhsembilan.presensi79.dto.response.AdminInformationResponse;
import com.tujuhsembilan.presensi79.dto.response.AdminManagementResponse;
import com.tujuhsembilan.presensi79.dto.response.AdminPhotoResponse;
import com.tujuhsembilan.presensi79.dto.response.AttendanceListResponse;
import com.tujuhsembilan.presensi79.dto.response.AttendanceOverview;
import com.tujuhsembilan.presensi79.dto.response.AttendanceOverviewResponse;
import com.tujuhsembilan.presensi79.dto.response.CompanyIdAndNameResponse;
import com.tujuhsembilan.presensi79.dto.response.CompanyResponse;
import com.tujuhsembilan.presensi79.dto.response.DashboardSummaryResponse;
import com.tujuhsembilan.presensi79.dto.response.DepartmentAttendanceOverview;
import com.tujuhsembilan.presensi79.model.Account;
import com.tujuhsembilan.presensi79.model.Admin;
import com.tujuhsembilan.presensi79.model.Attendance;
import com.tujuhsembilan.presensi79.model.Company;
import com.tujuhsembilan.presensi79.repository.AdminRepository;
import com.tujuhsembilan.presensi79.repository.AttendanceRepository;
import com.tujuhsembilan.presensi79.repository.CompanyRepository;
import com.tujuhsembilan.presensi79.repository.DepartmentRepository;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.repository.LeaveRepository;
import com.tujuhsembilan.presensi79.specification.AdminManagementSpecification;
import com.tujuhsembilan.presensi79.util.MessageUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdminManagementService {

        final private AdminRepository adminRepository;
        final MessageUtil messageUtil;
        final CompanyRepository companyRepository;
        private final BCryptPasswordEncoder passwordEncoder;
        private final AttendanceRepository attendanceRepository;
        private final EmployeeRepository employeeRepository;
        private final DepartmentRepository departmentRepository;
        private final LeaveRepository leaveRepository;
        private final MinioService minioService;

        @Transactional
        public MessageResponse getAdminList(
                        int pageNumber,
                        int pageSize,
                        String sortBy,
                        String search,
                        LocalDate startDateJoined,
                        LocalDate endDateJoined,
                        AdminManagementRequest filter) {

                try {
                        if (pageNumber < 1) {
                                pageNumber = 1;
                        }

                        Sort sort = Sort.by(Sort.Direction.ASC, "company.companyName")
                                        .and(Sort.by("firstName").ascending())
                                        .and(Sort.by("lastName").ascending());

                        if (sortBy != null && !sortBy.isEmpty()) {
                                sort = Sort.by(Sort.Direction.ASC, sortBy);
                        }

                        Pageable pageable = PageRequest.of(pageNumber - 1, pageSize, sort);

                        Specification<Admin> specification = AdminManagementSpecification.administratorFilter(filter);

                        if (search != null && !search.isEmpty()) {
                                specification = specification.and((root, query, builder) -> builder.or(
                                                builder.like(builder.lower(root.get("company.companyName")),
                                                                "%" + search.toLowerCase() + "%"),
                                                builder.like(builder.lower(root.get("firstName")),
                                                                "%" + search.toLowerCase() + "%"),
                                                builder.like(builder.lower(root.get("lastName")),
                                                                "%" + search.toLowerCase() + "%"),
                                                builder.like(builder.lower(root.get("email")),
                                                                "%" + search.toLowerCase() + "%")));
                        }

                        if (startDateJoined != null) {
                                specification = specification.and((root, query, builder) -> builder
                                                .greaterThanOrEqualTo(root.get("createdDate"),
                                                                startDateJoined.atStartOfDay()));
                        }

                        if (endDateJoined != null) {
                                specification = specification.and((root, query, builder) -> builder
                                                .lessThanOrEqualTo(root.get("createdDate"),
                                                                endDateJoined.atTime(23, 59, 59)));
                        }

                        var adminPage = adminRepository.findAll(specification, pageable);

                        List<AdminManagementResponse> adminResponses = adminPage.getContent().stream()
                                        .map(admin -> AdminManagementResponse.builder()
                                                        .idAdmin(admin.getIdAdmin())
                                                        .company(new CompanyIdAndNameResponse(
                                                                        admin.getCompany().getIdCompany(),
                                                                        admin.getCompany().getCompanyName()))
                                                        .profilePicture(getMinioPicture(admin.getProfilePicture()))
                                                        .firstName(admin.getFirstName())
                                                        .lastName(admin.getLastName())
                                                        .email(admin.getEmail())
                                                        .username(admin.getAccount().getUsername())
                                                        .createdDate(admin.getCreatedDate())
                                                        .build())
                                        .collect(Collectors.toList());

                        // Create metadata
                        MessageResponse.Meta meta = new MessageResponse.Meta(
                                        (int) adminPage.getTotalElements(),
                                        pageSize,
                                        pageNumber,
                                        adminPage.getTotalPages());

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Admins"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        adminResponses,
                                        meta);

                } catch (Exception e) {
                        e.printStackTrace();
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        public MessageResponse patchAdminPhto(Integer idAdmin, MultipartFile profilePicture) {
                try {
                        Optional<Admin> optionalAdmin = adminRepository.findById(idAdmin);
                        if (!optionalAdmin.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Admin"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Admin admin = optionalAdmin.get();

                        // Ambil nama file foto lama
                        String oldProfilePicture = admin.getProfilePicture();

                        // Hapus foto lama dari MinIO
                        if (oldProfilePicture != null && !oldProfilePicture.isEmpty()) {
                                try {
                                        minioService.deleteFile(oldProfilePicture);
                                } catch (Exception e) {
                                        return new MessageResponse(
                                                        messageUtil.get("application.error.internal"),
                                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                        messageUtil.get("application.status.error"),
                                                        e.getMessage());
                                }
                        }

                        // Upload file baru ke MinIO dan dapatkan nama file yang disimpan di bucket
                        String fileName;
                        try {
                                fileName = minioService.uploadFileToMinio(profilePicture, "admin-photos/" + idAdmin);
                        } catch (IOException e) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.uploadfile"),
                                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                messageUtil.get("application.status.error"),
                                                e.getMessage());
                        }

                        // Simpan path atau URL file baru ke database
                        admin.setProfilePicture(fileName);
                        adminRepository.save(admin);

                        // Buat response yang berisi informasi foto admin yang diperbarui
                        AdminPhotoResponse adminResponse = AdminPhotoResponse.builder()
                                        .id_admin(idAdmin)
                                        .profile_picture(fileName) // File name yang disimpan di MinIO
                                        .build();

                        // Kembalikan MessageResponse sukses
                        return new MessageResponse(
                                        messageUtil.get("application.success.update", "Admin photo"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        adminResponse);

                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional(readOnly = true)
        public MessageResponse getAdminInformation(Integer idAdmin) {
                try {
                        Optional<Admin> adminOpt = adminRepository.findById(idAdmin);
                        if (!adminOpt.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Admin"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Admin admin = adminOpt.get();
                        CompanyDTO companyDTO = new CompanyDTO(admin.getCompany().getIdCompany(),
                                        admin.getCompany().getCompanyName());

                        String profilePictureUrl = admin.getProfilePicture() != null
                                        ? minioService.getPublicLink(admin.getProfilePicture())
                                        : null;

                        AdminInformationResponse adminInfo = AdminInformationResponse.builder()
                                        .idAdmin(admin.getIdAdmin())
                                        .firstName(admin.getFirstName())
                                        .lastName(admin.getLastName())
                                        .username(admin.getAccount().getUsername())
                                        .email(admin.getEmail())
                                        .company(companyDTO)
                                        .profilePicture(profilePictureUrl)
                                        .joiningDate(admin.getCompany().getJoiningDate().toString())
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Admin information"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        adminInfo);

                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse updateAdminInformation(Integer idAdmin, EditAdminRequest request) {
                try {
                        Optional<Admin> adminOpt = adminRepository.findById(idAdmin);
                        if (!adminOpt.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Admin"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Admin admin = adminOpt.get();
                        admin.setFirstName(request.getFirstName());
                        admin.setLastName(request.getLastName());
                        admin.setEmail(request.getEmail());

                        // Update the related Account entity
                        Account account = admin.getAccount();
                        account.setUsername(request.getUsername());
                        admin.setAccount(account);

                        adminRepository.save(admin);

                        AdminInformationResponse adminInfo = AdminInformationResponse.builder()
                                        .idAdmin(admin.getIdAdmin())
                                        .firstName(admin.getFirstName())
                                        .lastName(admin.getLastName())
                                        .username(admin.getAccount().getUsername())
                                        .email(admin.getEmail())
                                        .company(new CompanyDTO(admin.getCompany().getIdCompany(),
                                                        admin.getCompany().getCompanyName()))
                                        .joiningDate(admin.getCompany().getJoiningDate().toString())
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.update", "Admin information"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        adminInfo);

                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse changeAdminPassword(Integer idAdmin, ChangePasswordByAdminRequest request) {
                try {
                        // Check if passwords match
                        if (!request.getNewPassword().equals(request.getRetypeNewPassword())) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.newpassword.notmatch"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.badrequest"));
                        }

                        // Find the admin by ID
                        Optional<Admin> adminOpt = adminRepository.findById(idAdmin);
                        if (!adminOpt.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Admin"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Admin admin = adminOpt.get();
                        admin.getAccount().setPassword(passwordEncoder.encode(request.getNewPassword()));
                        adminRepository.save(admin);

                        return new MessageResponse(
                                        messageUtil.get("application.success.changepassword"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"));

                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        public MessageResponse getTopAttendanceList() {
                try {
                        List<Attendance> attendances = attendanceRepository.findTop7ByOrderByCheckInAsc();

                        List<AttendanceListResponse> attendanceListResponses = attendances.stream().map(attendance -> {
                                String profilePictureUrl = attendance.getEmployee().getProfilePicture() != null
                                                ? minioService.getPublicLink(
                                                                attendance.getEmployee().getProfilePicture())
                                                : null;

                                return AttendanceListResponse.builder()
                                                .department(DepartmentDTO.builder()
                                                                .idDepartment(attendance.getEmployee().getDepartment()
                                                                                .getIdDepartment())
                                                                .departmentName(attendance.getEmployee().getDepartment()
                                                                                .getDepartmentName())
                                                                .build())
                                                .idEmployee(attendance.getEmployee().getIdEmployee())
                                                .employeeName(
                                                                attendance.getEmployee().getFirstName() + " "
                                                                                + attendance.getEmployee()
                                                                                                .getLastName())
                                                .status(attendance.getStatus())
                                                .checkIn(attendance.getCheckIn().toString())
                                                .totalWorkingHours(
                                                                attendance.getTotalWorkingHours() != null
                                                                                ? attendance.getTotalWorkingHours()
                                                                                                .toString()
                                                                                : "N/A")
                                                .profilePicture(profilePictureUrl)
                                                .build();
                        }).collect(Collectors.toList());

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Attendance list"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        attendanceListResponses);

                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse getCompanyList() {
                try {
                        List<Company> companies = companyRepository.findAll();

                        List<CompanyResponse> companyResponses = companies.stream()
                                        .map(company -> CompanyResponse.builder()
                                                        .idCompany(company.getIdCompany())
                                                        .companyName(company.getCompanyName())
                                                        .build())
                                        .collect(Collectors.toList());

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Companies"),
                                        HttpStatus.OK.value(),
                                        "OK",
                                        companyResponses);

                } catch (Exception e) {
                        e.printStackTrace();
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        "Internal Server Error",
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse changeAdminProfilePicture(Integer idAdmin, MultipartFile file) {
                try {
                        Optional<Admin> optionalAdmin = adminRepository.findById(idAdmin);
                        if (!optionalAdmin.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Admin"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Admin admin = optionalAdmin.get();

                        String profilePictureFilename = minioService.uploadFileToMinio(file,
                                        "admin_profile_picture_" + admin.getIdAdmin());

                        admin.setProfilePicture(profilePictureFilename);
                        adminRepository.save(admin);

                        return new MessageResponse(
                                        messageUtil.get("application.success.update", "Profile picture"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"));
                } catch (IOException e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.upload"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        public DashboardSummaryResponse getDashboardSummary(Integer companyId) {

                // Mendapatkan total employee
                int totalEmployee = (int) employeeRepository.countByCompanyId(companyId);

                // Mendapatkan kehadiran hari ini
                LocalDate today = LocalDate.now();
                LocalDate startOfWeek = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
                LocalDate startOfMonth = today.withDayOfMonth(1);

                int todayAttendance = (int) attendanceRepository.countTodayAttendanceByCompanyId(companyId, today);

                // Mendapatkan total leave
                int totalTodayLeave = (int) leaveRepository.countTodayLeaveByCompanyId(companyId, today);
                int totalThisWeekLeave = (int) leaveRepository.countThisWeekLeaveByCompanyId(companyId, startOfWeek);
                int totalThisMonthLeave = (int) leaveRepository.countThisMonthLeaveByCompanyId(companyId, startOfMonth);

                // Mendapatkan kehadiran on-time
                int totalTodayOnTime = (int) attendanceRepository.countTodayOnTimeByCompanyId(companyId, today);
                int totalThisWeekOnTime = (int) attendanceRepository.countThisWeekOnTimeByCompanyId(companyId,
                                startOfWeek);
                int totalThisMonthOnTime = (int) attendanceRepository.countThisMonthOnTimeByCompanyId(companyId,
                                startOfMonth);

                // Mendapatkan kehadiran late
                int totalTodayLate = (int) attendanceRepository.countTodayLateByCompanyId(companyId, today);
                int totalThisWeekLate = (int) attendanceRepository.countThisWeekLateByCompanyId(companyId, startOfWeek);
                int totalThisMonthLate = (int) attendanceRepository.countThisMonthLateByCompanyId(companyId,
                                startOfMonth);

                // Menghitung jumlah siswa yang tidak melakukan absensi hari ini
                int totalTodayAbsence = (int) attendanceRepository.countAbsenceByCompanyIdAndDate(companyId, today);

                // Menghitung total ketidakhadiran untuk minggu ini (hanya hari kerja)
                int totalThisWeekAbsence = 0;
                for (LocalDate date = startOfWeek; date.isBefore(today.plusDays(1)); date = date.plusDays(1)) {
                        // Periksa apakah tanggal tersebut adalah hari kerja (Senin hingga Jumat)
                        if (date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY) {
                                totalThisWeekAbsence += (int) attendanceRepository
                                                .countAbsenceByCompanyIdAndDate(companyId, date);
                        }
                }

                // Menghitung total ketidakhadiran untuk bulan ini (hanya hari kerja)
                int totalThisMonthAbsence = 0;
                for (LocalDate date = startOfMonth; date.isBefore(today.plusDays(1)); date = date.plusDays(1)) {
                        // Periksa apakah tanggal tersebut adalah hari kerja (Senin hingga Jumat)
                        if (date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY) {
                                totalThisMonthAbsence += (int) attendanceRepository
                                                .countAbsenceByCompanyIdAndDate(companyId, date);
                        }
                }

                // Mengembalikan data summary ke controller
                return DashboardSummaryResponse.builder()
                                .totalEmployee(totalEmployee)
                                .todayAttendance(todayAttendance)
                                .totalLeave(DashboardSummaryResponse.TotalData.builder()
                                                .today(totalTodayLeave)
                                                .thisWeek(totalThisWeekLeave)
                                                .thisMonth(totalThisMonthLeave)
                                                .build())
                                .totalOnTime(DashboardSummaryResponse.TotalData.builder()
                                                .today(totalTodayOnTime)
                                                .thisWeek(totalThisWeekOnTime)
                                                .thisMonth(totalThisMonthOnTime)
                                                .build())
                                .totalLate(DashboardSummaryResponse.TotalData.builder()
                                                .today(totalTodayLate)
                                                .thisWeek(totalThisWeekLate)
                                                .thisMonth(totalThisMonthLate)
                                                .build())
                                .totalAbsence(DashboardSummaryResponse.TotalData.builder()
                                                .today(totalTodayAbsence)
                                                .thisWeek(totalThisWeekAbsence)
                                                .thisMonth(totalThisMonthAbsence)
                                                .build())
                                .build();
        }

        public AttendanceOverviewResponse getAttendanceOverview(Integer companyId) {
                LocalDate today = LocalDate.now();
                LocalDate startOfWeek = today.with(DayOfWeek.MONDAY);
                LocalDate startOfMonth = today.withDayOfMonth(1);

                // Data untuk "this_week"
                List<AttendanceOverview> thisWeekAttendance = new ArrayList<>();
                for (LocalDate date = startOfWeek; date.isBefore(today.plusDays(1)); date = date.plusDays(1)) {
                        if (date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY) {
                                long onTime = attendanceRepository.countTodayOnTimeByCompanyId(companyId, date);
                                long late = attendanceRepository.countTodayLateByCompanyId(companyId, date);
                                long leave = leaveRepository.countTodayLeaveByCompanyId(companyId, date);
                                long absent = attendanceRepository.countAbsenceByCompanyIdAndDate(companyId, date);

                                thisWeekAttendance.add(new AttendanceOverview(date.getDayOfWeek().toString(), onTime,
                                                late, leave, absent));
                        }
                }

                // Data untuk "this_month"
                Map<String, AttendanceOverview> attendanceByWeek = new HashMap<>();

                for (LocalDate date = startOfMonth; date.isBefore(today.plusDays(1)); date = date.plusDays(1)) {
                        if (date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY) {
                                long onTime = attendanceRepository.countTodayOnTimeByCompanyId(companyId, date);
                                long late = attendanceRepository.countTodayLateByCompanyId(companyId, date);
                                long leave = leaveRepository.countTodayLeaveByCompanyId(companyId, date);
                                long absent = attendanceRepository.countAbsenceByCompanyIdAndDate(companyId, date);

                                // Mengelompokkan berdasarkan minggu
                                String timePeriod = "Week-" + ((date.getDayOfMonth() - 1) / 7 + 1);

                                // Periksa apakah sudah ada data untuk minggu ini
                                if (attendanceByWeek.containsKey(timePeriod)) {
                                        // Jika sudah ada, update data kehadiran
                                        AttendanceOverview existingOverview = attendanceByWeek.get(timePeriod);
                                        existingOverview.setOnTime(existingOverview.getOnTime() + onTime);
                                        existingOverview.setLate(existingOverview.getLate() + late);
                                        existingOverview.setLeave(existingOverview.getLeave() + leave);
                                        existingOverview.setAbsent(existingOverview.getAbsent() + absent);
                                } else {
                                        // Jika belum ada, tambahkan data baru
                                        AttendanceOverview newOverview = new AttendanceOverview(timePeriod, onTime,
                                                        late, leave, absent);
                                        attendanceByWeek.put(timePeriod, newOverview);
                                }
                        }
                }

                // Mengubah map menjadi list
                List<AttendanceOverview> thisMonthAttendance = new ArrayList<>(attendanceByWeek.values());

                // Data untuk "today"
                List<DepartmentAttendanceOverview> todayDepartmentAttendance = departmentRepository
                                .findAllByCompany_IdCompany(companyId)
                                .stream()
                                .map(department -> {
                                        long onTime = attendanceRepository.countTodayOnTimeByDepartmentId(
                                                        department.getIdDepartment(), today);
                                        long late = attendanceRepository.countTodayLateByDepartmentId(
                                                        department.getIdDepartment(), today);
                                        long leave = leaveRepository.countTodayLeaveByDepartmentId(
                                                        department.getIdDepartment(), today);
                                        long absent = attendanceRepository.countAbsenceByDepartmentIdAndDate(
                                                        department.getIdDepartment(), today);
                                        return new DepartmentAttendanceOverview(department.getDepartmentName(), onTime,
                                                        late, leave, absent);
                                })
                                .collect(Collectors.toList());

                // Mengisi data "this_week" dan "this_month"
                AttendanceOverviewResponse.TotalData thisWeekData = AttendanceOverviewResponse.TotalData.builder()
                                .attendanceOverview(thisWeekAttendance)
                                .departmentAttendanceOverview(todayDepartmentAttendance)
                                .build();

                AttendanceOverviewResponse.TotalData thisMonthData = AttendanceOverviewResponse.TotalData.builder()
                                .attendanceOverview(thisMonthAttendance)
                                .departmentAttendanceOverview(todayDepartmentAttendance)
                                .build();

                // Mengisi data "today"
                AttendanceOverviewResponse.TotalData todayData = AttendanceOverviewResponse.TotalData.builder()
                                .departmentAttendanceOverview(todayDepartmentAttendance)
                                .build();

                // Membuat instance dari AttendanceOverviewResponse
                return AttendanceOverviewResponse.builder()
                                .today(todayData)
                                .thisWeek(thisWeekData)
                                .thisMonth(thisMonthData)
                                .build();
        }

        @Transactional
        public MessageResponse softDeleteAdmin(Integer idAdmin, Boolean isDelete) {
                try {
                        Optional<Admin> optionalAdmin = adminRepository.findById(idAdmin);
                        if (!optionalAdmin.isPresent()) {
                                return new MessageResponse(
                                                "Admin not found",
                                                HttpStatus.NOT_FOUND.value(),
                                                HttpStatus.NOT_FOUND.getReasonPhrase(),
                                                "No admin with the provided ID");
                        }

                        Admin admin = optionalAdmin.get();

                        if (isDelete != null && isDelete) {
                                admin.setIsDeleted(true);
                                adminRepository.save(admin);

                                return new MessageResponse(
                                                "Admin successfully deleted",
                                                HttpStatus.OK.value(),
                                                HttpStatus.OK.getReasonPhrase(),
                                                null);
                        } else {
                                return new MessageResponse(
                                                "Invalid delete request",
                                                HttpStatus.BAD_REQUEST.value(),
                                                HttpStatus.BAD_REQUEST.getReasonPhrase(),
                                                "is_delete must be true");
                        }

                } catch (Exception e) {
                        return new MessageResponse(
                                        "An error occurred while deleting the admin",
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                                        e.getMessage());
                }
        }

        private String getMinioPicture(String pictures) {
                String profilePictureUrl = null;
                if (pictures != null) {
                        profilePictureUrl = minioService.getPublicLink(pictures);
                }
                return profilePictureUrl;
        }

}
