package com.tujuhsembilan.presensi79.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardSummaryResponse {

    @JsonProperty("total_employee")
    private Integer totalEmployee;

    @JsonProperty("today_attendance")
    private Integer todayAttendance;

    @JsonProperty("total_leave")
    private TotalData totalLeave;

    @JsonProperty("total_on_time")
    private TotalData totalOnTime;

    @JsonProperty("total_late")
    private TotalData totalLate;

    @JsonProperty("total_absence")
    private TotalData totalAbsence;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TotalData {

        @JsonProperty("today")
        private Integer today;

        @JsonProperty("this_week")
        private Integer thisWeek;

        @JsonProperty("this_month")
        private Integer thisMonth;
    }
}
