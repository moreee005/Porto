package com.tujuhsembilan.presensi79.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import com.tujuhsembilan.presensi79.config.minio.MinioService;
import com.tujuhsembilan.presensi79.dto.request.AddCompanyRequest;
import com.tujuhsembilan.presensi79.dto.response.*;
import com.tujuhsembilan.presensi79.dto.request.EditCompanyRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.multipart.MultipartFile;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.exception.CustomErrorWithStatusException;
import com.tujuhsembilan.presensi79.model.Company;
import com.tujuhsembilan.presensi79.repository.AdminRepository;
import com.tujuhsembilan.presensi79.repository.CompanyRepository;
import com.tujuhsembilan.presensi79.specification.CompanySpecification;
import com.tujuhsembilan.presensi79.util.MessageUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CompanyService {

    private final CompanyRepository companyRepository;
    private final AdminRepository adminRepository;
    private final MessageUtil messageUtil;
    private final MinioService minioService;

    public MessageResponse getCompanyLogo(Integer idCompany) {
        try {
            Company company = getCompanyOrThrow(idCompany);
            String logo = company.getCompanyLogo();

            if (logo != null) {
                return new MessageResponse(
                        messageUtil.get("application.success.retrieve", "Company logo"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        new GetLogoResponse(logo));
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company logo"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"),
                        messageUtil.get("application.error.logo.unavailable"));
            }
        } catch (Exception e) {
            return handleInternalError(e);
        }
    }

    public MessageResponse getCompanyCoordinates(Integer idCompany) {
        try {
            Company company = getCompanyOrThrow(idCompany);
            Double latitude = company.getLatitude();
            Double longitude = company.getLongitude();

            if (latitude != null && longitude != null) {
                CompanyCoordinatesResponse response = new CompanyCoordinatesResponse(idCompany, latitude, longitude);
                return new MessageResponse(
                        messageUtil.get("application.success.retrieve", "Company coordinates"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        response);
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company coordinates"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"),
                        messageUtil.get("application.error.coordinates.unavailable"));
            }
        } catch (Exception e) {
            return handleInternalError(e);
        }
    }

    public MessageResponse getCompanies(
            int pageNumber,
            int pageSize,
            String sortBy,
            CompanyFilterRequest request) {

        HttpStatus status = HttpStatus.OK;
        Object data = null;
        String message = null;
        MessageResponse.Meta meta = null;

        try {
            // Default sorting by companyName ASC
            Sort sort = Sort.by(Sort.Direction.ASC, "companyName");
            if (sortBy != null && !sortBy.isEmpty()) {
                sort = Sort.by(Sort.Direction.ASC, sortBy);
            }

            Pageable page = PageRequest.of(pageNumber - 1, pageSize, sort);
            Specification<Company> spec = CompanySpecification.companyFilterAll(request)
                    .and((root, query, criteriaBuilder) -> criteriaBuilder.isFalse(root.get("isDeleted")));

            Page<Company> companies = companyRepository.findAll(spec, page);

            if (companies.isEmpty()) {
                throw new CustomErrorWithStatusException(
                        messageUtil.get("application.error.notfound", "Companies"),
                        null,
                        HttpStatus.NOT_FOUND
                );
            }

            List<CompanyDetailResponse> companiesResponse = companies
                    .stream()
                    .map(item -> CompanyDetailResponse.builder()
                            .idCompany(item.getIdCompany())
                            .companyName(item.getCompanyName())
                            .email(item.getEmail())
                            .phone(item.getPhone())
                            .totalAdmin(adminRepository.countByCompanyId(item.getIdCompany())) // Calculate total_admin
                            .joiningDate(item.getJoiningDate() != null
                                    ? item.getJoiningDate().toString()
                                    : null)

                            .build())
                    .toList();

            // Create metadata
            meta = new MessageResponse.Meta(
                    (int) companies.getTotalElements(), // Total records
                    page.getPageSize(), // Records per page
                    page.getPageNumber() + 1, // Current page number (Pageable starts at 0)
                    companies.getTotalPages() // Total pages available
            );

            message = messageUtil.get("application.success.retrieve", "Companies");
            data = companiesResponse;

        } catch (CustomErrorWithStatusException e) {
            status = e.getStatus();
            message = e.getMessage();
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = messageUtil.get("application.error.internal");
        }

        return new MessageResponse(message, status.value(), status.getReasonPhrase(), data, meta);
    }




    public MessageResponse getCompaniDto(Integer idCompany) {
        try {
            Optional<Company> companyOptional = companyRepository.findById(idCompany);
            if (companyOptional.isPresent()) {
                Company company = companyOptional.get();

                String logo = null;
                if(company.getCompanyLogo()!= null){
                    logo = minioService.getPublicLink(company.getCompanyLogo());
                }
                CompanyResponse companyDto = CompanyResponse.builder()
                        .idCompany(company.getIdCompany())
                        .companyName(company.getCompanyName())
                        .companyLogo(logo)
                        .founder(company.getFounder())
                        .foundedAt(company.getFoundedAt())
                        .phone(company.getPhone())
                        .address(company.getAddress())
                        .state(company.getState())
                        .city(company.getCity())
                        .zipCode(company.getZipCode())
                        .joiningDate(company.getJoiningDate())
                        .email(company.getEmail())
                        .district(company.getDistrict())
                        .build();

                return new MessageResponse(
                        messageUtil.get("application.success.retrieve", "Company"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        companyDto);
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"),
                        messageUtil.get("application.error.id.notfound", "Company", idCompany.toString()));
            }

        } catch (Exception e) {
            return handleInternalError(e);
        }
    }

    // Fungsi untuk mendapatkan inisial dari company name
    private String getInitials(String companyName) {
        if (companyName == null || companyName.isEmpty()) {
            return "";  // Kembalikan string kosong jika nama perusahaan null atau kosong
        }

        String[] words = companyName.split(" ");
        StringBuilder initials = new StringBuilder();

        // Ambil huruf pertama dari setiap kata
        for (String word : words) {
            if (!word.isEmpty()) {
                initials.append(word.charAt(0));
            }
        }

        return initials.toString().toUpperCase();  // Mengembalikan inisial dalam huruf kapital
    }

    public MessageResponse postCompany(AddCompanyRequest companyRequest) {
        try {
            if (companyRequest.getCompany_name() == null || companyRequest.getCompany_name().isEmpty()) {
                return new MessageResponse(
                        messageUtil.get("application.error.missing", "Company name"),
                        HttpStatus.BAD_REQUEST.value(),
                        messageUtil.get("application.status.badrequest"));

            }

            String companyLogo = getInitials(companyRequest.getCompany_name());

            // Konversi CompanyRequest menjadi Company Entity
            Company company = Company.builder()
                    .companyName(companyRequest.getCompany_name())
                    .email(companyRequest.getEmail())
                    .phone(companyRequest.getPhone())
                    .address(companyRequest.getAddress())
                    .state(companyRequest.getState())
                    .city(companyRequest.getCity())
                    .zipCode(companyRequest.getZip_code())
                    .founder(companyRequest.getFounder())
                    .foundedAt(companyRequest.getFounded_at())
                    .district(companyRequest.getDistrict())
                    .joiningDate(companyRequest.getJoining_date())
                    .companyLogo(companyLogo)
                    .createdDate(new Timestamp(System.currentTimeMillis()))
                    .createdBy("Super Admin")
                    .modifiedBy("Super Admin")
                    .modifiedDate(new Timestamp(System.currentTimeMillis()))
                    .build();

            company = companyRepository.save(company);

            CompanyDto responseDto = CompanyDto.builder()
                    .id_company(company.getIdCompany()) // Mengembalikan ID setelah penyimpanan
                    .company_name(company.getCompanyName())
                    .email(company.getEmail())
                    .phone(company.getPhone())
                    .address(company.getAddress())
                    .founder(company.getFounder())
                    .founded_at(company.getFoundedAt())
                    .district(company.getDistrict())
                    .state(company.getState())
                    .city(company.getCity())
                    .zip_code(company.getZipCode())
                    .joining_date(company.getJoiningDate())
                    .build();

            return new MessageResponse(
                    messageUtil.get("application.success.create", "Company"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    responseDto);

        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();

            return new MessageResponse(
                    "An error occurred",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());
        }
    }

    public MessageResponse patchCompanyPhoto(Integer idCompany, MultipartFile companyLogo) {
        try {
            Optional<Company> companyOptional = companyRepository.findById(idCompany);
            if (!companyOptional.isPresent()) {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"),
                        messageUtil.get("application.error.id.notfound", "Company", idCompany.toString()));
            }

            Company company = companyOptional.get();

            String oldLogo = company.getCompanyLogo();

            if (oldLogo != null && !oldLogo.isEmpty()) {
                try {
                    minioService.deleteFile(oldLogo);
                } catch (Exception e) {
                    return handleInternalError(e);
                }

            }

            // Upload file baru ke MinIo daan dapatkan nama file yang disimpan di bucket

            String fileName;
            try {
                fileName = minioService.uploadFileToMinio(companyLogo, "company-logo/" + idCompany);
            } catch (IOException e) {
                return new MessageResponse(
                        "Failed to upload photo to MinIO",
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                        e.getMessage());
            }

            company.setCompanyLogo(fileName);
            companyRepository.save(company);

            CompanyPhotoResponse response = CompanyPhotoResponse.builder()
                    .id_company(idCompany)
                    .company_logo(fileName)
                    .build();

            return new MessageResponse(
                    messageUtil.get("application.success.update", "Company logo"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    response);

        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();

            return new MessageResponse(
                    "An error occurred while updating the company photo",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    e.getMessage());

        }
    }

    public MessageResponse deleteCompany(Integer idCompany) {
        try {
            Optional<Company> companyOptional = companyRepository.findById(idCompany);
            if (companyOptional.isPresent()) {
                Company company = companyOptional.get();

                companyRepository.delete(company);

                return new MessageResponse(
                        messageUtil.get("application.success.update", "Company profile"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        null);
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"),
                        messageUtil.get("application.error.id.notfound", "Company", idCompany.toString()));
            }
        } catch (Exception e) {
            return handleInternalError(e);
        }
    }

    @Transactional
    public MessageResponse updateCompanyProfile(Integer idCompany, CompanyDto companyDto) {
        try {
            Optional<Company> companyOptional = companyRepository.findById(idCompany);
            if (!companyOptional.isPresent()) {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"),
                        messageUtil.get("application.error.id.notfound", "Company", idCompany.toString()));
            }

            Company company = companyOptional.get();
            companyDto.setId_company(idCompany);
            company.setCompanyName(companyDto.getCompany_name());
            company.setFounder(companyDto.getFounder());
            company.setFoundedAt(companyDto.getFounded_at());
            company.setPhone(companyDto.getPhone());
            company.setEmail(companyDto.getEmail());
            company.setAddress(companyDto.getAddress());
            company.setState(companyDto.getState());
            company.setCity(companyDto.getCity());
            company.setDistrict(companyDto.getDistrict());
            company.setZipCode(companyDto.getZip_code());
            company.setJoiningDate(companyDto.getJoining_date());
            company.setLongitude(companyDto.getLongitude());
            company.setLatitude(companyDto.getLatitude());
            company.setModifiedDate(new Timestamp(System.currentTimeMillis()));

            companyRepository.save(company);

            return new MessageResponse(
                    messageUtil.get("application.success.update", "Company profile"),
                    HttpStatus.CREATED.value(),
                    messageUtil.get("application.status.created"),
                    companyDto);

        } catch (Exception e) {
            return handleInternalError(e);
        }
    }

    public MessageResponse getCompanyInfo(Integer idCompany) {
        try {
            Optional<Company> companyOptional = companyRepository.findById(idCompany);
            if (companyOptional.isPresent()) {
                Company company = companyOptional.get();
                String companyLogoUrl = company.getCompanyLogo() != null
                        ? minioService.getPublicLink(company.getCompanyLogo())
                        : null;
                CompanyResponse companyResponse = CompanyResponse.builder()
                        .idCompany(company.getIdCompany())
                        .companyName(company.getCompanyName())
                        .companyLogo(companyLogoUrl)
                        .founder(company.getFounder())
                        .foundedAt(company.getFoundedAt())
                        .phone(company.getPhone())
                        .email(company.getEmail())
                        .address(company.getAddress())
                        .state(company.getState())
                        .city(company.getCity())
                        .district(company.getDistrict())
                        .zipCode(company.getZipCode())
                        .joiningDate(company.getJoiningDate())
                        .longitude(company.getLongitude())
                        .latitude(company.getLatitude())
                        .build();

                return new MessageResponse(
                    messageUtil.get("application.success.retrieve", "Company profile"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    companyResponse);
        } else {
            return new MessageResponse(
                    messageUtil.get("application.error.notfound", "Company"),
                    HttpStatus.NOT_FOUND.value(),
                    messageUtil.get("application.status.notfound"),
                    messageUtil.get("application.error.id.notfound", "Company", idCompany.toString()));
        }
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    private Company getCompanyOrThrow(Integer idCompany) {
        return companyRepository.findById(idCompany)
                .orElseThrow(() -> new IllegalArgumentException(
                        messageUtil.get("application.error.invalid", "Company")
                ));
    }

    private MessageResponse handleInternalError(Exception e) {
        return new MessageResponse(
                messageUtil.get("application.error.internal"),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                messageUtil.get("application.status.error"),
                e.getMessage()
        );
    }


    public MessageResponse editCompany(EditCompanyRequest request, Integer idCompany){
        try {
            Optional<Company> optionalCompany = companyRepository.findById(idCompany);
            if (!optionalCompany.isPresent()) {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Employee"),
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        messageUtil.get("application.status.error")
                );
            }

            Company company = optionalCompany.get();

            company.setCompanyName(request.getCompanyName() == null ? company.getCompanyName() : request.getCompanyName());
            company.setFounder(request.getFounder() == null ? company.getFounder() : request.getFounder());
            company.setFoundedAt(request.getFounded_at() == null ? company.getFoundedAt() : request.getFounded_at());
            company.setEmail(request.getEmail() == null ? company.getEmail() : request.getEmail());
            company.setPhone(request.getPhone() == null ? company.getPhone() : request.getPhone());
            company.setAddress(request.getAddress() == null ? company.getAddress() : request.getAddress());
            company.setState(request.getState() == null ? company.getState() : request.getState());
            company.setCity(request.getCity() == null ? company.getCity() : request.getCity());
            company.setZipCode(request.getZipCode() == null ? company.getZipCode() : request.getZipCode());
            company.setJoiningDate(request.getJoiningDate() == null ? company.getJoiningDate() : request.getJoiningDate());
            company.setDistrict(request.getDistrict() == null ? company.getDistrict() : request.getDistrict());

            companyRepository.save(company);

            EditCompanyResponse editCompanyResponse = EditCompanyResponse.builder()
                    .idCompany(company.getIdCompany())
                    .companyName(company.getCompanyName())
                    .founder(company.getFounder())
                    .foundedAt(company.getFoundedAt())
                    .email(company.getEmail())
                    .phone(company.getPhone())
                    .address(company.getAddress())
                    .state(company.getState())
                    .city(company.getCity())
                    .zipCode(company.getZipCode())
                    .joiningDate(company.getJoiningDate())
                    .district(company.getDistrict())
                    .build();

            return new MessageResponse(
                    messageUtil.get("application.success.update", "Company"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    editCompanyResponse
            );
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();

            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage()
            );
        }
    }

    public MessageResponse deleteCompany(Integer idCompany, Boolean isDelete) {
        try {
            Optional<Company> companyOptional = companyRepository.findById(idCompany);
            if (!companyOptional.isPresent()) {
                return new MessageResponse(
                    "Company not found",
                    HttpStatus.NOT_FOUND.value(),
                    HttpStatus.NOT_FOUND.getReasonPhrase(),
                    "No company with the provided ID"
                );
            }
    
            Company company = companyOptional.get();
    
            if (isDelete != null && isDelete) {
                company.setIsDeleted(true);
                companyRepository.save(company);
    
                return new MessageResponse(
                    "Company profile deleted successfully",
                    HttpStatus.OK.value(),
                    HttpStatus.OK.getReasonPhrase(),
                    null
                );
            } else {
                return new MessageResponse(
                    "Invalid delete request",
                    HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST.getReasonPhrase(),
                    "is_delete must be true"
                );
            }
        } catch (Exception e) {

            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();

            return new MessageResponse(
                    "Response Gagal Mendapatkan Data Company",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Internal Server Error",
                    e.getMessage());
        }
    }
}
