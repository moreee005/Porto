package com.tujuhsembilan.presensi79.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TopEmployeeResponse {
    private Integer id;
    private String name;
    private String profilePicture;
    private String username;
    private String position;
}
