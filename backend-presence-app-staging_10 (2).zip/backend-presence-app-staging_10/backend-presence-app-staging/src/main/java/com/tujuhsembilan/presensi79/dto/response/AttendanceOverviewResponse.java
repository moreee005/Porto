package com.tujuhsembilan.presensi79.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceOverviewResponse {

    @JsonProperty("today")
    private TotalData today;

    @JsonProperty("this_week")
    private TotalData thisWeek;

    @JsonProperty("this_month")
    private TotalData thisMonth;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TotalData {

        @JsonProperty("attendance_overview")
        private List<AttendanceOverview> attendanceOverview;

        @JsonProperty("department_attendance_overview")
        private List<DepartmentAttendanceOverview> departmentAttendanceOverview;
    }
}
