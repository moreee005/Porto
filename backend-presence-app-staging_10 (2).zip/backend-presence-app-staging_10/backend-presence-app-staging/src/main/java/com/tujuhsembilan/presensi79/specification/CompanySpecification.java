package com.tujuhsembilan.presensi79.specification;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.tujuhsembilan.presensi79.dto.response.CompanyFilterRequest;
import com.tujuhsembilan.presensi79.model.Company;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CompanySpecification {

    private static final Logger logger = LoggerFactory.getLogger(CompanySpecification.class);

    public static Specification<Company> companyFilterAll(CompanyFilterRequest companyFilterRequest) {
        return (Root<Company> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (companyFilterRequest.getCompanyName() != null && !companyFilterRequest.getCompanyName().isEmpty()) {
                String companyName = "%" + companyFilterRequest.getCompanyName().toLowerCase() + "%";
                Predicate companyNamePredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("companyName")),
                        companyName);
                predicates.add(companyNamePredicate);
            }

            // Filter by start date joined
            if (companyFilterRequest.getStartDateJoined() != null) {
                logger.debug("Start Date Filter: {}", companyFilterRequest.getStartDateJoined());
                Predicate startDatePredicate = criteriaBuilder.greaterThanOrEqualTo(
                        root.get("joiningDate").as(LocalDate.class),
                        companyFilterRequest.getStartDateJoined());
                predicates.add(startDatePredicate);
            }

            // Filter by end date joined
            if (companyFilterRequest.getEndDateJoined() != null) {
                logger.debug("End Date Filter: {}", companyFilterRequest.getEndDateJoined());
                Predicate endDatePredicate = criteriaBuilder.lessThanOrEqualTo(
                        root.get("joiningDate").as(LocalDate.class),
                        companyFilterRequest.getEndDateJoined());
                predicates.add(endDatePredicate);
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}
