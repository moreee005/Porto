package com.tujuhsembilan.presensi79.service;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.TermsConditionsRequest;
import com.tujuhsembilan.presensi79.dto.request.CompanyConfigRequest;
import com.tujuhsembilan.presensi79.dto.response.CompanyConfigResponse;
import com.tujuhsembilan.presensi79.dto.response.TermsConditionsResponse;
import com.tujuhsembilan.presensi79.model.CompanyConfig;
import com.tujuhsembilan.presensi79.repository.CompanyConfigRepository;
import com.tujuhsembilan.presensi79.util.MessageUtil;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CompanyConfigService {

    private final CompanyConfigRepository companyConfigRepository;
    private final MessageUtil messageUtil;

    public MessageResponse getCompanyConfig(Integer idCompany) {
        try {
            CompanyConfig companyConfig = companyConfigRepository.findByCompany_IdCompany(idCompany);
            if (companyConfig != null) {
                CompanyConfigResponse response = CompanyConfigResponse.builder()
                        .idCompanyConfig(companyConfig.getIdCompanyConfig())
                        .idCompany(companyConfig.getCompany().getIdCompany())
                        .workingDayFlexible(companyConfig.getWorkingDayFlexible())
                        .workingDayStart(companyConfig.getWorkingDayStart())
                        .workingDayEnd(companyConfig.getWorkingDayEnd())
                        .workingHoursFlexible(companyConfig.getWorkingHoursFlexible())
                        .workingHoursStart(companyConfig.getWorkingHoursStart())
                        .workingHoursEnd(companyConfig.getWorkingHoursEnd())
                        .workingDurationFlexible(companyConfig.getWorkingDurationFlexible())
                        .workingDuration(companyConfig.getWorkingDuration())
                        .checkInToleranceFlexible(companyConfig.getCheckInToleranceFlexible())
                        .checkInTolerance(companyConfig.getCheckInTolerance())
                        .checkOutToleranceFlexible(companyConfig.getCheckOutToleranceFlexible())
                        .checkOutTolerance(companyConfig.getCheckOutTolerance())
                        .breakTimeFlexible(companyConfig.getBreakTimeFlexible())
                        .breakTime(companyConfig.getBreakTime())
                        .afterBreakToleranceFlexible(companyConfig.getAfterBreakToleranceFlexible())
                        .afterBreakTolerance(companyConfig.getAfterBreakTolerance())
                        .geolocation(companyConfig.getGeolocation())
                        .geolocationRadius(companyConfig.getGeolocationRadius())
                        .selfieMode(companyConfig.getSelfieMode())
                        .autoCheckOut(companyConfig.getAutoCheckOut())
                        .autoCheckOutTime(companyConfig.getAutoCheckOutTime())
                        .createdBy(companyConfig.getCreatedBy())
                        .createdDate(companyConfig.getCreatedDate())
                        .modifiedBy(companyConfig.getModifiedBy())
                        .modifiedDate(companyConfig.getModifiedDate())
                        .termsConditions(companyConfig.getTermsConditions())
                        .defaultHoliday(companyConfig.getDefaultHoliday())
                        .build();

                return new MessageResponse(
                        messageUtil.get("application.success.retrieve", "Configuration"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        response);
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Configuration"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    public MessageResponse getTermsConditions(Integer idCompany) {
        try {
            CompanyConfig companyConfig = companyConfigRepository.findByCompany_IdCompany(idCompany);
            if (companyConfig != null) {
                TermsConditionsResponse response = TermsConditionsResponse.builder()
                        .idCompany(companyConfig.getCompany().getIdCompany())
                        .terms_conditions(companyConfig.getTermsConditions())
                        .build();

                return new MessageResponse(
                        messageUtil.get("application.success.retrieve", "Terms and Conditions"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        response);
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Terms and Conditions"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    public MessageResponse updateCompanyConfig(Integer idCompany, CompanyConfigRequest request) {
        try {
            CompanyConfig companyConfig = companyConfigRepository.findByCompany_IdCompany(idCompany);
            if (companyConfig != null) {
                boolean isUpdated = false; // Flag untuk melacak apakah ada perubahan

                // Update jika nilai baru tidak sama dengan nilai yang ada saat ini (termasuk
                // jika nilai saat ini null)
                if (request.getWorkingDayFlexible() != null
                        && !request.getWorkingDayFlexible().equals(companyConfig.getWorkingDayFlexible())) {
                    companyConfig.setWorkingDayFlexible(request.getWorkingDayFlexible());
                    isUpdated = true;
                }
                if (request.getWorkingDayStart() != null
                        && !request.getWorkingDayStart().equals(companyConfig.getWorkingDayStart())) {
                    companyConfig.setWorkingDayStart(request.getWorkingDayStart());
                    isUpdated = true;
                }
                if (request.getWorkingDayEnd() != null
                        && !request.getWorkingDayEnd().equals(companyConfig.getWorkingDayEnd())) {
                    companyConfig.setWorkingDayEnd(request.getWorkingDayEnd());
                    isUpdated = true;
                }
                if (request.getWorkingHoursFlexible() != null
                        && !request.getWorkingHoursFlexible().equals(companyConfig.getWorkingHoursFlexible())) {
                    companyConfig.setWorkingHoursFlexible(request.getWorkingHoursFlexible());
                    isUpdated = true;
                }
                if (request.getWorkingHoursStart() != null
                        && !request.getWorkingHoursStart().equals(companyConfig.getWorkingHoursStart())) {
                    companyConfig.setWorkingHoursStart(request.getWorkingHoursStart());
                    isUpdated = true;
                }
                if (request.getWorkingHoursEnd() != null
                        && !request.getWorkingHoursEnd().equals(companyConfig.getWorkingHoursEnd())) {
                    companyConfig.setWorkingHoursEnd(request.getWorkingHoursEnd());
                    isUpdated = true;
                }
                if (request.getWorkingDurationFlexible() != null
                        && !request.getWorkingDurationFlexible().equals(companyConfig.getWorkingDurationFlexible())) {
                    companyConfig.setWorkingDurationFlexible(request.getWorkingDurationFlexible());
                    isUpdated = true;
                }
                if (request.getWorkingDuration() != null
                        && !request.getWorkingDuration().equals(companyConfig.getWorkingDuration())) {
                    companyConfig.setWorkingDuration(request.getWorkingDuration());
                    isUpdated = true;
                }
                if (request.getCheckInToleranceFlexible() != null
                        && !request.getCheckInToleranceFlexible().equals(companyConfig.getCheckInToleranceFlexible())) {
                    companyConfig.setCheckInToleranceFlexible(request.getCheckInToleranceFlexible());
                    isUpdated = true;
                }
                if (request.getCheckInTolerance() != null
                        && !request.getCheckInTolerance().equals(companyConfig.getCheckInTolerance())) {
                    companyConfig.setCheckInTolerance(request.getCheckInTolerance());
                    isUpdated = true;
                }
                if (request.getCheckOutToleranceFlexible() != null && !request.getCheckOutToleranceFlexible()
                        .equals(companyConfig.getCheckOutToleranceFlexible())) {
                    companyConfig.setCheckOutToleranceFlexible(request.getCheckOutToleranceFlexible());
                    isUpdated = true;
                }
                if (request.getCheckOutTolerance() != null
                        && !request.getCheckOutTolerance().equals(companyConfig.getCheckOutTolerance())) {
                    companyConfig.setCheckOutTolerance(request.getCheckOutTolerance());
                    isUpdated = true;
                }
                if (request.getBreakTimeFlexible() != null
                        && !request.getBreakTimeFlexible().equals(companyConfig.getBreakTimeFlexible())) {
                    companyConfig.setBreakTimeFlexible(request.getBreakTimeFlexible());
                    isUpdated = true;
                }
                if (request.getBreakTime() != null && !request.getBreakTime().equals(companyConfig.getBreakTime())) {
                    companyConfig.setBreakTime(request.getBreakTime());
                    isUpdated = true;
                }
                if (request.getAfterBreakToleranceFlexible() != null && !request.getAfterBreakToleranceFlexible()
                        .equals(companyConfig.getAfterBreakToleranceFlexible())) {
                    companyConfig.setAfterBreakToleranceFlexible(request.getAfterBreakToleranceFlexible());
                    isUpdated = true;
                }
                if (request.getAfterBreakTolerance() != null
                        && !request.getAfterBreakTolerance().equals(companyConfig.getAfterBreakTolerance())) {
                    companyConfig.setAfterBreakTolerance(request.getAfterBreakTolerance());
                    isUpdated = true;
                }
                if (request.getGeolocation() != null
                        && !request.getGeolocation().equals(companyConfig.getGeolocation())) {
                    companyConfig.setGeolocation(request.getGeolocation());
                    isUpdated = true;
                }
                if (request.getGeolocationRadius() != null
                        && !request.getGeolocationRadius().equals(companyConfig.getGeolocationRadius())) {
                    companyConfig.setGeolocationRadius(request.getGeolocationRadius());
                    isUpdated = true;
                }
                if (request.getSelfieMode() != null && !request.getSelfieMode().equals(companyConfig.getSelfieMode())) {
                    companyConfig.setSelfieMode(request.getSelfieMode());
                    isUpdated = true;
                }
                if (request.getDefaultHoliday() != null
                        && !request.getDefaultHoliday().equals(companyConfig.getDefaultHoliday())) {
                    companyConfig.setDefaultHoliday(request.getDefaultHoliday());
                    isUpdated = true;
                }
                if (request.getTermsConditions() != null
                        && !request.getTermsConditions().equals(companyConfig.getTermsConditions())) {
                    companyConfig.setTermsConditions(request.getTermsConditions());
                    isUpdated = true;
                }
                if (request.getAutoCheckOut() != null
                        && !request.getAutoCheckOut().equals(companyConfig.getAutoCheckOut())) {
                    companyConfig.setAutoCheckOut(request.getAutoCheckOut());
                    isUpdated = true;
                }
                if (request.getAutoCheckOutTime() != null
                        && !request.getAutoCheckOutTime().equals(companyConfig.getAutoCheckOutTime())) {
                    companyConfig.setAutoCheckOutTime(request.getAutoCheckOutTime());
                    isUpdated = true;
                }

                // Update timestamps jika ada perubahan
                if (isUpdated) {
                    companyConfig.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
                    companyConfigRepository.save(companyConfig);
                    return new MessageResponse(
                            messageUtil.get("application.success.update", "Company Configuration"),
                            HttpStatus.OK.value(),
                            messageUtil.get("application.status.ok"));
                } else {
                    // Jika tidak ada field yang berubah
                    return new MessageResponse(
                            messageUtil.get("application.error.nochange", "Company Configuration"),
                            HttpStatus.BAD_REQUEST.value(),
                            messageUtil.get("application.status.nochange"));
                }
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company Configuration"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    public MessageResponse createTermsConditions(Integer idCompany, TermsConditionsRequest request) {
        try {
            CompanyConfig companyConfig = companyConfigRepository.findByCompany_IdCompany(idCompany);
            if (companyConfig != null) {
                companyConfig.setTermsConditions(request.getTerms_conditions());
                companyConfig.setCreatedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
                companyConfig.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
                companyConfigRepository.save(companyConfig);

                return new MessageResponse(
                        messageUtil.get("application.success.create", "Terms and Conditions"),
                        HttpStatus.CREATED.value(),
                        messageUtil.get("application.status.created"));
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Company"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    public MessageResponse updateTermsConditions(Integer idCompany, TermsConditionsRequest request) {
        try {
            CompanyConfig companyConfig = companyConfigRepository.findByCompany_IdCompany(idCompany);
            if (companyConfig != null) {
                companyConfig.setTermsConditions(request.getTerms_conditions());
                companyConfig.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
                companyConfigRepository.save(companyConfig);

                return new MessageResponse(
                        messageUtil.get("application.success.update", "Terms and Conditions"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"));
            } else {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Terms and Conditions"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

}
