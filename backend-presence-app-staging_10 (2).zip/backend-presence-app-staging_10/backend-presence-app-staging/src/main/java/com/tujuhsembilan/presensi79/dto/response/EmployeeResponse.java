package com.tujuhsembilan.presensi79.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmployeeResponse {
    private Integer idEmployee;
    private String employeeName;
    private Department department;
    private String status;
    private String roleCurrentCompany;

    @Data
    @Builder
    public static class Department {
        private Integer idDepartment;
        private String departmentName;
    }
}