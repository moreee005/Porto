package com.tujuhsembilan.presensi79.service;

import com.tujuhsembilan.presensi79.config.minio.MinioService;
import com.tujuhsembilan.presensi79.dto.CompanyDTO;
import com.tujuhsembilan.presensi79.dto.DepartmentDTO;
import com.tujuhsembilan.presensi79.dto.EmployeeDTO;
import com.tujuhsembilan.presensi79.dto.EmployeeDetailDTO;
import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.ChangePasswordByAdminRequest;
import com.tujuhsembilan.presensi79.dto.request.EditPersonalInfoRequest;
import com.tujuhsembilan.presensi79.dto.request.EditProfessionalInfoRequest;
import com.tujuhsembilan.presensi79.dto.request.EditProfileRequest;
import com.tujuhsembilan.presensi79.dto.request.EmployeeRegistrationRequest;
import com.tujuhsembilan.presensi79.dto.response.EditProfileResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeePersonalInformationResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeeProfessionalInformationResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeeProfileResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeeRegistrationResponse;
import com.tujuhsembilan.presensi79.model.Account;
import com.tujuhsembilan.presensi79.model.Company;
import com.tujuhsembilan.presensi79.model.Department;
import com.tujuhsembilan.presensi79.model.Employee;
import com.tujuhsembilan.presensi79.repository.AccountRepository;
import com.tujuhsembilan.presensi79.repository.CompanyRepository;
import com.tujuhsembilan.presensi79.repository.DepartmentRepository;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.util.MessageUtil;

import java.io.IOException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.HashMap;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EmployeeService {

        private final Validator validator;
        private final AccountRepository accountRepository;
        private final EmployeeRepository employeeRepository;
        private final CompanyRepository companyRepository;
        private final DepartmentRepository departmentRepository;
        private final BCryptPasswordEncoder passwordEncoder;
        private final MessageUtil messageUtil;
        private final MinioService minioService;

        @Transactional
        public MessageResponse registerEmployee(EmployeeRegistrationRequest request, Integer idCompany) {
                try {
                        Set<ConstraintViolation<EmployeeRegistrationRequest>> constraintViolations = validator
                                        .validate(request);

                        if (!constraintViolations.isEmpty()) {
                                ConstraintViolation<EmployeeRegistrationRequest> firstViolation = constraintViolations
                                                .iterator()
                                                .next();
                                String errorMessage = firstViolation.getMessage();
                                return new MessageResponse(errorMessage, HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        if (accountRepository.existsByUsername(request.getUsername())) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.already.exists", "Username"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Optional<Company> optionalCompany = companyRepository.findById(idCompany);
                        if (!optionalCompany.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Company"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Optional<Department> optionalDepartment = departmentRepository
                                        .findById(request.getIdDepartment());
                        if (!optionalDepartment.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Department"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Account account = Account.builder()
                                        .username(request.getUsername())
                                        .password(passwordEncoder.encode(request.getPassword()))
                                        .role("Employee")
                                        .createdBy("Admin")
                                        .createdDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                                        .modifiedBy("Admin")
                                        .modifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                                        .build();

                        Employee employee = Employee.builder()
                                        .firstName(request.getFirstName())
                                        .lastName(request.getLastName())
                                        .email(request.getEmail())
                                        .employeeNumber(request.getEmployeeNumber())
                                        .company(optionalCompany.get())
                                        .department(optionalDepartment.get())
                                        .roleCurrentCompany(request.getRoleCurrentCompany())
                                        .joiningDate(LocalDate.now(ZoneId.of("Asia/Jakarta")))
                                        .createdBy("Admin")
                                        .createdDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                                        .modifiedBy("Admin")
                                        .modifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                                        .build();

                        Account savedAccount = accountRepository.save(account);
                        employee.setAccount(savedAccount);
                        Employee savedEmployee = employeeRepository.save(employee);

                        EmployeeRegistrationResponse employeeResponse = EmployeeRegistrationResponse.builder()
                                        .idEmployee(savedEmployee.getIdEmployee())
                                        .idAccount(savedAccount.getIdAccount())
                                        .idCompany(savedEmployee.getCompany().getIdCompany())
                                        .idDepartment(savedEmployee.getDepartment().getIdDepartment())
                                        .employeeNumber(savedEmployee.getEmployeeNumber())
                                        .firstName(savedEmployee.getFirstName())
                                        .lastName(savedEmployee.getLastName())
                                        .username(savedAccount.getUsername())
                                        .email(savedEmployee.getEmail())
                                        .role(savedAccount.getRole())
                                        .roleCurrentCompany(savedEmployee.getRoleCurrentCompany())
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.create", "Employee"),
                                        HttpStatus.CREATED.value(),
                                        messageUtil.get("application.status.ok"),
                                        employeeResponse);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse changeEmployeePassword(Integer idEmployee, ChangePasswordByAdminRequest request) {
                try {
                        // Validasi bahwa password baru dan konfirmasi password cocok
                        if (!request.getNewPassword().equals(request.getRetypeNewPassword())) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.newpassword.notmatch"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.badrequest"));
                        }

                        // Cari employee berdasarkan id
                        Optional<Employee> employeeOptional = employeeRepository.findById(idEmployee);
                        if (!employeeOptional.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Employee employee = employeeOptional.get();
                        Account account = employee.getAccount();

                        account.setPassword(passwordEncoder.encode(request.getNewPassword()));
                        accountRepository.save(account);

                        return new MessageResponse(
                                        messageUtil.get("application.success.changepassword"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"));

                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        public MessageResponse getEmployeeProfile(Integer idEmployee) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);

                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                messageUtil.get("application.status.error"),
                                                "Employee with ID " + idEmployee + " not found");
                        }

                        Employee employee = optionalEmployee.get();
                        String profilePictureUrl = employee.getProfilePicture() != null
                                        ? minioService.getPublicLink(employee.getProfilePicture())
                                        : null;

                        EmployeeProfileResponse profileResponse = EmployeeProfileResponse.builder()
                                        .idEmployee(employee.getIdEmployee())
                                        .firstName(employee.getFirstName())
                                        .lastName(employee.getLastName())
                                        .roleCurrentCompany(employee.getRoleCurrentCompany())
                                        .profilePicture(profilePictureUrl)
                                        .idCompany(employee.getCompany().getIdCompany())
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Employee profile"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        profileResponse);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        public MessageResponse getEmployeePersonalInformation(Integer idEmployee) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);

                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                messageUtil.get("application.status.error"),
                                                "Employee with ID " + idEmployee + " not found");
                        }

                        Employee employee = optionalEmployee.get();

                        EmployeePersonalInformationResponse personalInformationResponse = EmployeePersonalInformationResponse
                                        .builder()
                                        .idEmployee(employee.getIdEmployee())
                                        .firstName(employee.getFirstName())
                                        .lastName(employee.getLastName())
                                        .dateOfBirth(employee.getDateOfBirth())
                                        .gender(employee.getGender())
                                        .maritalStatus(employee.getMaritalStatus())
                                        .mobileNumber(employee.getMobileNumber())
                                        .nationality(employee.getNationality())
                                        .address(employee.getAddress())
                                        .province(employee.getProvince())
                                        .city(employee.getCity())
                                        .district(employee.getDistrict())
                                        .zipCode(employee.getZipCode())
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Employee profile"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        personalInformationResponse);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        public MessageResponse getEmployeeProfessionalInformation(Integer idEmployee) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);

                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                messageUtil.get("application.status.error"),
                                                "Employee with ID " + idEmployee + " not found");
                        }

                        Employee employee = optionalEmployee.get();
                        Account account = employee.getAccount();
                        Integer idDepartment = employee.getDepartment().getIdDepartment();
                        Optional<Department> optionalDepartment = departmentRepository.findById(idDepartment);

                        if (!optionalDepartment.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Department"),
                                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Department department = optionalDepartment.get();

                        EmployeeProfessionalInformationResponse professionalInformationResponse = EmployeeProfessionalInformationResponse
                                        .builder()
                                        .idEmployee(employee.getIdEmployee())
                                        .employeeNumber(employee.getEmployeeNumber())
                                        .username(account.getUsername())
                                        .email(employee.getEmail())
                                        .idDepartment(idDepartment)
                                        .departmentName(department.getDepartmentName())
                                        .status(employee.getStatus())
                                        .roleInClient(employee.getRoleInClient())
                                        .roleCurrentCompany(employee.getRoleCurrentCompany())
                                        .joiningDate(employee.getJoiningDate())
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "Employee profile"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        professionalInformationResponse);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse editEmployeeProfile(Integer idEmployee, EditProfileRequest request) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);
                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Employee employee = optionalEmployee.get();
                        String username = employee.getAccount().getUsername();

                        if (accountRepository.existsByUsername(request.getUsername())
                                        && !employee.getAccount().getUsername().equals(request.getUsername())) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.already.exists", "Username"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Optional<Department> optionalDepartment = departmentRepository
                                        .findById(request.getIdDepartment());
                        if (!optionalDepartment.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Department"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Department department = optionalDepartment.get();
                        Account account = employee.getAccount();
                        account.setUsername(request.getUsername());
                        employee.setEmail(request.getEmail());
                        employee.setFirstName(request.getFirstName());
                        employee.setLastName(request.getLastName());
                        employee.setDateOfBirth(request.getDateOfBirth());
                        employee.setMobileNumber(request.getMobileNumber());
                        employee.setGender(request.getGender());
                        employee.setMaritalStatus(request.getMaritalStatus());
                        employee.setNationality(request.getNationality());
                        employee.setAddress(request.getAddress());
                        employee.setProvince(request.getProvince());
                        employee.setCity(request.getCity());
                        employee.setDistrict(request.getDistrict());
                        employee.setZipCode(request.getZipCode());
                        employee.setEmployeeNumber(request.getEmployeeNumber());
                        employee.setStatus(request.getStatus());
                        employee.setDepartment(department);
                        employee.setRoleCurrentCompany(request.getRoleInCurrentCompany());
                        employee.setRoleInClient(request.getRoleInClient());
                        employee.setJoiningDate(request.getJoiningDate());
                        employee.setModifiedBy(username);
                        employee.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
                        account.setModifiedBy(username);
                        account.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));

                        accountRepository.save(account);
                        employeeRepository.save(employee);

                        EditProfileResponse response = EditProfileResponse.builder()
                                        .firstName(employee.getFirstName())
                                        .lastName(employee.getLastName())
                                        .dateOfBirth(employee.getDateOfBirth())
                                        .mobileNumber(employee.getMobileNumber())
                                        .gender(employee.getGender())
                                        .maritalStatus(employee.getMaritalStatus())
                                        .nationality(employee.getNationality())
                                        .address(employee.getAddress())
                                        .province(employee.getProvince())
                                        .city(employee.getCity())
                                        .district(employee.getDistrict())
                                        .zipCode(employee.getZipCode())
                                        .employeeNumber(employee.getEmployeeNumber())
                                        .username(account.getUsername())
                                        .status(employee.getStatus())
                                        .email(employee.getEmail())
                                        .idDepartment(employee.getDepartment().getIdDepartment())
                                        .roleInCurrentCompany(employee.getRoleCurrentCompany())
                                        .roleInClient(employee.getRoleInClient())
                                        .joiningDate(employee.getJoiningDate())
                                        .message(messageUtil.get("application.success.update", "Employee profile"))
                                        .build();

                        return new MessageResponse(
                                        messageUtil.get("application.success.update", "Employee profile"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        response);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse changeProfilePicture(Integer idEmployee, MultipartFile file) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);
                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Employee employee = optionalEmployee.get();
                        String username = employee.getAccount().getUsername();
                        String profilePictureFilename = minioService.uploadFileToMinio(file,
                                        "profile_picture_" + employee.getIdEmployee());
                        employee.setProfilePicture(profilePictureFilename);
                        employee.setModifiedBy(username);
                        employee.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
                        employeeRepository.save(employee);

                        return new MessageResponse(
                                        messageUtil.get("application.success.update", "Profile picture"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"));
                } catch (IOException e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.upload"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse getEmployeesByDepartment(Integer idDepartment, int page, int size, String keyword) {
                try {
                        Pageable pageable = PageRequest.of(page, size);
                        Page<Employee> employeePage;

                        if (keyword.isEmpty()) {
                                // Pencarian tanpa keyword, hanya berdasarkan idDepartment
                                employeePage = employeeRepository.findByDepartment_IdDepartment(idDepartment, pageable);
                        } else {
                                // Pencarian dengan keyword dan idDepartment
                                employeePage = employeeRepository.findByDepartmentAndKeyword(idDepartment, keyword,
                                                pageable);
                        }

                        if (employeePage.isEmpty()) {
                                return new MessageResponse(
                                                "Tidak ada data yang ditemukan untuk department dengan ID: "
                                                                + idDepartment,
                                                HttpStatus.OK.value(),
                                                "NO_DATA",
                                                new HashMap<>()); // Mengembalikan pesan dengan status tidak ada data
                        }

                        List<EmployeeDTO> employeeDTOs = employeePage.stream()
                                        .map(this::convertToDTO)
                                        .collect(Collectors.toList());

                        Map<String, Object> data = Map.of(
                                        "data", employeeDTOs,
                                        "total_data", employeePage.getTotalElements(),
                                        "total_page", employeePage.getTotalPages(),
                                        "page_size", employeePage.getSize(),
                                        "current_page", employeePage.getNumber(),
                                        "message", "T-EMP-SUCC-001",
                                        "statusCode", HttpStatus.OK.value(),
                                        "status", "OK");

                        return new MessageResponse(
                                        "Berhasil mendapatkan data employees by department",
                                        HttpStatus.OK.value(),
                                        "OK",
                                        data);
                } catch (Exception e) {
                        return new MessageResponse(
                                        "Gagal mendapatkan data employees by department",
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        "ERROR",
                                        e.getMessage());
                }
        }

        private EmployeeDTO convertToDTO(Employee employee) {
                String profilePictureUrl = employee.getProfilePicture() != null
                                ? minioService.getPublicLink(employee.getProfilePicture())
                                : null;

                DepartmentDTO departmentDTO = new DepartmentDTO(employee.getDepartment().getIdDepartment(),
                                employee.getDepartment().getDepartmentName());
                CompanyDTO companyDTO = new CompanyDTO(employee.getCompany().getIdCompany(),
                                employee.getCompany().getCompanyName());

                String username = employee.getAccount() != null ? employee.getAccount().getUsername() : "No Account";

                return new EmployeeDTO(
                                employee.getIdEmployee(),
                                employee.getEmployeeNumber(),
                                employee.getFirstName() + " " + employee.getLastName(),
                                username, // Use the username variable
                                departmentDTO,
                                employee.getStatus(),
                                employee.getRoleCurrentCompany(),
                                employee.getRoleInClient(),
                                companyDTO,
                                profilePictureUrl);
        }

        public Page<EmployeeDTO> getAllEmployeesByCompanyIdAndKeyword(Integer companyId, String keyword,
                        Pageable pageable) {
                Page<Employee> employees = employeeRepository.findAllByCompanyIdAndKeywordAndIsDeletedFalse(
                                companyId, keyword, pageable);
                return employees.map(this::convertToDTO);
        }

        @Transactional
        public MessageResponse updateEmployeePersonalInfo(Integer idEmployee, EditPersonalInfoRequest request) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);
                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Employee employee = optionalEmployee.get();
                        employee.setFirstName(request.getFirstName());
                        employee.setLastName(request.getLastName());
                        employee.setDateOfBirth(request.getDateOfBirth());
                        employee.setGender(request.getGender());
                        employee.setMaritalStatus(request.getMaritalStatus());
                        employee.setMobileNumber(request.getMobileNumber());
                        employee.setNationality(request.getNationality());
                        employee.setAddress(request.getAddress());
                        employee.setProvince(request.getProvince());
                        employee.setCity(request.getCity());
                        employee.setDistrict(request.getDistrict());
                        employee.setZipCode(request.getZipCode());

                        Employee updatedEmployee = employeeRepository.save(employee);
                        EmployeeDetailDTO employeeDetailDTO = mapToEmployeeDetailDTO(updatedEmployee);

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve",
                                                        "Employee personal information"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        employeeDetailDTO);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        @Transactional
        public MessageResponse updateEmployeeProfessionalInfo(Integer idEmployee, EditProfessionalInfoRequest request) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);
                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Employee employee = optionalEmployee.get();
                        Optional<Department> optionalDepartment = departmentRepository
                                        .findById(request.getIdDepartment());
                        if (!optionalDepartment.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Department"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Department department = optionalDepartment.get();
                        if (accountRepository.existsByUsername(request.getUsername())
                                        && !employee.getAccount().getUsername().equals(request.getUsername())) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.already.exists", "Username"),
                                                HttpStatus.BAD_REQUEST.value(),
                                                messageUtil.get("application.status.error"));
                        }

                        Account account = employee.getAccount();
                        account.setUsername(request.getUsername());
                        employee.setEmail(request.getEmail());
                        employee.setEmployeeNumber(request.getEmployeeNumber());
                        employee.setStatus(request.getStatus());
                        employee.setDepartment(department);
                        employee.setRoleCurrentCompany(request.getRoleCurrentCompany());
                        employee.setRoleInClient(request.getRoleInClient());
                        employee.setJoiningDate(request.getJoiningDate());

                        accountRepository.save(account);
                        Employee updatedEmployee = employeeRepository.save(employee);
                        EmployeeDetailDTO employeeDetailDTO = mapToEmployeeDetailDTO(updatedEmployee);

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve",
                                                        "Employee professional information"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        employeeDetailDTO);
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

        private EmployeeDetailDTO mapToEmployeeDetailDTO(Employee employee) {
                DepartmentDTO departmentDTO = new DepartmentDTO(employee.getDepartment().getIdDepartment(),
                                employee.getDepartment().getDepartmentName());

                CompanyDTO companyDTO = new CompanyDTO(employee.getCompany().getIdCompany(),
                                employee.getCompany().getCompanyName());

                return new EmployeeDetailDTO(
                                employee.getIdEmployee(),
                                employee.getFirstName(),
                                employee.getLastName(),
                                employee.getDateOfBirth(),
                                employee.getMobileNumber(),
                                employee.getGender(),
                                employee.getMaritalStatus(),
                                employee.getNationality(),
                                employee.getAddress(),
                                employee.getProvince(),
                                employee.getCity(),
                                employee.getDistrict(),
                                employee.getZipCode(),
                                employee.getEmployeeNumber(),
                                employee.getAccount().getUsername(),
                                employee.getStatus(),
                                employee.getEmail(),
                                departmentDTO,
                                companyDTO,
                                employee.getRoleCurrentCompany(),
                                employee.getRoleInClient(),
                                employee.getJoiningDate(),
                                employee.getProfilePicture());
        }

        public EmployeeProfileResponse getEmployeeProfileResponse(Integer idEmployee) {
                Employee employee = employeeRepository.findById(idEmployee).orElse(null);
                if (employee == null || Boolean.TRUE.equals(employee.getIsDeleted())) {
                        return null;
                }

                String profilePictureUrl = employee.getProfilePicture() != null
                                ? minioService.getPublicLink(employee.getProfilePicture())
                                : null;

                return EmployeeProfileResponse.builder()
                                .idEmployee(employee.getIdEmployee())
                                .firstName(employee.getFirstName())
                                .lastName(employee.getLastName())
                                .email(employee.getEmail())
                                .roleCurrentCompany(employee.getRoleCurrentCompany())
                                .profilePicture(profilePictureUrl)
                                .idCompany(employee.getCompany().getIdCompany())
                                .build();
        }

        public EmployeePersonalInformationResponse getEmployeePersonalInformationrResponse(Integer idEmployee) {
                Employee employee = employeeRepository.findById(idEmployee).orElse(null);
                if (employee == null || Boolean.TRUE.equals(employee.getIsDeleted())) {
                        return null;
                }

                return EmployeePersonalInformationResponse.builder()
                                .idEmployee(employee.getIdEmployee())
                                .firstName(employee.getFirstName())
                                .lastName(employee.getLastName())
                                .dateOfBirth(employee.getDateOfBirth())
                                .gender(employee.getGender())
                                .maritalStatus(employee.getMaritalStatus())
                                .mobileNumber(employee.getMobileNumber())
                                .nationality(employee.getNationality())
                                .address(employee.getAddress())
                                .province(employee.getProvince())
                                .city(employee.getCity())
                                .district(employee.getDistrict())
                                .zipCode(employee.getZipCode())
                                .build();
        }

        public EmployeeProfessionalInformationResponse getEmployeeProfessionalInformationResponse(Integer idEmployee) {
                Employee employee = employeeRepository.findById(idEmployee).orElse(null);
                if (employee == null || Boolean.TRUE.equals(employee.getIsDeleted())) {
                        return null;
                }

                return EmployeeProfessionalInformationResponse.builder()
                                .idEmployee(employee.getIdEmployee())
                                .employeeNumber(employee.getEmployeeNumber())
                                .username(employee.getAccount().getUsername())
                                .email(employee.getEmail())
                                .idDepartment(employee.getDepartment().getIdDepartment())
                                .departmentName(employee.getDepartment().getDepartmentName())
                                .status(employee.getStatus())
                                .roleInClient(employee.getRoleInClient())
                                .roleCurrentCompany(employee.getRoleCurrentCompany())
                                .joiningDate(employee.getJoiningDate())
                                .build();
        }

        @Transactional
        public MessageResponse softDeleteEmployee(Integer idEmployee) {
                try {
                        Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);
                        if (!optionalEmployee.isPresent()) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        Employee employee = optionalEmployee.get();
                        employee.setIsDeleted(true);
                        employeeRepository.save(employee);

            return new MessageResponse(
                    messageUtil.get("application.success.delete", "Employee"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"));
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

        @Transactional
        public MessageResponse getEmployeeIdByUsername(String username) {
                try {
                        Employee employee = employeeRepository.findByAccount_Username(username);

                        if (employee == null || Boolean.TRUE.equals(employee.getIsDeleted())) {
                                return new MessageResponse(
                                                messageUtil.get("application.error.notfound", "Employee"),
                                                HttpStatus.NOT_FOUND.value(),
                                                messageUtil.get("application.status.notfound"));
                        }

                        return new MessageResponse(
                                        messageUtil.get("application.success.retrieve", "employee id"),
                                        HttpStatus.OK.value(),
                                        messageUtil.get("application.status.ok"),
                                        employee.getIdEmployee());
                } catch (Exception e) {
                        return new MessageResponse(
                                        messageUtil.get("application.error.internal"),
                                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                        messageUtil.get("application.status.error"),
                                        e.getMessage());
                }
        }

}
