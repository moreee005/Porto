package com.tujuhsembilan.presensi79.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tujuhsembilan.presensi79.model.Attendance;

@Repository
@EnableJpaRepositories
public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {
        List<Attendance> findByEmployee_IdEmployee(Integer idEmployee);

        List<Attendance> findByEmployee_IdEmployeeAndDateAttendance(Integer idEmployee, LocalDate dateAttendance);

        List<Attendance> findByEmployee_IdEmployeeAndDateAttendanceBetween(Integer idEmployee, LocalDate startDate,
                        LocalDate endDate);

        List<Attendance> findByEmployee_IdEmployeeAndDateAttendanceBetweenOrderByDateAttendanceDesc(Integer idEmployee, LocalDate startDate, LocalDate endDate);

        @Query("SELECT a FROM Attendance a WHERE a.dateAttendance >= :startDateFilter AND a.dateAttendance <= :endDateFilter")
        List<Attendance> findAllAttendanceByDate(LocalDate startDateFilter, LocalDate endDateFilter);

        List<Attendance> findTop7ByOrderByCheckInAsc();

        List<Attendance> findByEmployee_Company_IdCompany(Integer idCompany);

        List<Attendance> findByEmployee_Company_IdCompanyAndEmployee_FirstNameContainingOrEmployee_LastNameContainingOrEmployee_Department_DepartmentNameContaining(
                        Integer idCompany, String firstName, String lastName, String departmentName);

        // List<Attendance> findByEmployee_Company_IdAndIsDeletedFalse(Integer
        // companyId);

        // Menghitung jumlah kehadiran hari ini
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.dateAttendance = :today")
        long countTodayAttendanceByCompanyId(@Param("companyId") Integer companyId, @Param("today") LocalDate today);

        // Menghitung jumlah kehadiran minggu ini (mulai dari hari Senin)
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.dateAttendance >= :startOfWeek")
        long countThisWeekAttendanceByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfWeek") LocalDate startOfWeek);

        // Menghitung jumlah kehadiran bulan ini (mulai dari tanggal 1)
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.dateAttendance >= :startOfMonth")
        long countThisMonthAttendanceByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfMonth") LocalDate startOfMonth);

        // Menghitung jumlah keterlambatan (late) hari ini
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.status = 'Late' AND a.dateAttendance = :today")
        long countTodayLateByCompanyId(@Param("companyId") Integer companyId, @Param("today") LocalDate today);

        // Menghitung jumlah keterlambatan minggu ini (mulai dari hari Senin)
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.status = 'Late' AND a.dateAttendance >= :startOfWeek")
        long countThisWeekLateByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfWeek") LocalDate startOfWeek);

        // Menghitung jumlah keterlambatan bulan ini (mulai dari tanggal 1)
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.status = 'Late' AND a.dateAttendance >= :startOfMonth")
        long countThisMonthLateByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfMonth") LocalDate startOfMonth);

        // Menghitung jumlah kehadiran tepat waktu (on_time) hari ini
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.status = 'On Time' AND a.dateAttendance = :today")
        long countTodayOnTimeByCompanyId(@Param("companyId") Integer companyId, @Param("today") LocalDate today);

        // Menghitung jumlah kehadiran tepat waktu minggu ini (mulai dari hari Senin)
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.status = 'On Time' AND a.dateAttendance >= :startOfWeek")
        long countThisWeekOnTimeByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfWeek") LocalDate startOfWeek);

        // Menghitung jumlah kehadiran tepat waktu bulan ini (mulai dari tanggal 1)
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.status = 'On Time' AND a.dateAttendance >= :startOfMonth")
        long countThisMonthOnTimeByCompanyId(@Param("companyId") Integer companyId,
                        @Param("startOfMonth") LocalDate startOfMonth);

        // Menghitung jumlah employee yang tidak melakukan absensi pada hari tertentu
        @Query("SELECT (COUNT(e) - COUNT(a)) FROM Employee e LEFT JOIN Attendance a ON e.idEmployee = a.employee.idEmployee AND a.dateAttendance = :date AND e.company.idCompany = :companyId WHERE e.company.idCompany = :companyId")
        long countAbsenceByCompanyIdAndDate(@Param("companyId") Integer companyId, @Param("date") LocalDate date);

        // Menghitung jumlah employee yang melakukan absensi pada hari ini
        @Query("SELECT COUNT(DISTINCT a.employee.idEmployee) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.dateAttendance = :today")
        long countEmployeesWithAttendanceToday(@Param("companyId") Integer companyId, @Param("today") LocalDate today);

        // Menghitung jumlah employee yang melakukan absensi selama minggu ini
        @Query("SELECT COUNT(DISTINCT a.employee.idEmployee) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.dateAttendance >= :startOfWeek AND a.dateAttendance <= :endOfWeek")
        long countEmployeesWithAttendanceThisWeek(@Param("companyId") Integer companyId,
                        @Param("startOfWeek") LocalDate startOfWeek, @Param("endOfWeek") LocalDate endOfWeek);

        // Menghitung jumlah employee yang melakukan absensi selama bulan ini
        @Query("SELECT COUNT(DISTINCT a.employee.idEmployee) FROM Attendance a WHERE a.employee.company.idCompany = :companyId AND a.dateAttendance >= :startOfMonth AND a.dateAttendance <= :endOfMonth")
        long countEmployeesWithAttendanceThisMonth(@Param("companyId") Integer companyId,
                        @Param("startOfMonth") LocalDate startOfMonth, @Param("endOfMonth") LocalDate endOfMonth);

        // Menghitung jumlah kehadiran tepat waktu (on_time) berdasarkan departmentId
        // dan tanggal
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.department.idDepartment = :departmentId AND a.status = 'On Time' AND a.dateAttendance = :date")
        long countTodayOnTimeByDepartmentId(@Param("departmentId") Integer departmentId, @Param("date") LocalDate date);

        // Menghitung jumlah kehadiran terlambat (late) berdasarkan departmentId dan
        // tanggal
        @Query("SELECT COUNT(a) FROM Attendance a WHERE a.employee.department.idDepartment = :departmentId AND a.status = 'Late' AND a.dateAttendance = :date")
        long countTodayLateByDepartmentId(@Param("departmentId") Integer departmentId, @Param("date") LocalDate date);

        // Menghitung jumlah karyawan yang absen (absent) berdasarkan departmentId
        // dan tanggal
        @Query("SELECT (COUNT(e) - COUNT(a)) FROM Employee e LEFT JOIN Attendance a ON e.idEmployee = a.employee.idEmployee AND a.dateAttendance = :date WHERE e.department.idDepartment = :departmentId")
        long countAbsenceByDepartmentIdAndDate(@Param("departmentId") Integer departmentId,
                        @Param("date") LocalDate date);

        
}
