package com.tujuhsembilan.presensi79.service;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.ChangePasswordRequest;
import com.tujuhsembilan.presensi79.model.Account;
import com.tujuhsembilan.presensi79.model.Admin;
import com.tujuhsembilan.presensi79.model.Employee;
import com.tujuhsembilan.presensi79.repository.AccountRepository;
import com.tujuhsembilan.presensi79.repository.AdminRepository;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.util.MessageUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AccountService {

    private final AccountRepository accountRepository;
    private final EmployeeRepository employeeRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final AdminRepository adminRepository;
    private final MessageUtil messageUtil;


    @Transactional
    public MessageResponse changeEmployeePassword(Integer idEmployee, ChangePasswordRequest request) {
        try {
            Optional<Employee> optionalEmployee = employeeRepository.findById(idEmployee);

            if (!optionalEmployee.isPresent()) {
                return new MessageResponse(
                    messageUtil.get("application.error.notfound", "Employee"),
                    HttpStatus.BAD_REQUEST.value(),
                    messageUtil.get("application.status.error")
                );
            }

            if (!request.getNewPassword().equals(request.getConfirmPassword())) {
                return new MessageResponse(
                    messageUtil.get("application.error.newpassword.notmatch"),
                    HttpStatus.BAD_REQUEST.value(),
                    messageUtil.get("application.status.error")
                );
            }

            Employee employee = optionalEmployee.get();
            Account account = employee.getAccount();
            String username = employee.getAccount().getUsername();

            if (!passwordEncoder.matches(request.getOldPassword(), account.getPassword())) {
                return new MessageResponse(
                    messageUtil.get("application.error.changepassword.incorrect"),
                    HttpStatus.BAD_REQUEST.value(),
                    messageUtil.get("application.status.error")
                );
            }

            account.setPassword(passwordEncoder.encode(request.getNewPassword()));
            account.setModifiedBy(username);
            account.setModifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))));
            accountRepository.save(account);

            return new MessageResponse(
                messageUtil.get("application.success.changepassword"),
                HttpStatus.OK.value(),
                messageUtil.get("application.status.ok")
            );
        } catch (Exception e) {
            return new MessageResponse(
                messageUtil.get("application.error.internal"),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                messageUtil.get("application.status.error"),
                e.getMessage()
            );
        }
    }

    public ResponseEntity<?> changeAdminPassword(Integer idAdmin, String newPassword) {
        Optional<Admin> admin = adminRepository.findById(idAdmin);
        if (!admin.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(messageUtil.get("application.error.idnotfound"), HttpStatus.NOT_FOUND.value(), messageUtil.get("application.status.notfound")));
        }
        if (newPassword.length() < 7) {
            return ResponseEntity.badRequest().body(new MessageResponse(messageUtil.get("application.error.password.tooshort"), HttpStatus.BAD_REQUEST.value(), messageUtil.get("application.status.badrequest")));
        }
        if (newPassword.length() > 20) {
            return ResponseEntity.badRequest().body(new MessageResponse(messageUtil.get("application.error.password.toolong"), HttpStatus.BAD_REQUEST.value(), messageUtil.get("application.status.badrequest")));
        }
        Admin adminToUpdate = admin.get();
        adminToUpdate.getAccount().setPassword(passwordEncoder.encode(newPassword));
        accountRepository.save(adminToUpdate.getAccount());
        return ResponseEntity.ok(new MessageResponse(messageUtil.get("application.success.changepassword"), HttpStatus.OK.value(), messageUtil.get("application.status.ok")));
    }
}

