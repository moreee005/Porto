package com.tujuhsembilan.presensi79.service;

import com.tujuhsembilan.presensi79.config.minio.MinioService;
import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.request.LeaveRequest;
import com.tujuhsembilan.presensi79.dto.request.UpdateLeaveStatusRequest;
import com.tujuhsembilan.presensi79.dto.response.ApplyLeaveResponse;
import com.tujuhsembilan.presensi79.dto.response.LeaveCardDepartmentResponse;
import com.tujuhsembilan.presensi79.dto.response.LeaveCardResponse;
import com.tujuhsembilan.presensi79.dto.response.EmployeeLeaveDetailResponse;
import com.tujuhsembilan.presensi79.dto.response.LeaveDetailResponse;
import com.tujuhsembilan.presensi79.model.Employee;
import com.tujuhsembilan.presensi79.model.Leave;
import com.tujuhsembilan.presensi79.model.Department;
import com.tujuhsembilan.presensi79.repository.EmployeeRepository;
import com.tujuhsembilan.presensi79.repository.LeaveRepository;
import com.tujuhsembilan.presensi79.util.MessageUtil;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Optional;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.HashMap;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
// import org.hibernate.mapping.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class LeaveService {

    private final LeaveRepository leaveRepository;
    private final EmployeeRepository employeeRepository;
    private final MessageUtil messageUtil;
    private final MinioService minioService;

    private static final Logger logger = LoggerFactory.getLogger(LeaveService.class);

    public MessageResponse getAllLeaves(Integer idEmployee, int page, int size) {
        try {
            logger.info("Fetching leaves for employee ID: {}", idEmployee);

            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "idLeave"));
            Page<Leave> leavesPage = leaveRepository.findByEmployee_IdEmployee(idEmployee, pageable);

            logger.info("Leaves Page: {}", leavesPage);

            List<Leave> leaves = leavesPage.getContent();
            logger.info("Fetched Leaves: {}", leaves);

            if (!leaves.isEmpty()) {
                List<LeaveCardResponse> response = leaves.stream().map(leave -> {
                    // Retrieve attachment URL if present
                    String attachmentUrl = null;
                    if (leave.getAttachment() != null) {
                        attachmentUrl = minioService.getPublicLink(leave.getAttachment());
                    }

                    LeaveCardResponse leaveCardResponse = LeaveCardResponse.builder()
                            .idLeave(leave.getIdLeave())
                            .leaveType(leave.getLeaveType())
                            .createdDate(leave.getCreatedDate())
                            .startDate(leave.getStartDate())
                            .endDate(leave.getEndDate())
                            .reason(leave.getReason())
                            .attachment(attachmentUrl) // Set the attachment URL here
                            .status(leave.getStatus())
                            .build();
                    logger.info("Mapped LeaveCardResponse: {}", leaveCardResponse);
                    return leaveCardResponse;
                }).collect(Collectors.toList());

                return new MessageResponse(
                        messageUtil.get("application.success.retrieve", "Leaves"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"),
                        response);
            } else {
                logger.warn("No leaves found for employee ID: {}", idEmployee);
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Leaves"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }
        } catch (Exception e) {
            logger.error("Error fetching all leaves for employee {}: {}", idEmployee, e.getMessage(), e);
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    public MessageResponse applyLeave(Integer idEmployee, LeaveRequest leaveRequest, MultipartFile attachment) {
        try {
            Optional<Employee> employeeOptional = employeeRepository.findById(idEmployee);
            if (!employeeOptional.isPresent()) {
                logger.warn("Employee not found for ID: {}", idEmployee);
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Employee"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }

            Employee employee = employeeOptional.get();
            String username = employee.getAccount().getUsername();

            // Validate dates
            if (leaveRequest.getEndDate() == null || leaveRequest.getStartDate() == null) {
                logger.warn("Invalid dates in leave request: {}", leaveRequest);
                return new MessageResponse(
                        messageUtil.get("application.error.invalid", "Start date and end date cannot be null"),
                        HttpStatus.BAD_REQUEST.value(),
                        messageUtil.get("application.status.badrequest"));
            }

            if (leaveRequest.getEndDate().isBefore(leaveRequest.getStartDate())) {
                logger.warn("End date is before start date in leave request: {}", leaveRequest);
                return new MessageResponse(
                        messageUtil.get("application.error.invalid", "End date cannot be before start date"),
                        HttpStatus.BAD_REQUEST.value(),
                        messageUtil.get("application.status.badrequest"));
            }

            // Handle file upload
            String attachmentFilename = null;
            String attachmentUrl = null;
            if (attachment != null && !attachment.isEmpty()) {
                attachmentFilename = minioService.uploadFileToMinio(attachment,
                        "leave_attachment_" + employee.getIdEmployee());
                attachmentUrl = minioService.getPublicLink(attachmentFilename);
            }

            // Create new Leave object
            Leave leave = Leave.builder()
                    .employee(employee)
                    .leaveTitle(leaveRequest.getLeaveTitle())
                    .leaveType(leaveRequest.getLeaveType())
                    .startDate(leaveRequest.getStartDate())
                    .endDate(leaveRequest.getEndDate())
                    .reason(leaveRequest.getReason())
                    .attachment(attachmentFilename)
                    .status("Pending")
                    .createdBy(username)
                    .createdDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                    .modifiedBy(username)
                    .modifiedDate(Timestamp.valueOf(LocalDateTime.now(ZoneId.of("Asia/Jakarta"))))
                    .build();

            Leave savedLeave = leaveRepository.save(leave);

            ApplyLeaveResponse applyLeaveResponse = ApplyLeaveResponse.builder()
                    .idLeave(savedLeave.getIdLeave())
                    .idEmployee(savedLeave.getEmployee().getIdEmployee())
                    .leaveTitle(savedLeave.getLeaveTitle())
                    .leaveType(savedLeave.getLeaveType())
                    .startDate(savedLeave.getStartDate())
                    .endDate(savedLeave.getEndDate())
                    .reason(savedLeave.getReason())
                    .attachment(attachmentUrl)
                    .status(savedLeave.getStatus())
                    .build();

            return new MessageResponse(
                    messageUtil.get("application.success.create", "Leave"),
                    HttpStatus.CREATED.value(),
                    messageUtil.get("application.status.created"),
                    applyLeaveResponse);
        } catch (Exception e) {
            logger.info("Error applying leave for employee {}: {}", idEmployee, e.getMessage(), e);
            return new MessageResponse(
                    messageUtil.get("application.error.notfound", "Leave"),
                    HttpStatus.NOT_FOUND.value(),
                    messageUtil.get("application.status.notfound"));
        }
    }

    @Transactional
    public MessageResponse softDeleteEmployeeLeave(Integer idEmployee, Integer idLeave) {
        try {
            Optional<Leave> leaveOptional = leaveRepository.findByIdLeaveAndEmployee_IdEmployee(idLeave, idEmployee);

            if (!leaveOptional.isPresent()) {
                return new MessageResponse(
                        messageUtil.get("application.success.update", "Leave"),
                        HttpStatus.OK.value(),
                        messageUtil.get("application.status.ok"));
            }

            Leave leave = leaveOptional.get();

            leave.setIsDeleted(true);
            leaveRepository.save(leave);

            return new MessageResponse(
                    "[T-SDT-SUCC-002]",
                    HttpStatus.OK.value(),
                    "OK");

        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    messageUtil.get("application.status.error"),
                    e.getMessage());
        }
    }

    public MessageResponse getAllLeavesByCompanyId(Integer idCompany, int page, int size, String keyword, String from,
            String to) {
        try {
            logger.info("Fetching leaves for company ID: {}, with keyword: {}, from: {}, to: {}", idCompany, keyword,
                    from, to);

            // Parsing tanggal dari String ke LocalDate
            LocalDate startDate = null;
            LocalDate endDate = null;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            if (from != null && !from.isEmpty()) {
                startDate = LocalDate.parse(from, formatter);
            }
            if (to != null && !to.isEmpty()) {
                endDate = LocalDate.parse(to, formatter);
            }

            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "idLeave"));

            // Panggil repository dengan parameter yang diperbarui
            Page<Leave> leavesPage = leaveRepository.findByCompanyAndMultipleFilters(
                    idCompany,
                    keyword != null ? keyword : null,
                    startDate,
                    endDate,
                    pageable);

            logger.info("Leaves Page: {}", leavesPage);

            if (leavesPage.getTotalElements() == 0) {
                logger.warn("No leaves found for company ID: {}", idCompany);
                return new MessageResponse(
                        messageUtil.get("T-LEA-ERR-003"),
                        HttpStatus.NOT_FOUND.value(),
                        "NOT_FOUND");
            }

            List<LeaveCardDepartmentResponse> response = leavesPage.getContent().stream()
                    .map(leave -> {
                        String profilePictureUrl = leave.getEmployee().getProfilePicture() != null
                                ? minioService.getPublicLink(leave.getEmployee().getProfilePicture())
                                : null;

                        // Retrieve attachment URL if present
                        String attachmentUrl = leave.getAttachment() != null
                                ? minioService.getPublicLink(leave.getAttachment())
                                : null;

                        return LeaveCardDepartmentResponse.builder()
                                .idLeave(leave.getIdLeave())
                                .idEmployee(leave.getEmployee().getIdEmployee())
                                .firstName(leave.getEmployee().getFirstName())
                                .lastName(leave.getEmployee().getLastName())
                                .idDepartment(leave.getEmployee().getDepartment().getIdDepartment())
                                .departmentName(leave.getEmployee().getDepartment().getDepartmentName())
                                .profilePicture(profilePictureUrl)
                                .leaveTitle(leave.getLeaveTitle())
                                .leaveType(leave.getLeaveType())
                                .startDate(leave.getStartDate())
                                .endDate(leave.getEndDate())
                                .reason(leave.getReason())
                                .attachment(attachmentUrl) // Set the attachment URL here
                                .status(leave.getStatus())
                                .createdBy(leave.getCreatedBy())
                                .createdDate(leave.getCreatedDate())
                                .modifiedBy(leave.getModifiedBy())
                                .modifiedDate(leave.getModifiedDate())
                                .build();
                    })
                    .collect(Collectors.toList());

            return new MessageResponse(
                    messageUtil.get("T-LEA-SUCC-001"),
                    HttpStatus.OK.value(),
                    "OK",
                    response,
                    leavesPage.getTotalElements(),
                    leavesPage.getTotalPages(),
                    size);

        } catch (Exception e) {
            logger.error("Error fetching leaves for company ID {}: {}", idCompany, e.getMessage(), e);
            return new MessageResponse(
                    messageUtil.get("T-LEA-ERR-001"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage());
        }
    }

    public MessageResponse getAllEmployeeLeave(Integer idEmployee, int page, int size) {
        try {
            logger.info("Fetching leaves for employee ID: {}", idEmployee);

            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "idLeave"));
            Page<Leave> leavesPage = leaveRepository.findByEmployee_IdEmployee(idEmployee, pageable);

            if (leavesPage.hasContent()) {
                List<EmployeeLeaveDetailResponse> response = leavesPage.getContent().stream()
                        .map(leave -> {
                            // Retrieve attachment URL if present
                            String attachmentUrl = leave.getAttachment() != null
                                    ? minioService.getPublicLink(leave.getAttachment())
                                    : null;

                            return EmployeeLeaveDetailResponse.builder()
                                    .idLeave(leave.getIdLeave())
                                    .leaveType(leave.getLeaveType())
                                    .createdDate(leave.getCreatedDate())
                                    .startDate(leave.getStartDate())
                                    .endDate(leave.getEndDate())
                                    .reason(leave.getReason())
                                    .attachment(attachmentUrl) // Set the attachment URL here
                                    .status(leave.getStatus())
                                    .build();
                        })
                        .collect(Collectors.toList());

                Map<String, Object> data = new HashMap<>();
                data.put("data", response);
                data.put("total_data", leavesPage.getTotalElements());
                data.put("total_page", leavesPage.getTotalPages());
                data.put("page_size", leavesPage.getSize());
                data.put("current_page", leavesPage.getNumber());

                return new MessageResponse(
                        "Berhasil mendapatkan data employee leave detail",
                        HttpStatus.OK.value(),
                        "OK",
                        data);
            } else {
                return new MessageResponse(
                        "No leave records found for employee ID: " + idEmployee,
                        HttpStatus.NOT_FOUND.value(),
                        "Not Found");
            }
        } catch (Exception e) {
            logger.error("Error fetching leaves for employee {}: {}", idEmployee, e.getMessage(), e);
            return new MessageResponse(
                    "Gagal mendapatkan data employee leave detail",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage());
        }
    }

    public MessageResponse getLeaveDetailById(Integer idLeave) {
        try {
            Optional<Leave> leaveOptional = leaveRepository.findById(idLeave);
            if (!leaveOptional.isPresent()) {
                return new MessageResponse(
                        messageUtil.get("application.error.notfound", "Leave"),
                        HttpStatus.NOT_FOUND.value(),
                        messageUtil.get("application.status.notfound"));
            }

            Leave leave = leaveOptional.get();
            Employee employee = leave.getEmployee();
            Department department = employee.getDepartment();

            // Retrieve attachment URL if present
            String attachmentUrl = null;
            if (leave.getAttachment() != null) {
                attachmentUrl = minioService.getPublicLink(leave.getAttachment());
            }

            LeaveDetailResponse detailResponse = LeaveDetailResponse.builder()
                    .idLeave(leave.getIdLeave())
                    .idEmployee(employee.getIdEmployee())
                    .firstName(employee.getFirstName())
                    .lastName(employee.getLastName())
                    .employeeNumber(employee.getEmployeeNumber())
                    .idDepartment(department.getIdDepartment())
                    .departmentName(department.getDepartmentName())
                    .leaveTitle(leave.getLeaveTitle())
                    .leaveType(leave.getLeaveType())
                    .startDate(leave.getStartDate())
                    .endDate(leave.getEndDate())
                    .reason(leave.getReason())
                    .attachment(attachmentUrl) // Set the attachment URL here
                    .status(leave.getStatus())
                    .createdBy(leave.getCreatedBy())
                    .createdDate(leave.getCreatedDate())
                    .modifiedBy(leave.getModifiedBy())
                    .modifiedDate(leave.getModifiedDate())
                    .build();

            return new MessageResponse(
                    messageUtil.get("application.success.retrieve", "Leave"),
                    HttpStatus.OK.value(),
                    messageUtil.get("application.status.ok"),
                    detailResponse);
        } catch (Exception e) {
            return new MessageResponse(
                    messageUtil.get("application.error.internal"),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage());
        }
    }

    public MessageResponse updateLeaveStatus(Integer idLeave, UpdateLeaveStatusRequest request) {
        try {
            Optional<Leave> leaveOptional = leaveRepository.findById(idLeave);

            if (leaveOptional.isPresent()) {
                Leave leave = leaveOptional.get();
                leave.setStatus(request.getStatus());

                leaveRepository.save(leave);

                return new MessageResponse(
                        "T-LEA-SUCC-002",
                        HttpStatus.OK.value(),
                        "OK",
                        "Status successfully updated");
            } else {
                return new MessageResponse(
                        "T-LEA-ERR-003",
                        HttpStatus.NOT_FOUND.value(),
                        "NOT_FOUND",
                        "Leave not found");
            }
        } catch (Exception e) {
            logger.error("Error updating leave status: {}", e.getMessage(), e);
            return new MessageResponse(
                    "T-LEA-ERR-001",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "ERROR",
                    e.getMessage());
        }
    }

    public InputStream exportLeavesToXlsx(Integer companyId) {
        List<Leave> leaves = leaveRepository.findByEmployee_Company_IdCompanyAndIsDeletedFalse(companyId);

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Leaves");

            // Header
            Row headerRow = sheet.createRow(0);
            String[] headers = { "Department", "Employee Name", "Leave Type", "Leave Duration", "Status", "Reason" };
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
            }

            // Data Rows
            int rowNum = 1;
            for (Leave leave : leaves) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(leave.getEmployee().getDepartment().getDepartmentName());
                row.createCell(1)
                        .setCellValue(leave.getEmployee().getFirstName() + " " + leave.getEmployee().getLastName());
                row.createCell(2).setCellValue(leave.getLeaveType());
                row.createCell(3).setCellValue(leave.getStartDate() + " - " + leave.getEndDate());
                row.createCell(4).setCellValue(leave.getStatus());
                row.createCell(5).setCellValue(leave.getReason());
            }

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());

        } catch (Exception e) {
            throw new RuntimeException("Failed to export data to XLSX file: " + e.getMessage());
        }
    }

}
