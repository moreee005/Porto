package com.tujuhsembilan.presensi79.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class EmployeeDetailDTO {
    private Integer idEmployee;
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private String mobileNumber;
    private String gender;
    private String maritalStatus;
    private String nationality;
    private String address;
    private String province;
    private String city;
    private String district;
    private String zipCode;
    private String employeeNumber;
    private String username;
    private String status;
    private String email;
    private DepartmentDTO department;
    private CompanyDTO company;
    private String roleCurrentCompany;
    private String roleInClient;
    private LocalDate joiningDate;
    private String profilePicture;
}
