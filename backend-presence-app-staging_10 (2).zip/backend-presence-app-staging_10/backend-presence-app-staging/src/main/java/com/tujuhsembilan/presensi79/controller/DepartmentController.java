package com.tujuhsembilan.presensi79.controller;

import com.tujuhsembilan.presensi79.dto.MessageResponse;
import com.tujuhsembilan.presensi79.dto.response.DepartmentDetailsResponse;
import com.tujuhsembilan.presensi79.security.jwt.JwtUtils;
import com.tujuhsembilan.presensi79.service.DepartmentService;
import com.tujuhsembilan.presensi79.util.MessageUtil;
import com.tujuhsembilan.presensi79.util.Messages;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@Tag(name = "Department", description = Messages.TAG_DEPARTMENT_DESCRIPTION)
@RestController
@RequestMapping("/company")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private MessageUtil messageUtil;

    @GetMapping(
        path = "/department",
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<MessageResponse> getDepartmentsByCompany(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization").substring(7);
        Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);
        MessageResponse response = departmentService.getDepartmentsByCompany(idCompany);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    @GetMapping(path = "/department/details", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MessageResponse> getAllDepartmentsByCompany(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization").substring(7);
        Integer idCompany = jwtUtils.getCompanyIdFromJwtToken(authToken);

        try {
            List<DepartmentDetailsResponse> departments = departmentService.getAllDepartmentsByCompany(idCompany);
            MessageResponse response = new MessageResponse(
            messageUtil.get("application.success.retrieve", "Department details"),
            HttpStatus.OK.value(),
            messageUtil.get("application.status.ok"),
            departments
            );
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            MessageResponse response = new MessageResponse(
                messageUtil.get("application.error.internal"),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                messageUtil.get("application.status.error"),
                e.getMessage()
            );
            return ResponseEntity.status(500).body(response);
        }
    }

}