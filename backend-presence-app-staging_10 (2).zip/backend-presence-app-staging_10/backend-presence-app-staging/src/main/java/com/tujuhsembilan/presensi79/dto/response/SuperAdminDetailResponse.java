package com.tujuhsembilan.presensi79.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SuperAdminDetailResponse {

    @JsonProperty("id_superadmin")
    private Integer idSuperadmin;

    @JsonProperty("name")
    private String name;

    @JsonProperty("created_date")
    private String createdDate;
}
