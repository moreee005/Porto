package com.tujuhsembilan.presensi79.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MessageResponse {
    private String message;
    private int statusCode;
    private String status;
    private Object data;
    private String errorMessage;
    private Long totalData; // Make these fields nullable
    private Integer totalPage;
    private Integer pageSize;
    private Meta meta; // Metadata for pagination

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Meta {
        private int total;
        private int perPage;
        private int currentPage;
        private int lastPage;
    }

    // Constructor for success response without data
    public MessageResponse(String message, int statusCode, String status) {
        this.message = message;
        this.statusCode = statusCode;
        this.status = status;
    }


    // Constructor for success response with data and meta
    public MessageResponse(String message, int statusCode, String status, Object data, Meta meta) {
        this.message = message;
        this.statusCode = statusCode;
        this.status = status;
        this.data = data;
        this.meta = meta;
    }

    

    // Constructor for success response with data and error message (tanpa meta)
    public MessageResponse(String message, int statusCode, String status, Object data, String errorMessage) {
        this.message = message;
        this.statusCode = statusCode;
        this.status = status;
        this.data = data;
        this.errorMessage = errorMessage;
}


    public MessageResponse(String message, int statusCode, String status, Object data) {
        this.message = message;
        this.statusCode = statusCode;
        this.status = status;
        this.data = data;
    }

    // Constructor for success response with additional pagination data
    public MessageResponse(String message, int statusCode, String status, Object data, Long totalData,
            Integer totalPage, Integer pageSize) {
        this.message = message;
        this.statusCode = statusCode;
        this.status = status;
        this.data = data;
        this.totalData = totalData;
        this.totalPage = totalPage;
        this.pageSize = pageSize;
    }

    // Constructor for error response
    public MessageResponse(String message, int statusCode, String status, String errorMessage) {
        this.message = message;
        this.statusCode = statusCode;
        this.status = status;
        this.errorMessage = errorMessage;
    }
}
