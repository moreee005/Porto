package com.tujuhsembilan.presensi79.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeByDepartmentResponse {

    @JsonProperty("id_employee")
    private Integer idEmployee;

    @JsonProperty("employee_number")
    private String employeeNumber;

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("last_name")
    private String lastName;

    @JsonProperty("email")
    private String email;

    @JsonProperty("status")
    private String status;

    @JsonProperty("role_current_company")
    private String roleCurrentCompany;

    @JsonProperty("role_in_client")
    private String roleInClient;

    @JsonProperty("profile_picture")
    private String profilePicture;

    @JsonProperty("department")
    private DepartmentResponse department;
}
