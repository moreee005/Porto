from pyreportjasper import PyReportJasper
import os


def json_to_pdf():
    RESOURCES_DIR = "DataReport"
    input_file = "DataReport/Invitation_Letter_KSEI_KTUR_NonCorpBond.jrxml"
    output_file = os.path.join(RESOURCES_DIR, 'Invitation Letter')
    conn = {
        'driver': 'json',
        'data_file': 'DataReport/DataReport.json'
    }
    pyreportjasper = PyReportJasper()
    pyreportjasper.config(
        input_file,
        output_file,
        output_formats=["pdf"],
        db_connection=conn
    )
    pyreportjasper.process_report()
    print('Laporan berhasil dibuat.')
    print(output_file + '.pdf')

json_to_pdf()
