package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class WorkExperienceResponse {

    private UUID idWorkExperience;
    private String companyName;
    private String position;
    private String city;
    private Short startYear;
    private Short endYear;
    private Short durationMonths;

    public WorkExperienceResponse(UUID idWorkExperience, String companyName, String position, String city, Short startYear, Short endYear, Short durationMonths) {
        this.idWorkExperience = idWorkExperience;
        this.companyName = companyName;
        this.position = position;
        this.city = city;
        this.startYear = startYear;
        this.endYear = endYear;
        this.durationMonths = durationMonths;
    }

}
