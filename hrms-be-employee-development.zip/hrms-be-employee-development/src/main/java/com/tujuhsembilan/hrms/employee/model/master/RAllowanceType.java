package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Allowance_Type")
@Table(name = "r_allowance_type", schema = "master", indexes = {
        @Index(name = "rel_allowance_group_fk", columnList = "allowance_group_id")
})
public class RAllowanceType implements Serializable {
    private static final long serialVersionUID = 2051839778986351146L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "allowance_type_id", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "allowance_group_id")
    private RAllowanceGroup allowanceGroup;

}