package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.dto.request.EndRequest;
import com.tujuhsembilan.hrms.employee.dto.request.ResignRequest;
import com.tujuhsembilan.hrms.employee.dto.response.*;
import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.exception.NotFoundException;
import com.tujuhsembilan.hrms.employee.helpers.Response;
import com.tujuhsembilan.hrms.employee.model.*;
import com.tujuhsembilan.hrms.employee.model.master.RContractStatus;
import com.tujuhsembilan.hrms.employee.model.master.RContractType;
import com.tujuhsembilan.hrms.employee.model.view.ViewDatatableContract;
import com.tujuhsembilan.hrms.employee.repositories.*;
import com.tujuhsembilan.hrms.employee.repositories.master.RContractStatusRepo;
import com.tujuhsembilan.hrms.employee.repositories.master.RContractTypeRepo;
import com.tujuhsembilan.hrms.employee.utils.Helper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DataContractService {

    @Autowired
    ViewDatatableContractRepo viewDatatableContractRepo;

    @Autowired
    EmployeeAllowanceRepo employeeAllowanceRepo;

    @Autowired
    EmployeeContractRepo employeeContractRepo;

    @Autowired
    PersonRepo personRepo;

    @Autowired
    EmployeeRepo employeeRepo;

    @Autowired
    ContractDocumentRepo contractDocumentRepo;

    @Autowired
    RContractStatusRepo rContractStatusRepo;

    @Autowired
    EmployeeResignationRepo employeeResignationRepo;

    @Autowired
    RContractTypeRepo rContractTypeRepo;

    @Autowired
    HistoricEmployeeContractRepo historicEmployeeContractRepo;

    public ResponseEntity<BaseResponse> getDatatableContract(String search, Integer contract, Integer status, String endDate, Pageable pageable) {
        Page<ViewDatatableContract> viewDatatableContracts = viewDatatableContractRepo.datatableContractByFilter(contract, status, endDate, search, pageable);
        if (viewDatatableContracts.getTotalElements() > 0) {
            DataTableResponse dataTableResponse = new DataTableResponse();
            dataTableResponse.setData(viewDatatableContracts.getContent());
            dataTableResponse.setRecordsTotal(viewDatatableContracts.getTotalElements());
            dataTableResponse.setRecordsFiltered(viewDatatableContractRepo.count());
            return Response.success(dataTableResponse);
        }
        return Response.notFound();
    }

    public ResponseEntity<BaseResponse> getDataHistoryByEmployeeId(UUID employeeId) {

        if (employeeId == null) {
            log.error("Employee ID is null");
            throw new BadRequestException("Employee ID cannot be null");
        }

        List<Object[]> contractDetailsList = employeeContractRepo.fetchContractDetails(employeeId);

        if (contractDetailsList == null || contractDetailsList.isEmpty()) {
            log.warn("No contract details found for employeeId: {}", employeeId);
            throw new NotFoundException("No contract details found for employee");
        }

        try {
            Object[] contractDetails = contractDetailsList.get(0);

            for (Object contractDetail : contractDetailsList) {

            }
            HistoryContractResponse historyContractResponse  = new HistoryContractResponse(
                    Helper.safeToString(contractDetails, 0),
                    Helper.safeToString(contractDetails, 1),
                    Helper.safeToLocalDateTime(contractDetails, 2),
                    Helper.safeToLocalDateTime(contractDetails, 3),
                    Helper.safeToString(contractDetails, 4),
                    Helper.safeToString(contractDetails, 5),
                    fetchAllowances(employeeId)
            );

            return Response.success(List.of(historyContractResponse));
        } catch (Exception e) {
            log.error("Error processing contract details for employeeId: {}", employeeId, e);
            throw new InternalServerErrorException("Failed to process contract details");
        }
    }

    private List<AllowanceResponse> fetchAllowances(UUID employeeId) {
        List<AllowanceResponse> allowances = Optional.ofNullable(employeeAllowanceRepo.fetchAllowances(employeeId))
                .map(allowanceResults -> allowanceResults.stream()
                        .map(this::createAllowanceResponse)
                        .collect(Collectors.toList())
                )
                .orElse(Collections.emptyList());

        return allowances.isEmpty() ? null : allowances;
    }

    private AllowanceResponse createAllowanceResponse(Object[] row) {
        try {
            UUID uuid = UUID.fromString(Helper.nullSafeToString(row[0]));
            String uuidString = uuid.toString();

            return new AllowanceResponse(
                    uuidString,
                    Helper.nullSafeToString(row[1]),
                    row[2] instanceof BigDecimal bigDecimal
                            ? bigDecimal
                            : BigDecimal.ZERO
            );
        } catch (Exception e) {
            log.warn("Error creating allowance response: {}", e.getMessage());
            return null;
        }
    }

    public ResponseEntity<BaseResponse> getDataContractByEmployeeId(UUID employeeId) {
        if (employeeId == null) {
            log.error("Employee ID is null");
            return Response.notFound("Employee ID is null");
        }
        try {

            DataContractResponse dataContractResponse = new DataContractResponse();
            Optional<Person> personOptional = personRepo.findById(employeeId);
            Optional<Employee> employeeOptional = employeeRepo.findById(employeeId);
            Optional<EmployeeContract> employeeContractOptional = employeeContractRepo.findById(employeeId);
            Optional<ContractDocument> contractDocumentOptional = contractDocumentRepo.findById(employeeId);
            if (personOptional.isPresent() && employeeOptional.isPresent()) {
                Person person = personOptional.get();
                Employee employee = employeeOptional.get();
                EmployeeContract employeeContract = new EmployeeContract();
                if (employeeContractOptional.isPresent()) {
                    employeeContract = employeeContractOptional.get();
                }

                ContractDocument contractDocument = new ContractDocument();
                if (contractDocumentOptional.isPresent()) {
                    contractDocument = contractDocumentOptional.get();
                }

                EmployeeDetailResponse employeeDetailResponse = new EmployeeDetailResponse();
                employeeDetailResponse.setId(person.getParty().getId());
                employeeDetailResponse.setFullName(person.getFullname());
                employeeDetailResponse.setDivision(employee.getDivision() != null ? employee.getDivision().getName() : null);
                employeeDetailResponse.setContractStatus(employeeContract.getContractStatus() != null ? employeeContract.getContractStatus().getName() : null);
                employeeDetailResponse.setPosition(employee.getPosition().getName());
                dataContractResponse.setEmployeeDetail(employeeDetailResponse);

                ContractInfoResponse contractInfoResponse = new ContractInfoResponse();
                contractInfoResponse.setStatus(employeeContract.getContractType() != null ? employeeContract.getContractType().getName() : null);
                contractInfoResponse.setPlacementType(employee.getPlacementType() != null ? employee.getPlacementType().getName() : null);
                contractInfoResponse.setEmployeeType(employee.getParty().getPartyType().getName());
                contractInfoResponse.setBankPlacement(employee.getBankingPlacement() != null ? employee.getBankingPlacement().getName() : null);
                contractInfoResponse.setDivision(employee.getDivision() != null ? employee.getDivision().getName() : null);
                contractInfoResponse.setPosition(employee.getPosition() != null ? employee.getPosition().getName() : null);
                contractInfoResponse.setContractStartDate(employeeContract.getStartDate());
                contractInfoResponse.setContractEndDate(employeeContract.getStartDate());
                contractInfoResponse.setGeneration(employee.getGeneration());
                contractInfoResponse.setContractDocument(null);
                contractInfoResponse.setContractDocumentName(contractDocument.getDocFilename());
                contractInfoResponse.setSalary(employeeContract.getCurrentSalary() != null ? employeeContract.getCurrentSalary() : null);
                dataContractResponse.setContractInfo(contractInfoResponse);

                List<PlacementAllowanceResponse> placementAllowanceResponseList = new ArrayList<>();
                PlacementAllowanceResponse placementAllowanceResponse = new PlacementAllowanceResponse();
                placementAllowanceResponse.setAllowanceType(null);
                placementAllowanceResponseList.add(placementAllowanceResponse);
                dataContractResponse.setPlacementAllowance(placementAllowanceResponseList);

                List<OtherAllowanceResponse> otherAllowanceResponseList = new ArrayList<>();
                OtherAllowanceResponse otherAllowanceResponse = new OtherAllowanceResponse();
                otherAllowanceResponse.setAllowanceType(null);
                otherAllowanceResponse.setAmount(null);
                otherAllowanceResponseList.add(otherAllowanceResponse);
                dataContractResponse.setOtherAllowance(otherAllowanceResponseList);

                return Response.success(dataContractResponse);
            }
        } catch (Exception e) {
            log.error("Error processing contract details for employeeId: {}", employeeId, e);
        }
        return Response.notFound();
    }

    public ResponseEntity<BaseResponse> createResign(UUID employeeId, ResignRequest request) {
        if (employeeId == null) {
            log.error("Employee ID is null");
        }
        try {
            EmployeeContract getEmployeeContract = employeeContractRepo.findContractByPartyId(employeeId);
            if (getEmployeeContract != null) {
                Optional<RContractStatus> contractStatus = rContractStatusRepo.findById(8);
                if (contractStatus.isPresent()) {
                    EmployeeContract employeeContract = getEmployeeContract;
                    employeeContract.setContractStatus(contractStatus.get());
                    employeeContractRepo.save(employeeContract);

                    EmployeeResignation employeeResignation = new EmployeeResignation();
                    employeeResignation.setEmployeeContract(employeeContract);
                    employeeResignation.setResignDate(request.getResignDate());
                    employeeResignation.setRemarks(request.getReason());
                    employeeResignationRepo.save(employeeResignation);

                    return Response.success();
                }
            }

        } catch (Exception e) {
            log.warn("Error creating resign response: {}", e.getMessage());
        }
        return Response.notFound();
    }

    public ResponseEntity<BaseResponse> createEnd(UUID employeeId, EndRequest request) {
        if (employeeId == null) {
            log.error("Employee ID is null");
        }
        try {

            Optional<EmployeeContract> employeeContractOptional = employeeContractRepo.findLatestContractByEmployeeId(employeeId);
            if (employeeContractOptional.isPresent()) {
                Integer endContractId = employeeContractOptional.get().getContractType().getId() + 9;
                Optional<RContractType> rContractType = rContractTypeRepo.findById(endContractId);
                employeeContractOptional.get().setContractType(rContractType.get());
                employeeContractOptional.get().setDeletedAt(OffsetDateTime.now(ZoneOffset.UTC));
                employeeContractRepo.save(employeeContractOptional.get());

                EmployeeContract employeeContract = new EmployeeContract();
                employeeContract.setContractType(rContractType.get());
                employeeContract.setContractStatus(employeeContractOptional.get().getContractStatus());
                employeeContract.setStartDate(employeeContractOptional.get().getStartDate());
                employeeContract.setEndDate(employeeContractOptional.get().getEndDate());
                employeeContract.setCurrentSalary(employeeContractOptional.get().getCurrentSalary());
                employeeContractRepo.save(employeeContract);

                HistoricEmployeeContract historicEmployeeContract = new HistoricEmployeeContract();
                historicEmployeeContract.setParty(employeeContract.getParty());
                historicEmployeeContract.setContractTypeId(endContractId);
                historicEmployeeContract.setContractStatusId(employeeContract.getContractStatus().getId());
                historicEmployeeContract.setStartDate(employeeContract.getStartDate());
                historicEmployeeContract.setEndDate(employeeContract.getEndDate());
                historicEmployeeContract.setCurrentSalary(employeeContract.getCurrentSalary());
                historicEmployeeContractRepo.save(historicEmployeeContract);

                return Response.success();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Response.notFound();
    }

}
