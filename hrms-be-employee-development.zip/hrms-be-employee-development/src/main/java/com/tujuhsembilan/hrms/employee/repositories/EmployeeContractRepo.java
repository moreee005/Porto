package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.Employee;
import com.tujuhsembilan.hrms.employee.model.EmployeeContract;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface EmployeeContractRepo extends JpaRepository<EmployeeContract, UUID> {

    Optional<EmployeeContract> findByParty(Employee employee);

    @Query(nativeQuery = true, value = """
            SELECT
                COALESCE(rct.name, '') AS contract, 
                COALESCE(cd.doc_filename, '') AS contractDocument,
                ec.start_date AS startDate,
                ec.end_date AS endDate,
                COALESCE(rbp.name, '') AS bankInsuranceAgreement,
                COALESCE(p.name, '') AS placement
            FROM employee_contract ec
            LEFT JOIN master.r_contract_type rct ON ec.contract_type_id = rct.contract_type_id
            LEFT JOIN contract_document cd ON ec.employee_contract_id = cd.employee_contract_id
            LEFT JOIN employee e ON ec.party_id = e.party_id
            LEFT JOIN master.r_banking_placement rbp ON e.banking_placement_id = rbp.banking_placement_id
            LEFT JOIN master.r_placement_type p ON e.placement_type_id = p.placement_type_id
            WHERE e.party_id = :employeeId
            LIMIT 1
        """)
    List<Object[]> fetchContractDetails(@Param("employeeId") UUID employeeId);

    @Query(nativeQuery = true, value = "SELECT * FROM employee_contract ec WHERE ec.party_id = :id")
    EmployeeContract findContractByPartyId(@Param("id") UUID id);

    @Query(nativeQuery = true, value =
            "SELECT " +
                    "   ea.employee_allowance_id AS allowance_id, " +
                    "   rat.name AS allowance_type, " +
                    "   ea.amount AS nominal " +
                    "FROM employee_allowance ea " +
                    "JOIN employee_contract ec ON ea.employee_contract_id = ec.employee_contract_id " +
                    "JOIN master.r_allowance_type rat ON ea.allowance_type_id = rat.allowance_type_id " +
                    "WHERE ec.party_id = :employeeId")
    List<Object[]> fetchAllowancesByEmployeeId(@Param("employeeId") UUID employeeId);

    @Query("SELECT ec FROM Employee_Contract ec WHERE ec.party.id = :partyId")
    List<EmployeeContract> findByPartyId(@Param("partyId") UUID partyId);

//    Optional<EmployeeContract> findByPartyId(UUID partyId);

    @Query("SELECT ec FROM Employee_Contract ec WHERE ec.party.id = :employeeId AND ec.deletedAt IS NULL")
    Optional<EmployeeContract> findLatestContractByEmployeeId(@Param("employeeId") UUID employeeId);

}