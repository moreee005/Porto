package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Range_Salary")
@Table(name = "r_range_salary", schema = "master")
public class RRangeSalary implements Serializable {
    private static final long serialVersionUID = 6950399036187455379L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "range_salary_id", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "salary", nullable = false, length = 100)
    private String salary;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}