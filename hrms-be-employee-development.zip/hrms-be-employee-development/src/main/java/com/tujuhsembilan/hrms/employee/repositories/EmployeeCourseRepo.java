package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.EmployeeCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeCourseRepo extends JpaRepository<EmployeeCourse, UUID> {

    @Query("SELECT ec FROM Employee_Course ec WHERE ec.party.id = :partyId")
    List<EmployeeCourse> findByPartyId(@Param("partyId") UUID partyId);

}
