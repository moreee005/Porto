package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Banking_Placement")
@Table(name = "r_banking_placement", schema = "master")
public class RBankingPlacement implements Serializable {
    private static final long serialVersionUID = 3740910441881447061L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "banking_placement_id", nullable = false)
    private Integer bankingPlacementId;

    @Size(max = 100)
    @NotNull
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}