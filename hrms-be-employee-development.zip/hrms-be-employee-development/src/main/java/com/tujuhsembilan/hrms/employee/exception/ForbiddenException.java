package com.tujuhsembilan.hrms.employee.exception;

import org.springframework.http.HttpStatus;

public class ForbiddenException extends BaseException {

    public ForbiddenException() {
        this.setMessage("Forbidden");
        this.setHttpStatus(HttpStatus.FORBIDDEN);
    }

    public ForbiddenException(String message) {
        this.setMessage(message);
        this.setHttpStatus(HttpStatus.FORBIDDEN);
    }

}
