package com.tujuhsembilan.hrms.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.tujuhsembilan.hrms.employee","lib.minio"})
public class HrmsBeEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmsBeEmployeeApplication.class, args);
	}

}
