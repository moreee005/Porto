package com.tujuhsembilan.hrms.employee.constant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum RPartyTypeEnum {
    TALENT(1, "Talent", "Individu berbakat"),
    KLIEN(2, "Klien", "Pihak eksternal yang dilayani"),
    MANAGER(3, "Manager", "Pimpinan tingkat menengah"),
    STAFF(4, "Staff", "Karyawan reguler"),
    LAINNYA(5, "Lainnya", "Kategori tambahan"),
    USER(6, "User", "Pengguna sistem");

    private final Integer id;
    private final String name;
    private final String description;
}