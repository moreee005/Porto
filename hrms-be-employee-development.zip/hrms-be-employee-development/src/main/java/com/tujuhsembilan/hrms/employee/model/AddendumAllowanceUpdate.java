package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Addendum_Allowance_Update")
@Table(name = "addendum_allowance_update", schema = "public", indexes = {
        @Index(name = "rel_allow_updt_fk", columnList = "employee_allowance_id"),
        @Index(name = "rel_add_allowupdt_fk", columnList = "addendum_id")
})
public class AddendumAllowanceUpdate implements Serializable {
    private static final long serialVersionUID = -2787021290940264355L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "add_allowance_update_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_allowance_id")
    private EmployeeAllowance employeeAllowance;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "addendum_id")
    private Addendum addendum;

    @Column(name = "amount_old", precision = 10, scale = 2)
    private BigDecimal amountOld;

    @Column(name = "amount_new", precision = 10, scale = 2)
    private BigDecimal amountNew;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}