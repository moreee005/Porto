package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RGeography;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Organization_Experience")
@Table(name = "organization_experience", schema = "public", indexes = {
        @Index(name = "rel_emp_org_exp_fk", columnList = "party_id"),
        @Index(name = "rel_org_exp_city_fk", columnList = "city_id")
})
public class OrganizationExperience implements Serializable {
    private static final long serialVersionUID = -9209860411514414091L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "organization_experience_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Employee party;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "city_id")
    private RGeography city;

    @Size(max = 100)
    @NotNull
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Size(max = 100)
    @Column(name = "\"position\"", length = 100)
    private String position;

    @Column(name = "start_year")
    private Short startYear;

    @Column(name = "duration")
    private Short duration;

    @Size(max = 20)
    @Column(name = "member_range", length = 20)
    private String memberRange;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}