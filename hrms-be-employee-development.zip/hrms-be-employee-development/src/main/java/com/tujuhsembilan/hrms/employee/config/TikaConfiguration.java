package com.tujuhsembilan.hrms.employee.config;

import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import org.apache.tika.Tika;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.detect.DefaultDetector;
import org.apache.tika.detect.Detector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@Configuration
public class TikaConfiguration {
    @Bean
    public Tika tika() {
        return new Tika();
    }

    @Bean
    public TikaConfig tikaConfig() {
        try {
            return TikaConfig.getDefaultConfig();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create Tika configuration", e);
        }
    }

    @Bean
    public Detector tikaDetector() {
        return new DefaultDetector();
    }

    @Bean
    public MediaTypeDetector mediaTypeDetector(Detector detector) {
        return new MediaTypeDetector(detector);
    }

    // Kelas utilitas untuk deteksi media type
    public static class MediaTypeDetector {
        private final Detector detector;
        private final Tika tika;

        public MediaTypeDetector(Detector detector) {
            this.detector = detector;
            this.tika = new Tika();
        }

        public MediaType detect(MultipartFile file) {
            try {
                Metadata metadata = new Metadata();

                // Gunakan nama file dari MultipartFile
                if (file.getOriginalFilename() != null) {
                    metadata.add("filename", file.getOriginalFilename());
                }

                // Tambahkan content type jika tersedia
                if (file.getContentType() != null) {
                    metadata.add(Metadata.CONTENT_TYPE, file.getContentType());
                }

                try (InputStream inputStream = file.getInputStream()) {
                    // Gunakan Tika untuk deteksi tipe
                    String detectedType = tika.detect(inputStream, metadata);
                    return MediaType.parse(detectedType);
                }
            } catch (IOException e) {
                throw new BadRequestException("Unable to detect file type: " + e.getMessage());
            }
        }

        // Metode tambahan untuk validasi tipe file
        public boolean isAllowedType(MultipartFile file, String... allowedTypes) {
            try {
                MediaType detectedType = detect(file);
                for (String allowedType : allowedTypes) {
                    if (detectedType.toString().startsWith(allowedType)) {
                        return true;
                    }
                }
                return false;
            } catch (Exception e) {
                return false;
            }
        }

        // Metode untuk mendapatkan ekstensi file
        public String getFileExtension(MultipartFile file) {
            try {
                MediaType mediaType = detect(file);

                // Coba dapatkan ekstensi dari nama file asli
                String originalFilename = file.getOriginalFilename();
                if (originalFilename != null && originalFilename.contains(".")) {
                    return originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
                }

                // Fallback ke subtype MIME
                return mediaType.getSubtype();
            } catch (Exception e) {
                return "unknown";
            }
        }

        // Metode tambahan untuk debugging
        public String getDetailedFileInfo(MultipartFile file) {
            try {
                MediaType mediaType = detect(file);
                return String.format(
                        "Filename: %s, Content Type: %s, Detected MIME Type: %s",
                        file.getOriginalFilename(),
                        file.getContentType(),
                        mediaType.toString()
                );
            } catch (Exception e) {
                return "Unable to get file details: " + e.getMessage();
            }
        }
    }
}