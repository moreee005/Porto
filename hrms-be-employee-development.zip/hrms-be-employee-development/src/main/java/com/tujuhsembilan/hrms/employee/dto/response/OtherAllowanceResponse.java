package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OtherAllowanceResponse {

    private String allowanceType;
    private BigDecimal amount;
}
