package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SocialMediaRequest {

    @NotNull(message = "Social media type cannot be null")
    private Integer socialMediaType;

    @NotNull(message = "Social media link cannot be null")
    @Size(min = 5, max = 255, message = "Social media link must be between 5 and 255 characters")
    @Pattern(regexp = "^(https?|ftp)://[^\s/$.?#].[^\s]*$", message = "Invalid URL format")
    private String linkSocmed;
}
