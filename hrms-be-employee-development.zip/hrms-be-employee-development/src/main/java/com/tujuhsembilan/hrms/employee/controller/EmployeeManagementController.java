package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.dto.request.EmployeeAddRequest;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.helpers.Response;
import com.tujuhsembilan.hrms.employee.service.EmployeeManagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(ResourceURL.EMPLOYEE_MANAGEMENT)
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('TALENT ADMINISTRATION')")
public class EmployeeManagementController {
    private final EmployeeManagementService employeeManagementService;

    // todo ini hanya bisa diakses oleh ROLE ADMIN
    @PostMapping(value = ResourceURL.ADD)
    public ResponseEntity<BaseResponse> submitEmployeeDataToApproval(
            @Validated @RequestBody EmployeeAddRequest request) {
        return Response.success(
                employeeManagementService.addEmployeeToApproval(request));
    }
}
