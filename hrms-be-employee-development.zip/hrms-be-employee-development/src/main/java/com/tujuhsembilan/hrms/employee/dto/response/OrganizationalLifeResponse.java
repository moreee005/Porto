package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class OrganizationalLifeResponse {

    private UUID organizationId;
    private String organizationName;
    private Short yearInPosition;
    private String position;
    private String memberCount;
    private String city;
    private Short durationMonths;

    public OrganizationalLifeResponse(UUID organizationId, String organizationName, Short yearInPosition, String position, String memberCount, String city, Short durationMonths) {
        this.organizationId = organizationId;
        this.organizationName = organizationName;
        this.yearInPosition = yearInPosition;
        this.position = position;
        this.memberCount = memberCount;
        this.city = city;
        this.durationMonths = durationMonths;
    }

}
