package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class FamilyMembersInKkResponse {

    private UUID idMember;
    private String gender;
    private String dateOfBirth;
    private String occupation;
    private String education;
    private Short yearJoined;
    private String major;

    public FamilyMembersInKkResponse(UUID idMember, String gender, String dateOfBirth, String occupation, String education, Short yearJoined, String major) {
        this.idMember = idMember;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.occupation = occupation;
        this.education = education;
        this.yearJoined = yearJoined;
        this.major = major;
    }

}
