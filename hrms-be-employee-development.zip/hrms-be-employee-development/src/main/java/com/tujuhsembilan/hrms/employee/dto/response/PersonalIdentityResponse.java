package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class PersonalIdentityResponse {

    private UUID partyId;
    private String imageUrl;
    private String fullname;
    private String gender;
    private String placeOfBirth;
    private String dateofBirth;
    private String ethnicity;
    private String religion;
    private String bloodType;
    private String maritalStatus;
    private String email;
    private String phoneNumber;
    private EmergencyContactResponse emergencyContact;
    private String background;
    private HomeAddressResponse homeAddress;
    private MotherIdentityResponse motherIdentity;
    private FatherIdentityResponse fatherIdentity;
    private SpouseIdentityResponse spouseIdentity;
    private FamilyOrderResponse familyOrder;
    private List<SiblingsResponse> siblings;
    private List<FamilyMembersInKkResponse> familyMembersInKk;
    private List<EducationHistoryResponse> educationHistory;
    private List<CoursesOrUpgradingResponse> coursesOrUpgrading;
    private List<WorkExperienceResponse> workExperience;
    private List<OrganizationalLifeResponse> organizationalLife;
    private List<EmployeeSportResponse> sports;
    private List<EmployeeArtResponse> art;
    private OtherResponse other;
    private ContractInformationResponse contractInformation;
    private HealthAndFinanceResponse healthAndFinance;
    private List<DocumentEmployeeResponse> documents;
    private List<SocialMediaResponse> socialMedia;

}
