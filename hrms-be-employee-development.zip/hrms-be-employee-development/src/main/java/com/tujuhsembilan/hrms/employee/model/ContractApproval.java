package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RApprovalStatus;
import com.tujuhsembilan.hrms.employee.model.master.RApprovalType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Contract_Approval")
@Table(name = "contract_approval", schema = "public", indexes = {
        @Index(name = "rel_approval_status_fk", columnList = "approval_status_id"),
        @Index(name = "rel_user_approval_fk", columnList = "submitter_id"),
        @Index(name = "rel_approval_type_fk", columnList = "approval_type_id"),
        @Index(name = "rel_approval_contract_fk", columnList = "employee_contract_id")
})
public class ContractApproval implements Serializable {
    private static final long serialVersionUID = -5834504638282843028L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "approval_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "approval_status_id")
    private RApprovalStatus approvalStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "submitter_id")
    private Users submitter;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "approval_type_id")
    private RApprovalType approvalType;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @NotNull
    @Column(name = "submission_date", nullable = false)
    private LocalDateTime submissionDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}