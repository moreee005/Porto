package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class LoginResponse {

    private String accessToken;
    private String role;

}
