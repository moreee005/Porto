package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ContractInfoResponse {

    private String status;
    private String placementType;
    private String employeeType;
    private String bankPlacement;
    private String division;
    private String position;
    private LocalDateTime contractStartDate;
    private LocalDateTime contractEndDate;
    private String generation;
    private String contractDocument;
    private String contractDocumentName;
    private BigDecimal salary;
}
