package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.dto.request.EndRequest;
import com.tujuhsembilan.hrms.employee.dto.request.ExtendContractRequest;
import com.tujuhsembilan.hrms.employee.dto.request.ResignRequest;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.dto.response.MessageResponse;
import com.tujuhsembilan.hrms.employee.service.DataContractService;
import com.tujuhsembilan.hrms.employee.service.EmployeeContractService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(ResourceURL.CONTRACT)
public class DataContractController {

    @Autowired
    DataContractService dataContractService;
    @Autowired
    EmployeeContractService employeeContractService;


    @GetMapping("/employees")
    public ResponseEntity<BaseResponse> searchDataContract(
            @RequestParam(value = "contract", required = false) Integer contract,
            @RequestParam(value = "status", required = false) Integer status,
            @RequestParam(value = "endDate", required = false) String endDate,
            @RequestParam(value = "search", required = false) String search,
            Pageable pageable)  {

        return dataContractService.getDatatableContract(search, contract, status, endDate, pageable);

    }

    @GetMapping("/history-contract/{employee_id}")
    ResponseEntity<BaseResponse> getHistoryEmployeeByIdEmployee(@PathVariable("employee_id") UUID employeeId) {
        return dataContractService.getDataHistoryByEmployeeId(employeeId);
    }

    @GetMapping("/detail/{employee_id}")
    ResponseEntity<BaseResponse> getDataContractByIdEmployee(@PathVariable("employee_id") UUID employeeId) {
        return dataContractService.getDataContractByEmployeeId(employeeId);
    }

    @PostMapping("/detail/{employee_id}/resign")
    ResponseEntity<BaseResponse> resignDataContract(@PathVariable("employee_id") UUID employeeId, @RequestBody ResignRequest request) {
        return dataContractService.createResign(employeeId, request);
    }

    @PostMapping("/employee/{employee_id}/end")
    ResponseEntity<BaseResponse> endDataContract(@PathVariable("employee_id") UUID employeeId, @RequestBody EndRequest request) {
        return dataContractService.createEnd(employeeId, request);
    }

    @PostMapping("/detail/{employee_id}/extend")
    public ResponseEntity<MessageResponse> createExtendContract(
            @PathVariable("employee_id") UUID employeeId,
            @RequestBody ExtendContractRequest request) {
        return employeeContractService.createExtendContract(employeeId, request);

    }


    @PostMapping("/tesemail")
    public ResponseEntity<MessageResponse> createTesemail(@RequestBody ExtendContractRequest request){
        return  employeeContractService.sendEmailForApprovalTask(request);
    }




}
