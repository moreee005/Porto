package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.AddendumBaseSalary;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddendumBaseSalaryRepo extends JpaRepository<AddendumBaseSalary, UUID> {
}
