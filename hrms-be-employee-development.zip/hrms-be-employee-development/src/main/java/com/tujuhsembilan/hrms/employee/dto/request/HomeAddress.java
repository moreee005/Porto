package com.tujuhsembilan.hrms.employee.dto.request;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HomeAddress {
    @NotBlank(message = "Full address is required")
    @Size(min = 10, max = 255, message = "Address must be between 10 and 255 characters")
    private String fullAddress;

    @NotNull(message = "Geographic ID is required")
    @Positive(message = "Geographic ID must be a positive number")
    private Integer geoId;

}
