package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Person_Phone_Number")
@Table(name = "person_phone_number", schema = "public", indexes = {
        @Index(name = "rel_person_phone_fk", columnList = "party_id")
})
public class PersonPhoneNumber implements Serializable {
    private static final long serialVersionUID = 8808540255146033108L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "person_phone_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Person party;

    @Size(max = 20)
    @Column(name = "phone_no", length = 20)
    private String phoneNo;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}