package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@StartYearBeforeEndYearWorkExperience
public class WorkExperienceRequest {

    @NotBlank(message = "Company name is required")
    @Size(max = 100, message = "Company name must not exceed 100 characters")
    private String companyName;

    @NotBlank(message = "Position is required")
    @Size(max = 100, message = "Position must not exceed 100 characters")
    private String position;

    @NotNull(message = "City type is required")
    @Positive(message = "City type must be a positive number")
    private Integer cityType;

    @NotNull(message = "Start year is required")
    @Min(value = 1900, message = "Start year must be at least 1900")
    @Max(value = 2100, message = "Start year must not exceed 2100")
    private Short startYear;

    @NotNull(message = "End year is required")
    @Min(value = 1900, message = "End year must be at least 1900")
    @Max(value = 2100, message = "End year must not exceed 2100")
    private Short endYear;

    @NotNull(message = "Duration in months is required")
    @Min(value = 1, message = "Duration must be at least 1 month")
    @Max(value = 120, message = "Duration must not exceed 120 months")
    private Short durationMonths;
}
