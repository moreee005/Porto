package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RPartyType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Party")
@Table(name = "party", schema = "public", indexes = {
        @Index(name = "rel_party_type_fk", columnList = "party_type_id")
})
public class Party implements Serializable {
    private static final long serialVersionUID = 7407796239478023537L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "party_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_type_id")
    private RPartyType partyType;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @OneToOne(mappedBy = "party")
    private Client client;

    @OneToOne(mappedBy = "party")
    private Employee employee;

    @OneToMany(mappedBy = "party")
    private Set<PartyAddress> partyAddresses = new LinkedHashSet<>();

    @OneToOne(mappedBy = "party")
    private Person person;

}