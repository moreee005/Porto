package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Employee_Metadata")
@Table(name = "employee_metadata", schema = "public", indexes = {
        @Index(name = "rel_employee_metadata_fk", columnList = "party_id")
})
public class EmployeeMetadata implements Serializable {
    private static final long serialVersionUID = 8075979899495169334L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "employee_metadata_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Employee party;

    @Size(max = 50)
    @NotNull
    @Column(name = "key", nullable = false, length = 50)
    private String key;

    @NotNull
    @Column(name = "value", nullable = false, length = Integer.MAX_VALUE)
    private String value;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}