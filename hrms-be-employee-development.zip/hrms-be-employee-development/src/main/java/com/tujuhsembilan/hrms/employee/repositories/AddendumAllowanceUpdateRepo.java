package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.AddendumAllowanceUpdate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddendumAllowanceUpdateRepo extends JpaRepository<AddendumAllowanceUpdate, UUID> {
}
