package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.AddendumAllowanceNew;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddendumAllowanceNewRepo extends JpaRepository<AddendumAllowanceNew, UUID> {
}
