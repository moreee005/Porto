package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class EmployeeDetailResponse {

    private UUID id;
    private String fullName;
    private String division;
    private String contractStatus;
    private String position;

}
