package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.config.LocaleResolverConfig;
import com.tujuhsembilan.hrms.employee.dto.request.LoginRequest;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.service.UsersService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("")
public class AuthController {

    @Autowired
    private UsersService usersService;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private LocaleResolverConfig localeResolverConfig;

    @PostMapping(value = ResourceURL.LOGIN)
    public ResponseEntity<BaseResponse> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpServletRequest) {
        System.out.println(messageSource.getMessage("hello", null, localeResolverConfig.resolveLocale(httpServletRequest)));
        return usersService.login(request);
    }

    @PostMapping(value = ResourceURL.REGISTER)
    public ResponseEntity<BaseResponse> reqister(@RequestBody String request) {
        return null;
    }

    // exception handling for validation
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationException(MethodArgumentNotValidException exception){

        Map<String, String> response = new HashMap<>();

        exception.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = messageSource.getMessage(error, LocaleContextHolder.getLocale());
            response.put(fieldName, errorMessage);
        });

        return response;

    }

}
