package com.tujuhsembilan.hrms.employee.model.log;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Employee_Art_Log")
@Table(name = "employee_art_log", schema = "logging")
public class EmployeeArtLog implements Serializable {
    private static final long serialVersionUID = -3079090486224907960L;
    @Id
    @Column(name = "emp_art_log_id", nullable = false)
    private Integer id;

    @Size(max = 50)
    @Column(name = "record_id", length = 50)
    private String recordId;

    @Size(max = 10)
    @NotNull
    @Column(name = "operation_type", nullable = false, length = 10)
    private String operationType;

    @Column(name = "operation_desc", length = Integer.MAX_VALUE)
    private String operationDesc;

    @Size(max = 50)
    @NotNull
    @Column(name = "changed_by", nullable = false, length = 50)
    private String changedBy;

    @NotNull
    @Column(name = "changed_at", nullable = false)
    private OffsetDateTime changedAt;

}