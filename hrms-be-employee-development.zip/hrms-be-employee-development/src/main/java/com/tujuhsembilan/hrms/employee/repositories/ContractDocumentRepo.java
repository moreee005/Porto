package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.ContractDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ContractDocumentRepo extends JpaRepository<ContractDocument, UUID> {
    @Query(value = """
            select * from contract_document where employee_contract_id in (:id)
            """, nativeQuery = true)
    Optional<ContractDocument> findByEmployeeContractId(@Param("id") UUID id);

    @Query(nativeQuery = true, value = "SELECT * FROM contract_document cd WHERE cd.employee_contract_id = :id ORDER BY cd.upload_date DESC LIMIT 1")
    ContractDocument findByContractId(@Param("id") UUID id);

    @Query(nativeQuery = true, value = "SELECT * FROM contract_document cd WHERE cd.employee_contract_id = :id and doc_type = 'CONTRACT' ORDER BY cd.upload_date DESC LIMIT 1")
    Optional<ContractDocument> findByContractIdAndStatusContract(@Param("id") UUID id);

}
