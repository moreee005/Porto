package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Employee_Resignation")
@Table(name = "employee_resignation", schema = "public", indexes = {
        @Index(name = "rel_emp_resign_fk", columnList = "employee_contract_id")
})
public class EmployeeResignation implements Serializable {
    private static final long serialVersionUID = 5105968623294182971L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "employee_resignation_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @NotNull
    @Column(name = "resign_date", nullable = false)
    private LocalDateTime resignDate;

    @Size(max = 255)
    @Column(name = "remarks")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}