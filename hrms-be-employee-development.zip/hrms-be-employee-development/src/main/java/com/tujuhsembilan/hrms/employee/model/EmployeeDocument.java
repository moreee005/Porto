package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RDocumentType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Employee_Document")
@Table(name = "employee_document", schema = "public", indexes = {
        @Index(name = "rel_employee_doc_fk", columnList = "party_id"),
        @Index(name = "rel_doc_type_fk", columnList = "document_type_id")
})
public class EmployeeDocument implements Serializable {
    private static final long serialVersionUID = -2908884008054780091L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "employee_doc_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Employee party;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "document_type_id")
    private RDocumentType documentType;

    @Size(max = 100)
    @NotNull
    @Column(name = "doc_filename", nullable = false, length = 100)
    private String docFilename;

    @NotNull
    @Column(name = "upload_date", nullable = false)
    private LocalDateTime uploadDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}