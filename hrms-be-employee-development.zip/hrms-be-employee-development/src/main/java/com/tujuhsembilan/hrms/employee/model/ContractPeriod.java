package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RContractType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Contract_Period")
@Table(name = "contract_period", schema = "public", indexes = {
        @Index(name = "rel_ctype_period_fk", columnList = "contract_type_id"),
        @Index(name = "rel_contract_period_fk", columnList = "employee_contract_id")
})
public class ContractPeriod implements Serializable {
    private static final long serialVersionUID = -8642356606888111388L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "contract_period_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "contract_type_id")
    private RContractType contractType;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}