package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountBank {

    @NotNull(message = "Bank type cannot be null")
    private Integer bankType;

    @NotNull(message = "Account number cannot be null")
    @Size(min = 20, max = 20, message = "Account number must be exactly 20 digits long")
    private String accountNumber;
}
