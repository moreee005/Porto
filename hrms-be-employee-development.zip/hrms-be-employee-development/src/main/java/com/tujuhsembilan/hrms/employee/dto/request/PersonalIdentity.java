package com.tujuhsembilan.hrms.employee.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tujuhsembilan.hrms.employee.common.validation.annotation.ValidGender;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PersonalIdentity {

    @NotBlank(message = "Full name is required")
    private String fullName;

    @ValidGender
    @NotNull(message = "Gender is required")
    private Character gender;

    @NotBlank(message = "Place of birth is required")
    private String placeOfBirth;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in the past")
    private LocalDateTime dateOfBirth;

    private Integer ethnicity; // optional

    @NotNull(message = "Religion is required")
    private Integer religion;

    private Integer bloodType; // optional

    @NotNull(message = "Marital status is required")
    private Integer maritalStatus;

    @NotBlank(message = "Email is required")
    @NotNull(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^\\+62\\d{8,15}$", message = "Phone number must start with +62 and be between 8 and 15 digits long")
    private String phoneNumber;

    @Valid
    @NotNull(message = "Emergency contact is required")
    private EmergencyContact emergencyContact;

    private String background; // optional

    @Valid
    @NotNull(message = "Home address is required")
    private HomeAddress homeAddress;

    @Valid
    @NotNull(message = "Mother Identity is required")
    private MotherIdentity motherIdentity;

    @Valid
    @NotNull(message = "Father Identity is required")
    private FatherIdentity fatherIdentity;

    // OPTIONAL
    @Valid
    private SpouseIdentity spouseIdentity;

    @Valid
    private FamilyOrder familyOrder;

    @Valid
    private List<Siblings> siblings;

    @Valid
    private List<FamilyMemberInKK> familyMembersInKk;

    @Valid
    @NotNull(message = "Education History is required")
    private List<EducationHistoryRequest> educationHistory;

    @Valid
    private List<CourseOrUpgrading> courseOrUpgrading;

    @Valid
    private List<WorkExperienceRequest> workExperienceRequest;


    @JsonProperty("organizationExperience")
    @Valid
    private List<OrganizationExperienceRequest> organizationExperienceRequest;

    @Valid
    private List<Sports> sports;

    @Valid
    private List<Arts> arts;

    @Valid
    private OtherRequest otherRequest;
}
