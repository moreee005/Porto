package com.tujuhsembilan.hrms.employee.helpers;

public enum DocumentType {
    PDF("application/pdf", "pdf", new String[]{"application/pdf"}),
    JPEG("image/jpeg", "jpg", new String[]{"image/jpeg", "image/jpg"}),
    PNG("image/png", "png", new String[]{"image/png"}),
    GIF("image/gif", "gif", new String[]{"image/gif"}),
    BMP("image/bmp", "bmp", new String[]{"image/bmp"}),
    WEBP("image/webp", "webp", new String[]{"image/webp"});

    private final String mimeType;
    private final String extension;
    private final String[] allowedMimeTypes;

    DocumentType(String mimeType, String extension, String[] allowedMimeTypes) {
        this.mimeType = mimeType;
        this.extension = extension;
        this.allowedMimeTypes = allowedMimeTypes;
    }

    public String getMimeType() {
        return mimeType;
    }

    public String getExtension() {
        return extension;
    }

    public String[] getAllowedMimeTypes() {
        return allowedMimeTypes;
    }
}