package com.tujuhsembilan.hrms.employee.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExtendContractRequest {
    private UUID employeeId;
    private String fullName;
    private String contractStatus;
    private String placementType;
    private String bankPlacement;
    private String division;
    private String position;
    private String contractStartDate;
    private String contractEndDate;
    private String generation;
    private String contractType;
    private String contractDocument;
    private String contractDocumentName;
    private BigDecimal salary;
    private Integer allowanceTypeId;
    private BigDecimal amount;
    private String jenisKaryawan;

}
