package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SpouseIdentity {

    @NotBlank(message = "Partner name is required")
    @Size(max = 100, message = "Partner name must not exceed 100 characters")
    private String partnerName;


    private LocalDateTime partnerDateOfBirth;

    @NotNull(message = "Highest education ID is required")
    @Positive(message = "Highest education ID must be a positive number")
    private Integer partnerHighestEducation;

    @NotBlank(message = "Occupation is required")
    @Size(max = 50, message = "Occupation must not exceed 50 characters")
    private String partnerOccupation;

    @PositiveOrZero(message = "Salary must be zero or a positive number")
    private Integer salary; // Optional field

    @NotNull(message = "Separate tax status is required")
    private Boolean separateTax;

    @NotBlank(message = "Partner address is required")
    @Size(max = 255, message = "Partner address must not exceed 255 characters")
    private String partnerAddress;

    @NotNull(message = "Geography ID is required")
    @Positive(message = "Geography ID must be a positive number")
    private Integer geoId;
}
