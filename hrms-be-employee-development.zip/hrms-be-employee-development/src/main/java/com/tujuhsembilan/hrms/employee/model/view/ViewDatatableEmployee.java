package com.tujuhsembilan.hrms.employee.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.io.Serializable;
import java.util.UUID;

/**
 * Mapping for DB view
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "View_Datatable_Employee")
@Immutable
@Table(name = "view_datatable_employee", schema = "public")
public class ViewDatatableEmployee implements Serializable {
    private static final long serialVersionUID = -819961184225283736L;
    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @Size(max = 100)
    @Column(name = "photo_filename", length = 100)
    private String photoFilename;

    @Size(max = 100)
    @Column(name = "fullname", length = 100)
    private String fullname;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Size(max = 100)
    @Column(name = "contract_type_name", length = 100)
    private String contractTypeName;

    @Column(name = "position_id")
    private Integer positionId;

    @Size(max = 100)
    @Column(name = "position_name", length = 100)
    private String positionName;

    @Size(max = 100)
    @Column(name = "geography_name", length = 100)
    private String geographyName;

    @Column(name = "placement_type_id")
    private Integer placementTypeId;

    @Size(max = 100)
    @Column(name = "placement_type_name", length = 100)
    private String placementTypeName;

    @Column(name = "date_of_birth_str", length = Integer.MAX_VALUE)
    private String dateOfBirthStr;

    @Column(name = "banking_placement_id")
    private Integer bankingPlacementId;

    @Size(max = 100)
    @Column(name = "banking_placement_name", length = 100)
    private String bankingPlacementName;

    @Column(name = "nip")
    private String nip;

}