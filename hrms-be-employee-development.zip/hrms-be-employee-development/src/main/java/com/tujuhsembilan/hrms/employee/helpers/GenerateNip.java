package com.tujuhsembilan.hrms.employee.helpers;

import lombok.extern.slf4j.Slf4j;

import java.util.Random;

@Slf4j
public class GenerateNip {
    /**
     * Generate NIP berdasarkan aturan:
     * - "Talent" = 01, "Staff" = 02
     * - 4 digit bulan dan tahun kontrak awal (MMYY)
     * - 3 digit indeks berurutan (jumlah total karyawan + 1)
     *
     * @param typeEmployee       tipe employee ("Talent" atau "Staff")
     * @param mm                 bulan kontrak awal (1-12)
     * @param yy                 tahun kontrak awal (2 digit, misal: 24 untuk 2024)
     * @param totalEmployeeCount jumlah total karyawan saat ini
     * @return String            NIP yang ter-generate
     */
    public static String nip(String typeEmployee, Integer mm, Integer yy, Integer totalEmployeeCount) {
        // Validasi input
        if (typeEmployee == null || (!typeEmployee.equalsIgnoreCase("Talent") && !typeEmployee.equalsIgnoreCase("Staff"))) {
            throw new IllegalArgumentException("Type employee harus 'Talent' atau 'Staff'.");
        }

        // 2 digit awal berdasarkan tipe employee
        String typeCode = typeEmployee.equalsIgnoreCase("Talent") ? "01" : "02";

        // Validasi bulan dan tahun
        if (mm < 1 || mm > 12) {
            throw new IllegalArgumentException("Bulan (mm) harus di antara 1 dan 12.");
        }
        if (yy < 0 || yy > 99) {
            throw new IllegalArgumentException("Tahun (yy) harus 2 digit (0-99).");
        }

        // 4 digit bulan dan tahun kontrak awal (format MMYY)
        String monthYear = String.format("%02d%02d", mm, yy);

        // TODO disini masih menggunakan generate yang salah perbaiki di production cukup uncomment index
        // Format the number to always be 3 digits with leading zeros, but avoid 999
        Random random = new Random();
        int randomNumber = random.nextInt(999);
        String index = (randomNumber == 998) ? String.format("%03d", randomNumber - 1) : String.format("%03d", randomNumber);

//        String index = String.format("%03d", totalEmployeeCount + 1);

        log.info(totalEmployeeCount.toString());

        // Gabungkan semua komponen menjadi 9 digit
        log.info(monthYear);
        log.info(index);
        log.info("full " + typeCode + monthYear + index);
        return typeCode + monthYear + index;
    }
}
