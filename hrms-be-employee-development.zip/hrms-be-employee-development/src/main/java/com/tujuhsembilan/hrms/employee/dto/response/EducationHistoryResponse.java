package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class EducationHistoryResponse {

    private String idEducation;
    private String jenjang;
    private String institutionName;
    private String location;
    private Short startDate;
    private String month;
    private Short year;
    private Short endDate;

    public EducationHistoryResponse(String idEducation, String jenjang, String institutionName, String location, Short startDate, String month, Short year, Short endDate) {
        this.idEducation = idEducation;
        this.jenjang = jenjang;
        this.institutionName = institutionName;
        this.location = location;
        this.startDate = startDate;
        this.month = month;
        this.year = year;
        this.endDate = endDate;
    }

}
