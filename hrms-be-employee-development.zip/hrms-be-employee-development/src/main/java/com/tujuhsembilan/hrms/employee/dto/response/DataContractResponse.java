package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class DataContractResponse {

    private EmployeeDetailResponse employeeDetail;
    private ContractInfoResponse contractInfo;
    private List<PlacementAllowanceResponse> placementAllowance;
    private List<OtherAllowanceResponse> otherAllowance;

}
