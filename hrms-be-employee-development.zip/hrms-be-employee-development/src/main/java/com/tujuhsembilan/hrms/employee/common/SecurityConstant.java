package com.tujuhsembilan.hrms.employee.common;

public class SecurityConstant {

    public static final String EMPLOYEE_API = "/employee/**";
    public static final String EMPLOYEE_MANAGEMENT_API = "/employee-management/**";
    public static final String DOCUMENT_API = "/document/**";
    public static final String VIEW_EMPLOYEE_API = "/view-employee/**";
    public static final String DOWNLOAD_API = "/download/**";
    public static final String CONTRACT_API = "/data-contract/**";

    public static final String[] endpoint = {
            EMPLOYEE_MANAGEMENT_API,
            DOCUMENT_API,
            EMPLOYEE_API,
            VIEW_EMPLOYEE_API,
            DOWNLOAD_API,
            CONTRACT_API
    };
}
