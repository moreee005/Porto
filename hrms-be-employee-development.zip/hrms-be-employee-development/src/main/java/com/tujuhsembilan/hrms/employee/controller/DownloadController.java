package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.service.DownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(ResourceURL.DOWNLOAD)
public class DownloadController {

    @Autowired
    DownloadService downloadService;

    @GetMapping
    public ResponseEntity<Object> download(
            @RequestParam(required = false) Integer contract,
            @RequestParam(required = false) Integer position,
            @RequestParam(required = false) Integer placement,
            @RequestParam(required = false) String dateOfBirth,
            @RequestParam(required = false) Integer bankPlacementAgreement,
            @RequestParam String type) {
        return downloadService.downloadDataEmployee(contract, position, placement, dateOfBirth, bankPlacementAgreement, type);
    }
}
