package com.tujuhsembilan.hrms.employee.utils;

import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Objects;

@Slf4j
public class Helper {
    /**
     * Safely converts an object to a string with null checks
     * @param array Input array
     * @param index Index to extract
     * @return String representation or null
     */
    public static String safeToString(Object[] array, int index) {
        return (array != null && index < array.length && array[index] != null)
                ? array[index].toString()
                : null;
    }

    /**
     * Safely converts an object to LocalDateTime with multiple type handling
     * @param array Input array
     * @param index Index to extract
     * @return LocalDateTime or null
     */
    public static LocalDateTime safeToLocalDateTime(Object[] array, int index) {
        // Null checks
        if (array == null || index >= array.length || array[index] == null) {
            return null;
        }

        Object dateObj = array[index];

        try {
            // Handle different date types
            if (dateObj instanceof LocalDateTime) {
                return (LocalDateTime) dateObj;
            }
            // Handle java.sql.Date
            if (dateObj instanceof java.sql.Date) {
                return ((java.sql.Date) dateObj).toLocalDate().atStartOfDay();
            }

            if (dateObj instanceof java.util.Date) {
                return ((java.util.Date) dateObj)
                        .toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDateTime();
            }

            // Attempt string parsing
            if (dateObj instanceof String) {
                try {
                    return LocalDateTime.parse(dateObj.toString());
                } catch (Exception e) {
                    log.warn("Could not parse date: {}", dateObj);
                }
            }

            log.warn("Unsupported date type: {}", dateObj.getClass());
            return null;
        } catch (Exception e) {
            log.error("Unexpected error converting date", e);
            return null;
        }
    }

    /**
     * Safely converts an object to a specific type
     * @param obj Input object
     * @param defaultValue Default value if conversion fails
     * @param <T> Type to convert to
     * @return Converted value or default value
     */
    public static <T> T safeCast(Object obj, T defaultValue) {
        try {
            return obj != null ? (T) obj : defaultValue;
        } catch (ClassCastException e) {
            log.warn("Failed to cast object: {}", obj, e);
            return defaultValue;
        }
    }

    /**
     * Safely get a value from an array with type checking
     * @param array Input array
     * @param index Index to extract
     * @param defaultValue Default value if extraction fails
     * @param <T> Type to convert to
     * @return Extracted value or default value
     */
    public static <T> T safeGet(Object[] array, int index, T defaultValue) {
        if (array == null || index < 0 || index >= array.length || array[index] == null) {
            return defaultValue;
        }

        try {
            return (T) array[index];
        } catch (ClassCastException e) {
            log.warn("Failed to cast array element at index {}", index, e);
            return defaultValue;
        }
    }

    /**
     * Provides a null-safe toString method
     * @param obj Input object
     * @return String representation or empty string
     */
    public static String nullSafeToString(Object obj) {
        return Objects.toString(obj, "");
    }
}