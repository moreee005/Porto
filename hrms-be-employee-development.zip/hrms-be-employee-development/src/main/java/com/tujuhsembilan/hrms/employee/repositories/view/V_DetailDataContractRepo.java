package com.tujuhsembilan.hrms.employee.repositories.view;


import com.tujuhsembilan.hrms.employee.model.view.ViewDetailDataKontrak;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface V_DetailDataContractRepo extends JpaRepository<ViewDetailDataKontrak, UUID> {
}
