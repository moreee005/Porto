package com.tujuhsembilan.hrms.employee.helpers;

import com.tujuhsembilan.hrms.employee.config.TikaConfiguration;
import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.mime.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.function.Predicate;

@Component
@RequiredArgsConstructor
@Slf4j
public class FileValidator {
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

    private final TikaConfiguration.MediaTypeDetector mediaTypeDetector;

    private static final Map<DocumentType,
            Predicate<byte[]>> STRUCTURE_VALIDATORS = Map.of(DocumentType.PDF,
            bytes
                    -> bytes.length >= 5 && bytes[0] == '%' && bytes[1] == 'P'
                    && bytes[2] == 'D' && bytes[3] == 'F' && bytes[4] == '-',

            DocumentType.JPEG,
            bytes
                    -> bytes.length >= 10 && bytes[0] == (byte) 0xFF
                    && bytes[1] == (byte) 0xD8 && bytes[bytes.length - 2] == (byte) 0xFF
                    && bytes[bytes.length - 1] == (byte) 0xD9,

            DocumentType.PNG,
            bytes
                    -> bytes.length >= 8 && bytes[0] == (byte) 0x89 && bytes[1] == (byte) 0x50
                    && bytes[2] == (byte) 0x4E && bytes[3] == (byte) 0x47
                    && bytes[4] == (byte) 0x0D && bytes[5] == (byte) 0x0A
                    && bytes[6] == (byte) 0x1A && bytes[7] == (byte) 0x0A);

    public void validate(MultipartFile file, DocumentType expectedType) {
        validateFileSize(file);
        validateFileType(file, expectedType);
        validateFileStructure(file, expectedType);
    }

    private void validateFileSize(MultipartFile file) {
        if (file.isEmpty()) {
            log.error("File is empty");
            throw new BadRequestException("File is empty");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            log.error("File exceeds maximum size of 10MB: size = {}", file.getSize());
            throw new BadRequestException("File exceeds maximum size of 10MB");
        }
    }

    private void validateFileType(MultipartFile file, DocumentType expectedType) {
        MediaType detectedType = mediaTypeDetector.detect(file);
        log.info("Detected file type: {}", detectedType);

        boolean isValidType =
                Arrays.stream(expectedType.getAllowedMimeTypes())
                        .anyMatch(
                                allowedType -> detectedType.toString().startsWith(allowedType));

        if (!isValidType) {
            log.error("Invalid file type. Expected: {}, Got: {}", expectedType,
                    detectedType);
            throw new BadRequestException(
                    String.format("Invalid file type. Expected %s, got %s", expectedType,
                            detectedType));
        }
    }

    private void validateFileStructure(
            MultipartFile file, DocumentType documentType) {
        try {
            byte[] fileBytes = file.getBytes();
            log.info("Validating file structure for type: {}", documentType);

            Predicate<byte[]> structureValidator =
                    STRUCTURE_VALIDATORS.get(documentType);

            if (structureValidator == null) {
                log.info("No structure validator available for document type: {}",
                        documentType);
                return;
            }

            if (!structureValidator.test(fileBytes)) {
                log.error("Invalid structure for file type: {}", documentType);
                throw new BadRequestException("Invalid " + documentType + " structure");
            }
        } catch (IOException e) {
            log.error("Error reading file bytes for structure validation: {}",
                    e.getMessage());
            throw new BadRequestException("File structure validation failed");
        }
    }

    public DocumentType determineImageType(MultipartFile file) {
        MediaType detectedType = mediaTypeDetector.detect(file);
        log.info("Determined image type: {}", detectedType);

        return switch (detectedType.toString()) {
            case "image/jpeg" -> DocumentType.JPEG;
            case "image/png" -> DocumentType.PNG;
            case "image/gif" -> DocumentType.GIF;
            case "image/webp" -> DocumentType.WEBP;
            case "image/bmp" -> DocumentType.BMP;
            default -> {
                log.error("Unsupported image type detected: {}", detectedType);
                throw new BadRequestException("Unsupported image type");
            }
        };
    }

}