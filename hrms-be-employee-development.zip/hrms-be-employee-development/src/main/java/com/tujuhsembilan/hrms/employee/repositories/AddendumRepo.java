package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.Addendum;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddendumRepo extends JpaRepository<Addendum, UUID> {
}
