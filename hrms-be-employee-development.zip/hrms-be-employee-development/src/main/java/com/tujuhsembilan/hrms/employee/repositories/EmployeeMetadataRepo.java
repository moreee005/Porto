package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.EmployeeMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeMetadataRepo extends JpaRepository<EmployeeMetadata, UUID> {

    @Query("SELECT em FROM Employee_Metadata em WHERE em.party.id = :partyId AND em.deletedAt is null")
    List<EmployeeMetadata> findByPartyId(@Param("partyId") UUID partyId);

}
