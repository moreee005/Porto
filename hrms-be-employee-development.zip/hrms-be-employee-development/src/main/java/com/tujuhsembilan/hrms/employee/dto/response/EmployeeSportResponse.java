package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class EmployeeSportResponse {

    private String name;
    private Boolean isActive;

    public EmployeeSportResponse(String name, Boolean isActive) {
        this.name = name;
        this.isActive = isActive;
    }

}
