package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.constant.ContractStatusEnum;
import com.tujuhsembilan.hrms.employee.dto.response.*;
import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.helpers.Response;
import com.tujuhsembilan.hrms.employee.model.*;
import com.tujuhsembilan.hrms.employee.model.view.ViewDatatableEmployee;
import com.tujuhsembilan.hrms.employee.repositories.*;
import com.tujuhsembilan.hrms.employee.repositories.master.RBankingPlacementRepo;
import com.tujuhsembilan.hrms.employee.repositories.master.RPtkpStatusRepo;
import com.tujuhsembilan.hrms.employee.repositories.view.ViewDatatableEmployeeRepo;
import com.tujuhsembilan.hrms.employee.repositories.view.ViewEmergencyContactRepo;
import com.tujuhsembilan.hrms.employee.utils.DateUtils;
import lib.minio.MinioSrvc;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmployeeService {
    @Autowired
    private ViewDatatableEmployeeRepo viewDatatableEmployeeRepo;
    @Autowired
    private EmployeeRepo employeeRepo;
    @Autowired
    private PersonRepo personRepo;
    @Autowired
    private PersonPhoneNumberRepo personPhoneNumberRepo;
    @Autowired
    private PartyAddressRepo partyAddressRepo;
    @Autowired
    private EducationHistoryRepo educationHistoryRepo;
    @Autowired
    private EmployeeCourseRepo employeeCourseRepo;
    @Autowired
    private WorkExperienceRepo workExperienceRepo;
    @Autowired
    private OrganizationExperienceRepo organizationExperienceRepo;
    @Autowired
    private EmployeeArtRepo employeeArtRepo;
    @Autowired
    private EmployeeSportRepo employeeSportRepo;
    @Autowired
    private EmployeeMetadataRepo employeeMetadataRepo;
    @Autowired
    private RBankingPlacementRepo bankPlacementRepo;
    @Autowired
    private RPtkpStatusRepo ptkpStatusRepo;
    @Autowired
    private ContractDocumentRepo contractDocumentRepo;
    @Autowired
    private EmployeeContractService employeeContractService;
    @Autowired
    private ViewEmergencyContactRepo viewEmergencyContactRepo;
    @Autowired
    PersonRelationshipRepo personRelationshipRepo;
    @Autowired
    MinioSrvc minioSrvc;
    @Value("${bucket.minio}")
    private String BUCKET_MINIO;
    @Value("${minio.base.url}")
    String minioBaseUrl;

    public ResponseEntity<BaseResponse> getDatatableEmployee(
            String search, Integer contract, Integer position, Integer placement, String dateOfBirth, Integer bankPlacementAgreement, Pageable pageable)  {
        Page<ViewDatatableEmployee> viewDatatableEmployeePage = viewDatatableEmployeeRepo.datatableEmployeeByFilter(search, contract, position, placement, dateOfBirth, bankPlacementAgreement, pageable);
        if (viewDatatableEmployeePage.hasContent()) {
            DataTableResponse dataTableResponse = new DataTableResponse();
            dataTableResponse.setRecordsTotal(viewDatatableEmployeeRepo.count());
            dataTableResponse.setRecordsFiltered(viewDatatableEmployeePage.getTotalElements());
            dataTableResponse.setData(viewDatatableEmployeePage.getContent());
            return Response.success(dataTableResponse);
        }
        return Response.success(new BaseResponse());
    }

    public ResponseEntity<BaseResponse> getDetailByEmployeeById(UUID id)  {
        Optional<Employee> employeeCheck = employeeRepo.findById(id);
        if (employeeCheck.isPresent()) {
            var employee = employeeCheck.get();
            PersonalIdentityResponse response = new PersonalIdentityResponse();
            response.setPartyId(id);
            response.setImageUrl(employee.getPhotoFilename());
            Optional<Person> person = personRepo.findById(id);
            person.ifPresent(p -> {
                response.setFullname(p.getFullname());
                response.setGender(p.getGender().toString());
                response.setDateofBirth(p.getDateOfBirth().toString());
            });
            response.setPlaceOfBirth(employee.getPlaceOfBirth());
            response.setEthnicity(employee.getEthnicity().getName());
            response.setReligion(employee.getReligion().getName());
            response.setBloodType(employee.getBloodType().getBloodType());
            response.setMaritalStatus(employee.getMaritalStatus().getName());
            response.setEmail(employee.getEmail());
            response.setPhoneNumber(employee.getPrimaryPhoneNo());

            response.setEmergencyContact(new EmergencyContactResponse(
                    employee.getEmergencyContactName(),
                    employee.getPrimaryPhoneNo(),
                    employee.getEmergencyContactRelation().getName()));
            response.setBackground(employee.getBackground());

            Optional<PartyAddress> partyAddress = partyAddressRepo.findByPartyId(id);
            partyAddress.ifPresent(p -> {
                response.setHomeAddress(new HomeAddressResponse(
                        p.getAddress(),
                        p.getGeography().getProvince(),
                        p.getGeography().getCity(),
                        p.getGeography().getDistrict(),
                        p.getGeography().getSubdistrict(),
                        p.getGeography().getPostalCode()
                ));
            });

            List<SiblingsResponse> siblings = new ArrayList<>();
            List<FamilyMembersInKkResponse> familyMembersInKk = new ArrayList<>();
            List<PersonRelationship> personRelationships = personRelationshipRepo.findByPartyId(id);
            personRelationships.forEach(personRelationship -> {
                Optional<Person> getPerson = personRepo.findById(personRelationship.getRelatedParty().getId());
                Optional<PersonPhoneNumber> getPersonPhone = personPhoneNumberRepo.findByPartyId(id);
                Optional<PartyAddress> partyAddressParent = partyAddressRepo.findByPartyId(personRelationship.getRelatedParty().getId());

                getPerson.ifPresent(p -> {
                    List<EducationHistory> educationHistories = educationHistoryRepo.findByPartyId(p.getParty().getId());
                    familyMembersInKk.add(new FamilyMembersInKkResponse(
                            p.getParty().getId(),
                            p.getGender().toString(),
                            p.getDateOfBirth().toString(),
                            personRelationship.getOccupation(),
                            educationHistories == null ? educationHistories.get(0).getUniversityName() : null,
                            educationHistories == null ? educationHistories.get(0).getAdmissionYear() : null,
                            educationHistories == null ? educationHistories.get(0).getMajor().getName() : null
                    ));

                    String phoneNo = getPersonPhone.map(PersonPhoneNumber::getPhoneNo).orElse(null);
                    String address = partyAddressParent.map(PartyAddress::getAddress).orElse(null);
                    String province = partyAddressParent.map(pa -> pa.getGeography().getProvince()).orElse(null);
                    String city = partyAddressParent.map(pa -> pa.getGeography().getCity()).orElse(null);
                    String district = partyAddressParent.map(pa -> pa.getGeography().getDistrict()).orElse(null);
                    String subdistrict = partyAddressParent.map(pa -> pa.getGeography().getSubdistrict()).orElse(null);
                    String postalCode = partyAddressParent.map(pa -> pa.getGeography().getPostalCode()).orElse(null);
                    switch (personRelationship.getRelationshipType().getId()) {
                        case 1:
                            response.setFatherIdentity(new FatherIdentityResponse(
                                    p.getFullname(),
                                    p.getDateOfBirth().toString(),
                                    p.getEducation().getName(),
                                    personRelationship.getOccupation(),
                                    personRelationship.getRangeSalary().getSalary(),
                                    phoneNo,
                                    personRelationship.getIsAlive() ? "Hidup" : "Meninggal",
                                    address,
                                    province,
                                    city,
                                    district,
                                    subdistrict,
                                    postalCode
                            ));
                            break;
                        case 2:
                            response.setMotherIdentity(new MotherIdentityResponse(
                                    p.getFullname(),
                                    p.getDateOfBirth().toString(),
                                    p.getEducation().getName(),
                                    personRelationship.getOccupation(),
                                    personRelationship.getRangeSalary().getSalary(),
                                    phoneNo,
                                    personRelationship.getIsAlive() ? "Hidup" : "Meninggal",
                                    address
                            ));
                            break;
                        case 3:
                            siblings.add(new SiblingsResponse(
                                    p.getParty().getId().toString(),
                                    p.getGender().toString(),
                                    p.getDateOfBirth().toString(),
                                    personRelationship.getOccupation(),
                                    p.getEducation().getName()
                            ));
                            break;
                        case 4:
                            LocalDateTime dateOfBirthLocalDateTime = p.getDateOfBirth().toInstant(null).atZone(ZoneId.systemDefault()).toLocalDateTime();
                            int age = Period.between(dateOfBirthLocalDateTime.toLocalDate(), LocalDateTime.now().toLocalDate()).getYears();
                            response.setSpouseIdentity(new SpouseIdentityResponse(
                                    p.getFullname(),
                                    String.valueOf(age),
                                    p.getEducation().getName(),
                                    personRelationship.getOccupation(),
                                    personRelationship.getRangeSalary().getSalary(),
                                    personRelationship.getIsSplitTax(),
                                    address
                            ));
                            break;
                    }
                });
            });

            response.setSiblings(siblings);
            response.setFamilyMembersInKk(familyMembersInKk);

            List<EducationHistoryResponse> educationHistoryResponses = educationHistoryRepo.findByPartyId(id).stream()
                    .map(educationHistory -> new EducationHistoryResponse(
                            educationHistory.getEducation().getId().toString(),
                            educationHistory.getEducation().getName(),
                            educationHistory.getUniversityName(),
                            educationHistory.getCity().getCity(),
                            educationHistory.getAdmissionYear(), // start date sekarang cuma disimpan tahunnya
                            "", // belum ada
                            educationHistory.getAdmissionYear(),
                            educationHistory.getGraduationYear()
                    ))
                    .collect(Collectors.toList());
            response.setEducationHistory(educationHistoryResponses);

            List<CoursesOrUpgradingResponse> coursesOrUpgradingResponses = employeeCourseRepo.findByPartyId(id).stream()
                    .map(employeeCourse -> new CoursesOrUpgradingResponse(
                            employeeCourse.getId(),
                            employeeCourse.getCourseType().getName(),
                            employeeCourse.getName(),
                            employeeCourse.getCity().getCity(),
                            employeeCourse.getDay(),
                            employeeCourse.getMonth(),
                            employeeCourse.getYear(),
                            employeeCourse.getDuration(),
                            employeeCourse.getIssuer(),
                            employeeCourse.getCourseNo()))
                    .collect(Collectors.toList());
            response.setCoursesOrUpgrading(coursesOrUpgradingResponses);

            List<WorkExperienceResponse> workExperienceResponse = workExperienceRepo.findByPartyId(id).stream()
                    .map(workExperience -> new WorkExperienceResponse(
                            workExperience.getId(),
                            workExperience.getName(),
                            workExperience.getPosition(),
                            workExperience.getCity().getCity(),
                            workExperience.getStartYear(),
                            workExperience.getEndYear(),
                            workExperience.getDuration()))
                    .collect(Collectors.toList());
            response.setWorkExperience(workExperienceResponse);

            List<OrganizationalLifeResponse> organizationalLife = organizationExperienceRepo.findByPartyId(id).stream()
                    .map(organizationExperience -> new OrganizationalLifeResponse(
                            organizationExperience.getId(),
                            organizationExperience.getName(),
                            organizationExperience.getStartYear(),
                            organizationExperience.getPosition(),
                            organizationExperience.getMemberRange(),
                            organizationExperience.getCity().getCity(),
                            organizationExperience.getDuration()
                    ))
                    .collect(Collectors.toList());
            response.setOrganizationalLife(organizationalLife);

            List<EmployeeSportResponse> sportList = employeeSportRepo.findByPartyId(id).stream()
                    .map(employeeSport -> new EmployeeSportResponse(
                            employeeSport.getSport().getName(),
                            employeeSport.getIsActive()
                    ))
                    .collect(Collectors.toList());
            response.setSports(sportList);

            List<EmployeeArtResponse> artList = employeeArtRepo.findByPartyId(id).stream()
                    .map(employeeArt -> new EmployeeArtResponse(
                            employeeArt.getArt().getName(),
                            employeeArt.getIsActive()
                    ))
                    .collect(Collectors.toList());
            response.setArt(artList);

            List<EmployeeMetadata> metadataList = employeeMetadataRepo.findByPartyId(id);
            List<String> foreignLanguageProficiency = metadataList.stream()
                    .filter(metadata -> "foreign_language".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .collect(Collectors.toList());
            List<String> hobbies = metadataList.stream()
                    .filter(metadata -> "hobby".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .collect(Collectors.toList());
//            List<String> careerInterests = metadataList.stream()
//                    .filter(metadata -> "career_interest".equals(metadata.getKey()))
//                    .map(EmployeeMetadata::getValue)
//                    .collect(Collectors.toList());
            OtherResponse otherResponse = new OtherResponse();
            otherResponse.setForeignLanguageProficiency(foreignLanguageProficiency);
            otherResponse.setHobbies(hobbies);
//            otherResponse.setCareerInterests(careerInterests);
            response.setOther(otherResponse);


            String childNumber = metadataList.stream()
                    .filter(metadata -> "child_no".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .findFirst()
                    .orElse(null);
            String totalSiblings = metadataList.stream()
                    .filter(metadata -> "siblings".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .findFirst()
                    .orElse(null);
            response.setFamilyOrder(new FamilyOrderResponse(childNumber, totalSiblings));

            // get contract information
            var contract = employee.getEmployeeContracts().stream()
                    .filter(x -> x.getContractStatus().getId() == ContractStatusEnum.ACTIVE.getStatus()).findFirst().orElse(null);
            if(contract == null) return Response.notFound();
            var contractInfo = new ContractInformationResponse();
            contractInfo.setStatusName(contract.getContractType().getName());
            contractInfo.setPlacementTypeName(employee.getPlacementType() != null ? employee.getPlacementType().getName() : "");
            contractInfo.setEmployeTypeName(""); //todo: cari tau dari mana
            contractInfo.setWillingToBePlaceInBankOrInsurance( employee.getBankingPlacement() != null ? employee.getBankingPlacement().getName() : "");
            contractInfo.setDivisionName(employee.getDivision() != null ? employee.getDivision().getName() : "");
            contractInfo.setJobPositionName(employee.getPosition() != null ? employee.getPosition().getName() : "");
            DateUtils dateUtils = new DateUtils();
            contractInfo.setContractStartDate(dateUtils.convertLocalDateTimeFormat1(contract.getStartDate()));
            contractInfo.setContractEndDate(dateUtils.convertLocalDateTimeFormat1(contract.getEndDate()));
            var document = contractDocumentRepo.findByEmployeeContractId(contract.getId()).orElse(null);
            if(document != null) {
                contractInfo.setContractDocument(ContractDocumentResponse.builder()
                        .documentName(document.getDocFilename())
                        .documentUrl(minioSrvc.getLink(BUCKET_MINIO, employee.getNik() + "/" + document.getDocFilename(), minioSrvc.getDefaultExpiry()))
                        .build());
            }
            contractInfo.setGeneration(employee.getGeneration());
            contractInfo.setBaseSalary(contract.getCurrentSalary());
            var allowances = employeeContractService.getEmployeeAllowanceByContractId(contract.getId());
            contractInfo.setAllowances(allowances);
            response.setContractInformation(contractInfo);

            // get data kependudukan
            var healthAndFinance = HealthAndFinanceResponse.builder()
                    .nik(employee.getNik())
                    .npwp(employee.getNpwp())
                    .ptkpStatus(employee.getPtkpStatus().getName())
                    .bpjsNumber(employee.getBpjsNo())
                    .bpjsClass(employee.getBpjsClass())
                    .employmentBpjsNumber(employee.getBpjsTkNo())
                    .bankName(employee.getBank().getShortName())
                    .accountNumber(employee.getBankAccountNo())
                    .build();
            response.setHealthAndFinance(healthAndFinance);

            // get employee document
            var empDocument = employee.getEmployeeDocuments();
            List<DocumentEmployeeResponse> documentEmployees = new ArrayList<>();
            empDocument.forEach(x -> {
                var doc = new DocumentEmployeeResponse();
                doc.setDocumentId(x.getId().toString());
                doc.setDocumentType(x.getDocumentType().getName());
                doc.setDocumentName(x.getDocFilename());
                doc.setDocumentUrl(minioSrvc.getLink(BUCKET_MINIO, employee.getNik() + "/" + x.getDocFilename(), minioSrvc.getDefaultExpiry()));
                documentEmployees.add(doc);
            });
            response.setDocuments(documentEmployees);

            // social media
            var empSocialMedia = employee.getSocialMedias();
            List<SocialMediaResponse> socialMediaResponses = new ArrayList<>();
            empSocialMedia.forEach(x -> {
                var soc = new SocialMediaResponse();
                soc.setSocialMediaType(x.getSocialMedia().getName());
                soc.setSocialMediaLink(x.getLink());
                socialMediaResponses.add(soc);
            });
            response.setSocialMedia(socialMediaResponses);

            return Response.success(response);
        }
        return Response.notFound();
    }

    public Employee findEmployeeByEmail(String email) {
        try {
            log.debug("email adalah " + email);
            Optional<Employee> employeeOptional = employeeRepo.findByEmailAndDeletedAtNull(email);
            if (employeeOptional.isEmpty()) {
                log.info("employee not found");
                throw new BadRequestException();
            }
            return employeeOptional.get();
        } catch (Exception e) {
            log.error("failed save Employee err : " + e.getMessage());
            throw new InternalServerErrorException();
        }
    }

    public Boolean saveEmployeeData(Employee employee) {
        try {
            employeeRepo.save(employee);
            return true;
        } catch (Exception e) {
            log.error("error save data employee " + e.getMessage());
            throw new InternalServerErrorException();
        }
    }
}
