package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.EmployeeAllowance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeAllowanceRepo extends JpaRepository<EmployeeAllowance, UUID> {

    @Query(value = """
            select * from employee_allowance where employee_contract_id in (:id)
            """, nativeQuery = true)
    List<EmployeeAllowance> findByEmployeeContractId(@Param("id") UUID id);

    @Query(nativeQuery = true, value =
            "SELECT " +
                    "ea.employee_allowance_id AS allowanceId, " +
                    "rat.name AS allowanceType, " +
                    "ea.amount AS nominal " +
                    "FROM employee_contract ec " +
                    "JOIN employee_allowance ea ON ec.employee_contract_id = ea.employee_contract_id " +
                    "JOIN master.r_allowance_type rat ON ea.allowance_type_id = rat.allowance_type_id " +
                    "JOIN employee e ON ec.party_id = e.party_id " +
                    "WHERE e.party_id = :employeeId")
    List<Object[]> fetchAllowances(@Param("employeeId") UUID employeeId);

    @Query(nativeQuery = true ,value = "SELECT * FROM employee_allowance ea WHERE ea.employee_contract_id = :id")
    List<EmployeeAllowance> findByEmployeeId(@Param("id") UUID employeeId);
}
