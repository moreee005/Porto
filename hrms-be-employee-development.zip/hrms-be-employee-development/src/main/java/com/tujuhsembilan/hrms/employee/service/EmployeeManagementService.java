package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.constant.Constant;
import com.tujuhsembilan.hrms.employee.constant.RPartyTypeEnum;
import com.tujuhsembilan.hrms.employee.constant.RRelationshipTypeEnum;
import com.tujuhsembilan.hrms.employee.dto.request.*;
import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.helpers.DetermineGender;
import com.tujuhsembilan.hrms.employee.helpers.GenerateNip;
import com.tujuhsembilan.hrms.employee.model.EducationHistory;
import com.tujuhsembilan.hrms.employee.model.*;
import com.tujuhsembilan.hrms.employee.model.master.*;
import com.tujuhsembilan.hrms.employee.repositories.*;
import com.tujuhsembilan.hrms.employee.repositories.master.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmployeeManagementService {
    private final EmployeeRepo employeeRepo;
    private final MessageSource messageSource;
    private final UsersRepo usersRepo;
    private final REducationRepo rEducationRepo;
    private final RBloodTypeRepo rBloodTypeRepo;
    private final REmergencyContactRelationRepo rEmergencyContactRelationRepo;
    private final RMaritalStatusRepo rMaritalStatusRepo;
    private final RGeographyRepo rGeographyRepo;
    private final RMajorRepo rMajorRepo;
    private final PersonRepo personRepo;
    private final EducationHistoryRepo educationHistoryRepo;
    private final PartyAddressRepo partyAddressRepository;
    private final RPositionRepo rPositionRepo;
    private final RPtkpStatusRepo rPtkpStatusRepo;
    private final RBankingPlacementRepo rBankingPlacementRepo;
    private final RReligionRepo rReligionRepo;
    private final RPlacementTypeRepo rPlacementType;
    private final RDivisionRepo rDivisionRepo;
    private final RBankRepo rBankRepo;
    private final RRelationshipTypeRepo rRelationshipTypeRepo;
    private final RPartyTypeRepo rPartyTypeRepo;
    private final PartyRepo partyRepo;
    private final RContractStatusRepo rContractStatusRepo;
    private final RContractTypeRepo rContractTypeRepo;
    private final EmployeeAllowanceRepo employeeAllowanceRepo;
    private final RAllowanceTypeRepo rAllowanceTypeRepo;
    private final RCourseTypeRepo rCourseTypeRepo;
    private final EmployeeCourseRepo employeeCourseRepo;
    private final WorkExperienceRepo workExperienceRepo;
    private final OrganizationExperienceRepo organizationExperienceRepo;
    private final EmployeeSportRepo employeeSportRepo;
    private final RsportRepo rsportRepo;
    private final RArtRepo rArtRepo;
    private final EmployeeArtRepo employeeArtRepo;
    private final EmployeeMetadatumRepo employeeMetadatumRepo;
    private final EmployeeContractRepo employeeContractRepo;
    private final HistoricEmployeeContractRepo historicEmployeeContractRepo;
    private final HistoricEmployeeRepo historicEmployeeRepo;
    private final RSocialMediaRepo rSocialMediaRepo;
    private final EmployeeSocialMediaRepo employeeSocialMediaRepo;
    private final PersonRelationshipRepo personRelationShipRepo;
    private final PersonPhoneNumberRepo personPhoneNumberRepo;
    private final RRangeSalaryRepo rRangeSalaryRepo;
    private final TalentRepo talentRepo;
    private final REthnicityRepo rEthnicityRepo;
    private final ProcessInstanceRepo processInstanceRepo;
    private final ProcessDefinitionRepo processDefinitionRepo;
    private final ProcessTaskRepo processTaskRepo;

    @Transactional
    public String addEmployeeToApproval(EmployeeAddRequest request) {
        //        TODO REFACTORING ( jika ada waktu )
        //        1. bisa tiap repo tiap service
        //        2. untuk insert data yang list itu bisa dibuat method/fungsi
        //        sendiri agar efisien
        //        3. Unutuk menghindari pengecekan yang banyak ke database mungkin
        //        yang master bisa dibuat enum dan menambahkan method disitu untuk
        //        pengecekan idnya secara program

        Authentication authentication =
                SecurityContextHolder.getContext().getAuthentication();
        Object principal = authentication.getPrincipal();
        String username = null;
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
            log.info("Username from Principal: " + username);
        } else {
            log.warn("Principal does not contain valid user details.");
        }
        log.info("Starting process to save personal identity");

        // Email must be unique
        Optional<Employee> employeeOptional =
                employeeRepo.findByEmailAndDeletedAtNull(
                        request.getPersonalIdentity().getEmail());
        if (employeeOptional.isPresent()) {
            throw new BadRequestException(messageSource.getMessage(
                    "employee.email.unique.error", null, Locale.getDefault()));
        }

        Optional<Users> usersOptional = usersRepo.findByEmail(username);
        if (usersOptional.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "user.not.found.error", null, Locale.getDefault()));
        }

        // Get latest education history
        List<EducationHistoryRequest> educationHistoryList =
                request.getPersonalIdentity().getEducationHistory();
        EducationHistoryRequest latestEducationHistory =
                educationHistoryList.stream()
                        .max(Comparator.comparingInt(EducationHistoryRequest::getYearEnd))
                        .orElseThrow(
                                ()
                                        -> new BadRequestException(messageSource.getMessage(
                                        "education.history.not.found.error", null,
                                        Locale.getDefault())));

        Optional<REducation> rEducationOptional = rEducationRepo.findById(
                latestEducationHistory.getHighestEducationLevelType());
        if (rEducationOptional.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "education.not.found.error", null, Locale.getDefault()));
        }

        // Create party
        Optional<RPartyType> rPartyTypeEmployeeOptional =
                rPartyTypeRepo.findById(RPartyTypeEnum.TALENT.getId());
        Party party =
                Party.builder().partyType(rPartyTypeEmployeeOptional.get()).build();

        try {
            party = partyRepo.saveAndFlush(party);
            log.info(
                    "Party for employee created successfully with ID: {}", party.getId());
        } catch (Exception e) {
            log.error("Failed to save Party for employee", e);
            throw new InternalServerErrorException(messageSource.getMessage(
                    "party.save.error", null, Locale.getDefault()));
        }

        // Save person
        Person person =
                Person.builder()
                        .party(party)
                        .education(rEducationOptional.get())
                        .fullname(request.getPersonalIdentity().getFullName())
                        .dateOfBirth(request.getPersonalIdentity().getDateOfBirth())
                        .gender(request.getPersonalIdentity().getGender())
                        .graduationYear(latestEducationHistory.getYearEnd())
                        .build();

        try {
            personRepo.save(person);
            log.info("Person saved successfully");
        } catch (Exception e) {
            log.error("Failed to save person: {}", e.getMessage());
            throw new InternalServerErrorException(messageSource.getMessage(
                    "person.save.error", null, Locale.getDefault()));
        }

        // Emergency contact relation validation
        Optional<REmergencyContactRelation> rEmergencyContactRelationOptional =
                rEmergencyContactRelationRepo.findById(request.getPersonalIdentity()
                        .getEmergencyContact()
                        .getRelationship());
        if (rEmergencyContactRelationOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "emergency.contact.not.found.error", null, Locale.getDefault()));
        }

        // Blood type validation
        Optional<RBloodType> rBloodTypeOptional =
                request.getPersonalIdentity() != null
                        ? rBloodTypeRepo.findById(request.getPersonalIdentity().getBloodType())
                        : Optional.empty();
        if (rBloodTypeOptional.isEmpty() && request.getPersonalIdentity() != null
                && request.getPersonalIdentity().getBloodType() != null) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "blood.type.not.found.error", null, Locale.getDefault()));
        }

        // Marital status validation
        Optional<RMaritalStatus> rMaritalStatusOptional =
                rMaritalStatusRepo.findById(
                        request.getPersonalIdentity().getMaritalStatus());
        if (rMaritalStatusOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "marital.status.not.found.error", null, Locale.getDefault()));
        }

        // Position validation
        Optional<RPosition> rPositionOptional =
                rPositionRepo.findById(request.getContractInformation()
                        .getContractInformationDetails()
                        .getPositionType());
        if (rPositionOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "position.not.found.error", null, Locale.getDefault()));
        }

        // Find PTKP Status
        Optional<RPtkpStatus> rPtkpStatusOptional = rPtkpStatusRepo.findById(
                request.getCivilRegistrationData().getCivilData().getStatusPtkp());
        if (rPtkpStatusOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "marital.status.not.found.error", null, Locale.getDefault()));
        }

        // Find Banking Placement
        Optional<RBankingPlacement> rBankingPlacementOptional =
                rBankingPlacementRepo.findById(request.getContractInformation()
                        .getContractInformationDetails()
                        .getBankOrIssuranceAgreementType());
        if (rBankingPlacementOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "banking.placement.not.found.error", null, Locale.getDefault()));
        }

        // Find Religion
        Optional<RReligion> rReligionOptional =
                rReligionRepo.findById(request.getPersonalIdentity().getReligion());
        if (rReligionOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "religion.not.found.error", null, Locale.getDefault()));
        }

        // Find Placement Type
        Optional<RPlacementType> rPlacementTypeOptional =
                rPlacementType.findById(request.getContractInformation()
                        .getContractInformationDetails()
                        .getPlacementType());
        if (rPlacementTypeOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "placement.type.not.found.error", null, Locale.getDefault()));
        }

        // Find Division
        Optional<RDivision> rDivisionOptional =
                rDivisionRepo.findById(request.getContractInformation()
                        .getContractInformationDetails()
                        .getDivisionType());
        if (rDivisionOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "division.not.found.error", null, Locale.getDefault()));
        }

        // Find Bank
        Optional<RBank> rBankOptional = rBankRepo.findById(
                request.getCivilRegistrationData().getAccountBank().getBankType());
        if (rBankOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "bank.not.found.error", null, Locale.getDefault()));
        }

        // Optional checks for ethnicity
        Optional<REthnicity> rEthnicityOptional =
                (request.getPersonalIdentity() != null && request.getPersonalIdentity().getEthnicity() != null)
                        ? rEthnicityRepo.findById(request.getPersonalIdentity().getEthnicity())
                        : Optional.empty();


        // Save Employee
        Employee employee =
                Employee.builder()
                        .party(party)
                        .ptkpStatus(rPtkpStatusOptional.get())
                        .background(request.getPersonalIdentity() != null
                                ? request.getPersonalIdentity().getBackground()
                                : null)
                        .bankingPlacement(rBankingPlacementOptional.get())
                        .generation(request.getContractInformation()
                                .getContractInformationDetails()
                                .getGenerationType())
                        .religion(rReligionOptional.get())
                        .placementType(rPlacementTypeOptional.get() != null
                                ? rPlacementTypeOptional.get()
                                : null)
                        .division(rDivisionOptional.get() != null ? rDivisionOptional.get()
                                : null)
                        .bloodType(rBloodTypeOptional.orElse(null))
                        .bank(rBankOptional.get())
                        .position(rPositionOptional.get() != null ? rPositionOptional.get()
                                : null)
                        .emergencyContactNo(request.getPersonalIdentity()
                                .getEmergencyContact()
                                .getPhoneNumber())
                        .joinDate(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractStartDate())
                        .bpjsNo(request.getCivilRegistrationData()
                                .getBpjsData()
                                .getHealthBpjsNumber())
                        .bpjsClass(request.getCivilRegistrationData()
                                .getBpjsData()
                                .getHealthBpjsClassType())
                        .bpjsTkNo(request.getCivilRegistrationData()
                                .getBpjsData()
                                .getEmploymentBpjsNumber())
                        .npwp(request.getCivilRegistrationData().getCivilData().getNpwp())
                        .bankAccountNo(request.getCivilRegistrationData()
                                .getAccountBank()
                                .getAccountNumber())
                        .nik(request.getCivilRegistrationData().getCivilData().getNik())
                        .ethnicity(rEthnicityOptional.orElse(null))
                        .email(request.getPersonalIdentity().getEmail())
                        .build();

        try {
            employeeRepo.save(employee);
            log.info("Employee saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Employee: {}", e.getMessage());
            throw new InternalServerErrorException(messageSource.getMessage(
                    "internal.server.error", null, Locale.getDefault()));
        }

        // Find Geography for Party Address
        Optional<RGeography> rGeographyOptional = rGeographyRepo.findById(
                request.getPersonalIdentity().getHomeAddress().getGeoId());
        if (rGeographyOptional.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "geography.not.found.error", null, Locale.getDefault()));
        }

        // Save Party Address
        PartyAddress partyAddress =
                PartyAddress.builder()
                        .party(party)
                        .geography(rGeographyOptional.get())
                        .address(
                                request.getPersonalIdentity().getHomeAddress().getFullAddress())
                        .build();

        try {
            partyAddressRepository.save(partyAddress);
            log.info("Party address saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Party address: {}", e.getMessage());
            throw new InternalServerErrorException(messageSource.getMessage(
                    "internal.server.error", null, Locale.getDefault()));
        }

        // saving educationHistory
        List<EducationHistory> educationHistories =
                request.getPersonalIdentity()
                        .getEducationHistory()
                        .stream()
                        .map(historyRequest -> {
                            RMajor major =
                                    rMajorRepo.findById(historyRequest.getMajorType())
                                            .orElseThrow(()
                                                    -> new BadRequestException(
                                                    messageSource.getMessage(
                                                            "major.not.found.error", null,
                                                            Locale.getDefault())));
                            return EducationHistory.builder()
                                    .party(employee)
                                    .major(major)
                                    .universityName(historyRequest.getInstitutionName())
                                    .admissionYear(historyRequest.getYearStart())
                                    .graduationYear(historyRequest.getYearEnd())
                                    .build();
                        })
                        .collect(Collectors.toList());

        try {
            educationHistoryRepo.saveAll(educationHistories);
            log.info("Education history saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Education history. Error: " + e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "education.history.save.error", null, Locale.getDefault()));
        }

        // save talent
        Talent talent = Talent.builder().employee(employee).build();

        try {
            talentRepo.save(talent);
            log.info("Talent saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Talent. Error: " + e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "talent.save.error", null, Locale.getDefault()));
        }

        // find contractStatusType
        Optional<RContractStatus> rContractStatusOptional =
                rContractStatusRepo.findById(request.getContractInformation()
                        .getContractInformationDetails()
                        .getContractStatusType());
        if (rContractStatusOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "contract.status.not.found.error", null, Locale.getDefault()));
        }
        // find employeeType
        Optional<RContractType> rContractTypeOptional =
                rContractTypeRepo.findById(request.getContractInformation()
                        .getContractInformationDetails()
                        .getEmployeeType());
        if (rContractTypeOptional.isEmpty()) {
            throw new InternalServerErrorException(messageSource.getMessage(
                    "employee.type.not.found.error", null, Locale.getDefault()));
        }

        // save employee contract
        EmployeeContract employeeContract =
                EmployeeContract.builder()
                        .party(employee)
                        .contractType(rContractTypeOptional.get())
                        .contractStatus(rContractStatusOptional.get())
                        .startDate(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractStartDate())
                        .currentSalary(request.getContractInformation()
                                .getContractInformationDetails()
                                .getCurrentSalary())
                        .endDate(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractEndDate())
                        .build();

        EmployeeContract savedEmployeeContract;
        try {
            savedEmployeeContract = employeeContractRepo.save(employeeContract);
            log.info("Employee contract saved successfully");

        } catch (Exception e) {
            log.error(
                    "Failed to save EmployeeContract or ContractDocument. Error: {}",
                    e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "employee.contract.save.error", null, Locale.getDefault()));
        }

        // Check if employeeAllowanceRequest is not null before proceeding
        EmployeeAllowanceRequest employeeAllowanceRequest =
                request.getContractInformation().getEmployeeAllowanceRequest();

        if (employeeAllowanceRequest != null) {
            List<PlacementAllowance> placementAllowances =
                    employeeAllowanceRequest.getPlacementAllowances();
            List<OtherAllowance> otherAllowances =
                    employeeAllowanceRequest.getOtherAllowances();

            // Initialize allowanceList
            List<EmployeeAllowance> allowanceList = new ArrayList<>();

            // If placementAllowances is not null, process them
            if (placementAllowances != null && !placementAllowances.isEmpty()) {
                allowanceList.addAll(
                        placementAllowances.stream()
                                .map(allowanceRequest -> {
                                    RAllowanceType allowanceType =
                                            rAllowanceTypeRepo
                                                    .findById(allowanceRequest.getAllowanceType())
                                                    .orElseThrow(
                                                            ()
                                                                    -> new BadRequestException(
                                                                    messageSource.getMessage(
                                                                            "allowance.type.not.found.error",
                                                                            null, Locale.getDefault())));

                                    return EmployeeAllowance.builder()
                                            .employeeContract(savedEmployeeContract)
                                            .allowanceType(allowanceType)
                                            .amount(allowanceRequest.getNominal())
                                            .build();
                                })
                                .collect(Collectors.toList()));
            }

            // If otherAllowances is not null, process them
            if (otherAllowances != null && !otherAllowances.isEmpty()) {
                allowanceList.addAll(
                        otherAllowances.stream()
                                .map(allowanceRequest -> {
                                    RAllowanceType allowanceType =
                                            rAllowanceTypeRepo
                                                    .findById(allowanceRequest.getAllowanceType())
                                                    .orElseThrow(
                                                            ()
                                                                    -> new BadRequestException(
                                                                    messageSource.getMessage(
                                                                            "allowance.type.not.found.error",
                                                                            null, Locale.getDefault())));

                                    return EmployeeAllowance.builder()
                                            .employeeContract(savedEmployeeContract)
                                            .allowanceType(allowanceType)
                                            .amount(allowanceRequest.getNominal())
                                            .build();
                                })
                                .collect(Collectors.toList()));
            }

            // Save allowances if the list is not empty
            if (!allowanceList.isEmpty()) {
                try {
                    employeeAllowanceRepo.saveAll(allowanceList);
                    log.info("Employee allowances saved successfully");
                } catch (Exception e) {
                    log.error(
                            "Failed to save Employee allowances. Error: {}", e.getMessage());
                    throw new BadRequestException(messageSource.getMessage(
                            "employee.allowance.save.error", null, Locale.getDefault()));
                }
            } else {
                log.info("No employee allowances to save.");
            }
        }

        // save historyEmployeeContract
        HistoricEmployeeContract historicEmployeeContract =
                HistoricEmployeeContract.builder()
                        .party(employee)
                        .contractTypeId(request.getContractInformation()
                                .getContractInformationDetails()
                                .getEmployeeType())
                        .contractStatusId(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractStatusType())
                        .startDate(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractStartDate())
                        .endDate(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractEndDate())
                        .currentSalary(request.getContractInformation()
                                .getContractInformationDetails()
                                .getCurrentSalary())
                        .build();

        try {
            historicEmployeeContractRepo.save(historicEmployeeContract);
            log.info("Historic Employee Contract saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Historic Employee Contract. Error: {}",
                    e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "historic.employee.contract.save.error", null, Locale.getDefault()));
        }

        Integer year = request.getContractInformation()
                .getContractInformationDetails()
                .getContractStartDate()
                .getYear();
        Integer totalEmployeeThisYear = employeeRepo.countEmployeeByYear(year);

        String nip = GenerateNip.nip(person.getParty().getPartyType().getName(),
                request.getContractInformation()
                        .getContractInformationDetails()
                        .getContractStartDate()
                        .getMonthValue(),
                year % 100, totalEmployeeThisYear);

        HistoricEmployee historicEmployee =
                HistoricEmployee.builder()
                        .emergencyContactRelationId(request.getPersonalIdentity()
                                .getEmergencyContact()
                                .getRelationship())
                        .positionId(request.getContractInformation()
                                .getContractInformationDetails()
                                .getPositionType())
                        .bloodTypeId(request.getPersonalIdentity().getBloodType())
                        .maritalStatusId(request.getPersonalIdentity().getMaritalStatus())
                        .ptkpStatusId(request.getCivilRegistrationData()
                                .getCivilData()
                                .getStatusPtkp())
                        .bankingPlacementId(request.getContractInformation()
                                .getContractInformationDetails()
                                .getBankOrIssuranceAgreementType())
                        .religionId(request.getPersonalIdentity().getReligion())
                        .divisionId(request.getContractInformation()
                                .getContractInformationDetails()
                                .getDivisionType())
                        .ethnicityId(request.getPersonalIdentity() != null
                                ? request.getPersonalIdentity().getEthnicity()
                                : null)
                        .bankId(request.getCivilRegistrationData()
                                .getAccountBank()
                                .getBankType())
                        .nip(nip) // TODO INI GENERATE DARI 3 TERKAHIR BELUM BENAR DI
                        // PRODUCTIONYNYA HATI HATI
                        .placeOfBirth(request.getPersonalIdentity().getPlaceOfBirth())
                        .primaryPhoneNo(request.getPersonalIdentity().getPhoneNumber())
                        .nik(request.getCivilRegistrationData().getCivilData().getNik())
                        .email(request.getPersonalIdentity().getEmail())
                        .emergencyContactNo(request.getPersonalIdentity()
                                .getEmergencyContact()
                                .getPhoneNumber())
                        .joinDate(request.getContractInformation()
                                .getContractInformationDetails()
                                .getContractStartDate())
                        .generation(request.getContractInformation()
                                .getContractInformationDetails()
                                .getGenerationType()
                                != null
                                ? request.getContractInformation()
                                .getContractInformationDetails()
                                .getGenerationType()
                                : null)
                        .bpjsNo(request.getCivilRegistrationData()
                                .getBpjsData()
                                .getHealthBpjsNumber())
                        .bpjsClass(request.getCivilRegistrationData()
                                .getBpjsData()
                                .getHealthBpjsClassType())
                        .bpjsTkNo(request.getCivilRegistrationData()
                                .getBpjsData()
                                .getEmploymentBpjsNumber())
                        .npwp(request.getCivilRegistrationData().getCivilData().getNpwp())
                        .background(request.getPersonalIdentity() != null
                                ? request.getPersonalIdentity().getBackground()
                                : null)
                        .bankAccountNo(request.getCivilRegistrationData()
                                .getAccountBank()
                                .getAccountNumber())
                        .build();

        try {
            historicEmployeeRepo.save(historicEmployee);
            log.info("Historic Employee saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Historic Employee. Error: {}", e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "historic.employee.save.error", null, Locale.getDefault()));
        }

        // save emplyeeCoursesOrUpgrading
        if (request.getPersonalIdentity().getCourseOrUpgrading() != null) {
            List<EmployeeCourse> employeeCourses =
                    request.getPersonalIdentity()
                            .getCourseOrUpgrading()
                            .stream()
                            .map(courseRequest -> {
                                RCourseType rCourseType =
                                        Optional.ofNullable(courseRequest.getCourseType())
                                                .flatMap(
                                                        courseType -> rCourseTypeRepo.findById(courseType))
                                                .orElseThrow(()
                                                        -> new BadRequestException(
                                                        messageSource.getMessage(
                                                                "course.type.not.found.error",
                                                                null, Locale.getDefault())));

                                RGeography rGeographyType =
                                        Optional.ofNullable(courseRequest.getCityType())
                                                .flatMap(cityType -> rGeographyRepo.findById(cityType))
                                                .orElseThrow(
                                                        ()
                                                                -> new BadRequestException(
                                                                messageSource.getMessage(
                                                                        "geography.type.not.found.error", null,
                                                                        Locale.getDefault())));

                                return EmployeeCourse.builder()
                                        .party(employee)
                                        .courseType(rCourseType)
                                        .city(rGeographyType)
                                        .name(courseRequest.getCourseName())
                                        .courseNo(courseRequest.getCertificationId())
                                        .duration(courseRequest.getDurationMonths())
                                        .issuer(courseRequest.getInstitution())
                                        .day(courseRequest.getDay())
                                        .month(courseRequest.getMonth())
                                        .year(courseRequest.getYear())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                if (!employeeCourses.isEmpty()) {
                    employeeCourseRepo.saveAll(employeeCourses);
                    log.info("Course records saved successfully.");
                } else {
                    log.info("No course records to save.");
                }
            } catch (Exception e) {
                log.error("Failed to save course records. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "course.records.save.error", null, Locale.getDefault()));
            }
        }

        // save workExperienceRequest
        if (request.getPersonalIdentity().getWorkExperienceRequest() != null) {
            List<WorkExperience> workExperiences =
                    request.getPersonalIdentity()
                            .getWorkExperienceRequest()
                            .stream()
                            .map(workExperience -> {
                                // Handle null safety for cityType by checking if it is not null
                                // before finding RGeography
                                RGeography rGeographyType =
                                        Optional.ofNullable(workExperience.getCityType())
                                                .flatMap(cityType -> rGeographyRepo.findById(cityType))
                                                .orElseThrow(
                                                        ()
                                                                -> new BadRequestException(
                                                                messageSource.getMessage(
                                                                        "geography.type.not.found.error", null,
                                                                        Locale.getDefault())));

                                // Map the work experience to the entity
                                return WorkExperience.builder()
                                        .party(employee)
                                        .city(rGeographyType)
                                        .name(workExperience.getCompanyName())
                                        .position(workExperience.getPosition())
                                        .startYear(workExperience.getStartYear())
                                        .endYear(workExperience.getEndYear())
                                        .duration(workExperience.getDurationMonths())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                // Save the list of work experiences to the repository
                workExperienceRepo.saveAll(workExperiences);
                log.info("WorkExperience records saved successfully.");
            } catch (Exception e) {
                // Log and throw an exception if saving fails
                log.error("Failed to save WorkExperience. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "work.experience.save.error", null, Locale.getDefault()));
            }
        }

        // save OrganizationExperience
        if (request.getPersonalIdentity().getOrganizationExperienceRequest()
                != null) {
            List<OrganizationExperience> organizationExperienceRequests =
                    request.getPersonalIdentity()
                            .getOrganizationExperienceRequest()
                            .stream()
                            .map(organizationExperience -> {
                                RGeography rGeographyType =
                                        rGeographyRepo
                                                .findById(organizationExperience.getCityType())
                                                .orElseThrow(
                                                        ()
                                                                -> new BadRequestException(
                                                                messageSource.getMessage(
                                                                        "geography.type.not.found.error", null,
                                                                        Locale.getDefault())));

                                return OrganizationExperience.builder()
                                        .party(employee)
                                        .city(rGeographyType)
                                        .name(organizationExperience.getOrganizationName())
                                        .position(organizationExperience.getPosition())
                                        .startYear(organizationExperience.getStartYear())
                                        .duration(organizationExperience.getDurationMonths())
                                        .memberRange(organizationExperience.getMemberCountRange())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                organizationExperienceRepo.saveAll(organizationExperienceRequests);
                log.info("OrganizationExperience records saved successfully.");
            } catch (Exception e) {
                log.error(
                        "Failed to save OrganizationExperience. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "organization.experience.save.error", null, Locale.getDefault()));
            }
        }
        // save sports
        // Save sports
        if (request.getPersonalIdentity() != null
                && request.getPersonalIdentity().getSports() != null) {
            List<EmployeeSport> employeeSports =
                    request.getPersonalIdentity()
                            .getSports()
                            .stream()
                            .map(employeeSport -> {
                                RSport rSport =
                                        rsportRepo.findById(employeeSport.getSportType())
                                                .orElseThrow(()
                                                        -> new BadRequestException(
                                                        messageSource.getMessage(
                                                                "sport.type.not.found.error",
                                                                null, Locale.getDefault())));

                                return EmployeeSport.builder()
                                        .party(employee)
                                        .sport(rSport)
                                        .isActive(employeeSport.getIsActive())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                employeeSportRepo.saveAll(employeeSports);
                log.info("EmployeeSport records saved successfully.");
            } catch (Exception e) {
                log.error("Failed to save EmployeeSport. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "employee.sport.save.error", null, Locale.getDefault()));
            }
        }

        // Save arts
        if (request.getPersonalIdentity() != null
                && request.getPersonalIdentity().getArts() != null) {
            List<EmployeeArt> employeeArts =
                    request.getPersonalIdentity()
                            .getArts()
                            .stream()
                            .map(art -> {
                                RArt rArt =
                                        rArtRepo.findById(art.getArt())
                                                .orElseThrow(()
                                                        -> new BadRequestException(
                                                        messageSource.getMessage(
                                                                "art.type.not.found.error",
                                                                null, Locale.getDefault())));

                                return EmployeeArt.builder()
                                        .art(rArt)
                                        .isActive(art.getIsActive())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                employeeArtRepo.saveAll(employeeArts);
                log.info("EmployeeArt records saved successfully.");
            } catch (Exception e) {
                log.error("Failed to save EmployeeArt. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "employee.art.save.error", null, Locale.getDefault()));
            }
        }

        // save metadata
        List<EmployeeMetadata> employeeMetadataList = new ArrayList<>();
        if (request.getPersonalIdentity().getOtherRequest() != null) {
            OtherRequest otherRequest =
                    request.getPersonalIdentity().getOtherRequest();

            if (otherRequest.getForeignLanguageProficiency() != null) {
                employeeMetadataList.add(
                        EmployeeMetadata.builder()
                                .party(employee)
                                .key("foreign_language")
                                .value(otherRequest.getForeignLanguageProficiency())
                                .build());
            }

            if (otherRequest.getHobbies() != null) {
                employeeMetadataList.add(EmployeeMetadata.builder()
                        .party(employee)
                        .key("hobbies")
                        .value(otherRequest.getHobbies())
                        .build());
            }

            if (otherRequest.getCareerInterests() != null) {
                employeeMetadataList.add(EmployeeMetadata.builder()
                        .party(employee)
                        .key("career_interest")
                        .value(otherRequest.getCareerInterests())
                        .build());
            }
        }

        if (request.getPersonalIdentity().getFamilyOrder() != null) {
            FamilyOrder familyOrder = request.getPersonalIdentity().getFamilyOrder();

            if (familyOrder.getChildNumber() != null) {
                employeeMetadataList.add(
                        EmployeeMetadata.builder()
                                .party(employee)
                                .key("child_no")
                                .value(familyOrder.getChildNumber().toString())
                                .build());
            }

            if (familyOrder.getTotalSiblings() != null) {
                employeeMetadataList.add(
                        EmployeeMetadata.builder()
                                .party(employee)
                                .key("siblings")
                                .value(familyOrder.getTotalSiblings().toString())
                                .build());
            }
        }

        try {
            employeeMetadatumRepo.saveAll(employeeMetadataList);
            log.info("Successfully saved OtherRequest metadata for employeeId: {}",
                    employee.getId());
        } catch (Exception e) {
            log.error(
                    "Failed to save OtherRequest metadata. Error: {}", e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "employee.metadata.save.error", null, Locale.getDefault()));
        }

        // save socmed
        if (request.getDocuments() != null) {
            List<EmployeeSocialMedia> employeeSocialMedia =
                    request.getDocuments()
                            .getSocialMediaRequest()
                            .stream()
                            .map(socmed -> {
                                RSocialMedia rSocialMedia =
                                        rSocialMediaRepo.findById(socmed.getSocialMediaType())
                                                .orElseThrow(
                                                        ()
                                                                -> new BadRequestException(
                                                                messageSource.getMessage(
                                                                        "social.media.type.not.found.error",
                                                                        null, Locale.getDefault())));

                                return EmployeeSocialMedia.builder()
                                        .party(employee)
                                        .socialMedia(rSocialMedia)
                                        .link(socmed.getLinkSocmed())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                employeeSocialMediaRepo.saveAll(employeeSocialMedia);
                log.info("Employee Social Media records saved successfully.");
            } catch (Exception e) {
                log.error(
                        "Failed to save Employee Social Media. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "employee.social.media.save.error", null, Locale.getDefault()));
            }
        }

        // ********************** SAVE SEMUA DATA YANG BERKAITAN DENGAN KARYAWAN
        Optional<RRelationshipType> rRelationshipTypeMother =
                rRelationshipTypeRepo.findById(RRelationshipTypeEnum.IBU.getId());
        Optional<RRelationshipType> rRelationshipTypeFather =
                rRelationshipTypeRepo.findById(RRelationshipTypeEnum.AYAH.getId());
        Optional<RRelationshipType> rRelationshipTypeSpouse =
                rRelationshipTypeRepo.findById(RRelationshipTypeEnum.PASANGAN.getId());

        // find TipeKaryawwan lainnya
        Optional<RPartyType> rPartyTypeOther =
                rPartyTypeRepo.findById(RPartyTypeEnum.LAINNYA.getId());

        // save mother
        Party partyMother =
                Party.builder().partyType(rPartyTypeOther.get()).build();
        try {
            partyRepo.save(partyMother);
            log.info("Party saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Party Error: " + e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "party.save.error", null, Locale.getDefault()));
        }

        Optional<REducation> rEducationOptionalMother =
                rEducationRepo.findById(request.getPersonalIdentity()
                        .getMotherIdentity()
                        .getHighestEducation());
        if (rEducationOptionalMother.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "education.not.found.error", null, Locale.getDefault()));
        }

        Person personMother =
                Person.builder()
                        .party(partyMother)
                        .education(rEducationOptionalMother.get())
                        .fullname(
                                request.getPersonalIdentity().getMotherIdentity().getName())
                        .dateOfBirth(request.getPersonalIdentity()
                                .getMotherIdentity()
                                .getDateOfBirth())
                        .gender('F')
                        .build();

        // save person mother
        try {
            personRepo.save(personMother);
            log.info("person relationship saved successfully");
        } catch (Exception e) {
            log.error("Failed to save person relationship Error: " + e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "person.relationship.save.error", null, Locale.getDefault()));
        }

        PersonPhoneNumber personMotherPhoneNumber =
                PersonPhoneNumber.builder()
                        .party(personMother)
                        .phoneNo(request.getPersonalIdentity()
                                .getMotherIdentity()
                                .getPhoneNumber())
                        .build();

        // personMotherPhoneNumber
        try {
            personPhoneNumberRepo.save(personMotherPhoneNumber);
            log.info("person phone number saved successfully");
        } catch (Exception e) {
            log.error("Failed to save person phone number Error: " + e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "person.phone.number.save.error", null, Locale.getDefault()));
        }
        Optional<RRangeSalary> rRangeSalaryOptional = rRangeSalaryRepo.findById(
                request.getPersonalIdentity().getMotherIdentity().getSalary() != null
                        ? request.getPersonalIdentity().getMotherIdentity().getSalary()
                        : null);
        if (rRangeSalaryOptional.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "salary.range.not.found.error", null, Locale.getDefault()));
        }

        PersonRelationship personRelationshipMother =
                PersonRelationship.builder()
                        .party(person) // employee
                        .relatedParty(personMother)
                        .rangeSalary(rRangeSalaryOptional.get())
                        .isAlive(true)
                        .relationshipType(rRelationshipTypeMother.get())
                        .occupation(request.getPersonalIdentity()
                                .getMotherIdentity()
                                .getOccupation())
                        .isAlive(request.getPersonalIdentity()
                                .getMotherIdentity()
                                .getStatusAlive())
                        .build();

        // save person relationship
        try {
            personRelationShipRepo.save(personRelationshipMother);
            log.info("Person relationship for mother saved successfully");
        } catch (Exception e) {
            log.error("Failed to save person relationship for mother. Error: {}",
                    e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "person.relationship.save.error", null, Locale.getDefault()));
        }

        Optional<RGeography> rGeographyMotherOptional = rGeographyRepo.findById(
                request.getPersonalIdentity().getMotherIdentity().getGeoId());
        if (rGeographyMotherOptional.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "geography.not.found.error", null, Locale.getDefault()));
        }

        PartyAddress partyAddressMother =
                PartyAddress.builder()
                        .party(partyMother)
                        .geography(rGeographyMotherOptional.get())
                        .address(
                                request.getPersonalIdentity().getMotherIdentity().getAddress())
                        .build();

        try {
            partyAddressRepository.save(partyAddressMother);
            log.info("Party address for mother saved successfully");
        } catch (Exception e) {
            log.error(
                    "Failed to save party address for mother. Error: {}", e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "party.address.save.error", null, Locale.getDefault()));
        }

        // save Father
        Party partyFather =
                Party.builder().partyType(rPartyTypeOther.get()).build();
        try {
            partyRepo.save(partyFather);
            log.info("Party for father saved successfully");
        } catch (Exception e) {
            log.error("Failed to save party for father. Error: {}", e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "party.save.error", null, Locale.getDefault()));
        }

        Optional<REducation> rEducationOptionalFather =
                rEducationRepo.findById(request.getPersonalIdentity()
                        .getFatherIdentity()
                        .getHighestEducation());
        if (rEducationOptionalFather.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "education.not.found.error", null, Locale.getDefault()));
        }

        Person personFather =
                Person.builder()
                        .party(partyFather)
                        .education(rEducationOptionalFather.get())
                        .fullname(
                                request.getPersonalIdentity().getFatherIdentity().getName())
                        .dateOfBirth(request.getPersonalIdentity()
                                .getFatherIdentity()
                                .getDateOfBirth())
                        .gender('M')
                        .build();

        // save person father
        try {
            personRepo.save(personFather);
            log.info("Person for father saved successfully");
        } catch (Exception e) {
            log.error("Failed to save person for father. Error: {}", e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "person.save.error", null, Locale.getDefault()));
        }

        PersonPhoneNumber personFatherPhoneNumber =
                PersonPhoneNumber.builder()
                        .party(personFather)
                        .phoneNo(request.getPersonalIdentity()
                                .getFatherIdentity()
                                .getPhoneNumber())
                        .build();

        // save personFatherPhoneNumber
        try {
            personPhoneNumberRepo.save(personFatherPhoneNumber);
            log.info("Phone number for father saved successfully");
        } catch (Exception e) {
            log.error(
                    "Failed to save phone number for father. Error: {}", e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "person.phone.number.save.error", null, Locale.getDefault()));
        }

        Optional<RRangeSalary> rRangeSalaryFatherOptional =
                rRangeSalaryRepo.findById(
                        request.getPersonalIdentity().getFatherIdentity().getSalary()
                                != null
                                ? request.getPersonalIdentity().getFatherIdentity().getSalary()
                                : null);
        if (rRangeSalaryFatherOptional.isEmpty()) {
            throw new BadRequestException(messageSource.getMessage(
                    "salary.range.not.found.error", null, Locale.getDefault()));
        }
        PersonRelationship personRelationshipFather =
                PersonRelationship.builder()
                        .party(person)
                        .relatedParty(personFather)
                        .rangeSalary(rRangeSalaryFatherOptional.get())
                        .isAlive(true)
                        .relationshipType(rRelationshipTypeFather.get())
                        .occupation(request.getPersonalIdentity()
                                .getFatherIdentity()
                                .getOccupation())
                        .isAlive(request.getPersonalIdentity()
                                .getFatherIdentity()
                                .getStatusAlive())
                        .build();

        // save person relationship
        try {
            personRelationShipRepo.save(personRelationshipFather);
            log.info("Person relationship for father saved successfully");
        } catch (Exception e) {
            log.error("Failed to save person relationship for father. Error: {}",
                    e.getMessage());
            throw new BadRequestException(messageSource.getMessage(
                    "person.relationship.save.error", null, Locale.getDefault()));
        }

        Optional<RGeography> rGeographyFatherOptional = rGeographyRepo.findById(
                request.getPersonalIdentity().getFatherIdentity().getGeoId());

        PartyAddress partyAddressFather =
                PartyAddress.builder()
                        .party(partyFather)
                        .geography(rGeographyFatherOptional.get())
                        .address(
                                request.getPersonalIdentity().getFatherIdentity().getAddress())
                        .build();
        try {
            partyAddressRepository.save(partyAddressFather);
            log.info("Party address for father saved successfully");
        } catch (Exception e) {
            log.error(
                    "Failed to save party address for father. Error: {}", e.getMessage());
            throw new InternalServerErrorException();
        }

        // Save SpouseIdentity
        if (request.getPersonalIdentity().getSpouseIdentity() != null) {
            SpouseIdentity spouseIdentity =
                    request.getPersonalIdentity().getSpouseIdentity();

            // Save Party for spouse
            Party partySpouse =
                    Party.builder().partyType(rPartyTypeOther.get()).build();
            try {
                partyRepo.save(partySpouse);
                log.info("Party for spouse saved successfully");
            } catch (Exception e) {
                log.error("Failed to save party for spouse. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "party.save.error", null, Locale.getDefault()));
            }

            Optional<REducation> rEducationOptionalSpouse =
                    rEducationRepo.findById(spouseIdentity.getPartnerHighestEducation());
            if (rEducationOptionalSpouse.isEmpty()) {
                throw new BadRequestException(messageSource.getMessage(
                        "education.not.found.error", null, Locale.getDefault()));
            }

            Person personSpouse =
                    Person.builder()
                            .party(partySpouse)
                            .education(rEducationOptionalSpouse.get())
                            .fullname(spouseIdentity.getPartnerName())
                            .dateOfBirth(spouseIdentity.getPartnerDateOfBirth() != null ? spouseIdentity.getPartnerDateOfBirth() : null)
                            .gender(DetermineGender.determineSpouseGender(person))
                            .build();

            try {
                personRepo.save(personSpouse);
                log.info("Person for spouse saved successfully");
            } catch (Exception e) {
                log.error(
                        "Failed to save person for spouse. Error: {}", e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "person.relationship.save.error", null, Locale.getDefault()));
            }

            // Find Range Salary
            Optional<RRangeSalary> rRangeSalaryMotherOptional =
                    rRangeSalaryRepo.findById(spouseIdentity.getSalary());
            if (rRangeSalaryMotherOptional.isEmpty()) {
                throw new BadRequestException(messageSource.getMessage(
                        "salary.range.not.found.error", null, Locale.getDefault()));
            }

            PersonRelationship personRelationshipSpouse =
                    PersonRelationship.builder()
                            .party(person)
                            .relatedParty(personSpouse)
                            .isAlive(true)
                            .isSplitTax(spouseIdentity.getSeparateTax())
                            .rangeSalary(rRangeSalaryMotherOptional.get())
                            .relationshipType(rRelationshipTypeSpouse.get())
                            .occupation(spouseIdentity.getPartnerOccupation())
                            .build();

            try {
                personRelationShipRepo.save(personRelationshipSpouse);
                log.info("PersonRelationship for spouse saved successfully");
            } catch (Exception e) {
                log.error("Failed to save PersonRelationship for spouse. Error: {}",
                        e.getMessage());
                throw new BadRequestException(messageSource.getMessage(
                        "person.relationship.save.error", null, Locale.getDefault()));
            }
        }

        // save siblings
        // Ambil relationship type untuk siblings
        if (request.getPersonalIdentity().getSiblings() != null
                && !request.getPersonalIdentity().getSiblings().isEmpty()) {
            Optional<RRelationshipType> rRelationshipTypeSiblings =
                    rRelationshipTypeRepo.findById(
                            RRelationshipTypeEnum.SAUDARA_KANDUNG.getId());
            if (rRelationshipTypeSiblings.isEmpty()) {
                throw new BadRequestException(messageSource.getMessage(
                        "relationship.type.siblings.not.found", null, Locale.getDefault()));
            }

            // Process and save siblings
            List<PersonRelationship> siblingRelationships =
                    request.getPersonalIdentity()
                            .getSiblings()
                            .stream()
                            .map(sibling -> {
                                // Create Party for each sibling
                                Party siblingParty =
                                        Party.builder().partyType(rPartyTypeOther.get()).build();

                                try {
                                    siblingParty = partyRepo.save(siblingParty);
                                    log.info("Sibling party created with ID: {}",
                                            siblingParty.getId());
                                } catch (Exception e) {
                                    log.error("Failed to create sibling party", e);
                                    throw new InternalServerErrorException(
                                            messageSource.getMessage("sibling.party.creation.error",
                                                    null, Locale.getDefault()));
                                }

                                // Find education level
                                Optional<REducation> rEducationOptionalSibling =
                                        rEducationRepo.findById(sibling.getEducationLevel());
                                if (rEducationOptionalSibling.isEmpty()) {
                                    throw new BadRequestException(messageSource.getMessage(
                                            "education.not.found.error", null, Locale.getDefault()));
                                }

                                Person siblingPerson =
                                        Person.builder()
                                                .party(siblingParty)
                                                .education(rEducationOptionalSibling.get())
                                                .dateOfBirth(sibling.getDateOfBirth())
                                                .gender(sibling.getGender())
                                                .build();

                                try {
                                    siblingPerson = personRepo.save(siblingPerson);
                                    log.info("Sibling person created with ID: {}",
                                            siblingPerson.getId());
                                } catch (Exception e) {
                                    log.error("Failed to create sibling person", e);
                                    throw new InternalServerErrorException(
                                            messageSource.getMessage("sibling.person.creation.error",
                                                    null, Locale.getDefault()));
                                }

                                return PersonRelationship.builder()
                                        .party(person)
                                        .isAlive(true)
                                        .relatedParty(siblingPerson)
                                        .relationshipType(rRelationshipTypeSiblings.get())
                                        .occupation(sibling.getOccupation())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                personRelationShipRepo.saveAll(siblingRelationships);
                log.info("Sibling relationships saved successfully");
            } catch (Exception e) {
                log.error("Failed to save sibling relationships", e);
                throw new InternalServerErrorException(messageSource.getMessage(
                        "sibling.relationships.save.error", null, Locale.getDefault()));
            }
        }

        if (request.getPersonalIdentity().getFamilyMembersInKk() != null
                && !request.getPersonalIdentity().getFamilyMembersInKk().isEmpty()) {
            List<PersonRelationship> familyMemberRelationships =
                    request.getPersonalIdentity()
                            .getFamilyMembersInKk()
                            .stream()
                            .map(familyMember -> {
                                // Null check untuk familyMember
                                if (familyMember == null) {
                                    throw new BadRequestException(messageSource.getMessage(
                                            "family.member.null.error", null, Locale.getDefault()));
                                }

                                Party familyMemberParty =
                                        Party.builder()
                                                .partyType(rPartyTypeOther.orElseThrow(
                                                        ()
                                                                -> new BadRequestException(
                                                                messageSource.getMessage(
                                                                        "party.type.not.found", null,
                                                                        Locale.getDefault()))))
                                                .build();

                                try {
                                    familyMemberParty = partyRepo.save(familyMemberParty);
                                    log.info("Family member party created with ID: {}",
                                            familyMemberParty.getId());
                                } catch (Exception e) {
                                    log.error("Failed to create family member party", e);
                                    throw new InternalServerErrorException(
                                            messageSource.getMessage(
                                                    "family.member.party.creation.error", null,
                                                    Locale.getDefault()));
                                }

                                Optional<REducation> rEducationOptionalFamilyMember =
                                        rEducationRepo.findById(familyMember.getEducationLevel());
                                if (rEducationOptionalFamilyMember.isEmpty()) {
                                    throw new BadRequestException(messageSource.getMessage(
                                            "education.not.found.error", null, Locale.getDefault()));
                                }

                                Person familyMemberPerson =
                                        Person.builder()
                                                .party(familyMemberParty)
                                                .education(rEducationOptionalFamilyMember.get())
                                                .dateOfBirth(familyMember.getDateOfBirth())
                                                .gender(familyMember.getGender())
                                                .graduationYear(familyMember.getGraduationYear())
                                                .build();

                                try {
                                    familyMemberPerson = personRepo.save(familyMemberPerson);
                                    log.info("Family member person created with ID: {}",
                                            familyMemberPerson.getId());
                                } catch (Exception e) {
                                    log.error("Failed to create family member person", e);
                                    throw new InternalServerErrorException(
                                            messageSource.getMessage(
                                                    "family.member.person.creation.error", null,
                                                    Locale.getDefault()));
                                }

                                Optional<RRelationshipType> rRelationshipTypeFamilyMember =
                                        rRelationshipTypeRepo.findById(
                                                RRelationshipTypeEnum.ANAK.getId());
                                if (rRelationshipTypeFamilyMember.isEmpty()) {
                                    throw new BadRequestException(messageSource.getMessage(
                                            "relationship.type.family.not.found", null,
                                            Locale.getDefault()));
                                }

                                return PersonRelationship.builder()
                                        .party(person)
                                        .relatedParty(familyMemberPerson)
                                        .isAlive(true)
                                        .relationshipType(rRelationshipTypeFamilyMember.get())
                                        .occupation(familyMember.getOccupation())
                                        .build();
                            })
                            .collect(Collectors.toList());

            try {
                personRelationShipRepo.saveAll(familyMemberRelationships);
                log.info("Family member relationships saved successfully");
            } catch (Exception e) {
                log.error("Failed to save family member relationships", e);
                throw new InternalServerErrorException(
                        messageSource.getMessage("family.member.relationships.save.error",
                                null, Locale.getDefault()));
            }
        }

        // SAVE PROCESS APPROVAL
        ProcessDefinition processDefinition =
                processDefinitionRepo.findByProcDefKey(Constant.NEW_CONTRACT);

        ProcessInstance processInstance =
                ProcessInstance.builder()
                        .procDefKey(processDefinition)
                        .submitterId(usersOptional.get().getId())
                        .startTime(OffsetDateTime.now())
                        .isActive(true)
                        .build();

        try {
            processInstanceRepo.save(processInstance);
            log.info("Process Instance saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Process Instance", e);
            throw new InternalServerErrorException(messageSource.getMessage(
                    "process.instance.save.error", null, Locale.getDefault()));
        }

        ProcessTask processTask = ProcessTask.builder()
                .procInst(processInstance)
                .assigneeId(employee.getId())
                .taskName(Constant.REQUEST_APPROVE_TASK_NAME)
                .startTime(OffsetDateTime.now())
                .isActive(true)
                .build();

        try {
            processTaskRepo.save(processTask);
            log.info("Process Task saved successfully");
        } catch (Exception e) {
            log.error("Failed to save Process Task", e);
            throw new InternalServerErrorException(messageSource.getMessage(
                    "process.task.save.error", null, Locale.getDefault()));
        }

        // todo mengirimkan data ke approval dengan messageBroker
        log.info("Sending data to approval via message broker");

        return "Success Add Employee Data";
    }
}
