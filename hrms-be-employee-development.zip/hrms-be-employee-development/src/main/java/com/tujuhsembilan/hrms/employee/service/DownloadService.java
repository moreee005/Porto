package com.tujuhsembilan.hrms.employee.service;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;
import com.tujuhsembilan.hrms.employee.model.view.ViewDatatableEmployee;
import com.tujuhsembilan.hrms.employee.repositories.view.ViewDatatableEmployeeRepo;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

@Service
public class DownloadService {

    @Autowired
    ViewDatatableEmployeeRepo viewDatatableEmployeeRepo;

    public ResponseEntity<Object> downloadDataEmployee(Integer contract, Integer position, Integer placement, String dateOfBirth, Integer bankPlacementAgreement, String type) {
        try {
            List<ViewDatatableEmployee> viewDatatableEmployeeList = viewDatatableEmployeeRepo.datatableEmployeeByFilter(contract, position, placement, dateOfBirth, bankPlacementAgreement);
            HttpHeaders headers = new HttpHeaders();
            if (type.equals("xls")) {
                byte[] generatedExcel = generatedExcel(viewDatatableEmployeeList);
                headers.add("Content-Disposition", "attachment; filename=employee_excel.xlsx");
                return ResponseEntity.ok().headers(headers).body(generatedExcel);
            } else if (type.equals("csv")) {
                String generatedCsv = generatedCsv(viewDatatableEmployeeList);
                headers.add("Content-Disposition", "attachment; filename=employee_excel.csv");
                return ResponseEntity.ok().headers(headers).body(generatedCsv);
            } else if (type.equals("pdf")) {
                byte[] generatedPdf = generatedPdf(viewDatatableEmployeeList);
                headers.add("Content-Disposition", "attachment; filename=employee_excel.pdf");
                return ResponseEntity.ok().headers(headers).body(generatedPdf);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private byte[] generatedExcel(List<ViewDatatableEmployee> viewDatatableEmployees) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Workbook wr = new XSSFWorkbook();
            Sheet sheet = wr.createSheet("Employee");

            // Header
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("No.");
            headerRow.createCell(1).setCellValue("Name");
            headerRow.createCell(2).setCellValue("Contract");
            headerRow.createCell(3).setCellValue("Position");
            headerRow.createCell(4).setCellValue("Date Of Birth");
            headerRow.createCell(5).setCellValue("Placement");

            Integer rowNum = 1;
            for (ViewDatatableEmployee item : viewDatatableEmployees) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(rowNum);
                row.createCell(1).setCellValue(item.getFullname());
                row.createCell(2).setCellValue(item.getContractTypeName());
                row.createCell(3).setCellValue(item.getPositionName());
                row.createCell(4).setCellValue(item.getDateOfBirthStr());
                row.createCell(5).setCellValue(item.getPlacementTypeName());
            }

            wr.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String generatedCsv(List<ViewDatatableEmployee> viewDatatableEmployees) {
        StringWriter sw = new StringWriter();
        CSVWriter csvWriter = new CSVWriter(sw);
        csvWriter.writeNext(new String[]{"No", "Name", "Contract", "Position", "DateOfBirth", "PlacementTypeName"});
        Integer rowNum = 1;
        for (ViewDatatableEmployee item : viewDatatableEmployees) {
            csvWriter.writeNext(new String[]{
                    rowNum.toString(),
                    item.getFullname(),
                    item.getContractTypeName(),
                    item.getPositionName(),
                    item.getDateOfBirthStr(),
                    item.getPlacementTypeName()

            });
            rowNum++;
        }
        return csvWriter.toString();
    }

    private byte[] generatedPdf(List<ViewDatatableEmployee> viewDatatableEmployees) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, outputStream);
            Paragraph paragraph = new Paragraph("Table Data Employee");
            document.open();
            document.addTitle("Data Employee");
            document.add(paragraph);

            PdfPTable pdfPTable = new PdfPTable(6);
            pdfPTable.setWidthPercentage(100);
            pdfPTable.setSpacingBefore(10f);
            pdfPTable.setSpacingAfter(10f);

            //Add header table
            PdfPCell pdfPCell = new PdfPCell();
            pdfPCell.setPhrase(new Phrase("NO"));
            pdfPTable.addCell(pdfPCell);
            pdfPCell.setPhrase(new Phrase("Name"));
            pdfPTable.addCell(pdfPCell);
            pdfPCell.setPhrase(new Phrase("Contract"));
            pdfPTable.addCell(pdfPCell);
            pdfPCell.setPhrase(new Phrase("Position"));
            pdfPTable.addCell(pdfPCell);
            pdfPCell.setPhrase(new Phrase("Date of Birth"));
            pdfPTable.addCell(pdfPCell);
            pdfPCell.setPhrase(new Phrase("Placement"));
            pdfPTable.addCell(pdfPCell);

            //Add Data
            Integer rowNum = 1;
            for (ViewDatatableEmployee item : viewDatatableEmployees) {
                pdfPTable.addCell(rowNum.toString());
                pdfPTable.addCell(item.getFullname());
                pdfPTable.addCell(item.getContractTypeName());
                pdfPTable.addCell(item.getPositionName());
                pdfPTable.addCell(item.getDateOfBirthStr());
                pdfPTable.addCell(item.getPlacementTypeName());
                rowNum++;
            }

            document.add(pdfPTable);
            document.close();
            return outputStream.toByteArray();
        } catch (DocumentException e) {
            throw new RuntimeException(e);
        }
    }

}
