package com.tujuhsembilan.hrms.employee.model.view;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.io.Serializable;
import java.util.UUID;

/**
 * Mapping for DB view
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "View_Datatable_Contract")
@Immutable
@Table(name = "view_datatable_contract", schema = "public")
public class ViewDatatableContract implements Serializable {
    private static final long serialVersionUID = 6415251817023033174L;
    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @Size(max = 100)
    @Column(name = "photo_filename", length = 100)
    private String photoFilename;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Size(max = 100)
    @Column(name = "contract_type_name", length = 100)
    private String contractTypeName;

    @Column(name = "work_period_str", length = Integer.MAX_VALUE)
    private String workPeriodStr;

    @Column(name = "start_date_str", length = Integer.MAX_VALUE)
    private String startDateStr;

    @Column(name = "end_date_str", length = Integer.MAX_VALUE)
    private String endDateStr;

    @Column(name = "contract_status_id")
    private Integer contractStatusId;

    @Size(max = 100)
    @Column(name = "contract_status_name", length = 100)
    private String contractStatusName;

    @Column(name = "division_id")
    private Integer divisionId;

    @Column(name = "division_name")
    private String divisionName;

    @Column(name = "position_id")
    private Integer positionId;

    @Column(name = "position_name")
    private String positionName;

    @Size(max = 100)
    @Column(name = "fullname", length = 100)
    private String fullname;

    @Column(name = "employee_contract_id")
    private UUID employeeContractId;

}
