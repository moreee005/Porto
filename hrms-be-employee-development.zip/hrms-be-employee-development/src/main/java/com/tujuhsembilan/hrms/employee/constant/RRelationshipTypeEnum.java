package com.tujuhsembilan.hrms.employee.constant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum RRelationshipTypeEnum {
    AYAH(1, "Ayah", "Laki-laki"),
    IBU(2, "Ibu", "Perempuan"),
    SAUDARA_KANDUNG(3, "Saudara Kandung", "Keluarga Inti"),
    PASANGAN(4, "Pasangan", "Keluarga Inti"),
    ANAK(5, "Anak", "Keluarga Inti"),
    KAKEK(6, "Kakek", "Keluarga Besar"),
    NENEK(7, "Nenek", "Keluarga Besar"),
    PAMAN(8, "Paman", "Keluarga Besar"),
    BIBI(9, "Bibi", "Keluarga Besar"),
    SEPUPU(10, "Sepupu", "Keluarga Besar");

    private final Integer id;
    private final String name;
    private final String category;
}