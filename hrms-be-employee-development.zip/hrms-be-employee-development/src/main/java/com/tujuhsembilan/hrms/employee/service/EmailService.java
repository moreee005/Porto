package com.tujuhsembilan.hrms.employee.service;

import jakarta.mail.MessagingException;

public interface EmailService {
    void send(String to, String subject, String content, boolean isHTMLFormat) throws MessagingException;
}
