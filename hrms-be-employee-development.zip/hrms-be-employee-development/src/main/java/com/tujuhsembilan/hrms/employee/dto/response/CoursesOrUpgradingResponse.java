package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class CoursesOrUpgradingResponse {

    private UUID idCourse;
    private String type;
    private String courseName;
    private String city;
    private Short date;
    private Short month;
    private Short year;
    private Short durationMonths;
    private String institution;
    private String certificateNumber;

    public CoursesOrUpgradingResponse(UUID idCourse, String type, String courseName, String city, Short date, Short month, Short year, Short durationMonths, String institution, String certificateNumber) {
        this.idCourse = idCourse;
        this.type = type;
        this.courseName = courseName;
        this.city = city;
        this.date = date;
        this.month = month;
        this.year = year;
        this.durationMonths = durationMonths;
        this.institution = institution;
        this.certificateNumber = certificateNumber;
    }

}
