package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.service.EmployeeContractService;
import com.tujuhsembilan.hrms.employee.service.EmployeeService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping(ResourceURL.EMPLOYEE)
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EmployeeContractService employeeContractService;
//
    @GetMapping("{partyId}")
    public ResponseEntity<BaseResponse> getDetailEmployee(@PathVariable("partyId") UUID partyId) {
        return employeeService.getDetailByEmployeeById(partyId);
    }
    @GetMapping("contract-history/{employeeId}")
    public ResponseEntity<BaseResponse> getUserById(@PathVariable("employeeId") UUID employeeId, HttpServletRequest httpServletRequest) {
        return employeeContractService.getEmployeeContractHistory(employeeId, httpServletRequest);
    }
    @GetMapping("/data-contract/detail/{id}")
    public ResponseEntity<BaseResponse> getDataContractDetail(@PathVariable("id") UUID id) {
        return employeeContractService.getDetailContractById(id);
    }
}
