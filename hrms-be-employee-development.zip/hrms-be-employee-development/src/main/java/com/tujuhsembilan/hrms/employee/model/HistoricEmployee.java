package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Historic_Employee")
@Table(name = "historic_employee", schema = "public", indexes = {
        @Index(name = "rel_diability_fk2", columnList = "disability_status_id"),
        @Index(name = "rel_emr_contact_fk2", columnList = "emergency_contact_relation_id"),
        @Index(name = "rel_position_fk2", columnList = "position_id"),
        @Index(name = "rel_blood_type_fk2", columnList = "blood_type_id"),
        @Index(name = "rel_marital_fk2", columnList = "marital_status_id"),
        @Index(name = "rel_ptkp_fk2", columnList = "ptkp_status_id"),
        @Index(name = "rel_banking_placement_fk2", columnList = "banking_placement_id"),
        @Index(name = "rel_religion_fk2", columnList = "religion_id"),
        @Index(name = "rel_placement_type_fk2", columnList = "placement_type_id"),
        @Index(name = "rel_division_fk2", columnList = "division_id"),
        @Index(name = "rel_ethnicity_fk2", columnList = "ethnicity_id"),
        @Index(name = "rel_bank_fk2", columnList = "bank_id")
})
public class HistoricEmployee implements Serializable {
    private static final long serialVersionUID = 3278463207475904045L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "party_id", nullable = false)
    private UUID id;

    @Column(name = "disability_status_id")
    private Integer disabilityStatusId;

    @Column(name = "emergency_contact_relation_id")
    private Integer emergencyContactRelationId;

    @Column(name = "position_id")
    private Integer positionId;

    @Column(name = "blood_type_id")
    private Integer bloodTypeId;

    @Column(name = "marital_status_id")
    private Integer maritalStatusId;

    @Column(name = "ptkp_status_id")
    private Integer ptkpStatusId;

    @Column(name = "banking_placement_id")
    private Integer bankingPlacementId;

    @Column(name = "religion_id")
    private Integer religionId;

    @Column(name = "placement_type_id")
    private Integer placementTypeId;

    @Column(name = "division_id")
    private Integer divisionId;

    @Column(name = "ethnicity_id")
    private Integer ethnicityId;

    @Column(name = "bank_id")
    private Integer bankId;

    @Size(max = 100)
    @Column(name = "photo_filename", length = 100)
    private String photoFilename;

    @Size(max = 50)
    @NotNull
    @Column(name = "place_of_birth", nullable = false, length = 50)
    private String placeOfBirth;

    @Size(max = 20)
    @NotNull
    @Column(name = "primary_phone_no", nullable = false, length = 20)
    private String primaryPhoneNo;

    @Size(max = 20)
    @Column(name = "secondary_phone_no", length = 20)
    private String secondaryPhoneNo;

    @Size(max = 16)
    @NotNull
    @Column(name = "nik", nullable = false, length = 16)
    private String nik;

    @Size(max = 100)
    @NotNull
    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Size(max = 10)
    @NotNull
    @Column(name = "nip", nullable = false, length = 10)
    private String nip;

    @Size(max = 100)
    @Column(name = "emergency_contact_name", length = 100)
    private String emergencyContactName;

    @Size(max = 20)
    @Column(name = "emergency_contact_no", length = 20)
    private String emergencyContactNo;

    @NotNull
    @Column(name = "join_date", nullable = false)
    private LocalDateTime joinDate;

    @Size(max = 10)
    @Column(name = "generation", length = 10)
    private String generation;

    @Size(max = 15)
    @Column(name = "bpjs_no", length = 15)
    private String bpjsNo;

    @Column(name = "bpjs_class")
    private Short bpjsClass;

    @Size(max = 15)
    @Column(name = "bpjs_tk_no", length = 15)
    private String bpjsTkNo;

    @Size(max = 20)
    @NotNull
    @Column(name = "npwp", nullable = false, length = 20)
    private String npwp;

    @Size(max = 20)
    @NotNull
    @Column(name = "bank_account_no", nullable = false, length = 20)
    private String bankAccountNo;

    @Size(max = 10)
    @Column(name = "background", length = 10)
    private String background;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}