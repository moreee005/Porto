package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class EmployeeArtResponse {

    private String name;
    private Boolean isActive;

    public EmployeeArtResponse(String name, Boolean isActive) {
        this.name = name;
        this.isActive = isActive;
    }

}
