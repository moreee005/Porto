package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CourseOrUpgrading {

    @NotNull(message = "Course type is required")
    @Positive(message = "Course type must be a positive number")
    private Integer courseType;

    @NotBlank(message = "Course name is required")
    @Size(max = 100, message = "Course name must not exceed 100 characters")
    private String courseName;

    @NotNull(message = "City type is required")
    @Positive(message = "City type must be a positive number")
    private Integer cityType;

    @NotNull(message = "Day is required")
    @Min(value = 1, message = "Day must be at least 1")
    @Max(value = 31, message = "Day must not exceed 31")
    private Short day;

    @NotNull(message = "Month is required")
    @Min(value = 1, message = "Month must be at least 1")
    @Max(value = 12, message = "Month must not exceed 12")
    private Short month;

    @NotNull(message = "Year is required")
    @Min(value = 1900, message = "Year must be at least 1900")
    @Max(value = 2100, message = "Year must not exceed 2100")
    private Short year;

    @NotNull(message = "Duration months is required")
    @Positive(message = "Duration months must be a positive number")
    private Short durationMonths;

    @NotBlank(message = "Institution is required")
    @Size(max = 100, message = "Institution name must not exceed 100 characters")
    private String institution;

    @NotBlank(message = "Certification ID is required")
    @Size(max = 100, message = "Certification ID must not exceed 100 characters")
    private String certificationId;
}
