package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Addendum_Contract_Period")
@Table(name = "addendum_contract_period", schema = "public", indexes = {
        @Index(name = "rel_addctr_period_fk", columnList = "addendum_id"),
        @Index(name = "rel_empctr_period_fk", columnList = "employee_contract_id")
})
public class AddendumContractPeriod implements Serializable {
    private static final long serialVersionUID = -5029654906181304280L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "add_contract_period_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "addendum_id")
    private Addendum addendum;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "end_date_old")
    private LocalDateTime endDateOld;

    @Column(name = "end_date_new")
    private LocalDateTime endDateNew;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}