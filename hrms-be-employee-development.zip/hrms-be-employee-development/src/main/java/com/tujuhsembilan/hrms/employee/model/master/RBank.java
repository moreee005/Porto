package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Bank")
@Table(name = "r_bank", schema = "master")
public class RBank implements Serializable {
    private static final long serialVersionUID = 2240795302363150563L;
    @Id
    @Column(name = "bank_id", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Size(max = 30)
    @Column(name = "short_name", length = 30)
    private String shortName;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @Size(max = 12)
    @Column(name = "bic_code", length = 12)
    private String bicCode;

    @Size(max = 7)
    @Column(name = "clearing_code", length = 7)
    private String clearingCode;

}