package com.tujuhsembilan.hrms.employee.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.io.Serializable;
import java.util.UUID;

/**
 * Mapping for DB view
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "View_Datatable_Approval")
@Immutable
@Table(name = "view_datatable_approval", schema = "public")
public class ViewDatatableApproval implements Serializable {
    private static final long serialVersionUID = 825329177360430231L;
    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @Size(max = 100)
    @Column(name = "photo_filename", length = 100)
    private String photoFilename;

    @Size(max = 100)
    @Column(name = "fullname", length = 100)
    private String fullname;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Size(max = 100)
    @Column(name = "contract_type_name", length = 100)
    private String contractTypeName;

    @Column(name = "approval_type_id")
    private Integer approvalTypeId;

    @Size(max = 100)
    @Column(name = "approval_type_name", length = 100)
    private String approvalTypeName;

    @Column(name = "start_date_str", length = Integer.MAX_VALUE)
    private String startDateStr;

    @Column(name = "end_date_str", length = Integer.MAX_VALUE)
    private String endDateStr;

    @Size(max = 50)
    @Column(name = "stage", length = 50)
    private String stage;

    @Column(name = "approval_id")
    private UUID approvalId;

}