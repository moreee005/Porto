package com.tujuhsembilan.hrms.employee.exception;

import org.springframework.http.HttpStatus;

public class InternalServerErrorException extends BaseException {

    public InternalServerErrorException() {
        this.setMessage("Internal Server Error");
        this.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public InternalServerErrorException(String message) {
        this.setMessage(message);
        this.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
