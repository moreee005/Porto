package com.tujuhsembilan.hrms.employee.repositories.master;

import com.tujuhsembilan.hrms.employee.model.master.RPlacementType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RPlacementTypeRepo extends JpaRepository<RPlacementType,Integer> {
    RPlacementType findByName(String name);
}
