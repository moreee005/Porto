package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Manager")
@Table(name = "manager", schema = "public")
public class Manager implements Serializable {
    private static final long serialVersionUID = 3132701447286684981L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "party_id", nullable = false)
    private UUID id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Employee employee;

}