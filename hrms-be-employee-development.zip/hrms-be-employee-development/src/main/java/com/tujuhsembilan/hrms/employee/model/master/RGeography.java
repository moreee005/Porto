package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Geography")
@Table(name = "r_geography", schema = "master")
public class RGeography implements Serializable {
    private static final long serialVersionUID = -2616079683332929335L;
    @Id
    @Column(name = "geography_id", nullable = false)
    private Integer id;

    @Size(max = 100)
    @Column(name = "province", length = 100)
    private String province;

    @Size(max = 100)
    @Column(name = "city", length = 100)
    private String city;

    @Size(max = 100)
    @Column(name = "district", length = 100)
    private String district;

    @Size(max = 100)
    @Column(name = "subdistrict", length = 100)
    private String subdistrict;

    @Size(max = 5)
    @Column(name = "postal_code", length = 5)
    private String postalCode;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}