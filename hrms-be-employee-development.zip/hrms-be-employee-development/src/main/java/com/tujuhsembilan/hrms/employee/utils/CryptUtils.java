package com.tujuhsembilan.hrms.employee.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

public class CryptUtils {

    public static String encryptDecrypt(String message, String action) {
        try {
            String secretKey = "79R4haS1A";
            String secretIV = "r4h$s1a79";
            String sKey = DigestUtils.sha256Hex(secretKey).substring(0, 32);
            String sIv = DigestUtils.sha256Hex(secretIV).substring(0, 16);

            byte[] bIv = sIv.getBytes(StandardCharsets.UTF_8);
            IvParameterSpec ivspec = new IvParameterSpec(bIv);
            byte[] key = sKey.getBytes(StandardCharsets.UTF_8);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            if (action.equals("encrypt")) {
                cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivspec);
                String encode = java.util.Base64.getEncoder().encodeToString(cipher.doFinal(message.getBytes()));
                return java.util.Base64.getEncoder().encodeToString(encode.getBytes());
            } else if (action.equals("decrypt")) {
                cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivspec);
                return new String(cipher.doFinal(java.util.Base64.getDecoder().decode(new String(Base64.decodeBase64(message)))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
