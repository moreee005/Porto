package com.tujuhsembilan.hrms.employee.helpers;

import com.tujuhsembilan.hrms.employee.model.Person;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DetermineGender {
    public static Character determineSpouseGender(Person employee) {
        if (employee.getGender() == null) {
            log.warn("Employee gender is null, cannot determine spouse gender");
            return null;
        }
        // Jika karyawan laki-laki (M), pasangan perempuan (F)
        // Jika karyawan perempuan (F), pasangan laki-laki (M)
        return employee.getGender() == 'M' ? 'F' : 'M';
    }
}
