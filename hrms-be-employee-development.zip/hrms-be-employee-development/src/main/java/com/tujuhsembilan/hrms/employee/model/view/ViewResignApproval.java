package com.tujuhsembilan.hrms.employee.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Mapping for DB view
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "View_Resign_Approval")
@Immutable
@Table(name = "view_resign_approval", schema = "public")
public class ViewResignApproval implements Serializable {
    private static final long serialVersionUID = -8001510620664957621L;
    @Id
    @Column(name = "approval_id")
    private UUID approvalId;

    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "division_id")
    private Integer divisionId;

    @Column(name = "contract_status_id")
    private Integer contractStatusId;

    @Column(name = "placement_type_id")
    private Integer placementTypeId;

    @Column(name = "position_id")
    private Integer positionId;

    @Column(name = "banking_placement_id")
    private Integer bankingPlacementId;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Column(name = "contract_doc_id")
    private UUID contractDocId;

    @Column(name = "employee_allowance_id")
    private UUID employeeAllowanceId;

    @Size(max = 100)
    @Column(name = "fullname", length = 100)
    private String fullname;

    @Size(max = 100)
    @Column(name = "doc_filename", length = 100)
    private String docFilename;

    @Column(name = "resign_date")
    private LocalDateTime resignDate;

    @Size(max = 10)
    @Column(name = "generation", length = 10)
    private String generation;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "current_salary", precision = 10, scale = 2)
    private BigDecimal currentSalary;

}