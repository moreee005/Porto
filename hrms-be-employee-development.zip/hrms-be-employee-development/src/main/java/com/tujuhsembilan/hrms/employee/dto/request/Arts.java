package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Arts {

    @NotNull(message = "Art type cannot be null")
    private Integer art;

    @NotNull(message = "Active status cannot be null")
    private Boolean isActive;

}
