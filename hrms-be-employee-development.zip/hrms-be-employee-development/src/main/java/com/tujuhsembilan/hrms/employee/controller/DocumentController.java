package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.dto.request.DocumentUploadRequest;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.helpers.Response;
import com.tujuhsembilan.hrms.employee.service.DocumentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(ResourceURL.DOCUMENT)
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasAuthority('TALENT ADMINISTRATION')")
public class DocumentController {
    private final DocumentService documentService;

    // DOCUMENT-CONTRACT
    @PostMapping(value = ResourceURL.UPLOAD_DOCUMENT_CONTRACT,
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<BaseResponse>
    uploadDocumentContractEmployee(
            @Valid @ModelAttribute DocumentUploadRequest request) {
        return Response.success(documentService.uploadEmployeeContract(
                request.getDocument(), request.getEmailEmployee()));
    }

    // IMAGE-PROFILE-KARYAWAN
    @PostMapping(ResourceURL.UPLOAD_IMAGE_EMPLOYEE)
    public ResponseEntity<BaseResponse> uploadImageProfileEmployee(
            @Valid @ModelAttribute DocumentUploadRequest request) {
        return Response.success(documentService.uploadProfileImage(
                request.getDocument(), request.getEmailEmployee()));
    }

    // DOCUMENT-DOCUMENT ( KTP,ETC )
    @PostMapping(ResourceURL.UPLOAD_DOCUMENT_CIVIL)
    public ResponseEntity<BaseResponse> uploadDocumentCivilEmployee(
            @Valid @ModelAttribute DocumentUploadRequest request) {
        return Response.success(documentService.uploadDocumentCivilEmployee(
                request.getDocument(), request.getEmailEmployee(),
                Integer.parseInt(request.getDocumentType())));
    }
}
