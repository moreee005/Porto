package com.tujuhsembilan.hrms.employee.dto.request;

import com.tujuhsembilan.hrms.employee.common.validation.annotation.ValidGender;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Siblings {

    // Gender validation: must be 'M' (Male) or 'F' (Female)
    @NotNull(message = "Gender is required")
    @ValidGender
    private Character gender;

    // Date of birth validation: must not be null
    @NotNull(message = "Date of birth is required")
    private LocalDateTime dateOfBirth;

    // Occupation validation: must not be blank and have a reasonable length
    @NotBlank(message = "Occupation is required")
    @Size(max = 50, message = "Occupation must not exceed 50 characters")
    private String occupation;

    // Education level validation: must not be null and positive
    @NotNull(message = "Education level is required")
    @Positive(message = "Education level must be a positive number")
    private Integer educationLevel;
}
