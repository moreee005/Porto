package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Addendum")
@Table(name = "addendum", schema = "public", indexes = {
        @Index(name = "rel_addendum_fk", columnList = "employee_contract_id")
})
public class Addendum implements Serializable {
    private static final long serialVersionUID = 1053641661754790039L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "addendum_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id", nullable = false)
    private EmployeeContract employeeContract;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Size(max = 255)
    @Column(name = "remarks")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}