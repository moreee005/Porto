package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.config.JwtService;
import com.tujuhsembilan.hrms.employee.config.UserInfoDetails;
import com.tujuhsembilan.hrms.employee.dto.request.LoginRequest;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.dto.response.LoginResponse;
import com.tujuhsembilan.hrms.employee.helpers.Response;
import com.tujuhsembilan.hrms.employee.model.Users;
import com.tujuhsembilan.hrms.employee.repositories.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class UsersService implements UserDetailsService {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UsersRepo usersRepo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<Users> user = usersRepo.findByEmail(email);
        if (user.isPresent()) {
            return user.map(UserInfoDetails::new)
                    .orElseThrow(() -> new UsernameNotFoundException("Email " + email + " not found"));
        }
        throw new UsernameNotFoundException("Email " + email + " not found");
    }

    public ResponseEntity<BaseResponse> login(LoginRequest loginRequest) {
        Optional<Users> user = usersRepo.findByEmail(loginRequest.getEmail());
        if (user.isPresent()) {
            if (user.get().getPassword().equals(loginRequest.getPassword())) {
//                String encrypt = CryptUtils.encryptDecrypt(loginRequest.getPassword(), "encrypt");

                LoginResponse loginResponse = new LoginResponse();
                loginResponse.setAccessToken(jwtService.generateToken(user.get().getId(), user.get().getEmail()));
                loginResponse.setRole(user.get().getRole());

                return Response.success(loginResponse);
            } else {
                return Response.Unauthorized("Email or password is incorrect. Please try again.");
            }
        }
        return Response.notFound("Data Not Found");
    }

    public ResponseEntity<BaseResponse> getUserById(UUID id) {
        Optional<Users> user = usersRepo.findById(id);
        if (user.isPresent()) {
            return Response.success(user);
        }
        return Response.notFound();
    }


}
