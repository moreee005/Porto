package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OtherAllowance {
    @NotNull(message = "Allowance type cannot be null")
    @Positive(message = "Allowance type level must be a positive number")
    private Integer allowanceType;

    @PositiveOrZero(message = "Nominal must be a positive value or zero")
    private BigDecimal nominal;
}
