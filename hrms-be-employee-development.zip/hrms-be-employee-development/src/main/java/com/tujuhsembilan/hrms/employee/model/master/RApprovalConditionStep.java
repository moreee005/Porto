package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Approval_Condition_Step")
@Table(name = "r_approval_condition_step", schema = "master", indexes = {
        @Index(name = "rel_flow_step_fk2", columnList = "approval_condition_id")
})
public class RApprovalConditionStep implements Serializable {
    private static final long serialVersionUID = 6709111314593467890L;
    @Id
    @Column(name = "approval_condition_step_id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "approval_condition_id")
    private RApprovalCondition approvalCondition;

    @NotNull
    @Column(name = "step_order", nullable = false)
    private Short stepOrder;

    @Size(max = 50)
    @NotNull
    @Column(name = "approver_role", nullable = false, length = 50)
    private String approverRole;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}