package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RAllowanceType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Addendum_Allowance_New")
@Table(name = "addendum_allowance_new", schema = "public", indexes = {
        @Index(name = "rel_add_alltype_fk", columnList = "allowance_type_id"),
        @Index(name = "rel_add_allownew_fk", columnList = "addendum_id"),
        @Index(name = "rel_empctr_allnew_fk", columnList = "employee_contract_id")
})
public class AddendumAllowanceNew implements Serializable {
    private static final long serialVersionUID = -6773949567470263728L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "addendum_allowance_new_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "allowance_type_id")
    private RAllowanceType allowanceType;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "addendum_id")
    private Addendum addendum;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "amount", precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}