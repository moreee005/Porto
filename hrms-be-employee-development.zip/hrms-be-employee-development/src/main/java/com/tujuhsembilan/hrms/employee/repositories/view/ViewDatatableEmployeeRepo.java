package com.tujuhsembilan.hrms.employee.repositories.view;

import com.tujuhsembilan.hrms.employee.model.view.ViewDatatableEmployee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ViewDatatableEmployeeRepo extends JpaRepository<ViewDatatableEmployee, UUID> {

    @Query("""
        SELECT view FROM View_Datatable_Employee view WHERE
        ((:search IS NULL OR :search = '') OR LOWER(view.fullname) like concat('%', :search, '%')) AND
        (:contract IS NULL OR view.contractTypeId = :contract) AND
        (:position IS NULL OR view.positionId = :position) AND 
        (:placement IS NULL OR view.placementTypeId = :placement) AND 
        ((:dateOfBirth IS NULL OR :dateOfBirth = '') OR view.dateOfBirthStr = :dateOfBirth) AND 
        (:bankPlacementAgreement IS NULL OR view.bankingPlacementId = :bankPlacementAgreement)
    """)
    Page<ViewDatatableEmployee> datatableEmployeeByFilter(@Param("search") String search,
                                                          @Param("contract") Integer contract,
                                                          @Param("position") Integer position,
                                                          @Param("placement") Integer placement,
                                                          @Param("dateOfBirth") String dateOfBirth,
                                                          @Param("bankPlacementAgreement") Integer bankPlacementAgreement,
                                                          Pageable pageable);

    @Query(value = "SELECT view FROM View_Datatable_Employee view WHERE" +
            "(:contract IS NULL OR view.contractTypeId = :contract) AND" +
            "(:position IS NULL OR view.positionId = :position) AND " +
            "(:placement IS NULL OR view.placementTypeId = :placement) AND " +
            "((:dateOfBirth IS NULL OR :dateOfBirth = '') OR view.dateOfBirthStr = :dateOfBirth) AND " +
            "(:bankPlacementAgreement IS NULL OR view.bankingPlacementId = :bankPlacementAgreement)")
    List<ViewDatatableEmployee> datatableEmployeeByFilter(@Param("contract") Integer contract,
                                                          @Param("position") Integer position,
                                                          @Param("placement") Integer placement,
                                                          @Param("dateOfBirth") String dateOfBirth,
                                                          @Param("bankPlacementAgreement") Integer bankPlacementAgreement);

}
