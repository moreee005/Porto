package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, UUID> {
    Optional<Employee> findByEmailAndDeletedAtNull(String email);

    // EmployeeRepository.java
    @Query("SELECT COUNT(e) FROM Employee e WHERE YEAR(e.joinDate) = :year AND e.deletedAt IS NULL")
    Integer countEmployeeByYear(@Param("year") int year);

}
