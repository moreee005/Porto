package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.AddendumAllowanceRemoval;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddendumAllowanceRemovalRepo extends JpaRepository<AddendumAllowanceRemoval, UUID> {
}
