package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class SiblingsResponse {

    private String idSibling;
    private String gender;
    private String dateOfBirth;
    private String occupation;
    private String educationLevel;

    public SiblingsResponse(String idSibling, String gender, String dateOfBirth, String occupation, String educationLevel) {
        this.idSibling = idSibling;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.occupation = occupation;
        this.educationLevel = educationLevel;
    }

}
