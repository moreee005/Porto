package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Contract_Document")
@Table(name = "contract_document", schema = "public", indexes = {
        @Index(name = "rel_contract_doc_fk", columnList = "employee_contract_id")
})
public class ContractDocument implements Serializable {
    private static final long serialVersionUID = 6057258275838233921L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "contract_doc_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Size(max = 100)
    @NotNull
    @Column(name = "doc_filename", nullable = false, length = 100)
    private String docFilename;

    @NotNull
    @Column(name = "upload_date", nullable = false)
    private LocalDateTime uploadDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @Size(max = 100)
    @Column(name = "doc_type", length = 100)
    private String docType;

}