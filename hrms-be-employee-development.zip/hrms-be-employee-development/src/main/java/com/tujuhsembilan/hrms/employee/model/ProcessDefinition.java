package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Process_Definition")
@Table(name = "process_definition", schema = "public")
public class ProcessDefinition implements Serializable {
    private static final long serialVersionUID = -3909238673216905381L;
    @Id
    @Size(max = 50)
    @Column(name = "proc_def_key", nullable = false, length = 50)
    private String procDefKey;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @OneToMany(mappedBy = "procDefKey")
    private Set<ProcessInstance> processInstances = new LinkedHashSet<>();

}