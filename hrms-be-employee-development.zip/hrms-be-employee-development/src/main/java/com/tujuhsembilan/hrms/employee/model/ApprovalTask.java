package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RApprovalStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Approval_Task")
@Table(name = "approval_task", schema = "public", indexes = {
        @Index(name = "rel_step_status_fk", columnList = "approval_status_id"),
        @Index(name = "rel_approval_step_fk", columnList = "approval_id")
})
public class ApprovalTask implements Serializable {
    private static final long serialVersionUID = -993108483114569899L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "approval_task_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "approval_status_id")
    private RApprovalStatus approvalStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "approval_id")
    private ContractApproval approval;

    @Column(name = "step_order")
    private Short stepOrder;

    @Column(name = "decision_date")
    private LocalDateTime decisionDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @Size(max = 255)
    @Column(name = "remarks")
    private String remarks;

    @Size(max = 50)
    @Column(name = "stage", length = 50)
    private String stage;

}