package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class DetailDataEmployeeResponse {

    private EmployeeDetail employeeDetail;
    private ContractInfoResponse contractInfo;
    private List<PlacementAllowanceResponse> placementAllowance;
    private List<PlacementAllowanceResponse> otherAllowance;

}
