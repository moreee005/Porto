package com.tujuhsembilan.hrms.employee.dto.request;

import lombok.Data;

@Data
public class EndRequest {

    private String reason;

}
