package com.tujuhsembilan.hrms.employee.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Documents {

    @Valid
    @JsonProperty("socialMedia")
    private List<SocialMediaRequest> socialMediaRequest;
}
