package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class ErrorResponse {
    private String message;
    private String status;

    public ErrorResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public ErrorResponse(int value, String message) {
        this.status = String.valueOf(value);
        this.message = message;
    }
}
