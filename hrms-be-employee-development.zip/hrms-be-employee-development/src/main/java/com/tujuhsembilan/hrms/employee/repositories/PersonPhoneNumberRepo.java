package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.PersonPhoneNumber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PersonPhoneNumberRepo extends JpaRepository<PersonPhoneNumber, UUID> {

    @Query("SELECT ppn FROM Person_Phone_Number ppn WHERE ppn.party.id = :partyId")
    Optional<PersonPhoneNumber> findByPartyId(UUID partyId);
}
