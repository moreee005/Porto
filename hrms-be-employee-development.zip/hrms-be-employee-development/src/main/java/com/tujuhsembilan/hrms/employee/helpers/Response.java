package com.tujuhsembilan.hrms.employee.helpers;

import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

public class Response {

    public static BaseResponse baseResponse(String message, Object data) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage(message);
        res.setData(data);
        return res;
    }

    public static BaseResponse baseResponse(String message) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage(message);
        return res;
    }

    public static Map<String, Object> baseResponseMap(String message) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", HttpStatus.OK.value());
        result.put("message", message);
        result.put("data", null);
        return result;
    }

    public static BaseResponse forbidden(String message) {
        BaseResponse response = new BaseResponse();
        response.setStatus(HttpStatus.FORBIDDEN.value());
        response.setMessage(message);
        return response;
    }

    public static BaseResponse unauthorized(String message) {
        BaseResponse response = new BaseResponse();
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setMessage(message);
        return response;
    }


    public static Map<String, Object> baseResponseMap(String message, Object data) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", HttpStatus.OK.value());
        result.put("message", message);
        result.put("data", data);
        return result;
    }

    public static Map<String, Object> baseResponseInternalServerErrorMap(String message) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.put("message", message);
        result.put("data", null);
        return result;
    }

    public static ResponseEntity<BaseResponse> success() {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage("success");
        res.setData(null);
        return ResponseEntity.ok(res);
    }

    public static ResponseEntity<BaseResponse> success(Object data) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage("success");
        res.setData(data);
        return ResponseEntity.ok(res);
    }

    public static ResponseEntity<BaseResponse> created(Object data) {
        return new ResponseEntity<>(baseResponse("Created", data), HttpStatus.CREATED);
    }

    public static ResponseEntity<BaseResponse> unprocessableEnity(String message) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.UNPROCESSABLE_ENTITY.value());
        res.setMessage(message);
        return ResponseEntity.unprocessableEntity().body(res);
    }

    public static ResponseEntity<BaseResponse> badRequest() {
        BaseResponse res = new BaseResponse();
        res.setMessage("Bad Request");
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<BaseResponse> badRequest(Object data) {
        BaseResponse res = new BaseResponse();
        res.setMessage("Bad Request");
        res.setData(data);
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<Object> badRequestObject(Object data) {
        return ResponseEntity.badRequest().body(baseResponseMap("Bad Request", data));
    }

    public static ResponseEntity<BaseResponse> badRequest(String message) {
        BaseResponse res = new BaseResponse();
        res.setMessage(message);
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<BaseResponse> badRequest(String message, Object data) {
        BaseResponse res = baseResponse(message, data);
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<BaseResponse> notFound(String message) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.NOT_FOUND.value());
        res.setMessage(message);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
    }

    public static ResponseEntity<BaseResponse> notFound() {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.NOT_FOUND.value());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
    }

    public static ResponseEntity<BaseResponse> forbidden() {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.FORBIDDEN.value());
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(res);
    }

    public static ResponseEntity<BaseResponse> Unauthorized(String message) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
        baseResponse.setMessage(message);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(baseResponse);
    }
}
