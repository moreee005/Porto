package com.tujuhsembilan.hrms.employee.dto.request;

import lombok.Data;

@Data
public class NotificationMessageRequest {

    private String type = "Notification";
    private Object payload;

}
