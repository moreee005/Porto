package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.constant.Constant;
import com.tujuhsembilan.hrms.employee.dto.response.DocumentUploadResponse;
import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.helpers.DocumentType;
import com.tujuhsembilan.hrms.employee.helpers.FileValidator;
import com.tujuhsembilan.hrms.employee.model.ContractDocument;
import com.tujuhsembilan.hrms.employee.model.Employee;
import com.tujuhsembilan.hrms.employee.model.EmployeeContract;
import com.tujuhsembilan.hrms.employee.model.EmployeeDocument;
import com.tujuhsembilan.hrms.employee.model.master.RDocumentType;
import io.minio.errors.MinioException;
import lib.minio.MinioSrvc;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Service
@RequiredArgsConstructor
@Slf4j
public class DocumentService {

    @Value("${bucket.minio}")
    private String BUCKET_MINIO;

    private final MessageSource messageSource;
    private final MinioSrvc minioSrvc;
    private final EmployeeService employeeService;
    private final RDcoumentTypeService rDcoumentTypeService;
    private final EmployeeDocumentService employeeDocumentService;
    private final EmployeeContractService employeeContractService;
    private final ContractDocumentService contractDocumentService;
    private final FileValidator fileValidator;

    private String generateSafeFilePath(
            String nik, DocumentType documentType, String fileType) {
        log.debug(
                "Generating safe file path for NIK: {}, DocumentType: {}, FileType: {}",
                nik, documentType, fileType);

        if (nik == null || nik.isEmpty()) {
            log.error("NIK cannot be null or empty");
            throw new BadRequestException("NIK cannot be null or empty");
        }

        String sanitizedNik = nik.replaceAll("[^a-zA-Z0-9]", "");
        String timestamp = LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        String fileName = String.format("%s_%s_%s.%s", sanitizedNik, fileType,
                timestamp, documentType.getExtension());
        String filePath = String.format("%s/%s", sanitizedNik, fileName);

        log.debug("Generated file path: {}", filePath);
        return filePath;
    }

    private DocumentUploadResponse uploadFile(MultipartFile file,
                                              Employee employee, DocumentType expectedType, String fileType) {
        log.info("Starting file validation for employee: {}, DocumentType: {}",
                employee.getNik(), expectedType);
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("File is missing or empty");
        }
        fileValidator.validate(file, expectedType);

        String pathWithFilename =
                generateSafeFilePath(employee.getNik(), expectedType, fileType);
        log.info("Uploading file to Minio with path: {}", pathWithFilename);
        uploadToMinio(file, pathWithFilename);

        String fileUrl = generateMinioLink(pathWithFilename);
        log.info("File uploaded successfully. File URL: {}", fileUrl);

        return DocumentUploadResponse.builder()
                .url(fileUrl)
                .fileName(pathWithFilename)
                .documentType(expectedType.name())
                .build();
    }

    public DocumentUploadResponse uploadDocumentCivilEmployee(
            MultipartFile file, String email, Integer docFileType) {
        log.info(
                "Starting upload for civil employee with email: {}, DocumentType: {}",
                email, docFileType);

        RDocumentType rDocumentType =
                rDcoumentTypeService.findMasterDocumentTypeById(docFileType);
        Employee employee = employeeService.findEmployeeByEmail(email);

        log.debug("Creating EmployeeDocument for employee: {}, DocumentType: {}",
                employee.getNik(), rDocumentType.getName());
        EmployeeDocument employeeDocument =
                EmployeeDocument.builder()
                        .party(employee)
                        .documentType(rDocumentType)
                        .docFilename(generateSafeFilePath(
                                employee.getNik(), DocumentType.PDF, rDocumentType.getName()))
                        .uploadDate(LocalDateTime.now())
                        .build();
        employeeDocumentService.saveNewData(employeeDocument);

        return uploadFile(
                file, employee, DocumentType.PDF, rDocumentType.getName());
    }

    public DocumentUploadResponse uploadProfileImage(
            MultipartFile file, String email) {
        log.info(
                "Starting upload for profile image of employee with email: {}", email);

        Employee employee = employeeService.findEmployeeByEmail(email);
        DocumentType documentType = fileValidator.determineImageType(file);

        String fileType = "PROFILE_PICTURE";
        employee.setPhotoFilename(
                generateSafeFilePath(employee.getNik(), documentType, fileType));

        log.debug("Saving employee data with photo filename: {}",
                employee.getPhotoFilename());
        employeeService.saveEmployeeData(employee);

        return uploadFile(file, employee, documentType, fileType);
    }

    public DocumentUploadResponse uploadEmployeeContract(
            MultipartFile file, String email) {
        log.info("Starting upload for employee contract with email: {}", email);

        Employee employee = employeeService.findEmployeeByEmail(email);
        EmployeeContract employeeContract =
                employeeContractService.findEmployeeContractByEmployee(employee);

        log.debug("Creating ContractDocument for employee: {}, Contract ID: {}",
                employee.getNik(), employeeContract.getId());
        ContractDocument contractDocument =
                ContractDocument.builder()
                        .docType(Constant.CONTRACT)
                        .employeeContract(employeeContract)
                        .docFilename(generateSafeFilePath(
                                employee.getNik(), DocumentType.PDF, "DOCUMENT_CONTRACT"))
                        .uploadDate(LocalDateTime.now())
                        .build();
        contractDocumentService.saveContractDocument(contractDocument);

        return uploadFile(file, employee, DocumentType.PDF, "DOCUMENT_CONTRACT");
    }

    @Retryable(maxAttempts = 3, backoff = @Backoff(delay = 1000, multiplier = 2),
            value = {MinioException.class, IOException.class})
    private void
    uploadToMinio(MultipartFile file, String uniqueFilename) {
        try {
            log.debug("Attempting to upload file to Minio with filename: {}",
                    uniqueFilename);
            minioSrvc.upload(file, BUCKET_MINIO,
                    o
                            -> MinioSrvc.UploadOption.builder().filename(uniqueFilename).build());
            log.info("File uploaded successfully: {}", uniqueFilename);
        } catch (Exception ex) {
            log.error("Upload failed after retries: {}", ex.getMessage());
            throw new InternalServerErrorException("File upload failed");
        }
    }

    private String generateMinioLink(String uniqueFilename) {
        try {
            log.debug("Generating Minio link for file: {}", uniqueFilename);
            return minioSrvc.getLink(
                    BUCKET_MINIO, uniqueFilename, MinioSrvc.DEFAULT_EXPIRY);
        } catch (Exception e) {
            log.error(
                    "Failed to generate Minio link for file: {}", uniqueFilename, e);
            throw new InternalServerErrorException(messageSource.getMessage(
                    "application.document.upload.error.minio.link", null,
                    Locale.getDefault()));
        }
    }
}
