package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Blood_Type")
@Table(name = "r_blood_type", schema = "master")
public class RBloodType implements Serializable {
    private static final long serialVersionUID = -2468830527033871730L;
    @Id
    @Column(name = "blood_type_id", nullable = false)
    private Integer id;

    @Size(max = 3)
    @NotNull
    @Column(name = "blood_type", nullable = false, length = 3)
    private String bloodType;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}