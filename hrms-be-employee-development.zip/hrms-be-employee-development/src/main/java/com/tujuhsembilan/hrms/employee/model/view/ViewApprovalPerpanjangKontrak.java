package com.tujuhsembilan.hrms.employee.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Mapping for DB view
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "View_Approval_Perpanjang_Kontrak")
@Immutable
@Table(name = "view_approval_perpanjang_kontrak", schema = "public")
public class ViewApprovalPerpanjangKontrak implements Serializable {
    private static final long serialVersionUID = -2207386429537117048L;
    @Id
    @Column(name = "approval_id")
    private UUID approvalId;

    @Column(name = "submission_date")
    private LocalDateTime submissionDate;

    @Column(name = "party_id")
    private UUID partyId;

    @Size(max = 100)
    @Column(name = "fullname", length = 100)
    private String fullname;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Size(max = 100)
    @Column(name = "contract_name", length = 100)
    private String contractName;

    @Column(name = "placement_type_id")
    private Integer placementTypeId;

    @Size(max = 100)
    @Column(name = "placement_type_name", length = 100)
    private String placementTypeName;

    @Column(name = "party_type_id")
    private Integer partyTypeId;

    @Size(max = 100)
    @Column(name = "employee_type", length = 100)
    private String employeeType;

    @Column(name = "banking_placement_id")
    private Integer bankingPlacementId;

    @Size(max = 100)
    @Column(name = "banking_placement", length = 100)
    private String bankingPlacement;

    @Column(name = "division_id")
    private Integer divisionId;

    @Size(max = 100)
    @Column(name = "division_name", length = 100)
    private String divisionName;

    @Column(name = "position_id")
    private Integer positionId;

    @Size(max = 100)
    @Column(name = "position_name", length = 100)
    private String positionName;

    @Column(name = "contract_period_id")
    private UUID contractPeriodId;

    @Column(name = "contract_start_date")
    private LocalDateTime contractStartDate;

    @Column(name = "contract_end_date")
    private LocalDateTime contractEndDate;

    @Size(max = 10)
    @Column(name = "generation", length = 10)
    private String generation;

    @Column(name = "current_salary", precision = 10, scale = 2)
    private BigDecimal currentSalary;

}