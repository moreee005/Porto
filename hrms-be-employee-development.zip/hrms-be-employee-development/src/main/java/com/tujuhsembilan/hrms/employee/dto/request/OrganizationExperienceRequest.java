package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrganizationExperienceRequest {

    @NotBlank(message = "Organization name is required")
    @Size(max = 100, message = "Organization name must not exceed 100 characters")
    private String organizationName;

    @NotNull(message = "Start year is required")
    @Min(value = 1900, message = "Start year must be at least 1900")
    @Max(value = 2100, message = "Start year must not exceed 2100")
    private Short startYear;

    @NotBlank(message = "Position is required")
    @Size(max = 100, message = "Position name must not exceed 100 characters")
    private String position;

    @NotNull(message = "City type is required")
    @Positive(message = "City type must be a positive number")
    private Integer cityType;

    @NotBlank(message = "Member count range is required")
    @Size(max = 20, message = "Member count range must not exceed 20 characters")
    private String memberCountRange;

    @NotNull(message = "Duration in months is required")
    @Min(value = 1, message = "Duration must be at least 1 month")
    @Max(value = 120, message = "Duration must not exceed 120 months")
    private Short durationMonths;
}
