package com.tujuhsembilan.hrms.employee.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.Immutable;

import java.io.Serializable;

/**
 * Mapping for DB view
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Emergency_Contact_View")
@Immutable
@Table(name = "emergency_contact_view", schema = "public")
public class EmergencyContactView implements Serializable {
    private static final long serialVersionUID = 4975966873440038214L;
    @Id
    @Size(max = 20)
    @Column(name = "phonenumber", length = 20)
    private String phonenumber;

    @Size(max = 100)
    @Column(name = "name", length = 100)
    private String name;

    @Size(max = 100)
    @Column(name = "relationship", length = 100)
    private String relationship;

}