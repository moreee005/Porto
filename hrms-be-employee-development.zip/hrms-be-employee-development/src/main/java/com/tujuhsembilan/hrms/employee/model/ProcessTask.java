package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Process_Task")
@Table(name = "process_task", schema = "public")
public class ProcessTask implements Serializable {
    private static final long serialVersionUID = -3739347874761528722L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "proc_task_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "proc_inst_id")
    private ProcessInstance procInst;

    @Column(name = "assignee_id")
    private UUID assigneeId;

    @Size(max = 50)
    @Column(name = "task_name", length = 50)
    private String taskName;

    @Column(name = "start_time")
    private OffsetDateTime startTime;

    @Column(name = "end_time")
    private OffsetDateTime endTime;

    @Size(max = 255)
    @Column(name = "comment")
    private String comment;

    @Size(max = 50)
    @Column(name = "action", length = 50)
    private String action;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}