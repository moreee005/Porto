package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.view.ViewDatatableContract;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ViewDatatableContractRepo extends JpaRepository<ViewDatatableContract, UUID> {

    @Query("""
        SELECT view FROM View_Datatable_Contract view WHERE 
        (:contract IS NULL OR view.contractTypeId = :contract) AND
        (:status IS NULL OR view.contractStatusId = :status) AND
        ((:endDate IS NULL OR :endDate = '') OR view.endDateStr = :endDate) AND 
        ((:search IS NULL OR :search = '') OR LOWER(view.fullname) LIKE CONCAT('%', :search ,'%') )
    """)
    Page<ViewDatatableContract> datatableContractByFilter(@Param("contract") Integer contract,
                                                          @Param("status") Integer status,
                                                          @Param("endDate") String endDate,
                                                          @Param("search") String search,
                                                          Pageable pageable);

//    @Query(value = "SELECT view FROM ViewDatatableContract view")
//    Page<ViewDatatableContract> datatableContractByFilter(@Param("contract") Integer contract,
//                                                          @Param("status") Integer status,
//                                                          @Param("endDate") String endDate,
//                                                          Pageable pageable);

}
