package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContractInformationDetails {

    @NotNull(message = "Contract status type cannot be null")
    private Integer contractStatusType;

    // Placement Type is optional
    private Integer placementType;

    @NotNull(message = "Employee type cannot be null")
    private Integer employeeType;

    // Bank or Insurance Agreement Type is optional
    private Integer bankOrIssuranceAgreementType;

    @NotNull(message = "Division type cannot be null")
    private Integer divisionType;

    // Position Type is optional
    private Integer positionType;

    @NotNull(message = "Start date of contract status cannot be null")
    @PastOrPresent(message = "Start date of contract status must be in the past or present")
    private LocalDateTime contractStartDate;

    @NotNull(message = "End date of contract status cannot be null")
    @FutureOrPresent(message = "End date of contract status must be in the future or present")
    private LocalDateTime contractEndDate;

    private String generationType;

    @DecimalMin(value = "0.01", message = "Salary must be greater than 0")
    private BigDecimal currentSalary;
}
