package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.model.EmployeeDocument;
import com.tujuhsembilan.hrms.employee.repositories.EmployeeDocumentRepo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class EmployeeDocumentService {

    private final EmployeeDocumentRepo employeeDocumentRepo;


    public void saveNewData(EmployeeDocument employeeDocument) {
        try {
            employeeDocumentRepo.save(employeeDocument);
        } catch (Exception e){
            log.error("failed to save new data " + e.getMessage());
            throw new InternalServerErrorException();
        }
    }
}
