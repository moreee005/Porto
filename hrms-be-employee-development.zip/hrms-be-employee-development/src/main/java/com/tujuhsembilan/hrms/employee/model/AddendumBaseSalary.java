package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Addendum_Base_Salary")
@Table(name = "addendum_base_salary", schema = "public", indexes = {
        @Index(name = "rel_empctr_salary_fk", columnList = "employee_contract_id"),
        @Index(name = "rel_add_salary_fk", columnList = "addendum_id")
})
public class AddendumBaseSalary implements Serializable {
    private static final long serialVersionUID = -800054377421312333L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "add_base_salary_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "addendum_id")
    private Addendum addendum;

    @Column(name = "base_salary_old", precision = 10, scale = 2)
    private BigDecimal baseSalaryOld;

    @Column(name = "base_salary_new", precision = 10, scale = 2)
    private BigDecimal baseSalaryNew;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}