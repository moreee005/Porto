package com.tujuhsembilan.hrms.employee.exception;

import org.springframework.http.HttpStatus;

public class NotFoundException extends BaseException {

    public NotFoundException() {
        this.setMessage("Not found");
        this.setHttpStatus(HttpStatus.NOT_FOUND);
    }

    public NotFoundException(String message) {
        this.setMessage(message);
        this.setHttpStatus(HttpStatus.NOT_FOUND);
    }

}
