package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.EmployeeSport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeSportRepo extends JpaRepository<EmployeeSport, UUID> {

    @Query("SELECT es FROM Employee_Sport  es WHERE es.id = :partyId")
    List<EmployeeSport> findByPartyId(@Param("partyId") UUID partyId);

}
