package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RGeography;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Party_Address")
@Table(name = "party_address", schema = "public", indexes = {
        @Index(name = "rel_party_address_fk", columnList = "party_id"),
        @Index(name = "rel_province_fk", columnList = "geography_id")
})
public class PartyAddress implements Serializable {
    private static final long serialVersionUID = 4492196946822760427L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "party_address_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Party party;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "geography_id")
    private RGeography geography;

    @Size(max = 255)
    @Column(name = "address")
    private String address;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}