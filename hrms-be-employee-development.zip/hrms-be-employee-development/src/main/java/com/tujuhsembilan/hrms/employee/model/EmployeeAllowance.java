package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RAllowanceType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Employee_Allowance")
@Table(name = "employee_allowance", schema = "public", indexes = {
        @Index(name = "rel_employee_salary_fk", columnList = "employee_contract_id"),
        @Index(name = "rel_salary_comp_fk", columnList = "allowance_type_id")
})
public class EmployeeAllowance implements Serializable {
    private static final long serialVersionUID = -6633338047574358116L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "employee_allowance_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "employee_contract_id", nullable = false)
    private EmployeeContract employeeContract;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "allowance_type_id")
    private RAllowanceType allowanceType;

    @NotNull
    @Column(name = "amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Size(max = 255)
    @Column(name = "remarks")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}