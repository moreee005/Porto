package com.tujuhsembilan.hrms.employee.controller;

import com.tujuhsembilan.hrms.employee.common.ResourceURL;
import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(ResourceURL.VIEW_EMPLOYEE)
public class ViewEmployeeController {

    @Autowired
    EmployeeService employeeService;

    @GetMapping
    public ResponseEntity<BaseResponse> viewDatatableEmployee(
            @RequestParam(required = false) String  search,
            @RequestParam(required = false) Integer contract,
            @RequestParam(required = false) Integer position,
            @RequestParam(required = false) Integer placement,
            @RequestParam(required = false) String dateOfBirth,
            @RequestParam(required = false) Integer bankPlacementAgreement,
            Pageable pageable) {
        return employeeService.getDatatableEmployee(search, contract, position, placement, dateOfBirth, bankPlacementAgreement, pageable);
    }
}
