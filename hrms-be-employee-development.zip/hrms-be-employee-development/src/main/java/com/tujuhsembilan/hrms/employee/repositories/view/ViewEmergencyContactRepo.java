package com.tujuhsembilan.hrms.employee.repositories.view;

import com.tujuhsembilan.hrms.employee.model.view.EmergencyContactView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ViewEmergencyContactRepo extends JpaRepository <EmergencyContactView, String> {
}
