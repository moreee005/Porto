package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RRangeSalary;
import com.tujuhsembilan.hrms.employee.model.master.RRelationshipType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Person_Relationship")
@Table(name = "person_relationship", schema = "public", indexes = {
        @Index(name = "rel_person_fk", columnList = "party_id"),
        @Index(name = "rel_range_salary_fk", columnList = "range_salary_id"),
        @Index(name = "rel_person_relationship_fk", columnList = "relationship_type_id")
})
public class PersonRelationship implements Serializable {
    private static final long serialVersionUID = -1483520766925139842L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "person_relationship_id", nullable = false)
    private UUID id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Person party;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "related_party_id")
    private Person relatedParty;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "range_salary_id")
    private RRangeSalary rangeSalary;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "relationship_type_id")
    private RRelationshipType relationshipType;

    @Size(max = 50)
    @Column(name = "occupation", length = 50)
    private String occupation;

    @NotNull
    @Column(name = "is_alive", nullable = false)
    private Boolean isAlive = false;

    @Column(name = "is_split_tax")
    private Boolean isSplitTax;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}