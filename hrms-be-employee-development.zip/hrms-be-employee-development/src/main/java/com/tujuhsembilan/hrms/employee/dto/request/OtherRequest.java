package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OtherRequest {
    @NotBlank(message = "Foreign Language Proficiency is required")
    @NotNull(message = "Foreign Language Proficiency cannot be null")
    @Size(min = 2, max = 100, message = "Foreign Language Proficiency must be between 2 and 100 characters")
    private String foreignLanguageProficiency;

    @NotBlank(message = "Hobbies are required")
    @NotNull(message = "Hobbies cannot be null")
    @Size(min = 3, max = 200, message = "Hobbies must be between 3 and 200 characters")
    private String hobbies;

    @NotBlank(message = "Career Interests are required")
    @NotNull(message = "Career Interests cannot be null")
    @Size(min = 3, max = 200, message = "Career Interests must be between 3 and 200 characters")
    private String careerInterests;
}
