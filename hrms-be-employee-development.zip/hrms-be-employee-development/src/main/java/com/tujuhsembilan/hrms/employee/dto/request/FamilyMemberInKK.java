package com.tujuhsembilan.hrms.employee.dto.request;

import com.tujuhsembilan.hrms.employee.common.validation.annotation.ValidGender;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FamilyMemberInKK {

    // Gender validation: must be 'M' (Male) or 'F' (Female)
    @NotNull(message = "Gender is required")
    @ValidGender
    private Character gender;

    @NotNull(message = "Date of birth is required")
    private LocalDateTime dateOfBirth;

    @NotBlank(message = "Occupation is required")
    @Size(max = 100, message = "Occupation must not exceed 100 characters")
    private String occupation;

    @NotNull(message = "Education level is required")
    @Positive(message = "Education level must be a positive number")
    private Integer educationLevel;

    @NotNull(message = "Graduation year is required")
    @Min(value = 1900, message = "Graduation year must be no earlier than 1900")
    @Max(value = 2099, message = "Graduation year must be no later than 2099")
    private Short graduationYear;
}
