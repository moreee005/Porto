package com.tujuhsembilan.hrms.employee.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContractInformation {
    @JsonProperty("details")
    @Valid
    @NotNull
    private ContractInformationDetails contractInformationDetails;

    @JsonProperty("allowance")
    @Valid
    private EmployeeAllowanceRequest employeeAllowanceRequest;

}
