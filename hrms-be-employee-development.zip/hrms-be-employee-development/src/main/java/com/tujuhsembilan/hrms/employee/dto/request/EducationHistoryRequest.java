package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@StartYearBeforeEndYearEducationHistory
public class EducationHistoryRequest {
    @NotBlank(message = "Institution name is required")
    @Size(max = 100, message = "Institution name must not exceed 100 characters")
    private String institutionName;

    @NotNull(message = "Highest education level type is required")
    @Positive(message = "Highest education level type must be a positive number")
    private Integer highestEducationLevelType;

    @NotNull(message = "Major type is required")
    @Positive(message = "Major type must be a positive number")
    private Integer majorType;

    @NotNull(message = "City type is required")
    @Positive(message = "City type must be a positive number")
    private Integer cityType;

    @NotNull(message = "Start year is required")
    @Min(value = 1900, message = "Start year must be at least 1900")
    @Max(value = 2100, message = "Start year must not exceed 2100")
    private Short yearStart;

    @NotNull(message = "End year is required")
    @Min(value = 1900, message = "End year must be at least 1900")
    @Max(value = 2100, message = "End year must not exceed 2100")
    private Short yearEnd;

}
