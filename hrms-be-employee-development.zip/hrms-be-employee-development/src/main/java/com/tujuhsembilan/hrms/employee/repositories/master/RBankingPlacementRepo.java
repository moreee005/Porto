package com.tujuhsembilan.hrms.employee.repositories.master;

import com.tujuhsembilan.hrms.employee.model.master.RBankingPlacement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RBankingPlacementRepo extends JpaRepository<RBankingPlacement, Integer> {
    RBankingPlacement findByName(String name);
}
