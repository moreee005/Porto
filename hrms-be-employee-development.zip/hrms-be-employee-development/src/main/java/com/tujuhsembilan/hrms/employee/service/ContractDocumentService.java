package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.model.ContractDocument;
import com.tujuhsembilan.hrms.employee.repositories.ContractDocumentRepo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class ContractDocumentService {
    private final ContractDocumentRepo contractDocumentRepo;

    public Boolean saveContractDocument(ContractDocument contractDocument) {
        try {
            contractDocumentRepo.save(contractDocument);
            log.info("Contract document saved successfully for document ID: {}", contractDocument.getId());
            return true;
        } catch (Exception e) {
            log.error("Error saving contract document: {}", e.getMessage());
            throw new InternalServerErrorException("Error saving contract document");
        }
    }

}
