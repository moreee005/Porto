package com.tujuhsembilan.hrms.employee.dto.request;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ResignRequest {

    private LocalDateTime resignDate;
    private String reason;

}
