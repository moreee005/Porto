package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.employee.dto.response.DetailDataEmployeeResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class AddendumeService {

    public ResponseEntity<BaseResponse> createAddendum(DetailDataEmployeeResponse req) {
        
        return null;
    }
}
