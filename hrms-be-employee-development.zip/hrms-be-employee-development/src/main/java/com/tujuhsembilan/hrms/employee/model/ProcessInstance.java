package com.tujuhsembilan.hrms.employee.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Process_Instance")
@Table(name = "process_instance", schema = "public")
public class ProcessInstance implements Serializable {
    private static final long serialVersionUID = -8707098672100393563L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "proc_inst_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "proc_def_key")
    private ProcessDefinition procDefKey;

    @Column(name = "submitter_id")
    private UUID submitterId;

    @NotNull
    @Column(name = "start_time", nullable = false)
    private OffsetDateTime startTime;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @OneToMany(mappedBy = "procInst")
    private Set<ProcessTask> processTasks = new LinkedHashSet<>();

}