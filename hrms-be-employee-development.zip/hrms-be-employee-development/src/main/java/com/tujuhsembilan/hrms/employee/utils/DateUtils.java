package com.tujuhsembilan.hrms.employee.utils;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtils {

    public static final String DATE_FORMAT_BIASA = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
    public static final String DATE_FORMAT= "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATE_SIMPLE_FORMAT= "yyyy-MM-dd";
    public static final String DATE_TIME_SIMPLE_FORMAT= "yyyy-MM-dd HH:mm:ss";
    public static final String ddMMyyyy = "dd/MM/yyyy";

    public String getCurrentISODate(Date date) {
        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.format(date);
    }

    public String convertLocalDateTimeFormat1(LocalDateTime date) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(ddMMyyyy);
        return date.format(dtf);
    }

}
