package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.AddendumContractPeriod;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AddendumContractPeriodRepo extends JpaRepository<AddendumContractPeriod, UUID> {
}
