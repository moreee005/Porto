package com.tujuhsembilan.hrms.employee.model.master;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "R_Approval_Condition")
@Table(name = "r_approval_condition", schema = "master")
public class RApprovalCondition implements Serializable {
    private static final long serialVersionUID = 1730279751156722482L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "approval_condition_id", nullable = false)
    private Integer id;

    @Column(name = "min_amount", precision = 10, scale = 2)
    private BigDecimal minAmount;

    @Column(name = "max_amount", precision = 10, scale = 2)
    private BigDecimal maxAmount;

    @NotNull
    @Column(name = "total_step", nullable = false)
    private Short totalStep;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}