package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.PartyAddress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PartyAddressRepo extends JpaRepository<PartyAddress, UUID> {

    @Query("SELECT pa FROM Party_Address pa WHERE pa.party.id = :partyId")
    Optional<PartyAddress> findByPartyId(@Param("partyId") UUID partyId);

}
