package com.tujuhsembilan.hrms.employee.constant;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum Authorities {
    TALENT_ADMINISTRATION("TALENT ADMINISTRATION",
            Arrays.asList("CREATE_EMPLOYEE", "UPDATE_EMPLOYEE", "DELETE_EMPLOYEE")),
    HR_MANAGER("HR MANAGER",
            Arrays.asList("READ_EMPLOYEE", "UPDATE_EMPLOYEE")),
    EMPLOYEE("EMPLOYEE",
            Arrays.asList("READ_PROFILE")),
    ADMIN("ADMIN",
            Arrays.asList("FULL_ACCESS", "CREATE_EMPLOYEE", "UPDATE_EMPLOYEE", "DELETE_EMPLOYEE", "READ_EMPLOYEE"));

    private final String authority;
    private final List<String> permissions;

    Authorities(String authority, List<String> permissions) {
        this.authority = authority;
        this.permissions = permissions;
    }

    public String getAuthority() {
        return authority;
    }

    public List<String> getPermissions() {
        return permissions;
    }

    public static List<String> getAuthoritiesAndPermissionsByRole(String role) {
        try {
            Authorities authorities = Authorities.valueOf(role.toUpperCase().replace(" ", "_"));
            return Stream.concat(
                    Stream.of(authorities.getAuthority()),
                    authorities.getPermissions().stream()
            ).collect(Collectors.toList());
        } catch (IllegalArgumentException e) {
            return Collections.singletonList("DEFAULT");
        }
    }
}