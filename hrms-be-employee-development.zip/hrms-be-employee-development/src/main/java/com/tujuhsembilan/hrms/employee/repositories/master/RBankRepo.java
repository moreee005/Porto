package com.tujuhsembilan.hrms.employee.repositories.master;

import com.tujuhsembilan.hrms.employee.model.master.RBank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RBankRepo extends JpaRepository<RBank, Integer> {
}
