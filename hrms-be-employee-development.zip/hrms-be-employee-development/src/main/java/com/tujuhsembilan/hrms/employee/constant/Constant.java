package com.tujuhsembilan.hrms.employee.constant;

public class Constant {
    public static final String REQUEST_APPROVE_TASK_NAME = "Requested Approve By HC MANAGER";
    public static final String NEW_CONTRACT = "NEW CONTRACT";
    public static final String CONTRACT = "CONTRACT";
}
