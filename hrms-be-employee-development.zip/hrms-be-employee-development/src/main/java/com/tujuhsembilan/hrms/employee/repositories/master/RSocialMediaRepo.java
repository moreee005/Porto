package com.tujuhsembilan.hrms.employee.repositories.master;

import com.tujuhsembilan.hrms.employee.model.master.RSocialMedia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RSocialMediaRepo extends JpaRepository<RSocialMedia, Integer> {
}
