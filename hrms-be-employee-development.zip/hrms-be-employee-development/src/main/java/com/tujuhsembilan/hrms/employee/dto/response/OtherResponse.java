package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class OtherResponse {

    private List<String> foreignLanguageProficiency;
    private List<String> hobbies;
    private String active;

}
