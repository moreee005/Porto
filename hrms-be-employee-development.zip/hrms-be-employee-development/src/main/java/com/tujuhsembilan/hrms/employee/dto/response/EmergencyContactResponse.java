package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class EmergencyContactResponse {

    private String name;
    private String phoneNumber;
    private String relationship;

    public EmergencyContactResponse(String name, String phoneNumber, String relationship) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.relationship = relationship;
    }

}
