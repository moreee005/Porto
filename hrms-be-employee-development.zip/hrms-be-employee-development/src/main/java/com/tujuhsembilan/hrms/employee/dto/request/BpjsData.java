package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BpjsData {

    @Size(min = 20, max = 20, message = "Health BPJS number must be exactly 20 digits long")
    private String healthBpjsNumber;

    @Size(min = 20, max = 20, message = "Employment BPJS number must be exactly 20 digits long")
    private String employmentBpjsNumber;

    @Min(value = 1, message = "Health BPJS class type must be at least 1")
    @Max(value = 3, message = "Health BPJS class type must be at most 3")
    private Short healthBpjsClassType;
}
