package com.tujuhsembilan.hrms.employee.exception;

import org.springframework.http.HttpStatus;

public class BadRequestException extends BaseException {

    public BadRequestException() {
        this.setMessage("Bad Request");
        this.setHttpStatus(HttpStatus.BAD_REQUEST);
    }

    public BadRequestException(String message) {
        this.setMessage(message);
        this.setHttpStatus(HttpStatus.BAD_REQUEST);
    }

}
