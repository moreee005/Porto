package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.REducation;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Person")
@Table(name = "person", schema = "public", indexes = {
        @Index(name = "rel_education_fk", columnList = "education_id")
})
public class Person implements Serializable {
    private static final long serialVersionUID = -3600049734952879030L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "party_id", nullable = false)
    private UUID id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id", nullable = false)
    private Party party;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "education_id")
    private REducation education;

    @Size(max = 100)
    @Column(name = "fullname", length = 100)
    private String fullname;

    @Column(name = "date_of_birth")
    private LocalDateTime dateOfBirth;

    @Column(name = "gender", length = 1)
    private Character gender;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @Column(name = "graduation_year")
    private Short graduationYear;

    @OneToMany(mappedBy = "party")
    private Set<PersonPhoneNumber> personPhoneNumbers = new LinkedHashSet<>();

    @OneToMany(mappedBy = "party")
    private Set<PersonRelationship> personRelationships = new LinkedHashSet<>();

    @OneToMany(mappedBy = "party")
    private Set<Users> users = new LinkedHashSet<>();

}