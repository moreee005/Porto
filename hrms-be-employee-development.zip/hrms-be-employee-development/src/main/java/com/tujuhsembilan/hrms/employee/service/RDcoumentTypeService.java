package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.model.master.RDocumentType;
import com.tujuhsembilan.hrms.employee.repositories.master.RDocumentTypeRepo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class RDcoumentTypeService {

    private final RDocumentTypeRepo rDocumentTypeRepo;

    public RDocumentType findMasterDocumentTypeById(Integer id) {
        try {
            Optional<RDocumentType> rDocumentTypeOptional = rDocumentTypeRepo.findByIdAndDeletedAtNull(id);
            if (rDocumentTypeOptional.isEmpty()){
                log.info("rdocument type not found, ID : " + id);
                throw new BadRequestException();
            }
            return rDocumentTypeOptional.get();
        } catch (Exception e) {
            log.error("error find document type " + e.getMessage());
            throw new InternalServerErrorException();
        }
    }

}
