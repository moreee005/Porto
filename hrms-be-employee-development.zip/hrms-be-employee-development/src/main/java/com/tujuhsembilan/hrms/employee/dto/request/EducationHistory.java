package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EducationHistory {

    @NotNull(message = "Education level is required")
    private Integer educationLevelType;

    @NotBlank(message = "Institution name is required")
    private String institutionName;

    @NotBlank(message = "Major is required")
    private String major;

    @NotNull(message = "Graduation year is required")
    @Min(value = 1900, message = "Graduation year must be valid")
    @Max(value = 2100, message = "Graduation year must be valid")
    private Short graduationYear;
}
