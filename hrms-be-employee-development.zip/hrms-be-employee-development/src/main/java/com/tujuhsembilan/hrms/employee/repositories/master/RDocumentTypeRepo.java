package com.tujuhsembilan.hrms.employee.repositories.master;

import com.tujuhsembilan.hrms.employee.model.master.RDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RDocumentTypeRepo extends JpaRepository<RDocumentType, Integer> {
    Optional<RDocumentType> findByIdAndDeletedAtNull(Integer integer);
}
