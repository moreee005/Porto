package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CivilRegistrationData {

    @NotNull(message = "Civil data cannot be null")
    private CivilData civilData;

    private BpjsData bpjsData; // optional

    @NotNull(message = "Account bank data cannot be null")
    private AccountBank accountBank;
}
