package com.tujuhsembilan.hrms.employee.common;

public class ResourceURL {

    public static final String LOGIN = "/login";
    public static final String REGISTER = "/register";

    public static final String VIEW_EMPLOYEE = "/view-employee";
    public static final String EMPLOYEE = "/employee";

    public static final String DOWNLOAD = "/download";

    public static final String CONTRACT = "/data-contract";

    public static final String DOCUMENT = "/document";
    public static final String UPLOAD_IMAGE_EMPLOYEE = "/upload/profile-image-employee";
    public static final String UPLOAD_DOCUMENT_CONTRACT = "/upload/document-contract";
    public static final String UPLOAD_DOCUMENT_CIVIL = "/upload/document-civil";
    public static final String EMPLOYEE_MANAGEMENT = "/employee-management";

    public static final String ADD =  "/add";

}
