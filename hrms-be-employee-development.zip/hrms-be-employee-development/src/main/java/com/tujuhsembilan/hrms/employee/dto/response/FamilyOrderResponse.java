package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class FamilyOrderResponse {

    private String childNumber;
    private String totalSiblings;

    public FamilyOrderResponse(String childNumber, String totalSiblings) {
        this.childNumber = childNumber;
        this.totalSiblings = totalSiblings;
    }

}
