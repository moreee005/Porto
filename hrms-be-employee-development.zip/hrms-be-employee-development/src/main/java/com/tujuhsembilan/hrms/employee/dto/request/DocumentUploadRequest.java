package com.tujuhsembilan.hrms.employee.dto.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class DocumentUploadRequest {
    private MultipartFile document;
    private String emailEmployee;
    private String documentType;
}