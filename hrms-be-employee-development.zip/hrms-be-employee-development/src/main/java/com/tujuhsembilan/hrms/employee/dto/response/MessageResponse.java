package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MessageResponse {
    private int status;
    private String message;
    private String errorCode;
    private Object data;

}
