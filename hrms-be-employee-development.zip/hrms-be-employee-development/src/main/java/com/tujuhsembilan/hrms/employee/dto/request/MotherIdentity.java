package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MotherIdentity {
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    @Pattern(regexp = "^[a-zA-Z\\s'.-]+$", message = "Name contains invalid characters")
    private String name;

    @Past(message = "Date of birth must be in the past")
    private LocalDateTime dateOfBirth;

    @Positive(message = "Highest education must be a positive number")
    private Integer highestEducation;

    @Size(max = 50, message = "Occupation must not exceed 50 characters")
    @Pattern(regexp = "^[a-zA-Z\\s'-]+$", message = "Occupation contains invalid characters")
    private String occupation;

    @PositiveOrZero(message = "Salary must be a non-negative number")
    private Integer salary; // optional

    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^\\+62\\d{8,15}$", message = "Phone number must start with +62 and be between 8 and 15 digits long")
    private String phoneNumber;

    @NotNull(message = "Status alive is required")
    private Boolean statusAlive;

    @NotBlank(message = "Full address is required")
    @Size(min = 10, max = 255, message = "Address must be between 10 and 255 characters")
    private String address;

    @NotNull(message = "Geographic ID is required")
    @Positive(message = "Geographic ID must be a positive number")
    private Integer geoId;
}
