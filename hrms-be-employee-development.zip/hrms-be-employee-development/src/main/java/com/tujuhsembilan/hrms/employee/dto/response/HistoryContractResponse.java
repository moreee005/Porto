package com.tujuhsembilan.hrms.employee.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HistoryContractResponse {
    private String contract;

    @JsonProperty("contract_document")
    private String contractDocument;

    @JsonProperty("start_date")
    private LocalDateTime startDate;

    @JsonProperty("end_date")
    private LocalDateTime endDate;

    @JsonProperty("bank_insurance_agreement")
    private String bankInsuranceAgreement;

    @JsonProperty("placement")
    private String placement;

    @JsonProperty("allowances")
    private List<AllowanceResponse> allowances;
}