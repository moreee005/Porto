package com.tujuhsembilan.hrms.employee.dto.request;


import jakarta.validation.Valid;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeAllowanceRequest {
    @Valid
    List<PlacementAllowance> placementAllowances;
    @Valid
    List<OtherAllowance> otherAllowances;
}
