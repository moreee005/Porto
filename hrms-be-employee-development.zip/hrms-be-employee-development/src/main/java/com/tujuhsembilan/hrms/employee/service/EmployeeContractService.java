package com.tujuhsembilan.hrms.employee.service;

import com.tujuhsembilan.hrms.employee.config.LocaleResolverConfig;
import com.tujuhsembilan.hrms.employee.dto.request.ExtendContractRequest;
import com.tujuhsembilan.hrms.employee.dto.response.*;
import com.tujuhsembilan.hrms.employee.exception.BadRequestException;
import com.tujuhsembilan.hrms.employee.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.employee.exception.NotFoundException;
import com.tujuhsembilan.hrms.employee.helpers.Response;
import com.tujuhsembilan.hrms.employee.model.*;
import com.tujuhsembilan.hrms.employee.model.master.*;
import com.tujuhsembilan.hrms.employee.model.view.ViewDetailDataKontrak;
import com.tujuhsembilan.hrms.employee.repositories.*;
import com.tujuhsembilan.hrms.employee.repositories.master.*;
import com.tujuhsembilan.hrms.employee.repositories.view.V_DetailDataContractRepo;
import com.tujuhsembilan.hrms.employee.utils.DateUtils;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Slf4j
public class EmployeeContractService {

    @Autowired
    private EmployeeRepo employeeRepo;
    @Autowired
    private EmployeeAllowanceRepo employeeAllowanceRepo;
    @Autowired
    private RAllowanceGroupRepo rAllowanceGroupRepo;
    @Autowired
    private ContractDocumentRepo contractDocumentRepo;
    @Autowired
    private LocaleResolverConfig localeResolverConfig;

    @Autowired
    private V_DetailDataContractRepo vDetailDataContractRepo;
    @Autowired
    private EmployeeContractRepo employeeContractRepo;
    @Autowired
    private RAllowanceTypeRepo allowanceTypeRepo;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    RContractTypeRepo rContractTypeRepo;
    @Autowired
    RContractStatusRepo rContractStatusRepo;
    @Autowired
    RDivisionRepo divisionRepo;
    @Autowired
    RPlacementTypeRepo placementTypeRepo;
    @Autowired
    RBankingPlacementRepo bankPlacementRepo;
    @Autowired
    RPositionRepo positionRepo;
    @Autowired
    PartyRepo partyRepo;
    @Autowired
    RPartyTypeRepo partyTypeRepo;
    @Autowired
    EmailService emailService;

    @Value("${minio.base.url}")
    String minioBaseUrl;


    public EmployeeContract findEmployeeContractByEmployee(Employee employee) {
        try {
            Optional<EmployeeContract> employeeContractOptional = employeeContractRepo.findByParty(employee);
            if (employeeContractOptional.isEmpty()) {
                log.info("employee contract not found ");
                throw new BadRequestException();
            }
            return employeeContractOptional.get();
        } catch (Exception e) {
            log.error("employee contract error " + e.getMessage());
            throw new InternalServerErrorException();
        }
    }

    public ResponseEntity<BaseResponse> getEmployeeContractHistory(UUID employeeId, HttpServletRequest httpServletRequest) {
        try{

            String EMPLOYEE_NOT_FOUND = messageSource.getMessage("employee.not.found", null, localeResolverConfig.resolveLocale(httpServletRequest));
            String CONTRACT_NOT_FOUND = messageSource.getMessage("contract.not.found", null, localeResolverConfig.resolveLocale(httpServletRequest));

            var employee = employeeRepo.findById(employeeId).orElse(null);
            if(employee == null) return Response.notFound(EMPLOYEE_NOT_FOUND);
            var contract = employee.getHistoricEmployeeContracts();
            if(contract.isEmpty()) return Response.notFound(CONTRACT_NOT_FOUND);

            DateUtils dateUtils = new DateUtils();
            List<ContractHistoryResponse> list = new ArrayList<>();
            contract.forEach(c -> {
                var document = contractDocumentRepo.findByContractIdAndStatusContract(c.getId()).orElse(null);
                ContractHistoryResponse contractHistoryResponse = ContractHistoryResponse.builder()
                        .contractId(c.getId().toString())
                        .contract(Objects.requireNonNull(rContractTypeRepo.findById(c.getContractTypeId()).orElse(null)).getName())
                        .contractDocument(document == null ? "" : minioBaseUrl + document.getDocFilename())
                        .bankInsuranceAgreement(employee.getBankingPlacement().getName())
                        .placement(employee.getPlacementType().getName())
                        .startDate(dateUtils.convertLocalDateTimeFormat1(c.getStartDate()))
                        .endDate(dateUtils.convertLocalDateTimeFormat1(c.getEndDate()))
                        .salary(c.getCurrentSalary())
                        .build();

                // add allowance
                var groupAllowanceResponses = getEmployeeAllowanceByContractId(c.getId());
                contractHistoryResponse.setAllowanceGroups(groupAllowanceResponses);

                list.add(contractHistoryResponse);
            });
            return Response.success(list);
        }
        catch(Exception e) {
            return Response.badRequest(e.getMessage());
        }
    }

    public ResponseEntity<MessageResponse> createExtendContract(UUID employeeId, ExtendContractRequest request) {
        try {

            Employee employee = employeeRepo.findById(employeeId).orElseThrow(() -> new NotFoundException("Employee is not found"));
            RContractType contractType = rContractTypeRepo.findFirstByName(request.getContractType());
            RContractStatus contractStatus = rContractStatusRepo.findFirstByName(request.getContractStatus());
            RAllowanceType masterAllowanceType = allowanceTypeRepo.findById(request.getAllowanceTypeId())
                    .orElseThrow(() -> new NotFoundException("Allowance Type not found for ID: " + request.getAllowanceTypeId()));
            List <EmployeeContract> employeeContractRepoId = employeeContractRepo.findByPartyId(employee.getParty().getId());
            RDivision masterDivison = divisionRepo.findByName(request.getDivision());
            RPlacementType masterPlacementType = placementTypeRepo.findByName(request.getPlacementType());
            RBankingPlacement masterBankPlacement = bankPlacementRepo.findByName(request.getBankPlacement());
            RPosition masterPosition = positionRepo.findByName(request.getPosition());
            RPartyType partyType = partyTypeRepo.findByName(request.getJenisKaryawan());


            Party party = Party.builder()
                    .partyType(partyType)
                    .build();


            Party partyResolve = partyRepo.save(party);

            Employee employee1 = Employee.builder()
                    .party(partyResolve)
                    .division(masterDivison)
                    .placementType(masterPlacementType)
                    .bankingPlacement(masterBankPlacement)
                    .generation(request.getGeneration())
                    .position(masterPosition)
                    .build();

            String contractStartDateStr = request.getContractStartDate();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
// Parse ke LocalDate
            LocalDate localDate = LocalDate.parse(contractStartDateStr, formatter);
// Konversi ke LocalDateTime dengan waktu default 00:00:00
            LocalDateTime localDateTime = localDate.atStartOfDay();

            String contractStartDateStr1 = request.getContractStartDate();
            DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
// Parse ke LocalDate
            LocalDate localDate1 = LocalDate.parse(contractStartDateStr1, formatter1);
// Konversi ke LocalDateTime dengan waktu default 00:00:00
            LocalDateTime localDateTime1 = localDate1.atStartOfDay();


            EmployeeContract employeeContract = EmployeeContract.builder()
                    .party(employee)
                    .contractType(contractType)
                    .contractStatus(contractStatus)
                    .startDate(localDateTime)
                    .endDate(localDateTime1)
                    .currentSalary(request.getSalary())
                    .build();


            EmployeeAllowance employeeAllowance = EmployeeAllowance.builder()
                    .amount(request.getAmount())
                    .allowanceType(masterAllowanceType)
                    .employeeContract(employeeContractRepoId.get(1))
                    .build();

            ContractDocument contractDocument = ContractDocument.builder()
                    .docFilename(request.getContractDocumentName())
                    .uploadDate(LocalDateTime.now())
                    .build();






//
//        // todo: menunggu penyesuaian dlu dari sisi table approval
//        Users submitter = employee.getParty().getPerson().getUsers().get(0);
//        MasterApprovalStatus approvalStatus = masterApprovalStatusRepo.findFirstByName("");
//        MasterApprovalType approvalType = masterApprovalTypeRepo.findFirstByName("");
//        ContractApproval contractApproval = ContractApproval.builder()
//                .approvalStatus(approvalStatus)
//                .submitter(submitter)
//                .approvalType(approvalType)
//                .employeeContract(employeeContract)
//                .submissionDate(new Date())
//                .build();
//
//        ApprovalTask approvalTask = ApprovalTask.builder()
//                .approvalStatus(approvalStatus)
//                .contractApproval(contractApproval)
//                .stepOrder(1)
//                .decisionDate(null)
//                .stage("Manager HC")
//                .build();


//            employeeContractRepo.save(employeeContract);
//            contractApprovalRepo.save(contractApproval);
//            approvalTaskRepo.save(approvalTask);
            employeeRepo.save(employee1);
            employeeContractRepo.save(employeeContract);
            employeeAllowanceRepo.save(employeeAllowance);
            contractDocumentRepo.save(contractDocument);

//            sendEmailForApprovalTask();
            MessageResponse response = MessageResponse.builder()
                    .status(200)
                    .message("Data fetched successfully")
                    .errorCode("") // No error
                    .data("success")
                    .build();

            return ResponseEntity.ok(response);
        }
        catch(Exception e) {
            e.printStackTrace();
            MessageResponse errorResponse = MessageResponse.builder()
                    .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                    .message("An error occurred while fetching data")
                    .errorCode("024") // Custom error code
                    .data(null)
                    .build();

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    public ResponseEntity<MessageResponse> sendEmailForApprovalTask(ExtendContractRequest request) {
        try {
            emailService.send(
                    "muriansyah602@gmail.com",
                    "HRMS 79 - Extend Contract" + request.getFullName(),
                    "HRMS 79 - Extend Contract",
                    true
            );

            MessageResponse response = MessageResponse.builder()
                    .status(200)
                    .message("Data fetched successfully")
                    .errorCode("") // No error
                    .data("success")
                    .build();
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            e.printStackTrace();
            MessageResponse errorResponse = MessageResponse.builder()
                    .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                    .message("An error occurred while fetching data")
                    .errorCode("024") // Custom error code
                    .data(null)
                    .build();

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }


    public List<GroupAllowanceResponse> getEmployeeAllowanceByContractId(UUID contractId) {
        List<EmployeeAllowance> allAllowances = employeeAllowanceRepo.findByEmployeeContractId(contractId);
        List<GroupAllowanceResponse> groupAllowanceResponses = new ArrayList<>();
        var allGroupAllowances = rAllowanceGroupRepo.findAll();
        allGroupAllowances.forEach(g -> {
            var group = new GroupAllowanceResponse();
            List<AllowanceResponse> allowanceList = new ArrayList<>();
            allAllowances.stream().filter(x -> x.getAllowanceType().getAllowanceGroup().getName().equalsIgnoreCase(g.getName())).forEach(x-> {
                var allowance = AllowanceResponse.builder()
                        .allowanceId(x.getId().toString())
                        .allowanceType(x.getAllowanceType().getName())
                        .amount(x.getAmount()).build();
                allowanceList.add(allowance);
            });
            group.setGroupName(g.getName());
            group.setAllowances(allowanceList);
            groupAllowanceResponses.add(group);
        });
        return groupAllowanceResponses;
    }

    // func get detail contract
    public ResponseEntity<BaseResponse> getDetailContractById(UUID id) {
        Optional<ViewDetailDataKontrak> dataContract = vDetailDataContractRepo.findById(id);

        if (dataContract.isPresent()) {
            ViewDetailDataKontrak detailData = dataContract.get();
            EmployeeContract idEmployee = employeeContractRepo.findContractByPartyId(detailData.getPartyId());

            // Instansiasi ModelMapper
            ModelMapper modelMapper = new ModelMapper();

            DetailDataEmployeeResponse response = modelMapper.map(detailData, DetailDataEmployeeResponse.class);

            // Membuat EmployeeDetail dan ContractInfoResponse
            EmployeeDetail responseEmployeeDetail = EmployeeDetail.builder()
                    .employeeId(detailData.getPartyId())
                    .fullName(detailData.getFullname())
                    .division(detailData.getDivisionName())
                    .contractStatus(detailData.getContractName())
                    .position(detailData.getPositionName())
                    .build();

            ContractDocument dataDoc = contractDocumentRepo.findByContractId(idEmployee.getId());

            ContractInfoResponse contract = ContractInfoResponse.builder()
                    .status(detailData.getContractName())
                    .placementType(detailData.getPlacementTypeName())
                    .employeeType(detailData.getEmployeeType())
                    .bankPlacement(detailData.getBankingPlacement())
                    .division(detailData.getDivisionName())
                    .position(detailData.getPositionName())
                    .contractStartDate(detailData.getContractStartDate())
                    .contractEndDate(detailData.getContractEndDate())
                    .generation(detailData.getGeneration())
                    .contractDocumentName(dataDoc.getDocFilename())
                    .salary(detailData.getCurrentSalary())
                    .build();

            response.setEmployeeDetail(responseEmployeeDetail);
            response.setContractInfo(contract);

            List<PlacementAllowanceResponse> placementAllowance = new ArrayList<>();
            List<PlacementAllowanceResponse> otherAllowance = new ArrayList<>();

            List<EmployeeAllowance> employeeAllowance = employeeAllowanceRepo.findByEmployeeId(idEmployee.getId());

            for (EmployeeAllowance data : employeeAllowance) {
                PlacementAllowanceResponse dataPlacement = modelMapper.map(data, PlacementAllowanceResponse.class);

                // Jika allowance terkait dengan kontrak yang sama
                if (data.getEmployeeContract().getId().equals(idEmployee.getId())) {
                    Optional<RAllowanceType> allowanceData = allowanceTypeRepo.findById(data.getAllowanceType().getId());
                    dataPlacement.setAllowanceType(allowanceData.get().getName());
                    dataPlacement.setAmount(data.getAmount());

                    if (allowanceData.get().getAllowanceGroup().getId() == 1) {
                        placementAllowance.add(dataPlacement);
                    } else {
                        otherAllowance.add(dataPlacement);
                    }
                }
            }

            response.setPlacementAllowance(placementAllowance);
            response.setOtherAllowance(otherAllowance);

            return Response.success(response);
        }
        return Response.notFound();
    }

}
