package com.tujuhsembilan.hrms.employee.exception;

import org.springframework.http.HttpStatus;

public class UnauthorizedException extends BaseException {
    public UnauthorizedException() {
        this.setMessage("Unauthorized");
        this.setHttpStatus(HttpStatus.UNAUTHORIZED);
    }

    public UnauthorizedException(String message) {
        this.setMessage(message);
        this.setHttpStatus(HttpStatus.UNAUTHORIZED);
    }

}
