package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.Valid;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeAddRequest {
    @Valid
    private PersonalIdentity personalIdentity;

    @Valid
    private ContractInformation contractInformation;

    @Valid
    private CivilRegistrationData civilRegistrationData;

    @Valid
    private Documents documents;
}
