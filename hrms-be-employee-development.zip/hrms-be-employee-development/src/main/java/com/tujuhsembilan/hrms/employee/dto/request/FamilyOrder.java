package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FamilyOrder {

    @NotNull(message = "Child number is required")
    @Min(value = 1, message = "Child number must be at least 1")
    private Integer childNumber;

    @NotNull(message = "Total siblings is required")
    @Min(value = 1, message = "Total siblings must be at least 1")
    private Integer totalSiblings;
}
