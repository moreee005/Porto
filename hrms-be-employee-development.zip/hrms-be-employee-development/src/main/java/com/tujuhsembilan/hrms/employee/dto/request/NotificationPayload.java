package com.tujuhsembilan.hrms.employee.dto.request;

public class NotificationPayload {

    private String date;
    private String type;
    private String title;
    private String message;
    public NotificationPayload(String date, String type, String title, String message) {
        this.date = date;
        this.type = type;
        this.title = title;
        this.message = message;
    }
}
