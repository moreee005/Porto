package com.tujuhsembilan.hrms.employee.common.validation.validator;


import com.tujuhsembilan.hrms.employee.common.validation.annotation.ValidGender;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class GenderValidator implements ConstraintValidator<ValidGender, Character> {

    @Override
    public boolean isValid(Character value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        return value == 'M' || value == 'F';
    }
}