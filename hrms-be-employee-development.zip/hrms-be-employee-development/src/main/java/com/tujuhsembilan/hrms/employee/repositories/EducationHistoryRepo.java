package com.tujuhsembilan.hrms.employee.repositories;

import com.tujuhsembilan.hrms.employee.model.EducationHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EducationHistoryRepo extends JpaRepository<EducationHistory, UUID> {

    @Query("SELECT eh FROM Education_History eh WHERE eh.party.id = :partyId ORDER BY eh.graduationYear DESC")
    List<EducationHistory> findByPartyId(@Param("partyId") UUID partyId);

}
