package com.tujuhsembilan.hrms.employee.model;

import com.tujuhsembilan.hrms.employee.model.master.RArt;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "Employee_Art")
@Table(name = "employee_art", schema = "public", indexes = {
        @Index(name = "rel_emp_art_fk", columnList = "party_id"),
        @Index(name = "rel_art_fk", columnList = "art_id")
})
public class EmployeeArt implements Serializable {
    private static final long serialVersionUID = 1689072852191829937L;
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "employee_art_id", nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "party_id")
    private Employee party;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    @JoinColumn(name = "art_id")
    private RArt art;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

}