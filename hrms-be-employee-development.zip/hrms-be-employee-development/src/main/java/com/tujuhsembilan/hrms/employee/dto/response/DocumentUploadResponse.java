package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentUploadResponse {
    private String fileName;
    private String url;
    private String documentType;
}
