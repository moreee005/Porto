package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CivilData {

    @NotNull(message = "NIK cannot be null")
    @Size(min = 16, max = 16, message = "NIK must be exactly 16 characters long")
    private String nik;

    @NotNull(message = "NPWP cannot be null")
    @Size(min = 20, max = 20, message = "NPWP must be exactly 20 characters long")
    private String npwp;

    @NotNull(message = "Status PTKP cannot be null")
    private Integer statusPtkp;
}
