package com.tujuhsembilan.hrms.employee.dto.response;

import lombok.Data;

@Data
public class SpouseIdentityResponse {

    private String partnerName;
    private String partnerAge;
    private String partnerHighestEducation;
    private String partnerOccupation;
    private String partnerSalary;
    private Boolean separateTax;
    private String partnerAddress;

    public SpouseIdentityResponse(String partnerName, String partnerAge, String partnerHighestEducation, String partnerOccupation, String partnerSalary, Boolean separateTax, String partnerAddress) {
        this.partnerName = partnerName;
        this.partnerAge = partnerAge;
        this.partnerHighestEducation = partnerHighestEducation;
        this.partnerOccupation = partnerOccupation;
        this.partnerSalary = partnerSalary;
        this.separateTax = separateTax;
        this.partnerAddress = partnerAddress;
    }

}
