package com.tujuhsembilan.hrms.employee.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmergencyContact {
    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^\\+62\\d{8,15}$", message = "Phone number must start with +62 and be between 8 and 15 digits long")
    private String phoneNumber;

    @NotNull(message = "Relationship is required")
    private Integer relationship;
}
