package lib.minio;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.minio.*;
import io.minio.errors.*;
import io.minio.http.Method;
import io.minio.messages.Item;
import jakarta.servlet.http.HttpServletResponse;
import lib.minio.configuration.property.MinioProp;
import lib.minio.exception.MinioServiceDownloadException;
import lib.minio.exception.MinioServiceUploadException;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MinioSrvc {
  public Long getDefaultExpiry() {
    return DEFAULT_EXPIRY;
  }

  public String getPublicLink(String bucket, String filename, Long expiry) {
    return getLink(bucket, filename, expiry);
  }

  public static final Long DEFAULT_EXPIRY = TimeUnit.HOURS.toSeconds(1);

  private final MinioClient minio;
  private final MinioProp prop;


  private  MessageSource message;

  private String getMessage(String code, Object... args) {
    try {
      return message.getMessage(code, args, Locale.getDefault());
    } catch (Exception e) {
      log.warn("Failed to get message for code: {}", code, e);
      return code;
    }
  }


  private static String bMsg(String bucket) {
    return "bucket " + bucket;
  }

  private static String bfMsg(String bucket, String filename) {
    return bMsg(bucket) + " of file " + filename;
  }

  public String getLink(String bucket, String filename, Long expiry) {
    try {
      return minio.getPresignedObjectUrl(
              GetPresignedObjectUrlArgs.builder()
                      .method(Method.GET)
                      .bucket(bucket)
                      .object(filename)
                      .expiry(Math.toIntExact(expiry), TimeUnit.SECONDS)
                      .build());
    } catch (InvalidKeyException | ErrorResponseException | InsufficientDataException | InternalException
             | InvalidResponseException | NoSuchAlgorithmException | XmlParserException | ServerException
             | IllegalArgumentException | IOException e) {
      String errorMessage = getMessage(prop.getGetErrorMessage(), bfMsg(bucket, filename));
      log.error(errorMessage + ": " + e.getLocalizedMessage(), e);
      throw new MinioServiceDownloadException(errorMessage, e);
    }
  }


  @Data
  public static class ListItem {
    private String objectName;
    private Long size;
    private boolean dir;
    private String versionId;

    @JsonIgnore
    private Item item;

    public ListItem(Item item) {
      this.objectName = item.objectName();
      this.size = item.size();
      this.dir = item.isDir();
      this.versionId = item.versionId();
      this.item = item;
    }
  }

  public List<Object> getList(String bucket) {
    List<Result<Item>> results = new ArrayList<>();
    minio.listObjects(
                    ListObjectsArgs.builder()
                            .bucket(bucket)
                            .recursive(true)
                            .build())
            .forEach(results::add);
    return results.stream().map(t -> {
      try {
        return new ListItem(t.get());
      } catch (InvalidKeyException | ErrorResponseException | IllegalArgumentException | InsufficientDataException
               | InternalException | InvalidResponseException | NoSuchAlgorithmException | ServerException
               | XmlParserException | IOException e) {
        String errorMessage = getMessage(prop.getGetErrorMessage(), bMsg(bucket));
        log.error(errorMessage + ": " + e.getLocalizedMessage(), e);
        return null;
      }
    }).collect(Collectors.toList());
  }

  public void view(HttpServletResponse response, String bucket, String filename, Long expiry) {
    try {
      response.sendRedirect(this.getLink(bucket, filename, expiry));
    } catch (IOException e) {
      String errorMessage = getMessage(prop.getGetErrorMessage(), bfMsg(bucket, filename));
      log.error(errorMessage + ": " + e.getLocalizedMessage(), e);
      throw new MinioServiceDownloadException(errorMessage, e);
    }
  }

  public void view(HttpServletResponse response, String bucket, String filename) {
    this.view(response, bucket, filename, DEFAULT_EXPIRY);
  }

  @Data
  @Builder
  public static class UploadOption {
    private String filename;
  }

  public ObjectWriteResponse upload(MultipartFile file, String bucket, Function<MultipartFile, UploadOption> modifier) {
    UploadOption opt = modifier.apply(file);
    try {
      return minio.putObject(
              PutObjectArgs.builder()
                      .bucket(bucket)
                      .object(opt.filename)
                      .stream(file.getInputStream(), file.getSize(), -1)
                      .contentType(file.getContentType())
                      .build());
    } catch (InvalidKeyException | ErrorResponseException | InsufficientDataException | InternalException
             | InvalidResponseException | NoSuchAlgorithmException | ServerException | XmlParserException
             | IllegalArgumentException | IOException e) {
      String errorMessage = getMessage(prop.getPostErrorMessage(), bfMsg(bucket, opt.filename));
      log.error(errorMessage + ": " + e.getLocalizedMessage(), e);
      throw new MinioServiceUploadException(errorMessage, e);
    }
  }

  public ObjectWriteResponse upload(MultipartFile file, String bucket) {
    return this.upload(file, bucket,
        o -> UploadOption.builder()
            .filename(System.currentTimeMillis() + "_-_"
                + o.getOriginalFilename().replace(" ", "_"))
            .build());
  }

  // ---

  public ObjectWriteResponse upload(InputStream file, String filename, String bucket) {
    try {
      return minio.putObject(
              PutObjectArgs.builder()
                      .bucket(bucket)
                      .object(filename)
                      .stream(file, file.available(), -1)
                      .build());
    } catch (InvalidKeyException | ErrorResponseException | InsufficientDataException | InternalException
             | InvalidResponseException | NoSuchAlgorithmException | ServerException | XmlParserException
             | IllegalArgumentException | IOException e) {
      String errorMessage = getMessage(prop.getPostErrorMessage(), bfMsg(bucket, filename));
      log.error(errorMessage + ": " + e.getLocalizedMessage(), e);
      throw new MinioServiceUploadException(errorMessage, e);
    }
  }
  public InputStream read(String filename, String bucket) throws InvalidKeyException, ErrorResponseException,
      InsufficientDataException, InternalException, InvalidResponseException, NoSuchAlgorithmException, ServerException,
      XmlParserException, IllegalArgumentException, IOException {
    return minio.getObject(GetObjectArgs.builder()
        .bucket(bucket)
        .object(filename)
        .build());
  }

  public void delete(String objName, String bucket) throws InvalidKeyException, ErrorResponseException,
      InsufficientDataException, InternalException, InvalidResponseException, NoSuchAlgorithmException,
      ServerException, XmlParserException, IllegalArgumentException, IOException {
    minio.removeObject(RemoveObjectArgs.builder().bucket(bucket).object(objName).build());
  }

}
