package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "party_address", schema = "public")
public class PartyAddress {

    @Id
    @Column(name = "party_address_id")
    private UUID partyAddressId;

    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "geography_id")
    private Geography geographyId;

    @Column(name = "address")
    private String address;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
