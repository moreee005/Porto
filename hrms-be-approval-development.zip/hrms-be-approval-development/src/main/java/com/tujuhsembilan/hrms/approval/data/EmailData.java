package com.tujuhsembilan.hrms.approval.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.modelmapper.internal.Pair;

import java.io.File;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailData {
    private String[] to;
    private String from;
    private String[] cc;
    private String[] bcc;
    private String subject;
    private String content;
    private Boolean isHtmlFormat = false;
    private Date sentDate;
    private List<Pair<String, File>> attachments;
}
