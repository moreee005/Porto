package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(schema = "master", name = "r_approval_status")
public class ApprovalStatus {

    @Id
    @Column(name = "approval_status_id")
    public Integer approvalStatusId;

    @Column(name = "name")
    public String name;
}
