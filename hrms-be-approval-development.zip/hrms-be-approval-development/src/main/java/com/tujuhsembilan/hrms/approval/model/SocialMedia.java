package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "r_social_media", schema = "master")
public class SocialMedia {

    @Id
    @Column(name = "social_media_id")
    private int socialMediaId;

    @Column(name = "name")
    private String name;

}
