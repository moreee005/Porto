package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class CoursesOrUpgradingResponse {

    private UUID idCourse;
    private String type;
    private String courseName;
    private String city;
    private Integer date;
    private Integer month;
    private Integer year;
    private Integer durationMonths;
    private String institution;
    private String certificateNumber;

    public CoursesOrUpgradingResponse(UUID idCourse, String type, String courseName, String city, Integer date, Integer month, Integer year, Integer durationMonths, String institution, String certificateNumber) {
        this.idCourse = idCourse;
        this.type = type;
        this.courseName = courseName;
        this.city = city;
        this.date = date;
        this.month = month;
        this.year = year;
        this.durationMonths = durationMonths;
        this.institution = institution;
        this.certificateNumber = certificateNumber;
    }

}
