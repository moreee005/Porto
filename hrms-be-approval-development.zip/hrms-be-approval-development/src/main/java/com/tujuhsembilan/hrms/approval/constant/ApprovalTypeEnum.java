package com.tujuhsembilan.hrms.approval.constant;

public enum ApprovalTypeEnum {
    NEW_EMPLOYEE(1),
    EXTEND(2),
    RESIGN(3),
    ADDENDUM(4);

    private Integer status;

    public Integer getStatus() { return this.status; }
    ApprovalTypeEnum(Integer status) { this.status = status; }

}
