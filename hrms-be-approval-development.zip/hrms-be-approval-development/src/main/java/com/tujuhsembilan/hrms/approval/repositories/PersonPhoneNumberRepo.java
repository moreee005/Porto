package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.PersonPhoneNumber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface PersonPhoneNumberRepo extends JpaRepository<PersonPhoneNumber, UUID> {

    @Query("SELECT ppn FROM PersonPhoneNumber ppn WHERE ppn.partyId = :partyId")
    Optional<PersonPhoneNumber> findByPartyId(UUID partyId);
}
