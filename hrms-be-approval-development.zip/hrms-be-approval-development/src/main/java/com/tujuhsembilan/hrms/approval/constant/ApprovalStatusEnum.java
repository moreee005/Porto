package com.tujuhsembilan.hrms.approval.constant;

public enum ApprovalStatusEnum {
    APPROVED(1),
    REJECTED(2),
    PENDING(3);

    private Integer status;

    public Integer getStatus() { return this.status; }
    ApprovalStatusEnum(Integer status) { this.status = status; }

}
