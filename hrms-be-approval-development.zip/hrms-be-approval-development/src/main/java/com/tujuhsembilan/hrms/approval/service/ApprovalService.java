package com.tujuhsembilan.hrms.approval.service;

import com.tujuhsembilan.hrms.approval.config.LocaleResolverConfig;
import com.tujuhsembilan.hrms.approval.constant.ApprovalStatusEnum;
import com.tujuhsembilan.hrms.approval.constant.ApprovalTypeEnum;
import com.tujuhsembilan.hrms.approval.constant.ContractStatusEnum;
import com.tujuhsembilan.hrms.approval.dto.request.ApprovalRejectRequest;
import com.tujuhsembilan.hrms.approval.dto.response.*;
import com.tujuhsembilan.hrms.approval.helpers.Response;
import com.tujuhsembilan.hrms.approval.model.*;
import com.tujuhsembilan.hrms.approval.model.view.V_ApprovalPerpanjangKontrak;
import com.tujuhsembilan.hrms.approval.repositories.*;
import com.tujuhsembilan.hrms.approval.repositories.view.V_ApprovalPerpanjangKontrakRepo;
import com.tujuhsembilan.hrms.approval.utils.DateUtils;
import jakarta.transaction.Transactional;
import lib.minio.MinioSrvc;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ApprovalService {

    @Autowired
    public EmailService emailService;

    @Autowired
    public ApprovalTaskRepo approvalTaskRepo;
    @Autowired
    public ApprovalStatusRepo approvalStatusRepo;
    @Autowired
    public ContractApprovalRepo contractApprovalRepo;
    @Autowired
    public ApprovalTaskLogRepo approvalTaskLogRepo;
    @Autowired
    public ContractApprovalLogRepo contractApprovalLogRepo;

    @Autowired
    private MessageSource messageSource;
    @Autowired
    private LocaleResolverConfig localeResolverConfig;

    @Autowired
    private V_ApprovalPerpanjangKontrakRepo approvalPerpanjangKontrakRepo;

    @Autowired
    private EmployeeAllowanceRepo employeeAllowanceRepo;

    @Autowired
    private AllowanceTypeRepo allowanceTypeRepo;

    @Autowired
    private EmployeeContractRepo employeeContractRepo;

    @Autowired
    private ContractDocumentRepo contractDocumentRepo;
    @Autowired
    private AllowanceGroupRepo allowanceGroupRepo;

    @Autowired
    private HistoricEmployeeContractRepo historicEmployeeContractRepo;

    @Autowired
    private ContractStatusRepo contractStatusRepo;

    @Autowired
    EmployeeRepo employeeRepo;

    @Autowired
    PersonRepo personRepo;

    @Autowired
    PersonRelationshipRepo personRelationshipRepo;

    @Autowired
    PersonPhoneNumberRepo personPhoneNumberRepo;

    @Autowired
    PartyAddressRepo partyAddressRepo;

    @Autowired
    EducationHistoryRepo educationHistoryRepo;

    @Autowired
    EmployeeCourseRepo employeeCourseRepo;

    @Autowired
    WorkExperienceRepo workExperienceRepo;

    @Autowired
    OrganizationExperienceRepo organizationExperienceRepo;

    @Autowired
    EmployeeArtRepo employeeArtRepo;

    @Autowired
    EmployeeSportRepo employeeSportRepo;

    @Autowired
    EmployeeMetadataRepo employeeMetadataRepo;
    @Autowired
    EmployeeResignationRepo employeeResignationRepo;

    @Autowired
    MinioSrvc minioSrvc;

    @Value("${bucket.minio}")
    private String BUCKET_MINIO;

    public ResponseEntity<BaseResponse> getApprovalById(UUID id) {

        return Response.success();
    }

    public ResponseEntity<BaseResponse> approved(UUID id) {
        return changeApprovalStatus(id, true, "");
    }
    public ResponseEntity<BaseResponse> rejected(UUID id, ApprovalRejectRequest request) {
        return changeApprovalStatus(id, false, request.getReason());
    }

    public ResponseEntity<BaseResponse> getDetailApprovalTask(UUID id)  {
        try{
            var task = approvalTaskRepo.findById(id).orElse(null);
            if(task == null) return Response.notFound();
            var contractApproval = task.getContractApproval();
            if(contractApproval == null) return Response.notFound();

            // new employee
            if(contractApproval.getApprovalType().getApprovalTypeId().equals(ApprovalTypeEnum.NEW_EMPLOYEE.getStatus())) {
                return getApprovalDetailNewEmployee(id);
            }
            // extend
            else if(contractApproval.getApprovalType().getApprovalTypeId().equals(ApprovalTypeEnum.EXTEND.getStatus())) {
                return getApprovalDetailExtendContract(task.getContractApproval().getApprovalId());
            }
            // resign
            else if(contractApproval.getApprovalType().getApprovalTypeId().equals(ApprovalTypeEnum.RESIGN.getStatus())) {
                return getApprovalDetailResignContract(task.getContractApproval().getApprovalId());
            }
            else throw new Exception("Approval type not found");
        }
        catch(Exception e){
            return Response.badRequest(e.getMessage());
        }
    }

    @Transactional
    public ResponseEntity<BaseResponse> changeApprovalStatus(UUID id, boolean approved, String reason) {

        try {
            //change approval status in approval task
            var approvalTask = approvalTaskRepo.findById(id).orElse(null);
            if(approvalTask == null) return Response.notFound(messageSource.getMessage("approvalTask.notFound", null, Locale.ENGLISH)); //todo : change locale to httpservletrequest later
            var status = approved ? ApprovalStatusEnum.APPROVED : ApprovalStatusEnum.REJECTED;
            approvalTask.setApprovalStatus(approvalStatusRepo.findById(status.getStatus()).get());
            approvalTask.setDecisionDate(new Date());
            approvalTask.setRemarks(reason);
            approvalTaskRepo.save(approvalTask);

            //change approval status in contract approval
            var contractApproval = contractApprovalRepo.findById(approvalTask.getContractApproval().getApprovalId()).orElse(null);
            if(contractApproval == null) return Response.notFound(messageSource.getMessage("contractApproval.notFound", null, Locale.ENGLISH)); //todo : change locale to httpservletrequest later
            contractApproval.setApprovalStatus(approvalStatusRepo.findById(status.getStatus()).get());
            contractApprovalRepo.save(contractApproval);

            //ubah contract status jadi active di table employee_contract
            var contractEmployee = employeeContractRepo.findById(contractApproval.getEmployeeContract().getEmployeeContractId()).orElse(null);
            var historicEmployeeContract = historicEmployeeContractRepo.findById(contractApproval.getEmployeeContract().getEmployeeContractId()).orElse(null);

            if (contractEmployee == null && historicEmployeeContract == null) {
                return Response.notFound(messageSource.getMessage("contractApproval.notFound", null, Locale.ENGLISH));
            }

            // Map the approvalTypeId to the corresponding rejection status
            Map<Integer, ContractStatusEnum> approvalStatusMapping = Map.of(
                    1, ContractStatusEnum.NEW_EMPLOYEE_APPROVAL_REJECTED, // New Employee Approval
                    2, ContractStatusEnum.CONTRACT_EXTENSION_APPROVAL_REJECTED, // Contract Extension Approval
                    3, ContractStatusEnum.RESIGN_CONTRACT_APPROVAL_REJECTED, // Resign Contract Approval
                    4, ContractStatusEnum.ADDENDUM_CONTRACT_APPROVAL_REJECTED // Addendum Contract Approval
            );

            ContractStatus activeStatus = contractStatusRepo.findById(ContractStatusEnum.ACTIVE.getStatus()).get();
            ContractStatusEnum rejectionStatus = approvalStatusMapping.get(contractApproval.getApprovalType().getApprovalTypeId());

            // Set the contract status based on approval status
            if (status == ApprovalStatusEnum.APPROVED) {
                contractEmployee.setContractStatus(activeStatus);
                if(historicEmployeeContract != null) historicEmployeeContract.setContractStatusId((long)activeStatus.getContractStatusId());
            } else if (rejectionStatus != null) {
                contractEmployee.setContractStatus(contractStatusRepo.findById(rejectionStatus.getStatus()).get());
                if(historicEmployeeContract != null) historicEmployeeContract.setContractStatusId((long)contractStatusRepo.findById(rejectionStatus.getStatus()).get().getContractStatusId());
            }

            employeeContractRepo.save(contractEmployee);
            historicEmployeeContractRepo.save(historicEmployeeContract);



            // logging
            var newApprovalTaskLog = ApprovalTaskLog.builder()
                    .recordId(approvalTask.getApprovalTaskId().toString())
                    .operationType("UPDATE")
                    .changedBy("") //TODO: change when login username can be retrieved
                    .changedAt(new Date())
                    .build();
            approvalTaskLogRepo.save(newApprovalTaskLog);

            var newContractApprovalLog = ContractApprovalLog.builder()
                    .recordId(contractApproval.getApprovalId().toString())
                    .operationType("UPDATE")
                    .changedBy("") //TODO: change when login username can be retrieved
                    .changedAt(new Date())
                    .build();
            contractApprovalLogRepo.save(newContractApprovalLog);

            // apakah perlu handler ketika gagal send email?
            // todo: buka komentar di bawah untuk menerapkan mailing
            // pastikan konfigurasi smtp pada properties sudah disesuaikan
            // var emailStatus = emailService.sendEmailForNewEmployeeApproval(contractApproval, approved);

            return Response.success();
        }
        catch (Exception e) {
            return Response.badRequest(e.getMessage());
        }
    }

    // todo : api get detail approve employee perpanjang contract
    public ResponseEntity<BaseResponse> getApprovalDetailExtendContract(UUID id) {
        Optional<V_ApprovalPerpanjangKontrak> dataApproval = approvalPerpanjangKontrakRepo.findById(id);

        if (dataApproval.isPresent()) {
            V_ApprovalPerpanjangKontrak approval = dataApproval.get();
            EmployeeContract idEmployee = employeeContractRepo.findContractByPartyId(approval.getPartyId());

            // Instansiasi ModelMapper
            ModelMapper modelMapper = new ModelMapper();

            ApprovalGetDetailDataResponse response = modelMapper.map(approval, ApprovalGetDetailDataResponse.class);

            // Membuat EmployeeDetail dan ContractInfoResponse
            EmployeeDetail responseEmployeeDetail = EmployeeDetail.builder()
                    .id(approval.getPartyId())
                    .fullName(approval.getFullName())
                    .date(approval.getSubmissionDate())
                    .build();

            List<DocumentResponse> documentResponses = new ArrayList<>();
            List<ContractDocument> dataDoc = contractDocumentRepo.findByContractId(idEmployee.getEmployeeContractId());
            Optional<Employee> employee = employeeRepo.findById(dataApproval.get().getPartyId());
            for(ContractDocument document : dataDoc) {
                String filePath = employee.get().getNik() + "/" + document.getDocFilename();
                documentResponses.add(
                    DocumentResponse.builder()
                        .name(document.getDocFilename())
                        .url(minioSrvc.getLink(BUCKET_MINIO, filePath, minioSrvc.getDefaultExpiry()))
                        .date(document.getUploadDate())
                    .build());
            }

            ContractInfoResponse contract = ContractInfoResponse.builder()
                    .status(approval.getStatus())
                    .placementType(approval.getPlacementTypeName())
                    .employeeType(approval.getEmployeeType())
                    .bankPlacement(approval.getBankingPlacement())
                    .division(approval.getDivisionName())
                    .position(approval.getPosition())
                    .contractStartDate(approval.getContractStartDate())
                    .contractEndDate(approval.getContractEndDate())
                    .generation(approval.getGeneration())
                    .document(documentResponses)
                    .salary(approval.getCurrentSalary())
                    .build();

            response.setEmployeeDetail(responseEmployeeDetail);
            response.setContractInfo(contract);

            List<PlacementAllowance> placementAllowance = new ArrayList<>();
            List<PlacementAllowance> otherAllowance = new ArrayList<>();

            List<EmployeeAllowance> employeeAllowance = employeeAllowanceRepo.findByEmployeeId(idEmployee.getEmployeeContractId());

            for (EmployeeAllowance data : employeeAllowance) {
                PlacementAllowance dataPlacement = modelMapper.map(data, PlacementAllowance.class);

                // Jika allowance terkait dengan kontrak yang sama
                if (data.getEmployeeContractId().getEmployeeContractId().equals(idEmployee.getEmployeeContractId())) {
                    Optional<AllowanceType> allowanceData = allowanceTypeRepo.findById(data.getAllowanceType().getAllowanceTypeId());
                    dataPlacement.setPlacementType(allowanceData.get().getName());
                    dataPlacement.setAmount(data.getAmount());

                    if (allowanceData.get().getAllowanceGroup().getAllowanceGroupId() == 1) {
                        placementAllowance.add(dataPlacement);
                    } else {
                        otherAllowance.add(dataPlacement);
                    }
                }
            }

            response.setPlacementAllowance(placementAllowance);
            response.setOtherAllowance(otherAllowance);

            return Response.success(response);
        }
        return Response.notFound();
    }

    public ResponseEntity<BaseResponse> getApprovalDetailResignContract(UUID id) {
        Optional<V_ApprovalPerpanjangKontrak> dataApproval = approvalPerpanjangKontrakRepo.findById(id);

        if (dataApproval.isPresent()) {
            Optional<Employee> employee = employeeRepo.findById(dataApproval.get().getPartyId());
            V_ApprovalPerpanjangKontrak approval = dataApproval.get();
            EmployeeContract idEmployee = employeeContractRepo.findContractByPartyId(approval.getPartyId());

            // Instansiasi ModelMapper
            ModelMapper modelMapper = new ModelMapper();

            ApprovalGetDetailDataResponse response = modelMapper.map(approval, ApprovalGetDetailDataResponse.class);
            var empResign = employeeResignationRepo.findByEmployeeContractId(idEmployee.getEmployeeContractId()).orElse(null);
            var empResignDoc = contractDocumentRepo.findByContractIdAndResignStatus(idEmployee.getEmployeeContractId()).stream().findFirst().orElse(null);

            // Membuat EmployeeDetail dan ContractInfoResponse
            EmployeeDetail responseEmployeeDetail = EmployeeDetail.builder()
                    .id(approval.getPartyId())
                    .fullName(approval.getFullName())
                    .date(approval.getSubmissionDate())
                    .resignDate(empResign != null ? empResign.getResignDate() : null)
                    .resignDocument(empResignDoc != null ? minioSrvc.getLink(BUCKET_MINIO, employee.get().getNik() + "/" + empResignDoc.getDocFilename(), minioSrvc.getDefaultExpiry()) : "") // link url
                    .resignReason(empResign != null ? empResign.getRemarks() : "")
                    .build();

            List<DocumentResponse> documentResponses = new ArrayList<>();
            List<ContractDocument> dataDoc = contractDocumentRepo.findByContractId(idEmployee.getEmployeeContractId());

            for(ContractDocument document : dataDoc) {
                String filePath = employee.get().getNik() + "/" + document.getDocFilename();
                documentResponses.add(
                        DocumentResponse.builder()
                                .name(document.getDocFilename())
                                .url(minioSrvc.getLink(BUCKET_MINIO, filePath, minioSrvc.getDefaultExpiry()))
                                .date(document.getUploadDate())
                                .build());
            }

            ContractInfoResponse contract = ContractInfoResponse.builder()
                    .status(approval.getStatus())
                    .placementType(approval.getPlacementTypeName())
                    .employeeType(approval.getEmployeeType())
                    .bankPlacement(approval.getBankingPlacement())
                    .division(approval.getDivisionName())
                    .position(approval.getPosition())
                    .contractStartDate(approval.getContractStartDate())
                    .contractEndDate(approval.getContractEndDate())
                    .generation(approval.getGeneration())
                    .document(documentResponses)
                    .salary(approval.getCurrentSalary())
                    .build();

            response.setEmployeeDetail(responseEmployeeDetail);
            response.setContractInfo(contract);

            List<PlacementAllowance> placementAllowance = new ArrayList<>();
            List<PlacementAllowance> otherAllowance = new ArrayList<>();

            List<EmployeeAllowance> employeeAllowance = employeeAllowanceRepo.findByEmployeeId(idEmployee.getEmployeeContractId());

            for (EmployeeAllowance data : employeeAllowance) {
                PlacementAllowance dataPlacement = modelMapper.map(data, PlacementAllowance.class);

                // Jika allowance terkait dengan kontrak yang sama
                if (data.getEmployeeContractId().getEmployeeContractId().equals(idEmployee.getEmployeeContractId())) {
                    Optional<AllowanceType> allowanceData = allowanceTypeRepo.findById(data.getAllowanceType().getAllowanceTypeId());
                    dataPlacement.setPlacementType(allowanceData.get().getName());
                    dataPlacement.setAmount(data.getAmount());

                    if (allowanceData.get().getAllowanceGroup().getAllowanceGroupId() == 1) {
                        placementAllowance.add(dataPlacement);
                    } else {
                        otherAllowance.add(dataPlacement);
                    }
                }
            }

            response.setPlacementAllowance(placementAllowance);
            response.setOtherAllowance(otherAllowance);

            return Response.success(response);
        }
        return Response.notFound();
    }

    public ResponseEntity<BaseResponse> getApprovalDetailNewEmployee(UUID id)  {
        var task = approvalTaskRepo.findById(id).orElse(null);
        if(task == null) return Response.notFound();
        var contractApproval = task.getContractApproval();
        if(contractApproval == null) return Response.notFound();
        var contract = contractApproval.getEmployeeContract();

        Optional<Employee> employeeCheck = employeeRepo.findById(contract.getPartyId().getPartyId());
        if (employeeCheck.isPresent()) {
            var employee = employeeCheck.get();
            PersonalIdentityResponse response = new PersonalIdentityResponse();
            response.setPartyId(id);
            response.setImageUrl(employee.getPhotoFilename());
            Optional<Person> person = personRepo.findById(id);
            person.ifPresent(p -> {
                response.setFullname(p.getFullname());
                response.setGender(p.getGender());
                response.setDateofBirth(p.getDateOfBirth().toString());
            });
            response.setPlaceOfBirth(employee.getPlaceOfBirth());
            response.setEthnicity(employee.getEthnicity().getName());
            response.setReligion(employee.getReligion().getName());
            response.setBloodType(employee.getBloodType().getBloodType());
            response.setMaritalStatus(employee.getMaritalStatus().getName());
            response.setEmail(employee.getEmail());
            response.setPhoneNumber(employee.getPrimaryPhoneNo());

            response.setEmergencyContact(new EmergencyContactResponse(
                    employee.getEmergencyContactName(),
                    employee.getPrimaryPhoneNo(),
                    employee.getEmergencyContactRelation().getName()));
            response.setBackground(employee.getBackground());

            Optional<PartyAddress> partyAddress = partyAddressRepo.findByPartyId(id);
            partyAddress.ifPresent(p -> {
                response.setHomeAddress(new HomeAddressResponse(
                        p.getAddress(),
                        p.getGeographyId().getProvince(),
                        p.getGeographyId().getCity(),
                        p.getGeographyId().getDistrict(),
                        p.getGeographyId().getSubdistrict(),
                        p.getGeographyId().getPostalCode()
                ));
            });

            List<SiblingsResponse> siblings = new ArrayList<>();
            List<FamilyMembersInKkResponse> familyMembersInKk = new ArrayList<>();
            List<PersonRelationship> personRelationships = personRelationshipRepo.findByPartyId(id);
            personRelationships.forEach(personRelationship -> {
                Optional<Person> getPerson = personRepo.findById(personRelationship.getRelatedPartyId());
                Optional<PersonPhoneNumber> getPersonPhone = personPhoneNumberRepo.findByPartyId(id);
                Optional<PartyAddress> partyAddressParent = partyAddressRepo.findByPartyId(personRelationship.getRelatedPartyId());

                getPerson.ifPresent(p -> {
                    List<EducationHistory> educationHistories = educationHistoryRepo.findByPartyId(p.getPartyId());
                    familyMembersInKk.add(new FamilyMembersInKkResponse(
                            p.getPartyId(),
                            p.getGender(),
                            p.getDateOfBirth().toString(),
                            personRelationship.getOccupation(),
                            educationHistories == null ? educationHistories.get(0).getUniversityName() : null,
                            educationHistories == null ? educationHistories.get(0).getAdmissionYear() : null,
                            educationHistories == null ? educationHistories.get(0).getMajorId().getName() : null
                    ));

                    String phoneNo = getPersonPhone.map(PersonPhoneNumber::getPhoneNo).orElse(null);
                    String address = partyAddressParent.map(PartyAddress::getAddress).orElse(null);
                    String province = partyAddressParent.map(pa -> pa.getGeographyId().getProvince()).orElse(null);
                    String city = partyAddressParent.map(pa -> pa.getGeographyId().getCity()).orElse(null);
                    String district = partyAddressParent.map(pa -> pa.getGeographyId().getDistrict()).orElse(null);
                    String subdistrict = partyAddressParent.map(pa -> pa.getGeographyId().getSubdistrict()).orElse(null);
                    String postalCode = partyAddressParent.map(pa -> pa.getGeographyId().getPostalCode()).orElse(null);
                    switch (personRelationship.getRelationshipType().getRelationshipTypeId()) {
                        case 1:
                            response.setFatherIdentity(new FatherIdentityResponse(
                                    p.getFullname(),
                                    p.getDateOfBirth().toString(),
                                    p.getEducationId().getName(),
                                    personRelationship.getOccupation(),
                                    personRelationship.getRangeSalary().getSalary(),
                                    phoneNo,
                                    personRelationship.getIsAlive() ? "Hidup" : "Meninggal",
                                    address,
                                    province,
                                    city,
                                    district,
                                    subdistrict,
                                    postalCode
                            ));
                            break;
                        case 2:
                            response.setMotherIdentity(new MotherIdentityResponse(
                                    p.getFullname(),
                                    p.getDateOfBirth().toString(),
                                    p.getEducationId().getName(),
                                    personRelationship.getOccupation(),
                                    personRelationship.getRangeSalary().getSalary(),
                                    phoneNo,
                                    personRelationship.getIsAlive() ? "Hidup" : "Meninggal",
                                    address
                            ));
                            break;
                        case 3:
                            siblings.add(new SiblingsResponse(
                                    p.getPartyId().toString(),
                                    p.getGender(),
                                    p.getDateOfBirth().toString(),
                                    personRelationship.getOccupation(),
                                    p.getEducationId().getName()
                            ));
                            break;
                        case 4:
                            LocalDate dateOfBirthLocalDate = p.getDateOfBirth().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                            int age = Period.between(dateOfBirthLocalDate, LocalDate.now()).getYears();
                            response.setSpouseIdentity(new SpouseIdentityResponse(
                                    p.getFullname(),
                                    String.valueOf(age),
                                    p.getEducationId().getName(),
                                    personRelationship.getOccupation(),
                                    personRelationship.getRangeSalary().getSalary(),
                                    personRelationship.getIsSplitTax(),
                                    address
                            ));
                            break;
                    }
                });
            });

            response.setSiblings(siblings);
            response.setFamilyMembersInKk(familyMembersInKk);

            List<EducationHistoryResponse> educationHistoryResponses = educationHistoryRepo.findByPartyId(id).stream()
                    .map(educationHistory -> new EducationHistoryResponse(
                            educationHistory.getEducationHistoryId().toString(),
                            educationHistory.getEducationId().getName(),
                            educationHistory.getUniversityName(),
                            educationHistory.getCityId().getCity(),
                            educationHistory.getAdmissionYear(), // start date sekarang cuma disimpan tahunnya
                            "", // belum ada
                            educationHistory.getAdmissionYear(),
                            educationHistory.getGraduationYear()
                    ))
                    .collect(Collectors.toList());
            response.setEducationHistory(educationHistoryResponses);

            List<CoursesOrUpgradingResponse> coursesOrUpgradingResponses = employeeCourseRepo.findByPartyId(id).stream()
                    .map(employeeCourse -> new CoursesOrUpgradingResponse(
                            employeeCourse.getCourseId(),
                            employeeCourse.getCourseType().getName(),
                            employeeCourse.getName(),
                            employeeCourse.getCityId().getCity(),
                            employeeCourse.getDay(),
                            employeeCourse.getMonth(),
                            employeeCourse.getYear(),
                            employeeCourse.getDuration(),
                            employeeCourse.getIssuer(),
                            employeeCourse.getCourseNo()))
                    .collect(Collectors.toList());
            response.setCoursesOrUpgrading(coursesOrUpgradingResponses);

            List<WorkExperienceResponse> workExperienceResponse = workExperienceRepo.findByPartyId(id).stream()
                    .map(workExperience -> new WorkExperienceResponse(
                            workExperience.getWorkExperienceId(),
                            workExperience.getName(),
                            workExperience.getPosition(),
                            workExperience.getCityId().getCity(),
                            workExperience.getStartYear(),
                            workExperience.getEndYear(),
                            workExperience.getDuration()))
                    .collect(Collectors.toList());
            response.setWorkExperience(workExperienceResponse);

            List<OrganizationalLifeResponse> organizationalLife = organizationExperienceRepo.findByPartyId(id).stream()
                    .map(organizationExperience -> new OrganizationalLifeResponse(
                            organizationExperience.getOrganizationExperienceId(),
                            organizationExperience.getName(),
                            organizationExperience.getStartYear(),
                            organizationExperience.getPosition(),
                            organizationExperience.getMemberRange(),
                            organizationExperience.getCityId().getCity(),
                            organizationExperience.getDuration()
                    ))
                    .collect(Collectors.toList());
            response.setOrganizationalLife(organizationalLife);

            List<EmployeeSportResponse> sportList = employeeSportRepo.findByPartyId(id).stream()
                    .map(employeeSport -> new EmployeeSportResponse(
                            employeeSport.getSport().getName(),
                            employeeSport.isActive()
                    ))
                    .collect(Collectors.toList());
            response.setSports(sportList);

            List<EmployeeArtResponse> artList = employeeArtRepo.findByPartyId(id).stream()
                    .map(employeeArt -> new EmployeeArtResponse(
                            employeeArt.getArt().getName(),
                            employeeArt.isActive()
                    ))
                    .collect(Collectors.toList());
            response.setArt(artList);

            List<EmployeeMetadata> metadataList = employeeMetadataRepo.findByPartyId(id);
            List<String> foreignLanguageProficiency = metadataList.stream()
                    .filter(metadata -> "foreign_language".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .collect(Collectors.toList());
            List<String> hobbies = metadataList.stream()
                    .filter(metadata -> "hobby".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .collect(Collectors.toList());
//            List<String> careerInterests = metadataList.stream()
//                    .filter(metadata -> "career_interest".equals(metadata.getKey()))
//                    .map(EmployeeMetadata::getValue)
//                    .collect(Collectors.toList());
            OtherResponse otherResponse = new OtherResponse();
            otherResponse.setForeignLanguageProficiency(foreignLanguageProficiency);
            otherResponse.setHobbies(hobbies);
//            otherResponse.setCareerInterests(careerInterests);
            response.setOther(otherResponse);


            String childNumber = metadataList.stream()
                    .filter(metadata -> "child_no".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .findFirst()
                    .orElse(null);
            String totalSiblings = metadataList.stream()
                    .filter(metadata -> "siblings".equals(metadata.getKey()))
                    .map(EmployeeMetadata::getValue)
                    .findFirst()
                    .orElse(null);
            response.setFamilyOrder(new FamilyOrderResponse(childNumber, totalSiblings));

            // get contract information
            if(contract == null) return Response.notFound();
            var contractInfo = new ContractInformationResponse();
            contractInfo.setStatusName(contract.getContractType().getName());
            contractInfo.setPlacementTypeName(employee.getPlacementType() != null ? employee.getPlacementType().getName() : "");
            contractInfo.setEmployeTypeName(""); //todo: cari tau dari mana
            contractInfo.setWillingToBePlaceInBankOrInsurance( employee.getBankingPlacement() != null ? employee.getBankingPlacement().getName() : "");
            contractInfo.setDivisionName(employee.getDivision() != null ? employee.getDivision().getName() : "");
            contractInfo.setJobPositionName(employee.getPosition() != null ? employee.getPosition().getName() : "");
            DateUtils dateUtils = new DateUtils();
            contractInfo.setContractStartDate(dateUtils.convertLocalDateTimeFormat1(contract.getStartDate()));
            contractInfo.setContractEndDate(dateUtils.convertLocalDateTimeFormat1(contract.getEndDate()));
            var document = contractDocumentRepo.findByContractId(contract.getEmployeeContractId()).stream().findFirst().orElse(null);
            if(document != null) {
                String filePath = employee.getNik() + "/" + document.getDocFilename();
                contractInfo.setContractDocument(ContractDocumentResponse.builder()
                        .documentName(document.getDocFilename())
                        .documentUrl(minioSrvc.getLink(BUCKET_MINIO, filePath, minioSrvc.getDefaultExpiry())) // todo: append with url
                        .build());
            }
            contractInfo.setGeneration(employee.getGeneration());
            contractInfo.setBaseSalary(contract.getCurrentSalary());
            var allowances = getEmployeeAllowanceByContractId(contract.getEmployeeContractId());
            contractInfo.setAllowances(allowances);
            response.setContractInformation(contractInfo);

            // get data kependudukan
            var healthAndFinance = HealthAndFinanceResponse.builder()
                    .nik(employee.getNik())
                    .npwp(employee.getNpwp())
                    .ptkpStatus(employee.getPtkpStatus().getName())
                    .bpjsNumber(employee.getBpjsNo())
                    .bpjsClass(employee.getBpjsClass())
                    .employmentBpjsNumber(employee.getBpjsTkNo())
                    .bankName(employee.getBank().getShortName())
                    .accountNumber(employee.getBankAccountNo())
                    .build();
            response.setHealthAndFinance(healthAndFinance);

            // get employee document
            var empDocument = employee.getEmployeeDocuments();
            List<DocumentEmployeeResponse> documentEmployees = new ArrayList<>();
            empDocument.forEach(x -> {
                var doc = new DocumentEmployeeResponse();
                doc.setDocumentId(x.getEmployeeDocId().toString());
                doc.setDocumentType(x.getDocumentType().getName());
                doc.setDocumentName(x.getDocFilename());
                doc.setDocumentUrl(minioSrvc.getLink(BUCKET_MINIO, employee.getNik() + "/" + x.getDocFilename(), minioSrvc.getDefaultExpiry())); // todo: append with url
                documentEmployees.add(doc);
            });
            response.setDocuments(documentEmployees);

            // social media
            var empSocialMedia = employee.getSocialMedias();
            List<SocialMediaResponse> socialMediaResponses = new ArrayList<>();
            empSocialMedia.forEach(x -> {
                var soc = new SocialMediaResponse();
                soc.setSocialMediaType(x.getSocialMediaType().getName());
                soc.setSocialMediaLink(x.getLink());
                socialMediaResponses.add(soc);
            });
            response.setSocialMedia(socialMediaResponses);

            return Response.success(response);
        }
        return Response.notFound();
    }

    public List<GroupAllowanceResponse> getEmployeeAllowanceByContractId(UUID contractId) {
        List<EmployeeAllowance> allAllowances = employeeAllowanceRepo.findByEmployeeContractId(contractId);
        List<GroupAllowanceResponse> groupAllowanceResponses = new ArrayList<>();
        var allGroupAllowances = allowanceGroupRepo.findAll();
        allGroupAllowances.forEach(g -> {
            var group = new GroupAllowanceResponse();
            List<AllowanceResponse> allowanceList = new ArrayList<>();
            allAllowances.stream().filter(x -> x.getAllowanceType().getAllowanceGroup().getName().equalsIgnoreCase(g.getName())).forEach(x-> {
                var allowance = AllowanceResponse.builder()
                        .allowanceId(x.getEmployeeAllowanceId().toString())
                        .allowanceType(x.getAllowanceType().getName())
                        .amount(x.getAmount()).build();
                allowanceList.add(allowance);
            });
            group.setGroupName(g.getName());
            group.setAllowances(allowanceList);
            groupAllowanceResponses.add(group);
        });
        return groupAllowanceResponses;
    }

}
