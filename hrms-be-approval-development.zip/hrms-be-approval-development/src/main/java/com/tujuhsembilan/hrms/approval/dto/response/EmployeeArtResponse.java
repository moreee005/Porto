package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class EmployeeArtResponse {

    private String name;
    private Boolean isActive;

    public EmployeeArtResponse(String name, Boolean isActive) {
        this.name = name;
        this.isActive = isActive;
    }

}

