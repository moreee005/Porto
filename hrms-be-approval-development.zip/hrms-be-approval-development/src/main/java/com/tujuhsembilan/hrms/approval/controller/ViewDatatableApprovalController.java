package com.tujuhsembilan.hrms.approval.controller;

import com.tujuhsembilan.hrms.approval.common.ResourceURL;
import com.tujuhsembilan.hrms.approval.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.approval.service.ViewDatatableApprovalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(ResourceURL.VIEW_APPROVAL)
public class ViewDatatableApprovalController {

    @Autowired
    ViewDatatableApprovalService viewDatatableApprovalService;

    @GetMapping
    public ResponseEntity<BaseResponse> viewDatatableApproval(@RequestParam(required = false) String search,
                                                              @RequestParam(required = false) Integer contract,
                                                              Pageable pageable) {
        return viewDatatableApprovalService.getDatatableApproval(search, contract, pageable);
    }
}
