package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

@Data
public class DataTableResponse {

    private int draw;
    private long recordsTotal;
    private long recordsFiltered;
    private Object data;

}
