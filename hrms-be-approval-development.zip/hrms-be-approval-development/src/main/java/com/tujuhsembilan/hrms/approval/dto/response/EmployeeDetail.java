package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmployeeDetail {

    private UUID id;
    private String fullName;
    private Date date;
    private Date resignDate;
    private String resignDocument;
    private String resignReason;
}
