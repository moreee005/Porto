package com.tujuhsembilan.hrms.approval.model;

import com.tujuhsembilan.hrms.approval.model.ApprovalStatus;
import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "approval_task")
public class ApprovalTask implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "approval_task_id")
    private UUID approvalTaskId;

    @ManyToOne
    @JoinColumn(name = "approval_status_id")
    private ApprovalStatus approvalStatus;

    @OneToOne
    @JoinColumn(name = "approval_id", referencedColumnName = "approval_id")
    private ContractApproval contractApproval;

    @Column(name = "step_order")
    private Integer stepOrder;

    @Column(name = "decision_date")
    private Date decisionDate;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "stage")
    private String stage;

}
