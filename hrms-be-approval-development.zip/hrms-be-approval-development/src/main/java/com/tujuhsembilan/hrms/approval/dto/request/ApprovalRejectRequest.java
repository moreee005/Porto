package com.tujuhsembilan.hrms.approval.dto.request;

import lombok.Data;

@Data
public class ApprovalRejectRequest {
    private String reason;
}
