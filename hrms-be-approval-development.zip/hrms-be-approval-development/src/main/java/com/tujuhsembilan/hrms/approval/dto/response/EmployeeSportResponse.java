package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class EmployeeSportResponse {

    private String name;
    private Boolean isActive;

    public EmployeeSportResponse(String name, Boolean isActive) {
        this.name = name;
        this.isActive = isActive;
    }

}
