package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.UUID;

@Data
@Entity
@Table(name = "employee_social_media", schema = "public")
public class EmployeeSocialMedia {

    @Id
    @Column(name = "employee_social_media_id")
    private UUID employeeSocialMediaId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "party_id")
    private Employee partyId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "social_media_id")
    private SocialMedia socialMediaType;

    @Column(name = "link")
    private String link;
}
