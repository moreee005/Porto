package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "education_history", schema = "public")
public class EducationHistory {

    @Id
    @Column(name = "education_history_id")
    private UUID educationHistoryId;

    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne
    @JoinColumn(name = "city_id", referencedColumnName = "geography_id")
    private Geography cityId;

    @OneToOne
    @JoinColumn(name = "major_id")
    private Major majorId;

    @OneToOne
    @JoinColumn(name = "education_id")
    private Education educationId;

    @Column(name = "university_name")
    private String universityName;

    @Column(name = "admission_year")
    private Integer admissionYear;

    @Column(name = "graduation_year")
    private Integer graduationYear;

    @Column(name = "deleted_at")
    private Date deletedAt;


}
