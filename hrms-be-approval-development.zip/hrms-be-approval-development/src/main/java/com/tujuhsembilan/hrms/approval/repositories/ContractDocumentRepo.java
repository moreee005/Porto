package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.ContractDocument;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ContractDocumentRepo extends CrudRepository<ContractDocument, UUID> {

    @Query(nativeQuery = true, value = "SELECT * FROM contract_document cd WHERE cd.employee_contract_id = :id")
    List<ContractDocument> findByContractId(@Param("id") UUID contractId);

    @Query(nativeQuery = true, value = "SELECT * FROM contract_document cd WHERE cd.employee_contract_id = :id and doc_type='RESIGN'")
    List<ContractDocument> findByContractIdAndResignStatus(@Param("id") UUID contractId);
}
