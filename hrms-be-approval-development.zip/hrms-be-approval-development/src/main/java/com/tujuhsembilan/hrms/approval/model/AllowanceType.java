package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "r_allowance_type", schema = "master")
public class AllowanceType {

    @Id
    @Column(name = "allowance_type_id")
    private int allowanceTypeId;

    @Column(name = "name")
    private String name;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @OneToOne
    @JoinColumn(name = "allowance_group_id")
    private AllowanceGroup allowanceGroup;
}
