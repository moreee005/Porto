package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

@Data
public class FatherIdentityResponse {

    private String name;
    private String dateOfBirth;
    private String highestEducation;
    private String occupation;
    private String salary;
    private String phoneNumber;
    private String statusAlive;
    private String address;
    private String province;
    private String city;
    private String district;
    private String subdistrict;
    private String postalCode;

    public FatherIdentityResponse(String name, String dateOfBirth, String highestEducation, String occupation, String salary, String phoneNumber, String statusAlive, String address, String province, String city, String district, String subdistrict, String postalCode) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.highestEducation = highestEducation;
        this.occupation = occupation;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
        this.statusAlive = statusAlive;
        this.address = address;
        this.province = province;
        this.city = city;
        this.district = district;
        this.subdistrict = subdistrict;
        this.postalCode = postalCode;
    }
}
