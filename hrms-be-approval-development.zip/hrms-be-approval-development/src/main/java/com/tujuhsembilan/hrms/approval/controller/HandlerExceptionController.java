package com.tujuhsembilan.hrms.approval.controller;

import com.tujuhsembilan.hrms.approval.exception.BaseException;
import com.tujuhsembilan.hrms.approval.exception.InternalServerErrorException;
import com.tujuhsembilan.hrms.approval.exception.NotFoundException;
import jakarta.servlet.http.HttpServletResponse;
import org.hibernate.exception.ConstraintViolationException;
import com.tujuhsembilan.hrms.approval.dto.response.ErrorResponse;
import com.tujuhsembilan.hrms.approval.helpers.Response;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@SuppressWarnings("ALL")
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class HandlerExceptionController extends ResponseEntityExceptionHandler {

    @ExceptionHandler
    public ResponseEntity<ErrorResponse> handleNotFoundException(NotFoundException e) {
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(), e.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }

    @ExceptionHandler
    public ResponseEntity<ErrorResponse> handleInternalServerErrorException(InternalServerErrorException e) {
        ErrorResponse error = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }

    @ExceptionHandler({RuntimeException.class})
    public ResponseEntity<Object> handleRuntimeException(Exception ex) {
        Map<String, Object> response = Response.baseResponseInternalServerErrorMap("Internal Server Error");
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;

        if (ex instanceof BaseException baseEx) {
            status = baseEx.getHttpStatus();
            if (status != HttpStatus.NOT_IMPLEMENTED) {
                response = Response.baseResponseMap(baseEx.getMessage());
            } else {
                response = Response.baseResponseMap("Not Implemented");
            }
        } else if (ex != null) {
            return new ResponseEntity<>(response, status);
        }

        return new ResponseEntity<>(response, status);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public void constraintViolationException(HttpServletResponse response) throws IOException {
        response.sendError(HttpStatus.BAD_REQUEST.value());
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        List<ObjectError> objectErrors = ((BeanPropertyBindingResult) ex.getBindingResult()).getAllErrors();
        List<ErrorResponse> listErr = new ArrayList<>();
        if (!objectErrors.isEmpty()) {
            for (ObjectError obje : objectErrors) {
                FieldError fieldError = (FieldError) obje;
                listErr.add(new ErrorResponse(fieldError.getField(), obje.getDefaultMessage()));
            }
            return Response.badRequestObject(listErr);
        }
        return Response.badRequestObject(ex.getMessage());
    }

}
