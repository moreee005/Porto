package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "person_phone_number", schema = "public")
public class PersonPhoneNumber {

    @Id
    @Column(name = "person_phone_id")
    private UUID personPhoneId;

    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "phone_no")
    private String phoneNo;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
