package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

@Data
public class EducationHistoryResponse {

    private String idEducation;
    private String jenjang;
    private String institutionName;
    private String location;
    private Integer startDate;
    private String month;
    private Integer year;
    private Integer endDate;

    public EducationHistoryResponse(String idEducation, String jenjang, String institutionName, String location, Integer startDate, String month, Integer year, Integer endDate) {
        this.idEducation = idEducation;
        this.jenjang = jenjang;
        this.institutionName = institutionName;
        this.location = location;
        this.startDate = startDate;
        this.month = month;
        this.year = year;
        this.endDate = endDate;
    }

}
