package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "employee_art", schema = "public")
public class EmployeeArt {

    @Id
    @Column(name = "employee_art_id")
    private UUID employeeArtId;

    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne
    @JoinColumn(name = "art_id")
    private Art art;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
