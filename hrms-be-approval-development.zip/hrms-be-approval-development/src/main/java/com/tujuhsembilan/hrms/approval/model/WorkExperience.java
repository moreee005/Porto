package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "work_experience", schema = "public")
public class WorkExperience {

    @Id
    @Column(name = "work_experience_id")
    private UUID workExperienceId;

    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "city_id", referencedColumnName = "geography_id")
    private Geography cityId;

    @Column(name = "name")
    private String name;

    @Column(name = "position")
    private String position;

    @Column(name = "start_year")
    private Integer startYear;

    @Column(name = "end_year")
    private Integer endYear;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @Column(name = "duration")
    private Integer duration;

}
