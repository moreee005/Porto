package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "r_marital_status", schema = "master")
public class MaritalStatus {

    @Id
    @Column(name = "marital_status_id")
    private int maritalStatusId;

    @Column(name = "name")
    private String name;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
