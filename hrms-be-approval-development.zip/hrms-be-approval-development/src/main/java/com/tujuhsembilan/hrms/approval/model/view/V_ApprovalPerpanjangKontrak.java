package com.tujuhsembilan.hrms.approval.model.view;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "view_Approval_perpanjang_kontrak", schema = "public")
public class V_ApprovalPerpanjangKontrak {

    @Id
    @Column(name = "approval_id")
    private UUID approvalId;

    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "fullname")
    private String fullName;

    @Column(name = "submission_date")
    private Date submissionDate;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Column(name = "contract_name")
    private String status;

    @Column(name = "placement_type_id")
    private Integer placementTypeId;

    @Column(name = "placement_type_name")
    private String placementTypeName;

    @Column(name = "party_type_id")
    private Integer partyTypeId;

    @Column(name = "employee_type")
    private String employeeType;

    @Column(name = "banking_placement_id")
    private int bankingPlacementId;

    @Column(name = "banking_placement")
    private String bankingPlacement;

    @Column(name = "division_id")
    private Integer divisionId;

    @Column(name = "division_name")
    private String divisionName;

    @Column(name = "position_id")
    private Integer positionId;

    @Column(name = "position_name")
    private String position;

    @Column(name = "contract_period_id")
    private UUID contractPeriodId;

    @Column(name = "contract_start_date")
    private Date contractStartDate;

    @Column(name = "contract_end_date")
    private Date contractEndDate;

    @Column(name = "generation")
    private String generation;

    @Column(name = "current_salary")
    private BigDecimal currentSalary;


}
