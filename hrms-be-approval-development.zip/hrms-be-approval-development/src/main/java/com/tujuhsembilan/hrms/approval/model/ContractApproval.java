package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "contract_approval")
public class ContractApproval implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "approval_id")
    private UUID approvalId;

    @ManyToOne
    @JoinColumn(name = "approval_status_id", referencedColumnName = "approval_status_id")
    private ApprovalStatus approvalStatus;

    @ManyToOne
    @JoinColumn(name = "submitter_id", referencedColumnName = "user_id")
    private Users submitter;

    @ManyToOne
    @JoinColumn(name = "approval_type_id", referencedColumnName = "approval_type_id")
    private ApprovalType approvalType;

    @ManyToOne
    @JoinColumn(name = "employee_contract_id", referencedColumnName = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "submission_date")
    private Date submissionDate;
}
