package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "r_ethnicity", schema = "master")
public class Ethnicity {

    @Id
    @Column(name = "ethnicity_id")
    private int ethnicityId;

    @Column(name = "name")
    private String name;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
