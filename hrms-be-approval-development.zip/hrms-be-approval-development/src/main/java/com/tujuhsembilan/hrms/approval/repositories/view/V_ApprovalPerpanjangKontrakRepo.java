package com.tujuhsembilan.hrms.approval.repositories.view;

import com.tujuhsembilan.hrms.approval.model.view.V_ApprovalPerpanjangKontrak;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface V_ApprovalPerpanjangKontrakRepo extends JpaRepository<V_ApprovalPerpanjangKontrak, UUID> {
}
