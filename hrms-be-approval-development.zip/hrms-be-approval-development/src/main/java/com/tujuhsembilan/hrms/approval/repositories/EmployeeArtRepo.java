package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.EmployeeArt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeArtRepo extends JpaRepository<EmployeeArt, UUID> {

    @Query("SELECT ea FROM EmployeeArt ea WHERE ea.partyId = :partyId")
    List<EmployeeArt> findByPartyId(@Param("partyId") UUID partyId);

}
