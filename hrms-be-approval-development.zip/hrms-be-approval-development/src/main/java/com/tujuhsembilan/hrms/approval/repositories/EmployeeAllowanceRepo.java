package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.EmployeeAllowance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface EmployeeAllowanceRepo extends JpaRepository<EmployeeAllowance, UUID> {

    @Query(nativeQuery = true ,value = "SELECT * FROM employee_allowance ea WHERE ea.employee_contract_id = :id")
    List<EmployeeAllowance> findByEmployeeId(@Param("id") UUID employeeId);

    @Query(value = """
            select * from employee_allowance where employee_contract_id in (:id)
            """, nativeQuery = true)
    List<EmployeeAllowance> findByEmployeeContractId(@Param("id") UUID id);
}
