package com.tujuhsembilan.hrms.approval.kafka.consumer;

public class KafkaConsumer {

//    @KafkaListener(topics = "notification-message", groupId = "my-group")
//    public void consume(String message) {
//        System.out.println("Consumed message: " + message);
//    }

}
