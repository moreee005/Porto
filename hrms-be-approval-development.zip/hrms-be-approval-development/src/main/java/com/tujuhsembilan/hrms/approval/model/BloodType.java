package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "r_blood_type", schema = "master")
public class BloodType {

    @Id
    @Column(name = "blood_type_id")
    private int bloodTypeId;

    @Column(name = "blood_type")
    private String bloodType;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
