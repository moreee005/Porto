package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "party",schema = "public")
public class Party {

    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "party_type_id")
    private PartyType partyType;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @OneToOne(mappedBy = "party")
    private Person person;
}
