package com.tujuhsembilan.hrms.approval.kafka.producer;

import com.tujuhsembilan.hrms.approval.utils.DateUtils;
import com.tujuhsembilan.hrms.approval.dto.request.NotificationMessageRequest;
import com.tujuhsembilan.hrms.approval.dto.request.NotificationPayload;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class KafkaProducer {

    private static final String TOPIC = "notification-message";

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendNotification(String notificationType, String title, String message) {
        DateUtils dateUtil = new DateUtils();
        NotificationMessageRequest notificationMessageRequest = new NotificationMessageRequest();
        notificationMessageRequest.setPayload(
                new NotificationPayload(
                        dateUtil.getCurrentISODate(new Date()),
                        notificationType,
                        title,
                        message
                )
        );
        kafkaTemplate.send(TOPIC, notificationMessageRequest.toString());
    }

    public void sendInfo(String title, String message) {
        sendNotification("info", title, message);
    }

    public void sendWarning(String title, String message) {
        sendNotification("warning", title, message);
    }

    public void sendError(String title, String message) {
        sendNotification("error", title, message);
    }

    public void sendMessage(String topic, String message) {
        kafkaTemplate.send(topic, message);
    }

}
