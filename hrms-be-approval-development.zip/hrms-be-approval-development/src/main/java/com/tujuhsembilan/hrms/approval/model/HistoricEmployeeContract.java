package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "historic_employee_contract", schema = "public")
public class HistoricEmployeeContract {

    @Id
    @Column(name = "employee_contract_id")
    private UUID employeeContractId;

    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "contract_type_id")
    private Long contractTypeId;

    @Column(name = "contract_status_id")
    private Long contractStatusId;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "end_date")
    private Date endDate;

    @Column(name = "actual_end_date")
    private Date actualEndDate;

    @Column(name = "current_salary")
    private BigDecimal currentSalary;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "deleted_at")
    private Date deletedAt;
}
