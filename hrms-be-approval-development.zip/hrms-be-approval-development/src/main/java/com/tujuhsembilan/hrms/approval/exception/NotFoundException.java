package com.tujuhsembilan.hrms.approval.exception;

public class NotFoundException extends BaseException {

    public NotFoundException() {
        this.setMessage("Not found");
    }

    public NotFoundException(String message) {
        this.setMessage(message);
    }

}
