package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.EmployeeResignation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface EmployeeResignationRepo extends JpaRepository<EmployeeResignation, UUID> {

    @Query(value = """
            select * from employee_resignation where employee_contract_id = :id
            """, nativeQuery = true)
    Optional<EmployeeResignation> findByEmployeeContractId(@Param("id") UUID id);
}

