package com.tujuhsembilan.hrms.approval.common;

public class ResourceURL {

    public static final String LOGIN = "/login";
    public static final String REGISTER = "/register";

    public static final String VIEW_APPROVAL = "/view-approval";
    public static final String APPROVAL = "/approval";

}
