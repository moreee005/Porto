package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.WorkExperience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface WorkExperienceRepo extends JpaRepository<WorkExperience, UUID> {

    @Query("SELECT we FROM WorkExperience we WHERE we.partyId = :partyId")
    List<WorkExperience> findByPartyId(@Param("partyId") UUID partyId);

}
