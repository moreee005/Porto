package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.PersonRelationship;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PersonRelationshipRepo extends JpaRepository<PersonRelationship, UUID> {

    @Query("SELECT pr FROM PersonRelationship pr WHERE pr.partyId = :partyId")
    List<PersonRelationship> findByPartyId(@Param("partyId") UUID partyId);

}
