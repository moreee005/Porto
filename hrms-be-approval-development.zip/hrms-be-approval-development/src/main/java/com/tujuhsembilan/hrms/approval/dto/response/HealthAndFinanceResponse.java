package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HealthAndFinanceResponse {

    private String nik;
    private String npwp;
    private String ptkpStatus;
    private String bpjsNumber;
    private Integer bpjsClass;
    private String employmentBpjsNumber;
    private String bankName;
    private String accountNumber;

}
