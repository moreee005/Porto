package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

@Data
public class MotherIdentityResponse {

    private String name;
    private String dateOfBirth;
    private String highestEducation;
    private String occupation;
    private String motherSalary;
    private String phoneNumber;
    private String statusAlive;
    private String address;

    public MotherIdentityResponse(String name, String dateOfBirth, String highestEducation, String occupation, String motherSalary, String phoneNumber, String statusAlive, String address) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.highestEducation = highestEducation;
        this.occupation = occupation;
        this.motherSalary = motherSalary;
        this.phoneNumber = phoneNumber;
        this.statusAlive = statusAlive;
        this.address = address;
    }

}
