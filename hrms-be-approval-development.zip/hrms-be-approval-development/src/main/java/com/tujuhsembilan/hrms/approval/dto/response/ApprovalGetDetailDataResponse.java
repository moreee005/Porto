package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApprovalGetDetailDataResponse {

    private UUID approvalId;
    private EmployeeDetail employeeDetail;
    private ContractInfoResponse contractInfo;
    private List<PlacementAllowance> placementAllowance;
    private List<PlacementAllowance> otherAllowance;

}
