package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "employee_contract")
public class EmployeeContract implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_contract_id")
    private UUID employeeContractId;

    @ManyToOne
    @JoinColumn(name = "party_id")
    private Employee partyId;

    @OneToOne
    @JoinColumn(name = "contract_type_id")
    private ContractType contractType;

    @OneToOne
    @JoinColumn(name = "contract_status_id")
    private ContractStatus contractStatus;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "actual_end_date")
    private LocalDateTime actualEndDate;

    @Column(name = "current_salary")
    private BigDecimal currentSalary;

    @Column(name = "remarks")
    private String remarks;
}

