package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.EmployeeContract;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.UUID;

public interface EmployeeContractRepo extends JpaRepository<EmployeeContract, UUID> {

    @Query(nativeQuery = true, value = "SELECT * FROM employee_contract ec WHERE ec.party_id = :id")
    EmployeeContract findContractByPartyId(@Param("id") UUID id);
}
