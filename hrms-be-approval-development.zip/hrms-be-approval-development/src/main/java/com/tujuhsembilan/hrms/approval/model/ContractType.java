package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(schema = "master", name = "r_contract_type")
public class ContractType {
    @Id
    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Column(name = "name")
    private String name;
}
