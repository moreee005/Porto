package com.tujuhsembilan.hrms.approval.common;

public class SecurityConstant {

    public static final String APPROVAL = "/approval/**";
    public static final String VIEW_APPROVAL = "/view-approval/**";
}
