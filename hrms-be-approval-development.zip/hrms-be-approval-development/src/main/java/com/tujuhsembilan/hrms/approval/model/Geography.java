package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "r_geography", schema = "master")
public class Geography {

    @Id
    @Column(name = "geography_id")
    private Long geographyId;

    @Column(name = "province")
    private String province;

    @Column(name = "city")
    private String city;

    @Column(name = "district")
    private String district;

    @Column(name = "subdistrict")
    private String subdistrict;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
