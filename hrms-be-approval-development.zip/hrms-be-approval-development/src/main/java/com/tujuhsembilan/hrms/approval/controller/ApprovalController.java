package com.tujuhsembilan.hrms.approval.controller;

import com.tujuhsembilan.hrms.approval.common.ResourceURL;
import com.tujuhsembilan.hrms.approval.dto.request.ApprovalRejectRequest;
import com.tujuhsembilan.hrms.approval.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.approval.service.ApprovalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping(ResourceURL.APPROVAL)
public class ApprovalController {

    @Autowired
    ApprovalService approvalService;

//    @GetMapping("/employee/{partyId}")
//    public ResponseEntity<BaseResponse> getDetailEmployeeApproval(@PathVariable("partyId") UUID partyId) {
//        return approvalService.getDetailByEmployeeById(partyId);
//    }

    @GetMapping("/{approvalTaskId}")
    public ResponseEntity<BaseResponse> getDetailApproval(@PathVariable("approvalTaskId") UUID approvalTaskId) {
        return approvalService.getDetailApprovalTask(approvalTaskId);
    }

//    @GetMapping("/extend/{partyId}")
//    public ResponseEntity<BaseResponse> getDetailEmployeeApprovalExtendContract(@PathVariable("partyId") UUID partyId) {
//        return approvalService.getApprovalDetailExtendContract(partyId);
//    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<BaseResponse> approve(@PathVariable("id") UUID id) {
        return approvalService.approved(id);
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<BaseResponse> reject(@PathVariable("id") UUID id, @RequestBody ApprovalRejectRequest request) {
        return approvalService.rejected(id, request);
    }
}
