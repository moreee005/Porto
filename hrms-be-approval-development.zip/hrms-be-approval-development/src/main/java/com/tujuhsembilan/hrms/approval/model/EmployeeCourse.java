package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "employee_course", schema = "public")
public class EmployeeCourse {

    @Id
    @Column(name = "course_id")
    private UUID courseId;

    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "course_type_id")
    private CourseType courseType;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "city_id", referencedColumnName = "geography_id")
    private Geography cityId;

    @Column(name = "name")
    private String name;

    @Column(name = "course_no")
    private String courseNo;

    @Column(name = "duration")
    private int duration;

    @Column(name = "issuer")
    private String issuer;

    @Column(name = "day")
    private int day;

    @Column(name = "month")
    private int month;

    @Column(name = "year")
    private int year;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
