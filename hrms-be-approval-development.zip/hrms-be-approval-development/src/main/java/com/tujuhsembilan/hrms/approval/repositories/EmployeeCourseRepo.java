package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.EmployeeCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeCourseRepo extends JpaRepository<EmployeeCourse, UUID> {

    @Query("SELECT ec FROM EmployeeCourse ec WHERE ec.partyId = :partyId")
    List<EmployeeCourse> findByPartyId(@Param("partyId") UUID partyId);

}
