package com.tujuhsembilan.hrms.approval.controller;

import com.tujuhsembilan.hrms.approval.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.approval.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("user")
public class UsersController {

    @Autowired
    private UsersService usersService;

    @GetMapping("")
    public ResponseEntity<BaseResponse> getUserById(@RequestParam("id") UUID id) {
        return usersService.getUserById(id);
    }
}
