package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class WorkExperienceResponse {

    private UUID idWorkExperience;
    private String companyName;
    private String position;
    private String city;
    private Integer startYear;
    private Integer endYear;
    private Integer duartionMonths;

    public WorkExperienceResponse(UUID idWorkExperience, String companyName, String position, String city, Integer startYear, Integer endYear, Integer duartionMonths) {
        this.idWorkExperience = idWorkExperience;
        this.companyName = companyName;
        this.position = position;
        this.city = city;
        this.startYear = startYear;
        this.endYear = endYear;
        this.duartionMonths = duartionMonths;
    }

}
