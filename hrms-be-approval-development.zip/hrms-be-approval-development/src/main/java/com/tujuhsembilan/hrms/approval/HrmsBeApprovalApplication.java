package com.tujuhsembilan.hrms.approval;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.tujuhsembilan.hrms.approval","lib.minio"})
public class HrmsBeApprovalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmsBeApprovalApplication.class, args);
	}

}
