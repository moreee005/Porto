package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.ContractApprovalLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContractApprovalLogRepo extends JpaRepository<ContractApprovalLog, Integer> {



}
