package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(schema = "master", name = "r_approval_type")
public class ApprovalType {

    @Id
    @Column(name = "approval_type_id")
    private Integer approvalTypeId;

}
