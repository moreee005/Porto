package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "organization_experience", schema = "public")
public class OrganizationExperience {

    @Id
    @Column(name = "organization_experience_id")
    private UUID organizationExperienceId;

    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne
    @JoinColumn(name = "city_id", referencedColumnName = "geography_id")
    private Geography cityId;

    @Column(name = "name")
    private String name;

    @Column(name = "position")
    private String position;

    @Column(name = "start_year")
    private int startYear;

    @Column(name = "duration")
    private int duration;

    @Column(name = "member_range")
    private String memberRange;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
