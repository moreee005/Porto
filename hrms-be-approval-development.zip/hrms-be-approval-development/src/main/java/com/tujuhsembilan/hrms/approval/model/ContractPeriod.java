package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "contract_period", schema = "public")
public class ContractPeriod {

    @Id
    @Column(name = "contract_period_id")
    private UUID contractEriodId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "contract_type_id")
    private ContractType contractType;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "end_date")
    private Date endDate;

    @Column(name = "deleted_at")
    private Date deletedAt;
}
