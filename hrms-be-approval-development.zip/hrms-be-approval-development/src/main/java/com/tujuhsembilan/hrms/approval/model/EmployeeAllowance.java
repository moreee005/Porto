package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "employee_allowance", schema = "public")
public class EmployeeAllowance {

    @Id
    @Column(name = "employee_allowance_id")
    private UUID employeeAllowanceId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContractId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "allowance_type_id")
    private AllowanceType allowanceType;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "deleted_at")
    private Date deletedAt;


}
