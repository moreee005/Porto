package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(schema = "logging", name = "contract_approval_log")
public class ContractApprovalLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "approval_log_id")
    private Integer approvalLogId;

    @Column(name = "record_id")
    private String recordId;

    @Column(name = "operation_type")
    private String operationType;

    @Column(name = "operation_desc")
    private String operationDesc;

    @Column(name = "changed_by")
    private String changedBy;

    @Column(name = "changedAt")
    private Date changedAt;

}
