package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "person_relationship", schema = "public")
public class PersonRelationship {

    @Id
    @Column(name = "person_relationship_id")
    private UUID personRelationshipId;

    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "related_party_id")
    private UUID relatedPartyId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "range_salary_id")
    private RangeSalary rangeSalary;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "relationship_type_id")
    private RelationshipType relationshipType;

    @Column(name = "occupation")
    private String occupation;

    @Column(name = "is_alive")
    private Boolean isAlive;

    @Column(name = "is_split_tax")
    private Boolean isSplitTax;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
