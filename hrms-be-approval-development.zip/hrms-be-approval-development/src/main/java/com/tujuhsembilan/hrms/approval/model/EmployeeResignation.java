package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "employee_resignation")
public class EmployeeResignation implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_resignation_id")
    private UUID employeeResignationId;

    @OneToOne
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "resign_date")
    private Date resignDate;

    @Column(name = "remarks")
    private String remarks;

}
