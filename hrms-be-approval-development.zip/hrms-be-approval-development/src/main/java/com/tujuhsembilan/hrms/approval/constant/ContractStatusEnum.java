package com.tujuhsembilan.hrms.approval.constant;

public enum ContractStatusEnum {
    ACTIVE(1),
    OFF(2),
    NEW_EMPLOYEE_APPROVAL_REJECTED(9),
    CONTRACT_EXTENSION_APPROVAL_REJECTED(10),
    CONTRACT_END_APPROVAL_REJECTED(11),
    ADDENDUM_CONTRACT_APPROVAL_REJECTED(13),
    RESIGN_CONTRACT_APPROVAL_REJECTED(14);


    private Integer status;

    public Integer getStatus() {
        return this.status;
    }
    ContractStatusEnum(Integer status) {
        this.status = status;
    }
}
