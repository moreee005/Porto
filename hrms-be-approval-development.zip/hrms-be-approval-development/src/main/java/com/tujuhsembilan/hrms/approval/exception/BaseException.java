package com.tujuhsembilan.hrms.approval.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class BaseException extends RuntimeException {

    private String message = "Internal Server Error";
    private Object data = null;
    private HttpStatus httpStatus = null;

}
