package com.tujuhsembilan.hrms.approval.model.view;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "view_datatable_approval", schema = "public")
public class ViewDatatableApproval {

    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "photo_filename")
    private String photoFilename;

    @Column(name = "fullname")
    private String fullname;

    @Column(name = "contract_type_id")
    private Integer contractTypeId;

    @Column(name = "contract_type_name")
    private String contractTypeName;

    @Column(name = "approval_type_id")
    private Integer approvalTypeId;

    @Column(name = "approval_type_name")
    private String approvalTypeName;

    @Column(name = "start_date_str")
    private String startDateStr;

    @Column(name = "end_date_str")
    private String endDateStr;

    @Column(name = "stage")
    private String stage;

    @Column(name = "approval_id")
    private UUID approvalId;

    @Column(name = "approval_task_id")
    private UUID approvalTaskId;

}
