package com.tujuhsembilan.hrms.approval.helpers;

import com.tujuhsembilan.hrms.approval.dto.response.BaseResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

public class Response {

    public static BaseResponse baseResponse(String message, Object data) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage(message);
        res.setData(data);
        return res;
    }

    public static BaseResponse baseResponse(String message) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage(message);
        return res;
    }

    public static Map<String, Object> baseResponseMap(String message) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", HttpStatus.OK.value());
        result.put("message", message);
        result.put("data", null);
        return result;
    }

    public static Map<String, Object> baseResponseMap(String message, Object data) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", HttpStatus.OK.value());
        result.put("message", message);
        result.put("data", data);
        return result;
    }

    public static Map<String, Object> baseResponseInternalServerErrorMap(String message) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        result.put("message", message);
        result.put("data", null);
        return result;
    }

    public static ResponseEntity<BaseResponse> success() {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage("success");
        res.setData(null);
        return ResponseEntity.ok(res);
    }

    public static ResponseEntity<BaseResponse> success(Object data) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.OK.value());
        res.setMessage("success");
        res.setData(data);
        return ResponseEntity.ok(res);
    }

    public static ResponseEntity<BaseResponse> created(Object data) {
        return new ResponseEntity<>(baseResponse("Created", data), HttpStatus.CREATED);
    }

    public static ResponseEntity<BaseResponse> unprocessableEnity(String message) {
        BaseResponse res = new BaseResponse();
        res.setStatus(HttpStatus.UNPROCESSABLE_ENTITY.value());
        res.setMessage(message);
        return ResponseEntity.unprocessableEntity().body(res);
    }

    public static ResponseEntity<BaseResponse> badRequest() {
        BaseResponse res = new BaseResponse();
        res.setMessage("Bad Request");
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<BaseResponse> badRequest(Object data) {
        BaseResponse res = new BaseResponse();
        res.setMessage("Bad Request");
        res.setData(data);
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<Object> badRequestObject(Object data) {
        return ResponseEntity.badRequest().body(baseResponseMap("Bad Request", data));
    }

    public static ResponseEntity<BaseResponse> badRequest(String message) {
        BaseResponse res = new BaseResponse();
        res.setMessage(message);
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<BaseResponse> badRequest(String message, Object data) {
        BaseResponse res = baseResponse(message, data);
        return ResponseEntity.badRequest().body(res);
    }

    public static ResponseEntity<BaseResponse> notFound(String message) {
        return new ResponseEntity<>(baseResponse(message), HttpStatus.NOT_FOUND);
    }

    public static ResponseEntity<BaseResponse> notFound() {
        return new ResponseEntity<>(baseResponse("Not found"), HttpStatus.NOT_FOUND);
    }

    public static ResponseEntity<BaseResponse> forbidden() {
        return new ResponseEntity<>(baseResponse("Forbidden"), HttpStatus.FORBIDDEN);
    }

}
