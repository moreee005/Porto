package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.ContractStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContractStatusRepo extends JpaRepository<ContractStatus, Integer> {
}
