package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "employee", schema = "public")
public class Employee {

    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "party_id", referencedColumnName = "party_id")
    private Party party;

    @Column(name = "disability_status_id")
    private Integer disabilityStatus;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "emergency_contact_relation_id")
    private EmergencyContactRelation emergencyContactRelation;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "position_id")
    private Position position;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "blood_type_id")
    private BloodType bloodType;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "marital_status_id")
    private MaritalStatus maritalStatus;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ptkp_status_id")
    private PtkpStatus ptkpStatus;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "banking_placement_id")
    private BankingPlacement bankingPlacement;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "religion_id")
    private Religion religion;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "placement_type_id")
    private PlacementType placementType;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "division_id")
    private Division division;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ethnicity_id")
    private Ethnicity ethnicity;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bank_id")
    private Bank bank;

    @Column(name = "photo_filename")
    private String photoFilename;

    @Column(name = "place_of_birth")
    private String placeOfBirth;

    @Column(name = "primary_phone_no")
    private String primaryPhoneNo;

    @Column(name = "secondary_phone_no")
    private String secondaryPhoneNo;

    @Column(name = "nik")
    private String nik;

    @Column(name = "email")
    private String email;

    @Column(name = "nip")
    private String nip;

    @Column(name = "emergency_contact_name")
    private String emergencyContactName;

    @Column(name = "emergency_contact_no")
    private String emergencyContactNo;

    @Column(name = "join_date")
    private Date joinDate;

    @Column(name = "generation")
    private String generation;

    @Column(name = "bpjs_no")
    private String bpjsNo;

    @Column(name = "bpjs_class")
    private int bpjsClass;

    @Column(name = "bpjs_tk_no")
    private String bpjsTkNo;

    @Column(name = "npwp")
    private String npwp;

    @Column(name = "bank_account_no")
    private String bankAccountNo;

    @Column(name = "background")
    private String background;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @OneToMany(mappedBy = "partyId")
    private List<EmployeeContract> employeeContracts;

    @OneToMany(mappedBy = "partyId")
    private List<EmployeeDocument> employeeDocuments;

    @OneToMany(mappedBy = "partyId")
    private List<EmployeeSocialMedia> socialMedias;

}
