package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ContractDocumentResponse {

    private String documentName;
    private String documentUrl;

}
