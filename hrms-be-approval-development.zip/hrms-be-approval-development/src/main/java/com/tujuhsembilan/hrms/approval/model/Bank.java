package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "r_bank", schema = "master")
public class Bank {
    @Id
    @Column(name = "bank_id")
    private int bankId;

    @Column(name = "name")
    private String name;

    @Column(name = "short_name")
    private String shortName;

    @Column(name = "bic_code")
    private String bicCode;

    @Column(name = "clearing_code")
    private String clearingCode;
}
