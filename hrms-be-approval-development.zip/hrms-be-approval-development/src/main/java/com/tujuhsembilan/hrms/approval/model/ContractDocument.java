package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "contract_document", schema = "public")
public class ContractDocument {

    @Id
    @Column(name = "contract_doc_id")
    private UUID contractDocId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_contract_id")
    private EmployeeContract employeeContract;

    @Column(name = "doc_filename")
    private String docFilename;

    @Column(name = "upload_date")
    private Date uploadDate;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @Column(name = "doc_type")
    private String docType;
}
