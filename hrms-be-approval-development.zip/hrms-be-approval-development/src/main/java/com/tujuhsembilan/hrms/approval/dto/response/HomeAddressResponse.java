package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

@Data
public class HomeAddressResponse {

    private String fullAddress;
    private String province;
    private String city;
    private String district;
    private String subDistrict;
    private String postalCode;

    public HomeAddressResponse(String fullAddress, String province, String city, String district, String subDistrict, String postalCode) {
        this.fullAddress = fullAddress;
        this.province = province;
        this.city = city;
        this.district = district;
        this.subDistrict = subDistrict;
        this.postalCode = postalCode;
    }

}
