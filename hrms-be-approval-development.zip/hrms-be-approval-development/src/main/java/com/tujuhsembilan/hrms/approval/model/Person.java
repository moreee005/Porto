package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "person", schema = "public")
public class Person {

    @Id
    @Column(name = "party_id")
    private UUID partyId;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "party_id")
    private Party party;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "education_id")
    private Education educationId;

    @Column(name = "fullname")
    private String fullname;

    @Column(name = "date_of_birth")
    private Date dateOfBirth;

    @Column(name = "gender")
    private String gender;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @Column(name = "graduation_year")
    private Integer graduationYear;

}
