package com.tujuhsembilan.hrms.approval.service;
        
import com.tujuhsembilan.hrms.approval.data.EmailData;
import com.tujuhsembilan.hrms.approval.model.ContractApproval;
import com.tujuhsembilan.hrms.approval.model.Employee;
import com.tujuhsembilan.hrms.approval.model.EmployeeContract;
import com.tujuhsembilan.hrms.approval.model.Person;
import com.tujuhsembilan.hrms.approval.utils.DateUtils;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.internal.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor_ = @__(@Autowired))
public class EmailService {

    private final JavaMailSender mailSender;
    private final TemplateEngine templateEngine;
    private final MessageSource messageSource;

    @Value("${spring.mail.from}")
    private String defaultFromEmailAddress;

    /**
      * Core method to send email
      * @param emailData consist of the email information
      * @return true if success, false if failed
    */
    public boolean sendEmail(EmailData emailData) {
        try {
            if (
                emailData.getTo() == null ||
                emailData.getSubject() == null ||
                emailData.getContent() == null ||
                emailData.getIsHtmlFormat() == null
            ) {
                throw new IllegalArgumentException("Email data must not be null");
            }
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

            helper.setTo(emailData.getTo());
            helper.setFrom(Optional.ofNullable(emailData.getFrom()).orElse(defaultFromEmailAddress));
            helper.setSubject(emailData.getSubject());
            helper.setText(emailData.getContent(), emailData.getIsHtmlFormat());

            if (emailData.getAttachments() != null) {
            for (Pair<String, File> attachment : emailData.getAttachments()) {
                    helper.addAttachment(attachment.getLeft(), attachment.getRight());
                }
            }

            mailSender.send(mimeMessage);
            return true;
        } catch (Exception e) {
            log.error("Failed to send the email\nReason: {}", e.getMessage());
            return false;
        }
    }

    private boolean sendEmailForApproval(ContractApproval contractApproval, boolean isApproved, String subjectKey, String templateApproved, String templateRejected) {
        // todo: sesuaikan template dan subject berdasarkan Locale aktif pada konfigurasi sistem
        Locale locale = Locale.forLanguageTag("id-ID");

        Person submitter = contractApproval.getSubmitter().getPerson();
        EmployeeContract employeeContract = contractApproval.getEmployeeContract();
        Employee employee = employeeContract.getPartyId();

        Context context = new Context();
        context.setVariable("submitter_fullname", submitter.getFullname());
        context.setVariable("employee_fullname", employee.getParty().getPerson().getFullname());

        DateUtils dateUtils = new DateUtils();
        if (isApproved) {
            context.setVariable("employee_position", employee.getPosition().getName());
            context.setVariable("employeeContract_startDate", dateUtils.convertLocalDateTimeFormat2(employeeContract.getStartDate()));
            context.setVariable("employeeContract_endDate", dateUtils.convertLocalDateTimeFormat2(employeeContract.getEndDate()));
        }
        else {
            context.setVariable("reject_reason", Optional.ofNullable(employeeContract.getRemarks()).orElse("-"));
        }

        EmailData emailData = EmailData.builder()
                .to(new String[]{contractApproval.getSubmitter().getEmail()})
                .content(templateEngine.process(isApproved ? templateApproved : templateRejected, context))
                .isHtmlFormat(true)
                .subject(messageSource.getMessage(subjectKey, null, locale))
                .build();

        return this.sendEmail(emailData);
    }

    private String formattedDate(Date date, Locale locale) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy", locale);
        return formatter.format(date);
    }

    public boolean sendEmailForNewEmployeeApproval(ContractApproval contractApproval, boolean isApproved) {
        return sendEmailForApproval(contractApproval, isApproved, "email.new_employee_approval.subject", "new_employee_approved", "new_employee_rejected");
    }

    public boolean sendEmailForExtendContractApproval(ContractApproval contractApproval, boolean isApproved) {
        return sendEmailForApproval(contractApproval, isApproved, "email.extend_contract_approval.subject", "extend_contract_approved", "extend_contract_rejected");
    }
}