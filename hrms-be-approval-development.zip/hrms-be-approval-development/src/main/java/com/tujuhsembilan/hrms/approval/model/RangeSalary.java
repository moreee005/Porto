package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "r_range_salary", schema = "master")
public class RangeSalary {

    @Id
    @Column(name = "range_salary_id")
    private int rangeSalaryId;

    @Column(name = "salary")
    private String salary;

    @Column(name = "deleted_at")
    private Date deletedAt;
}
