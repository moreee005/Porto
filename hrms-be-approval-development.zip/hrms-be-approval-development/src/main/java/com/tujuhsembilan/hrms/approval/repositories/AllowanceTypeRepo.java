package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.AllowanceType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AllowanceTypeRepo extends JpaRepository<AllowanceType, Integer> {
}
