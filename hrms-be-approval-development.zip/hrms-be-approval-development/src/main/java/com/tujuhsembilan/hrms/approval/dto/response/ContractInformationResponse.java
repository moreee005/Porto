package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ContractInformationResponse {

    private String statusName;
    private String placementTypeName;
    private String employeTypeName;
    private String willingToBePlaceInBankOrInsurance;
    private String divisionName;
    private String jobPositionName;
    private String contractStartDate;
    private String contractEndDate;
    private ContractDocumentResponse contractDocument;
    private String generation;
    private BigDecimal baseSalary;
    private List<GroupAllowanceResponse> allowances;

}
