package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.HistoricEmployeeContract;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface HistoricEmployeeContractRepo extends JpaRepository<HistoricEmployeeContract, UUID> {
}
