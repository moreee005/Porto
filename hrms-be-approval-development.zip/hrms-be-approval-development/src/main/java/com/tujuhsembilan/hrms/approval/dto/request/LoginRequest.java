package com.tujuhsembilan.hrms.approval.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class LoginRequest {
    @Valid

    // to do : translation
    @NotNull(message = "{email.isMandatory}")
    @NotBlank(message = "{email.isMandatory}")
    private String email;

    // to do : translation
    @NotNull(message = "{password.isMandatory}")
    private String password;

}
