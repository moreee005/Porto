package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "employee_document", schema = "public")
public class EmployeeDocument {

    @Id
    @Column(name = "employee_doc_id")
    private UUID employeeDocId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "party_id")
    private Employee partyId;

    @Column(name = "doc_filename")
    private String docFilename;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "document_type_id")
    private DocumentType documentType;

    @Column(name = "upload_date")
    private LocalDateTime uploadDate;
}
