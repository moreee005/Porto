package com.tujuhsembilan.hrms.approval.repositories;

import com.tujuhsembilan.hrms.approval.model.EmployeeSport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface EmployeeSportRepo extends JpaRepository<EmployeeSport, UUID> {

    @Query("SELECT es FROM EmployeeSport  es WHERE es.partyId = :partyId")
    List<EmployeeSport> findByPartyId(@Param("partyId") UUID partyId);

}
