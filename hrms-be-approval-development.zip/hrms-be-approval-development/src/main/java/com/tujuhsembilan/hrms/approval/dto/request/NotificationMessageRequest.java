package com.tujuhsembilan.hrms.approval.dto.request;

import lombok.Data;

@Data
public class NotificationMessageRequest {

    private String type = "Notification";
    private Object payload;

}
