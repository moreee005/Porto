package com.tujuhsembilan.hrms.approval.service;

import com.tujuhsembilan.hrms.approval.dto.response.BaseResponse;
import com.tujuhsembilan.hrms.approval.dto.response.DataTableResponse;
import com.tujuhsembilan.hrms.approval.helpers.Response;
import com.tujuhsembilan.hrms.approval.model.view.ViewDatatableApproval;
import com.tujuhsembilan.hrms.approval.repositories.ViewDatatableApprovalRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ViewDatatableApprovalService {

    @Autowired
    ViewDatatableApprovalRepo viewDatatableApprovalRepo;

    public ResponseEntity<BaseResponse> getDatatableApproval(String search, Integer contract, Pageable pageable) {
        Page<ViewDatatableApproval> viewDatatableApprovals = viewDatatableApprovalRepo.datatableByFilter(search, contract, pageable);
        if (viewDatatableApprovals.hasContent()) {
            DataTableResponse dataTableResponse = new DataTableResponse();
            dataTableResponse.setRecordsTotal(viewDatatableApprovalRepo.count());
            dataTableResponse.setRecordsFiltered(viewDatatableApprovals.getTotalElements());
            dataTableResponse.setData(viewDatatableApprovals.getContent());
            return Response.success(dataTableResponse);
        }
        return Response.notFound();
    }

}
