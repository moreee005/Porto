package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "employee_metadata", schema = "public")
public class EmployeeMetadata {

    @Id
    @Column(name = "employee_metadata_id")
    private UUID employeeMetadataId;

    @Column(name = "party_id")
    private UUID partyId;

    @Column(name = "key")
    private String key;

    @Column(name = "value")
    private String value;

    @Column(name = "deleted_at")
    private Date deletedAt;

}
