package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class OtherResponse {

    private List<String> foreignLanguageProficiency;
    private List<String> hobbies;
    private List<String> careerInterests;

}
