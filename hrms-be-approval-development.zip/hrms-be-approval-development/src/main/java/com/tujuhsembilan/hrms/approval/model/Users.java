package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "users")
public class Users implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private UUID userId = UUID.randomUUID();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "party_id")
    private Person person;

    // to do : translation
    @NotNull(message = "{email.isMandatory}")
    @NotBlank(message = "{email.isMandatory}")
    @Column(name = "email")
    private String email;

    // to do : translation
    @NotNull(message = "{password.isMandatory}")
    @NotNull(message = "{password.isMandatory}")
    @Column(name = "password")
    private String password;

    @NonNull
    @Column(name = "role")
    private String role;

    @Column(name = "deleted_at")
    private Date deletedAt;

}

