package com.tujuhsembilan.hrms.approval.dto.response;

import lombok.Data;

import java.util.UUID;

@Data
public class OrganizationalLifeResponse {

    private UUID organizationId;
    private String organizationName;
    private Integer yearInPosition;
    private String position;
    private String memberCount;
    private String city;
    private Integer durationMonths;

    public OrganizationalLifeResponse(UUID organizationId, String organizationName, Integer yearInPosition, String position, String memberCount, String city, Integer durationMonths) {
        this.organizationId = organizationId;
        this.organizationName = organizationName;
        this.yearInPosition = yearInPosition;
        this.position = position;
        this.memberCount = memberCount;
        this.city = city;
        this.durationMonths = durationMonths;
    }

}
