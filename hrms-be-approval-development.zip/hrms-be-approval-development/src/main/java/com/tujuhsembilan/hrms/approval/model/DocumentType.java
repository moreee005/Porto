package com.tujuhsembilan.hrms.approval.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "r_document_type", schema = "master")
public class DocumentType {

    @Id
    @Column(name = "document_type_id")
    private int documentTypeId;

    @Column(name = "name")
    private String name;

}
