package lib.minio.configuration;

import io.minio.MinioClient;
import lib.minio.configuration.property.MinioProp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class MinioConfig {

  @Value("${application.minio.url}")
  private String endpoint;

  @Value("${application.minio.key}")
  private String accessKey;

  @Value("${application.minio.secret}")
  private String secretKey;

  @Bean
  public MinioClient minioClient(MinioProp props) {
    log.info("Minio Endpoint1: {}", endpoint);
    log.info("Minio Access Key: {}", accessKey);
    log.info("Minio Secret Key: {}", secretKey);
    return MinioClient.builder()
        .endpoint(endpoint)
        .credentials(accessKey, secretKey)
        .build();
  }
}
