from dataclasses import dataclass
from decimal import Decimal
from typing import List


# Class for json report
@dataclass
class OwnAccountData:
    OWN_ACCOUNT: str
    OWN_ACCOUNT_DESC: str
    RECORD_BALANCE_OWN: Decimal
    TAX_PCT: str
    ENTITLEMENT_DEP_ACCT_OWN: str
    CF_INSTRUMENT_SHORT_OWN: str
    ENTITLEMENT_AMT_GROSS_OWN: Decimal
    ENTITLEMENT_AMT_NET_OWN: Decimal
    ENTITLEMENT_AMT_TAX: Decimal
    CF_ENTITLEMENT_FRAC: str
    HOLDING_PERIOD_OWN1: int
    START_HOLDING_PERIOD_OWN1: str
    END_HOLDING_PERIOD_OWN1: str
    HOLDING_BALANCE_OWN1: Decimal
    NET_AMOUNT_OWN1: Decimal
    PROCEED_AMOUNT_OWN1: Decimal
    TAX_AMOUNT_OWN1: Decimal


@dataclass
class ClientAccountData:
    CLIENT_ACCOUNT: str
    CLIENT_ACCOUNT_DESC: str
    CLIENT_RECORD_BALANCE: Decimal
    CLIENT_TAX_PCT: str
    CLIENT_DEPOSIT_ACCOUNT: str
    DEP_INSTRUMENT: str
    DEP_AMT_GROSS: Decimal
    DEP_FRAC: str
    DEP_AMT_TAX: Decimal
    NET_PROCEED_AMT_CLIENT: Decimal
    HOLDING_PERIOD_CLIENT: int
    START_HOLDING_PERIOD_CLIENT: str
    END_HOLDING_PERIOD_CLIENT: str
    HOLDING_BALANCE_CLIENT: Decimal
    PROCEED_AMOUNT_CLIENT: Decimal
    TAX_AMOUNT_CLIENT: Decimal
    NET_AMOUNT_CLIENT: Decimal


@dataclass
class SubData:
    OWN_ACCOUNT_DATA: List[OwnAccountData]
    CLIENT_ACCOUNT_DATA: List[ClientAccountData]
    CLIENT_RECORD_BALANCE2: Decimal
    INSTRUMENT: str
    FRAC: str
    AMT_GROSS: Decimal
    AMT_TAX: Decimal
    AMT_NET: Decimal
    MEMBER: str


@dataclass
class RootData:
    CA_ANNOUNCEMENT_DATE: str
    CA_DEADLINE_DATE: str
    CA_EFFECT_DATE: str
    CA_EX_DATE: str
    CA_INT_END_DATE: str
    CA_INTEREST_ST_DATE: str
    CA_RECORD_DATE: str
    CA_START_DATE: str
    CA_TAX_METHOD: str
    CORPORATE_ACTION: str
    CORR_ACCT: str
    CS_SUM_REC_BAL: Decimal
    GLOBAL_FRAC: str
    GLOBAL_AMT_GROSS: Decimal
    GLOBAL_AMT_NET: Decimal
    GLOBAL_AMT_TAX: Decimal
    GLOBAL_INSTRUMENT: str
    ISSUER_ACCOUNT: str
    P_REC_DATE: str
    SECURITY: str
    SECURITY_SHORT: str
    TIMESTAMP: str
    SUB_DATA: List[SubData]


# DTO
@dataclass
class RsMember:
    id_ca_capco: str
    id_mem: str
    sec: str
    catype: str


@dataclass
class CorporateAction:
    ca_id: str
    ca_instrument_id: str
    ca_secshortcode: str
    ca_seclongname: str
    ca_announce_date: str
    ca_record_date: str
    ca_ex_date: str
    ca_effect_date: str
    ca_start_date: str
    ca_deadline_date: str
    ca_type: str
    issuer_proceed_acct: str
    issuer_tax_acct: str
    ca_flg_tax: str
    ca_interest_start_date: str
    ca_interest_end_date: str
    ca_tax_method: str
    ca_type_desc: str
    ca_member: str
    ca_member_id: str

@dataclass
class OwnAccount:
    entitlement_clnt_id_own: str
    account_id_own: str
    account_id_disp_own: str
    member_id_own: str
    ata_code_own: str
    rblnc_blnc_amt_own: Decimal
    account_desc_own: str
    ca_id_own: str
    entitlement_ordercol: str
    entitlement_ins_sht_nm: str
    entitlement_amt_gross_own: Decimal
    entitlement_amt_tax_own: Decimal
    entitlement_amt_net_own: Decimal
    entitlement_frac_nom: Decimal
    entitlement_frac_denom: Decimal
    entitlement_dep_acct_own: str
    ip_holding_period_own: int
    ip_start_date_own: str
    ip_end_date_own: str
    ip_holding_balance_own: Decimal
    ip_proceed_amount_own: Decimal
    ip_tax_amount_own: Decimal
    ip_net_amount_own: Decimal
    ip_ca_id: str
    ip_acct_id: str
    tax_rate_own: Decimal

@dataclass
class GlobalAmount:
    global_amt_gross: Decimal
    global_amt_tax: Decimal
    global_amt_net: Decimal
    global_frac_nom: Decimal
    global_frac_denom: Decimal
    global_ordercol: str
    global_sht_nm: str
    global_cae_ca_id: str
    global_ins: str

@dataclass
class ClientData:
    client_acct_id: str
    client_mem_id: str
    client_ata_code: str
    client_blnc_amt: Decimal
    client_acct_desc: str
    new_client_ca_id: str
    dep_amt_gross: Decimal
    dep_amt_tax: Decimal
    dep_amt_net: Decimal
    dep_ordercol: str
    dep_ins_sht_nm: str
    dep_frac_nom: Decimal
    dep_frac_denom: Decimal
    dep_account_id_disp: str
    ip_holding_period_client: int
    ip_start_date_client: str
    ip_end_date_client: str
    ip_holding_balance_client: Decimal
    ip_proceed_amount_client: Decimal
    ip_tax_amount_client: Decimal
    ip_net_amount_client: Decimal
    ip_ca_id_client: str
    ip_acct_id_client: str
    client_tax_rate: Decimal

@dataclass
class TotalData:
    amt_gross: Decimal
    amt_tax: Decimal
    amt_net: Decimal
    frac_nom: Decimal
    frac_denom: Decimal
    account_member_id: str
    total_ca_id: str
    ordercol: str
    ins_nm: str