from dataclasses import dataclass
import decimal

@dataclass
class InvLetterNonCorpBond:
    F_ACCT_DESC1: str #F_ACCT_DESC1
    F_ADDRESS4: str #F_ADDRESS4
    F_ADDR1: str #F_ADDR1
    F_ADDR2: str #F_ADDR2
    F_CA_DSC1: str #F_CA_DSC1
    CLIENT_CODE: str #CLIENT_CODE
    CODE_BASE_CUR: str #CODE_BASE_CUR
    F_EFF_DT1: str #F_EFF_DT1
    F_INV_KTP1: str #F_INV_KTP1
    F_INV_PASSPORT1: str #F_INV_PASSPORT1
    MEM_CODE: str #MEM_CODE
    MEM_ID: str #MEM_ID
    F_NEXT_DAY1: str #F_NEXT_DAY1
    F_REC_BAL1: decimal #F_REC_BAL1
    F_RECORD_DATE1: str #F_RECORD_DATE1
    SEC_CODE: str #SEC_CODE
    SEC_NM: str #SEC_NM
    TRUSTEE: str #TRUSTEE
    TYP_SEC_TXT: str #TYP_SEC_TXT
    F_INV_NPWP1: str #F_INV_NPWP1
    EF_DATE: str #EF_DATE
    MEM_NM: str


def model_to_dict(model: InvLetterNonCorpBond):
    return {
        "F_ACCT_DESC1": model.F_ACCT_DESC1,
        "F_ADDRESS4": model.F_ADDRESS4,
        "F_ADDR1": model.F_ADDR1,
        "F_ADDR2": model.F_ADDR2,
        "F_CA_DSC1": model.F_CA_DSC1,
        "CLIENT_CODE": model.CLIENT_CODE,
        "CODE_BASE_CUR": model.CODE_BASE_CUR,
        "F_EFF_DT1": model.F_EFF_DT1,
        "F_INV_KTP1": model.F_INV_KTP1,
        "F_INV_PASSPORT1": model.F_INV_PASSPORT1,
        "MEM_CODE": model.MEM_CODE,
        "MEM_ID": model.MEM_ID,
        "F_NEXT_DAY1": model.F_NEXT_DAY1,
        "F_REC_BAL1": str(model.F_REC_BAL1),  # Convert Decimal to string for JSON compatibility
        "F_RECORD_DATE1": model.F_RECORD_DATE1,
        "SEC_CODE": model.SEC_CODE,
        "SEC_NM": model.SEC_NM,
        "TRUSTEE": model.TRUSTEE,
        "TYP_SEC_TXT": model.TYP_SEC_TXT,
        "F_INV_NPWP1": model.F_INV_NPWP1,
        "EF_DATE": model.EF_DATE,
        "MEM_NM": model.MEM_NM
    }

