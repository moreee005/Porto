from dataclasses import dataclass

@dataclass
class OwnAccount:
    entitlement_clnt_id_own: str
    account_id_own: str
    account_id_disp_own: str
    member_id_own: str
    ata_code_own: str
    rblnc_blnc_amt_own: str
    rblnc_ins_id_own: str
    account_desc_own: str
    ca_id_own: str
    entitlement_ins_id_own: str
    entitlement_amt_gross_own: str
    entitlement_amt_tax_own: str
    entitlement_amt_net_own: str
    entitlement_dep_acct_id_own: str
    entitlement_frac_nom: str
    entitlement_frac_denom: str
    entitlement_dep_acct_own: str
    entitlement_ordercol: int
    entitlement_ins_sht_nm: str
    ip_holding_period_own: str
    ip_start_date_own: str
    ip_end_date_own: str
    ip_holding_balance_own: str
    ip_proceed_amount_own: str
    ip_tax_amount_own: str
    ip_net_amount_own: str
    ip_ca_id: str
    ip_acct_id: str
    tax_rate_own: str
