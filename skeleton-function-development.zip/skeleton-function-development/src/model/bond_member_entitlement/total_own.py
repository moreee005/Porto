from dataclasses import dataclass

@dataclass
class TotalOwn:
    amt_gross_own: str
    amt_tax_own: str
    amt_net_own: str
    frac_nom_own: str
    frac_denom_own: str
    own_ins_id_ins: str
    ca_id_total_own: str
    ordercol_own: int
    ins_sht_nm_own: str