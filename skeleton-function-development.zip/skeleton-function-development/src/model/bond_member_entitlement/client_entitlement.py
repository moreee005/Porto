from dataclasses import dataclass

@dataclass
class ClientEntitlement:
    client_member_id: str
    client_ca_id: str
    cae_client_id: str
    dep_amt_gross: str
    dep_amt_tax: str
    dep_amt_net: str
    dep_ins_id: str
    dep_frac_nom: str
    dep_frac_denom: str
    dep_account_id_disp: str
    dep_account_id: str
    source_acct: str
    dep_ordercol: int
    dep_ins_sht_nm: str
    ip_holding_period_client: str
    ip_start_date_client: str
    ip_end_date_client: str
    ip_holding_balance_client: str
    ip_proceed_amount_client: str
    ip_tax_amount_client: str
    ip_net_amount_client: str
    ip_ca_id_client: str
    ip_acct_id_client: str