from dataclasses import dataclass

@dataclass
class Total:
    amt_gross: str
    amt_tax: str
    amt_net: str
    frac_nom: str
    frac_denom: str
    ins_id_ins_capco: str
    ca_id_ca_capco: str
    total_ordercol: int
    total_sht_nm: str