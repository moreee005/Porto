from dataclasses import dataclass

@dataclass
class TotalClient:
    amt_gross_client: str
    amt_tax_client: str
    amt_net_client: str
    frac_nom_client: str
    frac_denom_client: str
    client_ins_id_ins: str
    total_ca_client_id: str
    client_ordercol: int
    client_ins_sht_nm: str