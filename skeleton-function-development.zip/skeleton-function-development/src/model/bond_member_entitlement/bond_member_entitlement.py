from dataclasses import dataclass
from typing import List

@dataclass
class OwnAccountData:
    OWN_ACCOUNT: str
    OWN_ACCOUNT_DESC: str
    RECORD_BALANCE_OWN: str
    TAX_PCT: str
    ENTITLEMENT_DEP_ACCT_OWN: str
    CF_INSTRUMENT_SHORT_OWN: str
    ENTITLEMENT_AMT_GROSS_OWN: str
    ENTITLEMENT_AMT_NET_OWN: str
    ENTITLEMENT_AMT_TAX: str
    CF_ENTITLEMENT_FRAC: str
    HOLDING_PERIOD_OWN1: str
    START_HOLDING_PERIOD_OWN1: str
    END_HOLDING_PERIOD_OWN1: str
    HOLDING_BALANCE_OWN1: str
    NET_AMOUNT_OWN1: str
    PROCEED_AMOUNT_OWN1: str
    TAX_AMOUNT_OWN1: str

@dataclass
class ClientAccountData:
    CLIENT_ACCOUNT: str
    CLIENT_ACCOUNT_DESC: str
    CLIENT_RECORD_BALANCE: str
    CLIENT_TAX_PCT: str
    CLIENT_DEPOSIT_ACCOUNT: str
    DEP_INSTRUMENT: str
    DEP_AMT_GROSS: str
    DEP_FRAC: str
    DEP_AMT_TAX: str
    NET_PROCEED_AMT_CLIENT: str
    HOLDING_PERIOD_CLIENT: str
    START_HOLDING_PERIOD_CLIENT: str
    END_HOLDING_PERIOD_CLIENT: str
    HOLDING_BALANCE_CLIENT: str
    PROCEED_AMOUNT_CLIENT: str
    TAX_AMOUNT_CLIENT: str
    NET_AMOUNT_CLIENT: str

@dataclass
class SubData:
    CA_ANNOUNCEMENT_DATE: str
    CA_DEADLINE_DATE: str
    CA_EFFECTIVE_DATE: str
    CA_EX_DATE: str
    CA_INT_END_DATE: str
    CA_INT_START_DATE: str
    CA_RECORD_DATE: str
    CA_START_DATE: str
    CA_TAX_IN_OUT: str
    CORPORATE_ACTION: str
    SECURITY: str
    SECURITY_SHORT: str
    TOTAL_RBLNC: str
    AMT_GROSS: str
    AMT_NET: str
    AMT_TAX: str
    FRAC: str
    INSTRUMENT: str
    SUM_RBLNC_AMT_OWN: str
    AMT_GROSS_OWN: str
    AMT_NET_OWN: str
    AMT_TAX_OWN: str
    FRAC_OWN: str
    OWN_SEC_SHORT: str
    SUM_CLIENT_RECORD_BALANCE: str
    AMT_GROSS_CLIENT: str
    AMT_NET_CLIENT: str
    AMT_TAX_CLIENT: str
    CLIENT_SEC_SHORT: str
    FRAC_CLIENT: str
    OWN_ACCOUNT_DATA: List[OwnAccountData]
    CLIENT_ACCOUNT_DATA: List[ClientAccountData]

@dataclass
class BondMemberEntitlement:
    DATE: str
    MEMBER: str
    P_SINCE: str
    SUB_DATA: List[SubData]