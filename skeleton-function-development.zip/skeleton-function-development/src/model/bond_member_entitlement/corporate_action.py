from dataclasses import dataclass

@dataclass
class CorporateAction:
    ca_id: str
    ca_instrument_id: str
    ca_secshortcode: str
    ca_seclongname: str
    ca_announcement_date: str
    ca_record_date: str
    ca_ex_date: str
    ca_effective_date: str
    ca_start_date: str
    ca_deadline_date: str
    ca_type: str
    ca_flg_tax: str
    ca_interest_start_date: str
    ca_interest_end_date: str
    ca_tax_in_out: str
    ca_type_dsc: str
    member: str
    member_name: str
    member_id: str