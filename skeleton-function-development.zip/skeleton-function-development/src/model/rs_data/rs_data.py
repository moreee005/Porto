from dataclasses import dataclass

@dataclass
class RsData:
    id_ca_capco: str
    typmet: str
    typsec: str
    insname: str
    id_mem: str
    cnt: int
