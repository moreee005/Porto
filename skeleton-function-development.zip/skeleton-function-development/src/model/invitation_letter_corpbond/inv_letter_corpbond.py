from dataclasses import dataclass

@dataclass
class InvLetterCorpBond:
    acct_desc1: str
    address4: str
    addr1: str
    addr2: str
    ca_dsc1: str
    code_base_cur: str
    client_code: str
    eff_dt1: str
    ef_date: str
    inv_ktp1: str
    inv_npwp1: str
    inv_passport1: str
    mem_code: str
    mem_id: str
    mem_nm: str
    next_day1: str
    rec_bal1: int
    record_date1: str
    sec_code: str
    sec_nm: str
    trustee: str

def model_to_dict(model: InvLetterCorpBond):
    return {
        "acct_desc1": model.acct_desc1,
        "address4": model.address4,
        "addr1": model.addr1,
        "addr2": model.addr2,
        "ca_dsc1": model.ca_dsc1,
        "code_base_cur": model.code_base_cur,
        "client_code": model.client_code,
        "eff_dt1": model.eff_dt1,
        "ef_date": model.ef_date,
        "inv_ktp1": model.inv_ktp1,
        "inv_npwp1": model.inv_npwp1,
        "inv_passport1": model.inv_passport1,
        "mem_code": model.mem_code,
        "mem_id": model.mem_id,
        "mem_nm": model.mem_nm,
        "next_day1": model.next_day1,
        "rec_bal1": model.rec_bal1,
        "record_date1": model.record_date1,
        "sec_code": model.sec_code,
        "sec_nm": model.sec_nm,
        "trustee": model.trustee,
    }
