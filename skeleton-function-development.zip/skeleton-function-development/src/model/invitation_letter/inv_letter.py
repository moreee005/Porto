from dataclasses import dataclass

@dataclass
class InvLetter:
    acct_desc: str
    acct_no: str
    addr1: str
    addr2: str
    addr3: str
    ca_desc: str
    city: str
    client_code: str
    country: str
    eff_dt: str
    inv_id: str
    ktp: str
    npwp: str
    passport: str
    bus_reg_num: str
    mem_code: str
    mem_id: str
    mem_nm: str
    next_day: str
    province: str
    rec_bal: str
    rec_dt: str
    sec_code: str
    sec_nm: str
    zipcode: str

def model_to_dict(model: InvLetter):
    return {
        "acct_desc": model.acct_desc,
        "acct_no": model.acct_no,
        "addr1": model.addr1,
        "addr2": model.addr2,
        "addr3": model.addr3,
        "ca_desc": model.ca_desc,
        "city": model.city,
        "client_code": model.client_code,
        "country": model.country,
        "eff_dt": model.eff_dt,
        "inv_id": model.inv_id,
        "ktp": model.ktp,
        "npwp": model.npwp,
        "passport": model.passport,
        "bus_reg_num": model.bus_reg_num,
        "mem_code": model.mem_code,
        "mem_id": model.mem_id,
        "mem_nm": model.mem_nm,
        "next_day": model.next_day,
        "province": model.province,
        "rec_bal": model.rec_bal,
        "rec_dt": model.rec_dt,
        "sec_code": model.sec_code,
        "sec_nm": model.sec_nm,
        "zipcode": model.zipcode
    }
