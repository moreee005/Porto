import argparse
# from limit_mem import limit_memory
from generator.bond_issuer_overview import gen_report_bond_issuer_overview
from generator.bond_member_entitlement import gen_report_bond_member_entitlement
from generator.invitation_letter import gen_report_inv_letter
from generator.invitation_letter_corpbond import gen_report_inv_letter_corpbond
from generator.invitation_letter_noncorpbond import gen_report_inv_letter_noncorpbond

parser = argparse.ArgumentParser()
parser.add_argument("--generate")

args = parser.parse_args()

# @limit_memory()
def main():
    match args.generate:
        case "inv_letter_corpbond": # `--generate inv_letter_corpbond` will generate only invitation letter corpbond
            gen_report_inv_letter_corpbond.gen_report_inv_letter_corpbond()
        case "bond_member_entitlement": # `--generate bond_member_entitlement` will generate only bond member entitlement
            gen_report_bond_member_entitlement.gen_report_bond_member_entitlement_db()
        case "bond_issuer_overview": # `--generate bond_issuer_overview` will generate only bond issuer overview
            gen_report_bond_issuer_overview.gen_report_bio_db()
        case "inv_letter": # `--generate inv_letter` will generate only invitation letter
            gen_report_inv_letter.gen_report_inv_letter()    
        case "inv_letter_noncorpbond": # `--generate inv_letter_corpbond` will generate only invitation letter non corpbond
            gen_report_inv_letter_noncorpbond.gen_report_inv_letter_noncorpbond()
        case "bond_issuer_overview_dc": # `--generate bond_issuer_overview` will generate only bond issuer overview from datacollector
            gen_report_bond_issuer_overview.gen_report_bio_dc()
        case "bond_member_entitlement_dc": # `--generate bond_member_entitlement` will generate only bond member entitlement from datacollector
            gen_report_bond_member_entitlement.gen_report_bond_member_entitlement_dc()
        case _:
            print("Command line argument not contain any report name to generate")

if __name__ == "__main__":
    main()
