from oracledb import Connection
from model.invitation_letter.inv_letter import InvLetter, model_to_dict
from utils.utils import beautify_content
from config import config

def fetch_data(P_CA_ID, P_MEMBER, conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT 
            DECODE(
                invs.ident_investortype, 1, invs.displayname, 
                bal.accountname
            ) acct_desc, 
            SUBSTR(bal.acct_id_acct_capco, 1, 5)|| '-' || SUBSTR(bal.acct_id_acct_capco, 6, 4)|| '-' || SUBSTR(bal.acct_id_acct_capco, 10, 3)|| '-' || SUBSTR(bal.acct_id_acct_capco, 13, 2) acct_no, 
            SUBSTR(bal.acct_id_acct_capco, 1, 5) mem_code, 
            SUBSTR(bal.acct_id_acct_capco, 6, 4) client_code, 
            invs.mainid inv_id,
            CASE WHEN si_ktp.IDENT_STAKEHOLDERIDTYPE IS NOT null THEN invs.MAINID END ktp,
            CASE WHEN si_npwp.IDENT_STAKEHOLDERIDTYPE IS NOT null THEN invs.MAINID END npwp,
            CASE WHEN si_pass.IDENT_STAKEHOLDERIDTYPE IS NOT null THEN invs.MAINID END passport,
            CASE WHEN si_busreg.IDENT_STAKEHOLDERIDTYPE IS NOT null THEN invs.MAINID END bus_reg_num, 
            addr.address1 addr_1, 
            addr.address2 addr_2, 
            addr.address3 addr_3, 
            addr.city city, 
            addr.stateprovince province, 
            addr.postalcode zipcode, 
            (SELECT name FROM country@{config.DB_LINK_TOBA} c WHERE c.code = addr.country) country, 
            mem.longname iss_mem_nm, 
            mem.code iss_mem_id, 
            bal.mem_dsc mem_nm, 
            bal.mem_id_mem_capco mem_id, 
            ins.longname sec_nm, 
            ins.name sec_code, 
            ca.dat_pay eff_dt, 
            ca.ca_dsc ca_desc, 
            ca.dat_rec rec_dt, 
            (SELECT operatingdate FROM operatingdate@{config.DB_LINK_TOBA} WHERE validfrom = (SELECT MAX(validfrom) FROM operatingdate@{config.DB_LINK_TOBA})) next_day, 
            bal.amt_blnc rec_bal 
        FROM 
            record_balances@{config.DB_LINK_TOBAMR} bal 
        JOIN corporate_actions@{config.DB_LINK_TOBAMR} ca ON bal.ca_id_ca_capco = ca.id_ca_capco 
        JOIN instrument@{config.DB_LINK_TOBAMR} ins ON ca.ins_id_ins_capco = ins.isin AND ins.ident_master IS NULL
        JOIN assetclass@{config.DB_LINK_TOBAMR} ac on ins.ident_assetclass = ac.ident_assetclass 
        JOIN issuer@{config.DB_LINK_TOBAMR} mem ON ins.ident_issuer = mem.ident_stakeholder 
        JOIN investor@{config.DB_LINK_TOBAMR} invs ON bal.ident_investor = invs.ident_stakeholder
        LEFT JOIN stakeholderidentifier@{config.DB_LINK_TOBAMR} si_ktp ON si_ktp.IDENT_INVESTOR = invs.IDENT_STAKEHOLDER AND si_ktp.IDENT_STAKEHOLDERIDTYPE  = 8
        LEFT JOIN stakeholderidentifier@{config.DB_LINK_TOBAMR} si_npwp ON si_npwp.IDENT_INVESTOR = invs.IDENT_STAKEHOLDER AND si_npwp.IDENT_STAKEHOLDERIDTYPE  = 6
        LEFT JOIN stakeholderidentifier@{config.DB_LINK_TOBAMR} si_pass ON si_pass.IDENT_INVESTOR = invs.IDENT_STAKEHOLDER AND si_pass.IDENT_STAKEHOLDERIDTYPE  = 7
        LEFT JOIN stakeholderidentifier@{config.DB_LINK_TOBAMR} si_busreg ON si_busreg.IDENT_INVESTOR = invs.IDENT_STAKEHOLDER AND si_busreg.IDENT_STAKEHOLDERIDTYPE  = 15 
        LEFT JOIN address@{config.DB_LINK_TOBAMR} addr ON invs.ident_stakeholder = addr.ident_investor AND addr.ident_addresstype = 1 
        WHERE 
            ca.typ_ca = 12
            AND ca.proxy_act_typ IS NULL 
            AND bal.amt_blnc > 0 
            AND ac.ident_assetclasstype = 3
            AND (bal.mem_id_mem_capco = '{P_MEMBER}' OR '{P_MEMBER}' IS NULL) 
            AND NLS_UPPER(ca.id_ca_capco) = NLS_UPPER('{P_CA_ID}') 
        ORDER BY bal.acct_id_acct_capco
    """)

    columns = list(cursor.description)
    rows = cursor.fetchall()
    results = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col.name.lower()] = row[i]
        results.append(row_dict)

    cursor.close()    

    return [model_to_dict(InvLetter(acct_desc=beautify_content(row['acct_desc']), acct_no=beautify_content(row['acct_no']),
                      addr1=beautify_content(row['addr_1']),addr2=beautify_content(row['addr_2'], empty_content="EMPTY"),
                      addr3=beautify_content(row['addr_3'], empty_content="EMPTY"),ca_desc=beautify_content(row['ca_desc']),
                      city=beautify_content(row['city']),client_code=beautify_content(row['client_code']),
                      country=beautify_content(row['country'], empty_content="EMPTY"),eff_dt=beautify_content(row['eff_dt']),
                      inv_id=beautify_content(row['inv_id']), ktp=beautify_content(row['ktp']), npwp=beautify_content(row['npwp']),
                      passport=beautify_content(row['passport']), bus_reg_num=beautify_content(row['bus_reg_num']), 
                      mem_code=beautify_content(row['mem_code']),
                      mem_id=beautify_content(row['mem_id']), mem_nm=beautify_content(row['mem_nm']),
                      next_day=beautify_content(row['next_day']), province=beautify_content(row['province'], empty_content="EMPTY"),
                      rec_bal=row['rec_bal'] if row['rec_bal'] is not None else "-", rec_dt=beautify_content(row['rec_dt']),
                      sec_code=beautify_content(row['sec_code']), sec_nm=beautify_content(row['sec_nm']),
                      zipcode=beautify_content(row['zipcode'], empty_content="EMPTY"))) for row in results]
