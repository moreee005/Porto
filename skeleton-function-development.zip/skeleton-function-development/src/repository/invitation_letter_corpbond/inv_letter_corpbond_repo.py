from oracledb import Connection
from model.invitation_letter_corpbond.inv_letter_corpbond import InvLetterCorpBond, model_to_dict
from utils.utils import beautify_content
from config import config

def fetch_data(P_CA_ID, P_MEMBER, conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
        decode(
            invs.ident_investortype, 1, invs.displayname, 
            bal.accountname
        ) acct_desc, 
        substr(bal.acct_id_acct_capco, 1, 5)|| '-' || substr(bal.acct_id_acct_capco, 6, 4)|| '-' || substr(bal.acct_id_acct_capco, 10, 3)|| '-' || substr(bal.acct_id_acct_capco, 13, 2) acct_no, 
        substr(bal.acct_id_acct_capco, 1, 5) mem_code, 
        substr(bal.acct_id_acct_capco, 6, 4) client_code, 
        invs.ktp invs_ktp_num, 
        invs.npwp invs_npwp_num, 
        invs.passport invs_passport_num, 
        addr.address1 addr_1, 
        addr.address2 addr_2, 
        addr.address3 addr_3, 
        decode(
            addr.city, null, '', addr.city || ', '
        ) || decode(
            addr.stateprovince, null, '', addr.stateprovince || ', '
        ) || decode(
            postalcode, null, '', postalcode || ', '
        ) || decode(
            addr.country, 
            null, 
            '', 
            (
            select 
                name 
            from 
                country@{config.DB_LINK_TOBA} c 
            where 
                c.code = addr.country
            )
        ) address4, 
        mem.longname iss_mem_nm, 
        mem.code iss_mem_id, 
        bal.mem_dsc mem_nm, 
        bal.mem_id_mem_capco mem_id, 
        ins.longname sec_nm, 
        ins.name sec_code, 
        ca.dat_pay eff_dt, 
        ca.ca_dsc ca_desc, 
        ca.dat_rec rec_dt, 
        (
            select 
            operatingdate 
            from 
            operatingdate@{config.DB_LINK_TOBA} 
            where 
            validfrom = (
                select 
                max(validfrom) 
                from 
                operatingdate@{config.DB_LINK_TOBA}
            )
        ) next_day, 
        bal.amt_blnc rec_bal, 
        typ_sec.cbest_code_val typ_sec, 
        typ_sec.ncsd_code_long_dsc typ_sec_txt, 
        ca.trustee, 
        ca.proxy_act_typ, 
        cur.code code_base_cur, 
        to_char(ca.dat_pay, 'DD fmMonth RRRR') ef_date 
        from 
        record_balances@{config.DB_LINK_TOBAMR} bal 
        join corporate_actions@{config.DB_LINK_TOBAMR} ca on bal.ca_id_ca_capco = ca.id_ca_capco 
        join instrument@{config.DB_LINK_TOBAMR} ins on ca.ins_id_ins_capco = ins.isin 
        and ins.ident_master is null 
        join issuer@{config.DB_LINK_TOBAMR} mem on ins.ident_issuer = mem.ident_stakeholder 
        left join currency@{config.DB_LINK_TOBAMR} cur on ins.ident_currency = cur.ident_currency 
        join (
            select 
            iv.*, 
            ktp.identifier ktp, 
            npwp.identifier npwp, 
            passport.identifier passport 
            from 
            investor@{config.DB_LINK_TOBAMR} iv 
            left join (
                select 
                ident_investor, 
                identifier 
                from 
                stakeholderidentifier@{config.DB_LINK_TOBAMR} 
                where 
                ident_stakeholderidtype = 8 
                and ident_investor is not null
            ) ktp on iv.ident_stakeholder = ktp.ident_investor 
            left join (
                select 
                ident_investor, 
                identifier 
                from 
                stakeholderidentifier@{config.DB_LINK_TOBAMR} 
                where 
                ident_stakeholderidtype = 6 
                and ident_investor is not null
            ) npwp on iv.ident_stakeholder = npwp.ident_investor 
            left join (
                select 
                ident_investor, 
                identifier 
                from 
                stakeholderidentifier@{config.DB_LINK_TOBAMR} 
                where 
                ident_stakeholderidtype = 7 
                and ident_investor is not null
            ) passport on iv.ident_stakeholder = passport.ident_investor 
            where 
            iv.ident_master is null
        ) invs on bal.ident_investor = invs.ident_stakeholder 
        left join address@{config.DB_LINK_TOBAMR} addr on invs.ident_stakeholder = addr.ident_investor 
        and addr.ident_addresstype = 1 
        left join ncsd_codes@{config.DB_LINK_TOBA} typ_sec on ins.ident_assetclass = typ_sec.ncsd_code_val 
        and typ_sec.ncsd_col_nm = 'ASSET_CLASS' 
        where 
        ca.typ_ca = 12 
        and bal.amt_blnc > 0 
        and ca.proxy_act_typ = 1 
        and ins.ident_assetclass in (1001, 1029, 1030) 
        and (
            bal.mem_id_mem_capco = '{P_MEMBER}'
            or '{P_MEMBER}' is null
        ) 
        and nls_upper(ca.id_ca_capco) = nls_upper('{P_CA_ID}') 
        order by 
        bal.acct_id_acct_capco
    """)
    
    columns = list(cursor.description)
    rows = cursor.fetchall()
    results = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col.name.lower()] = row[i]
        results.append(row_dict)

    cursor.close()

    return [model_to_dict(InvLetterCorpBond(acct_desc1=beautify_content(row['acct_desc']), address4=beautify_content(row['address4'], empty_content="EMPTY"),
            addr1=beautify_content(row['addr_1'], empty_content="EMPTY"),addr2=beautify_content(row['addr_2'], empty_content="EMPTY"),
            ca_dsc1=beautify_content(row['ca_desc']),code_base_cur=beautify_content(row['code_base_cur']),
            client_code=beautify_content(row['client_code']), eff_dt1=beautify_content(row['eff_dt']),
            ef_date=beautify_content(row['ef_date']), inv_ktp1=beautify_content(row['invs_ktp_num']),
            inv_npwp1=beautify_content(row['invs_npwp_num']), inv_passport1=beautify_content(row['invs_passport_num']),
            mem_code=beautify_content(row['mem_code']), mem_id=beautify_content(row['mem_id']),
            mem_nm=beautify_content(row['mem_nm']), next_day1=beautify_content(row['next_day']),
            rec_bal1=beautify_content(row['rec_bal']), record_date1=beautify_content(row['rec_dt']),
            sec_code=beautify_content(row['sec_code']), sec_nm=beautify_content(row['sec_nm']),
            trustee=beautify_content(row['trustee'], empty_content="EMPTY"))) for row in results]
