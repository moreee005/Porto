from datetime import datetime
from oracledb import Connection
from model.bond_issuer_overview.bond_issuer_overview_model import *
from utils.utils import beautify_content, format_frac, format_tax
from typing import List
from config import config


def fetch_bond_issuer(tgl, conn: Connection):
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT
            DISTINCT ca.id_ca_capco,
            p.code AS id_mem,
            ins.name AS sec,
            INITCAP(ca_type_ncsd_desc) AS catype
        FROM
            record_balances@{config.DB_LINK_TOBAMR} rb
        JOIN corporate_actions@{config.DB_LINK_TOBAMR} ca ON rb.ca_id_ca_capco = ca.id_ca_capco
        JOIN instrument@{config.DB_LINK_TOBAMR} ins ON ca.ident_instrument = ins.ident_instrument
        JOIN assetclass@{config.DB_LINK_TOBAMR} ac ON ins.ident_assetclass = ac.ident_assetclass AND ac.ident_assetclasstype = 5
        JOIN participant@{config.DB_LINK_TOBAMR} p ON ins.ident_issuercsd = p.ident_stakeholder
        WHERE 
            ca.code_sta = 1
            AND nls_upper(ca.id_ca_capco) IN ('KSEI202400037579')
            AND (ca.dat_rec = '{tgl}' OR dat_pay = get_next_bus_date@{config.DB_LINK_TOBAMR}('{tgl}', 1))
        ORDER  BY 1
    """
    )

    rows = cursor.fetchall()
    cursor.close()

    return [
        RsMember(
            id_ca_capco=beautify_content(row[0]),
            id_mem=beautify_content(row[1]),
            sec=beautify_content(row[2]),
            catype=beautify_content(row[3]),
        )
        for row in rows
    ]


def fetch_corporate_action(p_ca_id, conn: Connection):
    cursor = conn.cursor()
    cursor.execute(
        f"""
        select 
            distinct ca.id_ca_capco ca_id, 
            ca.ins_id_ins_capco ca_instrument_id, 
            sec.name ca_secshortcode, 
            sec.longname ca_seclongname, 
            ca.dat_ann ca_announce_date, 
            ca.dat_rec ca_record_date, 
            ca.dat_ex ca_ex_date, 
            ca.dat_pay ca_effect_date, 
            ca.dat_start_per ca_start_date, 
            ca.dat_inst_dead ca_deadline_date, 
            ca.typ_ca ca_type, 
            ca.acct_id_acct_capco_proceed issuer_proceed_acct, 
            ca.acct_id_acct_capco_tax issuer_tax_acct, 
            ca.flg_tax ca_flg_tax, 
            ca.dat_first_int_per ca_interest_start_date, 
            ca.dat_end_int_per ca_interest_end_date, 
            decode(
                ca.code_tax_pay_meth, 1, 'INSIDE THE SYSTEM', 
                2, 'OUTSIDE THE SYSTEM', ''
            ) ca_tax_method, 
            upper(ca.ca_type_ncsd_desc) ca_type_desc, 
            mem1.code ca_member, 
            mem1.code ca_member_id 
        from 
            corporate_actions@{config.DB_LINK_TOBAMR} ca, 
            record_balances@{config.DB_LINK_TOBAMR} rblnc, 
            (
                select 
                    acct.ident_operator, 
                    acct.ident_accountcomposite, 
                    sa.ident_account, 
                    acct.accountidentifiervalue 
                from 
                    securitiesaccount@{config.DB_LINK_TOBAMR} sa 
                join accountcomposite@{config.DB_LINK_TOBAMR} acct on sa.ident_accountcomposite = acct.ident_accountcomposite 
                where 
                    acct.ident_master is null
            ) acct, 
            (
                select 
                    code, 
                    ident_stakeholder, 
                    longname 
                from 
                    participant@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) mem1, 
            (
                select 
                    ident_instrument, 
                    ident_assetclass, 
                    name, 
                    longname, 
                    isin 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) sec, 
            assetclass@{config.DB_LINK_TOBAMR} ac 
        where 
            ca.code_sta = 1 
            and ac.ident_assetclasstype = 5 
            and ca.id_ca_capco = rblnc.ca_id_ca_capco 
            and rblnc.acct_id_acct_capco = acct.accountidentifiervalue 
            and acct.ident_operator = mem1.ident_stakeholder 
            and ca.ins_id_ins_capco = sec.isin 
            and sec.ident_assetclass = ac.ident_assetclass 
            and nls_upper(ca.id_ca_capco) = nls_upper('{p_ca_id}')
    """
    )

    columns = list(cursor.description)
    rows = cursor.fetchall()
    results = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col.name.lower()] = row[i]
        results.append(row_dict)

    cursor.close()

    return [
        CorporateAction(
            ca_id=beautify_content(row["ca_id"]),
            ca_instrument_id=beautify_content(row["ca_instrument_id"]),
            ca_secshortcode=beautify_content(row["ca_secshortcode"]),
            ca_seclongname=beautify_content(row["ca_seclongname"]),
            ca_announce_date=beautify_content(row["ca_announce_date"], format_date='%d/%m/%Y'),
            ca_record_date=beautify_content(row["ca_record_date"], format_date='%d/%m/%Y'),
            ca_ex_date=beautify_content(row["ca_ex_date"], format_date='%d/%m/%Y'),
            ca_effect_date=beautify_content(row["ca_effect_date"], format_date='%d/%m/%Y'),
            ca_start_date=beautify_content(row["ca_start_date"], format_date='%d/%m/%Y'),
            ca_deadline_date=beautify_content(row["ca_deadline_date"], format_date='%d/%m/%Y'),
            ca_type=beautify_content(row["ca_type"]),
            issuer_proceed_acct=beautify_content(row["issuer_proceed_acct"]),
            issuer_tax_acct=beautify_content(row["issuer_tax_acct"]),
            ca_flg_tax=beautify_content(row["ca_flg_tax"]),
            ca_interest_start_date=beautify_content(row["ca_interest_start_date"], format_date='%d/%m/%Y'),
            ca_interest_end_date=beautify_content(row["ca_interest_end_date"], format_date='%d/%m/%Y'),
            ca_tax_method=beautify_content(row["ca_tax_method"]),
            ca_type_desc=beautify_content(row["ca_type_desc"]),
            ca_member=beautify_content(row["ca_member"]),
            ca_member_id=beautify_content(row["ca_member_id"]),
        )
        for row in results
    ]


def fetch_own_account(list_member_id, ca_id, conn: Connection):
    placeholders = ", ".join(":" + str(i + 1) for i in range(len(list_member_id)))

    cursor = conn.cursor()
    cursor.execute(
        f"""
        select 
            substr(acct.accountidentifiervalue,6,length(acct.accountidentifiervalue)-10) entitlement_clnt_id_own,
            acct.accountidentifiervalue account_id_own,
            substr(acct.accountidentifiervalue,1,5) || '-' || substr(acct.accountidentifiervalue,6,4) || '-' || substr(acct.accountidentifiervalue,10,3) || '-' || substr(acct.accountidentifiervalue,13,2) account_id_disp_own,
            mem.code member_id_own,
            rblnc.acct_code_ata ata_code_own,
            rblnc.amt_blnc rblnc_blnc_amt_own,
            acct.accountname account_desc_own,
            rblnc.ca_id_ca_capco ca_id_own,
            ins.ordercol entitlement_ordercol,
            ins.sht_nm entitlement_ins_sht_nm,
            cae.amt_gross entitlement_amt_gross_own,
            cae.amt_tax entitlement_amt_tax_own,
            cae.amt_net entitlement_amt_net_own,
            cae.amt_frac_nom entitlement_frac_nom,
            cae.amt_frac_denom entitlement_frac_denom,
            substr(acct_ent.accountidentifiervalue,1,5) || '-' || substr(acct_ent.accountidentifiervalue,6,length(acct_ent.accountidentifiervalue)-10) || '-' || substr(acct_ent.accountidentifiervalue,-5,3) || '-' || substr(acct_ent.accountidentifiervalue,length(acct_ent.accountidentifiervalue)-1,2) entitlement_dep_acct_own,
            ip.hold_days ip_holding_period_own,
            ip.start_dat ip_start_date_own,
            ip.end_dat ip_end_date_own,
            ip.amt_blnc ip_holding_balance_own,
            ip.amt_gross ip_proceed_amount_own,
            ip.amt_tax ip_tax_amount_own,
            ip.amt_net ip_net_amount_own,
            ip.ca_id_ca_capco ip_ca_id,
            ip.acct_id_acct_capco ip_acct_id,
            (ip.applicable_rate*100) tax_rate_own
        from 
            record_balances@{config.DB_LINK_TOBAMR} rblnc,
            (select accountidentifiervalue, accountname, ident_operator
                from accountcomposite@{config.DB_LINK_TOBAMR}
                where ident_master is null ) acct,
            (select code, ident_stakeholder, longname
                from participant@{config.DB_LINK_TOBAMR}
                where ident_master is null ) mem,
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae,
            (select accountidentifiervalue, accountname, ident_operator
                from accountcomposite@{config.DB_LINK_TOBAMR}
                where ident_master is null ) acct_ent,
            interest_payments@{config.DB_LINK_TOBAMR} ip,
            (select code sht_nm, code id_ins_capco, 1 ordercol
                from currency@{config.DB_LINK_TOBAMR} where ident_master is null
                union all
                select name sht_nm, isin id_ins_capco, 2 ordercol
                from instrument@{config.DB_LINK_TOBAMR} where ident_master is null ) ins
        where 
            rblnc.amt_blnc != 0
            and rblnc.acct_id_acct_capco = acct.accountidentifiervalue 
            and substr(acct.accountidentifiervalue,6,4) = '0000' 
            and cae.client_id(+) = '0000'
            and rblnc.ca_id_ca_capco = cae.ca_id_ca_capco(+)
            and rblnc.acct_id_acct_capco = cae.acct_id_acct_capco_src(+)
            and cae.acct_id_acct_capco = acct_ent.accountidentifiervalue(+) 
            and cae.ins_id_ins_capco = ins.id_ins_capco(+)
            and cae.acct_id_acct_capco_src = ip.acct_id_acct_capco(+)
            and cae.ca_id_ca_capco = ip.ca_id_ca_capco(+)
            and acct.ident_operator = mem.ident_stakeholder
            and mem.code in ({placeholders}) -- where member_id_own = ca_member_id in Q_CORPORATE_ACTIONS
            and nls_upper(rblnc.ca_id_ca_capco) = nls_upper('{ca_id}') -- where ca_id_own = ca_id in Q_CORPORATE_ACTIONS
        order by ins.ordercol, ins.sht_nm
    """,
        list_member_id,
    )

    columns = list(cursor.description)
    rows = cursor.fetchall()
    results = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col.name.lower()] = row[i]
        results.append(row_dict)

    cursor.close()

    return [
        OwnAccount(
            entitlement_clnt_id_own=beautify_content(row["entitlement_clnt_id_own"]),
            account_id_own=beautify_content(row["account_id_own"]),
            account_id_disp_own=beautify_content(row["account_id_disp_own"]),
            member_id_own=beautify_content(row["member_id_own"]),
            ata_code_own=beautify_content(row["ata_code_own"]),
            rblnc_blnc_amt_own=Decimal(row["rblnc_blnc_amt_own"]) if row["rblnc_blnc_amt_own"] is not None else Decimal(0),
            account_desc_own=beautify_content(row["account_desc_own"]),
            ca_id_own=beautify_content(row["ca_id_own"]),
            entitlement_ordercol=beautify_content(row["entitlement_ordercol"]),
            entitlement_ins_sht_nm=beautify_content(row["entitlement_ins_sht_nm"]),
            entitlement_amt_gross_own=Decimal(
                row["entitlement_amt_gross_own"]
            ) if row["entitlement_amt_gross_own"] is not None else "-",
            entitlement_amt_tax_own=Decimal(
                row["entitlement_amt_tax_own"]
            ) if row["entitlement_amt_tax_own"] is not None else "-",
            entitlement_amt_net_own=Decimal(
                row["entitlement_amt_net_own"]
            ) if row["entitlement_amt_net_own"] is not None else "-",
            entitlement_frac_nom=Decimal(row["entitlement_frac_nom"]) if row["entitlement_frac_nom"] is not None else Decimal(0),
            entitlement_frac_denom=Decimal(
                row["entitlement_frac_denom"]
            ) if row["entitlement_frac_denom"] is not None else Decimal(0),
            entitlement_dep_acct_own=beautify_content(row["entitlement_dep_acct_own"]),
            ip_holding_period_own=int(row["ip_holding_period_own"]) if row["ip_holding_period_own"] is not None else "-",
            ip_start_date_own=beautify_content(row["ip_start_date_own"]),
            ip_end_date_own=beautify_content(row["ip_end_date_own"]),
            ip_holding_balance_own=Decimal(
                row["ip_holding_balance_own"]
            ) if row["ip_holding_balance_own"] is not None else "-",
            ip_proceed_amount_own=Decimal(
                row["ip_proceed_amount_own"]
            ) if row["ip_proceed_amount_own"] is not None else "-",
            ip_tax_amount_own=Decimal(row["ip_tax_amount_own"]) if row["ip_tax_amount_own"] is not None else "-",
            ip_net_amount_own=Decimal(row["ip_net_amount_own"]) if row["ip_net_amount_own"] is not None else "-",
            ip_ca_id=beautify_content(row["ip_ca_id"]),
            ip_acct_id=beautify_content(row["ip_acct_id"]),
            tax_rate_own=Decimal(row["tax_rate_own"]) if row["tax_rate_own"] is not None else "-",
        )
        for row in results
    ]


def fetch_global_amount(p_ca_id, conn: Connection):
    cursor = conn.cursor()
    cursor.execute(
        f"""
        select 
            sum(cae.amt_gross) global_amt_gross, 
            sum(cae.amt_tax) global_amt_tax, 
            sum(cae.amt_net) global_amt_net, 
            sum(cae.amt_frac_nom) global_frac_nom, 
            cae.amt_frac_denom global_frac_denom, 
            ins.ordercol global_ordercol, 
            ins.sht_nm global_sht_nm, 
            cae.ca_id_ca_capco global_cae_ca_id, 
            cae.ins_id_ins_capco global_ins 
        from 
            corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae, 
            (
                select 
                    code sht_nm, 
                    code id_ins_capco, 
                    1 ordercol 
                from 
                    currency@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null 
                union all 
                select 
                    name sht_nm, 
                    isin id_ins_capco, 
                    2 ordercol 
                from 
                    instrument@{config.DB_LINK_TOBAMR} 
                where 
                    ident_master is null
            ) ins 
        where 
            cae.ins_id_ins_capco = ins.id_ins_capco 
            and nls_upper(cae.ca_id_ca_capco) = nls_upper('{p_ca_id}') -- where global_cae_ca_id = ca_id in Q_CORPORATE_ACTION
        group by 
            cae.ca_id_ca_capco, 
            ins.ordercol, 
            ins.sht_nm, 
            cae.amt_frac_denom, 
            cae.ins_id_ins_capco 
        order by 
            ins.ordercol, 
            ins.sht_nm
    """
    )

    rows = cursor.fetchall()
    cursor.close()

    return [
        GlobalAmount(
            global_amt_gross=Decimal(row[0]) if row[0] is not None else "-",
            global_amt_tax=Decimal(row[1]) if row[1] is not None else "-",
            global_amt_net=Decimal(row[2]) if row[2] is not None else "-",
            global_frac_nom=Decimal(row[3]) if row[3] is not None else Decimal(0),
            global_frac_denom=Decimal(row[4]) if row[4] is not None else Decimal(0),
            global_ordercol=beautify_content(row[5]),
            global_sht_nm=beautify_content(row[6]),
            global_cae_ca_id=beautify_content(row[7]),
            global_ins=beautify_content(row[8]),
        )
        for row in rows
    ]


def fetch_client_acct(list_member_id, ca_id, conn: Connection):
    placeholders = ", ".join(":" + str(i + 1) for i in range(len(list_member_id)))

    cursor = conn.cursor()
    cursor.execute(
        f"""
    select 
        substr(acct.accountidentifiervalue,1,5) || '-' || substr(acct.accountidentifiervalue,6,length(acct.accountidentifiervalue)-10) || '-' || substr(acct.accountidentifiervalue,-5,3) || '-' || substr(acct.accountidentifiervalue,length(acct.accountidentifiervalue)-1,2) client_acct_id,
        mem.code  client_mem_id,
        rblnc.acct_code_ata client_ata_code,
        rblnc.amt_blnc client_blnc_amt,
        acct.accountname client_acct_desc,
        rblnc.ca_id_ca_capco new_client_ca_id,
        cae.amt_gross dep_amt_gross,
        cae.amt_tax dep_amt_tax,
        cae.amt_net dep_amt_net,
        ins.ordercol dep_ordercol,
        ins.sht_nm dep_ins_sht_nm,
        cae.amt_frac_nom dep_frac_nom,
        cae.amt_frac_denom dep_frac_denom,
        substr(acct1.accountidentifiervalue,1,5) || '-' || substr(acct1.accountidentifiervalue,6,length(acct1.accountidentifiervalue)-10) || '-' || substr(acct1.accountidentifiervalue,-5,3) || '-' || substr(acct1.accountidentifiervalue,length(acct.accountidentifiervalue)-1,2) dep_account_id_disp,
        ip.hold_days ip_holding_period_client,
        ip.start_dat ip_start_date_client,
        ip.end_dat ip_end_date_client,
        ip.amt_blnc ip_holding_balance_client,
        ip.amt_gross ip_proceed_amount_client,
        ip.amt_tax ip_tax_amount_client,
        ip.amt_net ip_net_amount_client,
        ip.ca_id_ca_capco ip_ca_id_client,
        ip.acct_id_acct_capco ip_acct_id_client,
        cae.applicable_rate client_tax_rate
    from record_balances@{config.DB_LINK_TOBAMR} rblnc
    , (select accountidentifiervalue, accountname, ident_operator
        from accountcomposite@{config.DB_LINK_TOBAMR}
        where ident_master is null ) acct
    , (select code, ident_stakeholder, longname
        from participant@{config.DB_LINK_TOBAMR}
        where ident_master is null ) mem
    , corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae
    , (select accountidentifiervalue, accountname, ident_operator
        from accountcomposite@{config.DB_LINK_TOBAMR}
        where ident_master is null ) acct1
    , interest_payments@{config.DB_LINK_TOBAMR} ip
    , (select code sht_nm, code id_ins_capco, 1 ordercol
        from currency@{config.DB_LINK_TOBAMR} where ident_master is null
        union all
        select name sht_nm, isin id_ins_capco, 2 ordercol
        from instrument@{config.DB_LINK_TOBAMR} where ident_master is null ) ins
    where rblnc.amt_blnc != 0
        and rblnc.acct_id_acct_capco = acct.accountidentifiervalue 
        and acct.ident_operator = mem.ident_stakeholder
        and substr(acct.accountidentifiervalue,6,4) != '0000' 
        and rblnc.ca_id_ca_capco = cae.ca_id_ca_capco(+)
        and cae.acct_id_acct_capco = acct1.accountidentifiervalue(+) 
        and rblnc.acct_id_acct_capco = cae.acct_id_acct_capco_src(+)
        and cae.ins_id_ins_capco = ins.id_ins_capco(+)
        and cae.acct_id_acct_capco_src = ip.acct_id_acct_capco(+)
        and cae.ca_id_ca_capco = ip.ca_id_ca_capco(+)
        and mem.code in ({placeholders}) -- where client_mem_id = ca_member_id in Q_CORPORATE_ACTIONS
        and nls_upper(rblnc.ca_id_ca_capco) = nls_upper('{ca_id}') -- where new_client_ca_id = ca_id in Q_CORPORATE_ACTIONS
    order by ins.ordercol, ins.sht_nm, ip.start_dat
    """,
        list_member_id,
    )

    columns = list(cursor.description)
    rows = cursor.fetchall()
    results = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col.name.lower()] = row[i]
        results.append(row_dict)

    cursor.close()

    return [
        ClientData(
            client_acct_id=beautify_content(row["client_acct_id"]),
            client_mem_id=beautify_content(row["client_mem_id"]),
            client_ata_code=beautify_content(row["client_ata_code"]),
            client_blnc_amt=Decimal(row["client_blnc_amt"]) if row["client_blnc_amt"] is not None else Decimal(0),
            client_acct_desc=beautify_content(row["client_acct_desc"]),
            new_client_ca_id=beautify_content(row["new_client_ca_id"]),
            dep_amt_gross=Decimal(row["dep_amt_gross"]) if row["dep_amt_gross"] is not None else "-",
            dep_amt_tax=Decimal(row["dep_amt_tax"]) if row["dep_amt_tax"] is not None else "-",
            dep_amt_net=Decimal(row["dep_amt_net"]) if row["dep_amt_net"] is not None else "-",
            dep_ordercol=beautify_content(row["dep_ordercol"]),
            dep_ins_sht_nm=beautify_content(row["dep_ins_sht_nm"]),
            dep_frac_nom=Decimal(row["dep_frac_nom"]) if row["dep_frac_nom"] is not None else Decimal(0),
            dep_frac_denom=Decimal(row["dep_frac_denom"]) if row["dep_frac_denom"] is not None else Decimal(0),
            dep_account_id_disp=beautify_content(row["dep_account_id_disp"]),
            ip_holding_period_client=int(
                row["ip_holding_period_client"]
            ) if row["ip_holding_period_client"] is not None else "-",
            ip_start_date_client=row["ip_start_date_client"],
            ip_end_date_client=row["ip_end_date_client"],
            ip_holding_balance_client=Decimal(
                row["ip_holding_balance_client"]
            ) if row["ip_holding_balance_client"] is not None else "-",
            ip_proceed_amount_client=Decimal(
                row["ip_proceed_amount_client"]
            ) if row["ip_proceed_amount_client"] is not None else "-",
            ip_tax_amount_client=Decimal(row["ip_tax_amount_client"]) if row["ip_tax_amount_client"] is not None else "-",
            ip_net_amount_client=Decimal(row["ip_net_amount_client"]) if row["ip_net_amount_client"] is not None else "-",
            ip_ca_id_client=beautify_content(row["ip_ca_id_client"]),
            ip_acct_id_client=beautify_content(row["ip_acct_id_client"]),
            client_tax_rate=Decimal(row["client_tax_rate"]) if row["client_tax_rate"] is not None else "-",
        )
        for row in results
    ]


def fetch_total(list_member_id, ca_id, conn: Connection):
    placeholders = ", ".join(":" + str(i + 1) for i in range(len(list_member_id)))

    cursor = conn.cursor()
    cursor.execute(
        f"""
    select 
        sum(cae.amt_gross) amt_gross,
        sum(cae.amt_tax) amt_tax,
        sum(cae.amt_net) amt_net,
        sum(cae.amt_frac_nom) frac_nom,
        cae.amt_frac_denom frac_denom,
        mem.code   account_member_id,
        cae.ca_id_ca_capco total_ca_id,
        ins.ordercol ordercol,
        ins.sht_nm ins_nm
    from corporate_action_entitlements@{config.DB_LINK_TOBAMR} cae
    , (select accountidentifiervalue, ident_operator
        from accountcomposite@{config.DB_LINK_TOBAMR} 
        where ident_master is null) acct
    , (select code sht_nm, code id_ins_capco, 1 ordercol
        from currency@{config.DB_LINK_TOBAMR} where ident_master is null
        union all
        select name sht_nm, isin id_ins_capco, 2 ordercol
        from instrument@{config.DB_LINK_TOBAMR} where ident_master is null 
    ) ins
    , (select code, ident_stakeholder, longname
        from participant@{config.DB_LINK_TOBAMR}
        where ident_master is null ) mem
    where cae.acct_id_acct_capco = acct.accountidentifiervalue
        and  cae.ins_id_ins_capco = ins.id_ins_capco
        and acct.ident_operator = mem.ident_stakeholder
        and mem.code in ({placeholders}) -- where account_member_id = ca_member_id in Q_CORPORATE_ACTIONS
        and nls_upper(cae.ca_id_ca_capco) = nls_upper('{ca_id}') -- where total_ca_id = ca_id in Q_CORPORATE_ACTION
    group by ca_id_ca_capco, ins.ordercol, ins.sht_nm, mem.code, cae.amt_frac_denom
    order by ins.ordercol, ins.sht_nm
    """,
        list_member_id,
    )

    columns = list(cursor.description)
    rows = cursor.fetchall()
    results = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col.name.lower()] = row[i]
        results.append(row_dict)

    cursor.close()

    return [
        TotalData(
            amt_gross=Decimal(row["amt_gross"]) if row["amt_gross"] is not None else "-",
            amt_tax=Decimal(row["amt_tax"]) if row["amt_tax"] is not None else "-",
            amt_net=Decimal(row["amt_net"]) if row["amt_net"] is not None else "-",
            frac_nom=Decimal(row["frac_nom"]) if row["frac_nom"] is not None else Decimal(0),
            frac_denom=Decimal(row["frac_denom"]) if row["frac_denom"] is not None else Decimal(0),
            account_member_id=beautify_content(row["account_member_id"]),
            total_ca_id=beautify_content(row["total_ca_id"]),
            ordercol=beautify_content(row["ordercol"]),
            ins_nm=beautify_content(row["ins_nm"]),
        )
        for row in results
    ]


"""
Fungsi-fungsi yang digunakan untuk proses mapping (jika diperlukan)
"""


# Fungsi-fungsi yang parameternya diambil dari query Corporate Action
def get_security_short(ca_flg_tax1):
    show = True
    if ca_flg_tax1 == 0 or ca_flg_tax1 is None:
        show = False
    return show


def get_cf_security(obj: CorporateAction):
    return obj.ca_seclongname


"""
1. Fungsi ini membutuhkan fungsi yang lain
2. Dia membutuhkan parameter SHORT yang belum diketahui berasal dari query fetch yang mana
def get_cf_sec_short(obj : CorporateAction):
    return DefineSecurityInfo(obj.ca_secshortcode, SHORT)
"""

"""
Fungsi ini membutuhkan fungsi yang lain
def get_cd_issuer_account(obj: CorporateAction):
    return (GetFormatAccount(obj.issuer_proceed_acct))
"""


# Fungsi-fungsi yang parameternya diambil dari query OWN_ACCOUNTS + CLIENT_ACCT
def get_cf_1formula0021(obj1: List[OwnAccount], obj2: List[ClientData]):
    cs_sum_rblnc_own = sum(data.rblnc_blnc_amt_own for data in obj1)
    cs_sum_rblnc_client = sum(data.client_blnc_amt for data in obj2)
    return cs_sum_rblnc_own + cs_sum_rblnc_client


def get_cf_corr_acct():
    return None


def get_cf_global_frac(obj: GlobalAmount):
    if obj.global_frac_nom == None or obj.global_frac_denom == None:
        return None
    else:
        return (obj.global_frac_nom) + "/" + (obj.global_frac_denom)


# Bingung apakah objek dari query bond_iss atau corporate action
def get_f_tax_pct(obj1: RsMember, obj2: CorporateAction):
    # If proxy voting don't show the tax
    if obj2.ca_type == 12:
        return False


def get_f_entitlement_dep_acct_own(obj: OwnAccount):
    # hide the column if there are 3 hyphens
    if obj.entitlement_dep_acct_own == "---":
        return False
    return True


def get_cf_entitlement_frac(obj: OwnAccount):
    if obj.entitlement_frac_nom == None or obj.entitlement_frac_denom == None:
        return None
    else:
        return (obj.entitlement_frac_nom) + "/" + (obj.entitlement_frac_denom)


def get_cf_client_tax_pct(obj: ClientData):
    return obj.client_tax_rate


def get_f_dep_account_id_disp(obj: ClientData):
    # hide the column if there are 3 hyphens
    if obj.dep_account_id_disp == "---":
        return False
    return True


def get_cf_dep_frac(obj: ClientData):
    if obj.dep_frac_nom == None or obj.dep_frac_denom == None:
        return None
    else:
        return (obj.dep_frac_nom) + "/" + (obj.dep_frac_denom)


def get_cf_frac(obj: TotalData):
    if obj.frac_nom == None or obj.frac_denom == None:
        return None
    else:
        return (obj.frac_nom) + "/" + (obj.frac_denom)


def fetch_GetCAID(p_ca_id, conn: Connection):
    cursor = conn.cursor()
    cursor.execute(
        f"""
    SELECT ca.id_ca_capco
    FROM corporate_actions ca
       , instrument_codes ic
    WHERE ic.ins_id_ins_capco = ca.ins_id_ins_capco
      AND ic.typ_code_ic = :P_SECURITY_CODE_TYPE
      AND ic.code_ic = :P_SECURITY_CODE
      AND ca.dat_pay = :P_EFF_DATE
      AND ca.typ_ca = :P_CA_TYPE"""
    )

    columns = [col[0] for col in cursor.description]
    rows = cursor.fetchall()

    results = []
    for row in rows:
        row_dict = dict(zip(columns, row))
        results.append(row_dict)

    cursor.close()

    return results


# Fungsi-fungsi mapping dari database ke JSON siap untuk jasper
def map_own_account_data(own_account: OwnAccount):
    return OwnAccountData(
        OWN_ACCOUNT=own_account.account_id_disp_own,
        OWN_ACCOUNT_DESC=own_account.account_desc_own,
        RECORD_BALANCE_OWN=own_account.rblnc_blnc_amt_own,
        TAX_PCT=format_tax(own_account.tax_rate_own),
        ENTITLEMENT_DEP_ACCT_OWN=own_account.entitlement_dep_acct_own,
        CF_INSTRUMENT_SHORT_OWN=own_account.entitlement_ins_sht_nm,
        ENTITLEMENT_AMT_GROSS_OWN=own_account.entitlement_amt_gross_own,
        ENTITLEMENT_AMT_NET_OWN=own_account.entitlement_amt_net_own,
        ENTITLEMENT_AMT_TAX=own_account.entitlement_amt_tax_own,
        CF_ENTITLEMENT_FRAC=format_frac(
            own_account.entitlement_frac_nom, own_account.entitlement_frac_denom
        ),
        HOLDING_PERIOD_OWN1=own_account.ip_holding_period_own,
        START_HOLDING_PERIOD_OWN1=own_account.ip_start_date_own,
        END_HOLDING_PERIOD_OWN1=own_account.ip_end_date_own,
        HOLDING_BALANCE_OWN1=own_account.ip_holding_balance_own,
        NET_AMOUNT_OWN1=own_account.ip_net_amount_own,
        PROCEED_AMOUNT_OWN1=own_account.ip_proceed_amount_own,
        TAX_AMOUNT_OWN1=own_account.ip_tax_amount_own,
    )


def map_client_account_data(client_account: ClientData):
    return ClientAccountData(
        CLIENT_ACCOUNT=client_account.client_acct_id,
        CLIENT_ACCOUNT_DESC=client_account.client_acct_desc,
        CLIENT_RECORD_BALANCE=client_account.client_blnc_amt,
        CLIENT_TAX_PCT=format_tax(client_account.client_tax_rate),
        CLIENT_DEPOSIT_ACCOUNT=client_account.dep_account_id_disp,
        DEP_INSTRUMENT=client_account.dep_ins_sht_nm,
        DEP_AMT_GROSS=client_account.dep_amt_gross,
        DEP_FRAC=format_frac(
            client_account.dep_frac_nom, client_account.dep_frac_denom
        ),
        DEP_AMT_TAX=client_account.dep_amt_tax,
        NET_PROCEED_AMT_CLIENT=client_account.dep_amt_net,
        HOLDING_PERIOD_CLIENT=client_account.ip_holding_period_client,
        START_HOLDING_PERIOD_CLIENT=client_account.ip_start_date_client,
        END_HOLDING_PERIOD_CLIENT=client_account.ip_end_date_client,
        HOLDING_BALANCE_CLIENT=client_account.ip_holding_balance_client,
        PROCEED_AMOUNT_CLIENT=client_account.ip_proceed_amount_client,
        TAX_AMOUNT_CLIENT=client_account.ip_tax_amount_client,
        NET_AMOUNT_CLIENT=client_account.ip_net_amount_client,
    )


def get_json_report_data(p_ca_id, conn: Connection):
    corporate_actions = fetch_corporate_action(p_ca_id, conn)
    global_amounts = fetch_global_amount(p_ca_id, conn)

    list_member_id = [
        ca.ca_member_id for ca in corporate_actions
    ]  # data yang akan digunakan sebagai basis grouping

    own_accounts = fetch_own_account(list_member_id, p_ca_id, conn)
    client_accounts = fetch_client_acct(list_member_id, p_ca_id, conn)

    totals = fetch_total(list_member_id, p_ca_id, conn)

    ca = corporate_actions[0]  # Assuming we're using the first corporate action

    ga: GlobalAmount = GlobalAmount("-", "-", "-", "-", "-", "-", "-", "-", "-")
    if len(global_amounts) > 0:
        ga = global_amounts[0]

    sub_data: List[SubData] = []
    for member_id in list_member_id:
        # grouping berdasarkan member_id
        own_account_data = [
            map_own_account_data(oa)
            for oa in own_accounts
            if oa.member_id_own == member_id
        ]
        client_account_data = [
            map_client_account_data(ca)
            for ca in client_accounts
            if ca.client_mem_id == member_id
        ]
        totalPerMember = [total for total in totals if total.account_member_id == member_id]

        total: TotalData = TotalData(
            "-","-","-",0,0,"-","-","-","-"
        )
        if len(totalPerMember) > 0:
            total = totalPerMember[0]

        own_account_data_nf = []
        own_account_data_formatted = []
        if len(own_account_data) == 0:
            own_account_data_nf = [OwnAccountData("","",0,"","","","","","","","","","","","","","")]
            own_account_data_formatted = [OwnAccountData("-","-","-","-","---","-","-","-","-","-","-","-","-","-","-","-","-")]
        else:
            own_account_data_nf = own_account_data

        client_account_data_nf = []
        client_account_data_formatted = []
        if len(client_account_data) == 0:
            client_account_data_nf = [ClientAccountData("","",0,"","","","","","","","","","","","","","")]
            client_account_data_formatted = [ClientAccountData("-","-","-","-","---","-","-","-","-","-","-","-","-","-","-","-","-")]
        else:
            client_account_data_nf = client_account_data

        sub_data.append(
            SubData(
                OWN_ACCOUNT_DATA=own_account_data_formatted if len(own_account_data) == 0 else own_account_data_nf,
                CLIENT_ACCOUNT_DATA=client_account_data_formatted if len(client_account_data) == 0 else client_account_data_nf,
                CLIENT_RECORD_BALANCE2=sum(
                    ca.CLIENT_RECORD_BALANCE for ca in client_account_data
                )
                + sum(oc.RECORD_BALANCE_OWN for oc in own_account_data),
                INSTRUMENT=total.ins_nm,
                FRAC=format_frac(total.frac_nom, total.frac_denom),
                AMT_GROSS=total.amt_gross,
                AMT_TAX=total.amt_tax,
                AMT_NET=total.amt_net,
                MEMBER=member_id,
            )
        )

    root_data = RootData(
        CA_ANNOUNCEMENT_DATE=ca.ca_announce_date,
        CA_DEADLINE_DATE=ca.ca_deadline_date,
        CA_EFFECT_DATE=ca.ca_effect_date,
        CA_EX_DATE=ca.ca_ex_date,
        CA_INT_END_DATE=ca.ca_interest_end_date,
        CA_INTEREST_ST_DATE=ca.ca_interest_start_date,
        CA_RECORD_DATE=ca.ca_record_date,
        CA_START_DATE=ca.ca_start_date,
        CA_TAX_METHOD=ca.ca_tax_method,
        CORPORATE_ACTION=ca.ca_type_desc,
        CORR_ACCT="-",
        CS_SUM_REC_BAL=sum(sd.CLIENT_RECORD_BALANCE2 for sd in sub_data),
        GLOBAL_FRAC=format_frac(ga.global_frac_nom, ga.global_frac_denom),
        GLOBAL_AMT_GROSS=ga.global_amt_gross,
        GLOBAL_AMT_NET=ga.global_amt_net,
        GLOBAL_AMT_TAX=ga.global_amt_tax,
        GLOBAL_INSTRUMENT=ga.global_sht_nm,
        ISSUER_ACCOUNT=ca.issuer_proceed_acct,
        P_REC_DATE=datetime.strptime(ca.ca_record_date, "%d/%m/%Y").strftime("%d %B %Y"),
        SECURITY=ca.ca_seclongname,
        SECURITY_SHORT=ca.ca_secshortcode,
        TIMESTAMP=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        SUB_DATA=sub_data,
    )

    # Convert RootData to JSON-serializable dictionary
    json_data = {
        key: beautify_content(value) for key, value in root_data.__dict__.items()
    }

    # Convert SubData objects within json_data to dictionaries
    json_data["SUB_DATA"] = [
        {
            key: (
                beautify_content(value)
                if key not in ["OWN_ACCOUNT_DATA", "CLIENT_ACCOUNT_DATA"]
                else value
            )
            for key, value in sub.__dict__.items()
        }
        for sub in json_data["SUB_DATA"]
    ]

    # Convert OWN_ACCOUNT_DATA and CLIENT_ACCOUNT_DATA to list of dictionaries
    for sub in json_data["SUB_DATA"]:
        sub["OWN_ACCOUNT_DATA"] = [
            {key: beautify_content(value) for key, value in own.__dict__.items()}
            for own in sub["OWN_ACCOUNT_DATA"]
        ]
        sub["CLIENT_ACCOUNT_DATA"] = [
            {key: beautify_content(value) for key, value in client.__dict__.items()}
            for client in sub["CLIENT_ACCOUNT_DATA"]
        ]

    return json_data


def get_failed_bio_member(tgl, tgl2, conn: Connection):
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT
            distinct p.code id_mem_failed_bio
        FROM
            record_balances@{config.DB_LINK_TOBAMR} rb
        JOIN corporate_actions@{config.DB_LINK_TOBAMR} ca ON rb.ca_id_ca_capco = ca.id_ca_capco
        JOIN instrument@{config.DB_LINK_TOBAMR} ins ON ca.ident_instrument = ins.ident_instrument
        JOIN assetclass@{config.DB_LINK_TOBAMR} ac ON ins.ident_assetclass = ac.ident_assetclass AND ac.ident_assetclasstype = 5
        JOIN participant@{config.DB_LINK_TOBAMR} p ON ins.ident_issuercsd = p.ident_stakeholder
        WHERE 
            ca.code_sta = 1
            AND (ca.dat_rec = '{tgl}' OR dat_pay = get_next_bus_date('{tgl}', 1))
        MINUS
        SELECT
            distinct memberid from reports
        WHERE
            tgl = '{tgl2}'
        AND
            dsc like 'Issuer Overview for Bonds -%'
    """
    )

    rows = cursor.fetchall()
    cursor.close()
    return [row[0] for row in rows]
