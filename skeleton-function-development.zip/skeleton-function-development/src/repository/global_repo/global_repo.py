from oracledb import Connection
import oracledb
from model.rs_data.rs_data import RsData
from config import config

def fetch_tgl(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
        to_char(
            get_last_bus_day(sysdate), 
            'DD-MON-YYYY'
        ) tgl, 
        to_char(
            get_next_bus_day(sysdate), 
            'YYYYMMDD'
        ) tgl2 
        from dual
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0], row[1]

def fetch_libur(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            count(*) as libur 
        from off_days 
        where 
            to_char(off_day, 'DD-MON-YYYY')= to_char(sysdate, 'DD-MON-YYYY')
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0]

def fetch_rs_datas(tgl, conn:Connection, typmet="", typsec=""):
    param = ""
    if typmet == "BMET":
        if typsec == "2":
            param = f"AND ca_type_ncsd = '{typmet}' AND typ_sec.cbest_code_val = '{typsec}'"
        else:
            param = f"AND ca_type_ncsd = '{typmet}' AND typ_sec.cbest_code_val != '2'"
    else:
        param = f"AND ca_type_ncsd != 'BMET'"

    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT 
            ca.id_ca_capco,
            ca_type_ncsd AS typmet, 
            typ_sec.cbest_code_val AS typsec, 
            ca.code_base_sec AS insname,  
            bal.mem_id_mem_capco AS id_mem, 
            COUNT(*) AS cnt  
        FROM record_balances@{config.DB_LINK_TOBAMR} bal  
        JOIN corporate_actions@{config.DB_LINK_TOBAMR} ca ON bal.ca_id_ca_capco = ca.id_ca_capco   
        JOIN ncsd_codes@{config.DB_LINK_TOBAMR} typ_sec ON ca.ident_assetclass = typ_sec.ncsd_code_val AND typ_sec.ncsd_col_nm = 'ASSET_CLASS'  
        WHERE  
            ca.typ_ca = 12 
            AND dat_rec = '{tgl}'  
            {param}
        GROUP  BY ca.id_ca_capco, 
                ca_type_ncsd, 
                typ_sec.cbest_code_val, 
                ca.code_base_sec, 
                bal.mem_id_mem_capco  
        ORDER  BY id_ca_capco, 
                id_mem
        FETCH FIRST 4 ROWS ONLY    
    """)

    rows = cursor.fetchall()
    cursor.close()

    return [RsData(id_ca_capco=row[0], typmet=row[1],
                   typsec=row[2], insname=row[3],
                   id_mem=row[4], cnt=row[5]) for row in rows]

def insert_report(id_member, tanggal, filename, dsc, conn:Connection):
    try:
        cursor = conn.cursor()
        cursor.execute(f"""
            insert into reports
            values 
            (
                :1, :2, :3, 
                :4, 'C-BEST'
            )
        """, (id_member, tanggal, filename, dsc))
        conn.commit()        
    except oracledb.DatabaseError as e:
        print(f"Error Insert To Oracle: {e}")
    finally:
        cursor.close()

def delete_report(id_member, tanggal, dsc, conn:Connection):
    try:
        cursor = conn.cursor()
        cursor.execute("""
            delete from reports
            where 
                tgl = :1 
                and memberid = :2 
                and dsc = :3 
                and tipe = 'C-BEST'
        """, (tanggal, id_member, dsc))
        conn.commit()
    except oracledb.DatabaseError as e:        
        print(f"Error Delete To Oracle: {e}")
    finally:
        cursor.close()

def fetch_cf_eff_date(p_since, conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT 
            get_next_bus_date@{config.DB_LINK_TOBAMR}(:p_since, 1)
        FROM dual
    """, {'p_since': p_since})

    row = cursor.fetchone()
    cursor.close()

    return row[0]

def fetch_tgl_bond(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            to_char(sysdate, 'DD-MON-YYYY') as dat_rec, 
            to_char(sysdate, 'YYYYMMDD') as dat_rec2 
        from 
            dual
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0], row[1]

def fetch_libur_bond(conn:Connection):
    cursor = conn.cursor()
    cursor.execute(f"""
        select 
            count(*) as libur 
        from 
            vw_off_bi_days 
        where 
            to_char(off_day, 'DD-MON-YYYY')= to_char(sysdate, 'DD-MON-YYYY')
    """)

    row = cursor.fetchone()
    cursor.close()

    return row[0]
