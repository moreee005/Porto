import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import config

def send_email(subject, html_body, receiver_email, cc_emails=None):
    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = config.SENDER_EMAIL
    message["To"] = receiver_email

    if cc_emails:
        message["Cc"] = ", ".join(cc_emails)

    body = MIMEText(html_body, 'html')

    message.attach(body)

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(config.SMTP_HOST, int(config.SMTP_PORT), context=context) as server:
        # server.starttls() # secure the connection
        server.login(config.USERNAME_EMAIL, config.PASSWORD_EMAIL) # login if necessary

        # Combine To and Cc recipients for sendmail
        all_recipients = [receiver_email] + (cc_emails or [])
        server.sendmail(config.SENDER_EMAIL, all_recipients, message.as_string())        
