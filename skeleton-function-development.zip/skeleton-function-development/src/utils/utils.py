import datetime
import decimal
import zipfile
import os
import logging


def beautify_content(data, format_date="%d %B %Y", empty_content="STRIPE"):
    if isinstance(data, (datetime.datetime, datetime.date)):
        return data.strftime(format_date)
    elif (
        isinstance(data, float)
        or isinstance(data, decimal.Decimal)
        or isinstance(data, int)
    ):
        return "{:,.2f}".format(data) if data is not None else "-"
    else:
        if empty_content == "EMPTY":
            return data if data is not None else ""
        return data if data is not None else "-"


def format_frac(frac_nom, frac_denom):
    return (
        "-"
        if (frac_nom is None or frac_nom == 0 or frac_nom == decimal.Decimal(0))
        and (frac_denom is None or frac_denom == 0 or frac_denom == decimal.Decimal(0))
        else f"{frac_nom}/{frac_denom}"
    )


def format_tax(tax):
    return f"{tax} %" if tax is not None and tax != "-" else "-"


def archive_pdf_to_zip(pdf_file):
    try:
        zip_filename = pdf_file.replace(".pdf", ".zip")
        with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(pdf_file, os.path.basename(pdf_file))

        logging.info(f"Archived {pdf_file} to {zip_filename} successfully!")
    except Exception as e:
        logging.info(f"Failed to archive {pdf_file}: {str(e)}")


def check_json_data(data):
    if data is None:
        logging.info("JSON data is Null")
        return False
    elif not data or data == {}:
        logging.info("JSON data is Empty")
        return False
    else:
        return True
