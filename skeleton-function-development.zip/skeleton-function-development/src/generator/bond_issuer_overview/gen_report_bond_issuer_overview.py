from services.bond_issuer_overview.bond_issuer_overview_db import bond_issuer_overview_maker_multi_db
from services.bond_issuer_overview.bond_issuer_overview_dc import bond_issuer_overview_maker_multi_data_collector

def gen_report_bio_dc():
    bond_issuer_overview_maker_multi_data_collector()

def gen_report_bio_db():
    bond_issuer_overview_maker_multi_db()