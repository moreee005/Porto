# from services.inv_letter_corpbond import inv_letter_corpbond
from services.invitation_letter_corpbond.inv_letter_corpbond import inv_letter_corp_svc_multiprocessing

def gen_report_inv_letter_corpbond():
    # inv_letter_corpbond
    inv_letter_corp_svc_multiprocessing()
