# from services.inv_letter_noncorpbond import inv_letter_noncorpbond_svc
from services.invitation_letter_noncorpbond.inv_letter_noncorpbond import inv_letter_noncorp_svc_multiprocessing

def gen_report_inv_letter_noncorpbond():
    # inv_letter_noncorpbond.inv_letter_noncorpbond_svc()
    inv_letter_noncorp_svc_multiprocessing()
