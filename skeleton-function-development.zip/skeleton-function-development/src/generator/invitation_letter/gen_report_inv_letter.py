# from services.inv_letter import inv_letter_svc
from services.invitation_letter.inv_letter import inv_letter_svc_multiprocessing

def gen_report_inv_letter():
    # inv_letter_svc()
    inv_letter_svc_multiprocessing()
