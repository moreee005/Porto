import json
import os
import time
from datetime import datetime
from pyreportjasper import PyReportJasper
from pathlib import Path
from utils.utils import archive_pdf_to_zip
import multiprocessing
from config import config
from services.bond_member_entitlement.bond_member_entitlement_utils import *

def generate_report_json(member_data):
    start_time = time.time()

    try:

        input_filename = 'Bond_Member_Entitlement_KSEI_Template.jrxml'
        input_file = os.path.join(RESOURCES_DIR, input_filename)

        id_mem = member_data["MEMBER"].split()[0]
        
        print(f'\nStart generate {id_mem} report')
        
        try:
            p_since_str = member_data["P_SINCE"]
            p_since_date = datetime.strptime(p_since_str, "%d %B %Y")
            p_since = p_since_date.strftime('%Y%m%d')
        except Exception as e:
            print(f"Error parsing 'P_SINCE' date: {str(e)}")
            return False

        # Create a unique output filename for each member
        output_filename = f'{id_mem}_Bond_Member_Entitlement_KSEI_{p_since}.pdf'
        output_file = os.path.join(REPORTS_DIR, output_filename)

        # Prepare the JSON data for this member
        json_data = json.dumps([member_data])
        bytes_data = json_data.encode('utf-8')

        try:
            # Configure the PyReportJasper instance
            pyreportjasper = PyReportJasper()
            pyreportjasper.config(
                input_file,
                output_file,
                output_formats=["pdf"],
                db_connection={
                    'driver': 'json',
                    'data_file': bytes_data,
                    'json_query': ''
                },
                resource=ASSET_DIR
            )
            pyreportjasper.process_report()
        
        except Exception as e:
            print(f"Error generating report: {str(e)}")
            return False

        end_time = time.time()

        # Check if the file is created
        if os.path.isfile(output_file):
            print('==========================')
            print(f'Report for {id_mem} generated successfully!')
            print(f'Output file name: {output_filename}')
            print(f'Time taken: {end_time - start_time} seconds')
            print('==========================')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                print(f"Error archiving report: {str(e)}")

            return True  # Report generated successfully
        else:
            print(f"Failed to generate report for {id_mem}.")
            return False  # Report generation failed
        
    except FileNotFoundError as fnf_error:
        print(f"File error: {fnf_error}")
    except json.JSONDecodeError as json_error:
        print(f"JSON error: {json_error}")
    except Exception as e:
        print(f"DB conn error in generate report or initialization failure: {str(e)}")
    
    end_time = time.time()
    print(f"Total time taken for generating report: {end_time - start_time} seconds")

def bond_member_entitlement_svc_json_multiprocessing():
    try:
        # Ensure the reports directory exists
        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

        start_time = time.time()

        try:
            data = 'bond_member.json'
            with open(os.path.join(RESOURCES_DIR, data), 'r') as file:
                json_data = json.load(file)
        except FileNotFoundError:
            print(f"Error: {data} file not found in {RESOURCES_DIR}")
            return
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON data: {str(e)}")
            return
        except Exception as e:
            print(f"Unexpected error while loading JSON data: {str(e)}")
            return

        print(f'Total CPU: {multiprocessing.cpu_count()}')

        try:
            # Use multiprocessing to generate reports in parallel
            with multiprocessing.Pool(processes=multiprocessing.cpu_count()) as pool:
                results = pool.map(generate_report_json, json_data)
        except Exception as e:
            print(f"Error during multiprocessing: {str(e)}")
            return

        end_time = time.time()

        # Count the number of reports successfully generated
        jml_report = sum(results)
        id_mem_failed_bmer = []

        print('=========================================')
        print(f'No. of Reports Generated: {jml_report}')
        print(f'Not generated Member BMER Report: {id_mem_failed_bmer}')
        print(f'Total time taken: {end_time - start_time} seconds')
        print('=========================================')
        
        # Send the email notification
        # try:
        #     tgl = datetime.now().strftime('%Y%m%d')
        #     send_email_report_bond_member_entitlement(config.RECEIVER_EMAIL, jml_report, tgl, id_mem_failed_bmer)
        # except Exception as e:
        #     print(f"Error sending email: {str(e)}")

    except Exception as e:
        print(f"An error occurred in the bond_member_entitlement_svc_json_multiprocessing function: {str(e)}")

    finally:
        end_time = time.time()
        print(f"Total time taken for processing: {end_time - start_time} seconds")
