import json
import os
import time
from datetime import datetime
import threading
from repository.global_repo.global_repo import fetch_tgl_bond, fetch_libur_bond, fetch_cf_eff_date, delete_report, insert_report
from repository.bond_member_entitlement.bond_member_entitlement_repo import fetch_id_mem, map_to_json, fetch_id_mem_failed
from pyreportjasper import PyReportJasper
from pathlib import Path
from config.db import get_connection_db
from utils.utils import archive_pdf_to_zip
import multiprocessing
import urllib.request
import urllib.parse
from config import config
from services.bond_member_entitlement.bond_member_entitlement_utils import *
import logging

def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'bond_member_entitlement.log'))  
        ]
    )

# get data from data collector
def get_data_collector(date):
    start_time = time.time()
    
    url = f"{config.HOST_DATA_COLLECTOR}/bond-member-entitlement?date={date}"
    api_key = config.API_KEY  
    
    headers = {
        'API-Key': api_key
    }
    
    request = urllib.request.Request(url, headers=headers)
    
    try:
        response = urllib.request.urlopen(request).read()
        end_time = time.time()
        
        if response:
            res = json.loads(response.decode("utf-8"))
            logging.info('=========================================')
            logging.info('Get data from Data Collector successfully!')
            logging.info(f"Total data: {len(res)}")
            logging.info(f'It took {end_time - start_time} seconds')
            logging.info('=========================================')
            return res
        else:
            logging.info("Failed Get Data From Data Collector")
            return None
    except urllib.error.URLError as e:
        logging.info(f"Failed to get data: {e.reason}")
        return None

def generate_report_dc(data):
    start_time = time.time()

    try:
        input_filename = 'Bond_Member_Entitlement_KSEI_Template.jrxml'
        input_file = os.path.join(RESOURCES_DIR, input_filename)

        logging.info(f'Start generate {data['ID_MEM']} report')
        
        # Create a unique output filename for each member
        output_filename = f'{data['ID_MEM']}_Bond_Member_Entitlement_KSEI_{data['P_SINCE_FN']}.pdf'
        output_file = os.path.join(REPORTS_DIR, output_filename)
        
        # Prepare the JSON data for this member
        json_data = json.dumps(data, indent=4)
        bytes_data = json_data.encode('utf-8')

        try:
            # Configure the PyReportJasper instance
            pyreportjasper = PyReportJasper()
            pyreportjasper.config(
                input_file,
                output_file,
                output_formats=["pdf"],
                db_connection={
                    'driver': 'json',
                    'data_file': bytes_data,
                    'json_query': ''
                },
                resource=ASSET_DIR
            )
            pyreportjasper.process_report()
        
        except Exception as e:
            logging.info(f"Error generating report: {str(e)}")
            return False

        end_time = time.time()

        if os.path.isfile(output_file):
            logging.info('==========================')
            logging.info(f'Report for {data['ID_MEM']} generated successfully!')
            logging.info(f'Output file name: {output_filename}')
            logging.info(f'Time taken: {end_time - start_time} seconds')
            logging.info('==========================')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # try:
            #     # deleting old report and inserting new report
            #     conn = get_connection_db()
            #     dsc = f'Bond Member Entitlement PDF - {data['P_SINCE_FN']}, {data['ID_MEM']}'
            #     filename = output_file.replace(".pdf", ".zip")
            #     delete_report(data['P_SINCE_FN'], data['ID_MEM'], dsc, conn)
            #     insert_report(data['ID_MEM'], data['P_SINCE_FN'], os.path.basename(filename), dsc, conn)
            #     if conn:
            #         conn.close()
            # except Exception as e:
            #     logging.info(f"Error inserting/deleting report in database: {str(e)}")
            #     return False

            return True  # Report generated success
        else:
            logging.info(f"Failed to generate report for {data['ID_MEM']}.")
            return False  # Report generation faile
        
    except FileNotFoundError as fnf_error:
        logging.info(f"File error: {fnf_error}")
    except json.JSONDecodeError as json_error:
        logging.info(f"JSON error: {json_error}")
    except Exception as e:
        logging.info(f"DB conn error in generate report or initialization failure: {str(e)}")
    
    end_time = time.time()
    logging.info(f"Total time taken for generating report: {end_time - start_time} seconds")

def bond_member_entitlement_svc_dc_multiprocessing():
    config_log()
    
    conn = None
    try:
        conn = get_connection_db()

        try:
            libur = fetch_libur_bond(conn)
        except Exception as e:
            logging.info(f"Error fetching holiday data: {str(e)}")
            return

        if libur == 0:
            # Ensure the reports directory exists
            Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

            try:
                # Fetch tgl and p_since values
                # tgl, p_since = fetch_tgl_bond(conn)
                tgl, p_since = ('09-SEP-2024', '20240909')
            except Exception as e:
                logging.info(f"Error fetching tgl and p_since: {str(e)}")
                return

            start_time = time.time()

            # Load data from data collector
            try:
                dat_rec_encoded = urllib.parse.quote(datetime.strptime(tgl, "%d-%b-%Y").strftime("%d %B %Y"))
                json_data = get_data_collector(dat_rec_encoded)
                if json_data is None:
                    end_time = time.time()
                    logging.info('=========================================')
                    logging.info("No data available to process. Exiting.")
                    logging.info(f'Total time taken: {end_time - start_time} seconds')
                    logging.info('=========================================')
                    return
            except Exception as e:
                logging.info(f"Error loading data from data collector: {str(e)}")
                return

            num_process = min(len(json_data), multiprocessing.cpu_count())
            logging.info(f'Total CPU: {num_process}')

            try:
                # Use multiprocessing to generate reports in parallel
                with multiprocessing.Pool(processes=num_process) as pool:
                    results = pool.map(generate_report_dc, json_data)
            except Exception as e:
                logging.info(f"Error during multiprocessing: {str(e)}")
                return

            end_time = time.time()

            # Count the number of reports successfully generated
            try:
                jml_report = sum(r for r in results if r is True)
                # id_mem_failed_bmer = fetch_id_mem_failed(tgl, p_since, conn)
                id_mem_failed_bmer = "-"
            except Exception as e:
                logging.info(f"Error fetching failed members: {str(e)}")
                id_mem_failed_bmer = []  # In case of error, initialize with an empty list

            logging.info('=========================================')
            logging.info(f'No. of Reports Generated: {jml_report}')
            logging.info(f'Not generated Member BMER Report: {id_mem_failed_bmer}')
            logging.info(f'Total time taken: {end_time - start_time} seconds')
            logging.info('=========================================')
        
        # Send the email notification
        try:
            threading.Thread(
                target=send_email_report_bond_member_entitlement,
                kwargs={
                    'receiver_email': config.RECEIVER_EMAIL,
                    'jml_report': jml_report,
                    'dat_rec': tgl,
                    'id_mem_failed_bmer': id_mem_failed_bmer
                }
            ).start()
        except Exception as e:
            logging.info(f"Error sending email notification: {str(e)}")

    except Exception as e:
        logging.info(f"Database connection error or initialization failure: {str(e)}")

    finally:
        # Ensure that the connection is properly closed
        if conn:
            try:
                conn.close()
            except Exception as e:
                logging.info(f"Error closing the database connection: {str(e)}")
