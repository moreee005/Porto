import os
import logging
from utils.email import send_email
from config import config

RESOURCES_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'report_template', 'bond_member_report')
ASSET_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'asset')
REPORTS_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'output_report')
LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'log')

def send_email_report_bond_member_entitlement(receiver_email, jml_report, dat_rec, id_mem_failed_bmer):
    # Prepare the email content
    subject = f"Generate Bond Member Entitlement PDF {dat_rec}"
    html_body = f"""
        <p>PDF Report Creation for Bond Member Entitlement is done</p>
        <p><strong>Record date:</strong> {dat_rec}</p>
        <p><strong>No. of Reports Generated:</strong> {jml_report}</p>
        <p><strong>Not generated Member BMER Report:</strong> {id_mem_failed_bmer}</p>
    """

    # Send the email using the send_email function
    send_email(subject, html_body, receiver_email, [config.CC_EMAIL])
    logging.info("Email sent..")
