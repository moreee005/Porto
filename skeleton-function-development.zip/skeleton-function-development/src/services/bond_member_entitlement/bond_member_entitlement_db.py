import json
import os
import time
import threading
from repository.global_repo.global_repo import fetch_tgl_bond, fetch_libur_bond, fetch_cf_eff_date, delete_report, insert_report
from repository.bond_member_entitlement.bond_member_entitlement_repo import fetch_id_mem, map_to_json, fetch_id_mem_failed
from pyreportjasper import PyReportJasper
from pathlib import Path
from config.db import get_connection_db
from utils.utils import archive_pdf_to_zip
import multiprocessing
from config import config
from services.bond_member_entitlement.bond_member_entitlement_utils import *
import logging

def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'bond_member_entitlement.log'))  
        ]
    )

#generate from db
def generate_report_db(id_mem, tgl, cf_eff_date, p_since):
    start_time = time.time()
    conn = None

    try:
        conn = get_connection_db()

        input_filename = 'Bond_Member_Entitlement_KSEI_Template.jrxml'
        input_file = os.path.join(RESOURCES_DIR, input_filename)

        logging.info(f'Start generate {id_mem} report')
        
        # Create a unique output filename for each member
        output_filename = f'{id_mem}_Bond_Member_Entitlement_KSEI_{p_since}.pdf'
        output_file = os.path.join(REPORTS_DIR, output_filename)
        
        # Prepare the JSON data for this member
        member_data = map_to_json(id_mem, tgl, cf_eff_date, conn)
        json_data = json.dumps(member_data, indent=4)

        with open(f"result_{id_mem}_{p_since}.json", "w") as outfile:
            outfile.write(json_data)

        bytes_data = json_data.encode('utf-8')

        try:
            # Configure the PyReportJasper instance
            pyreportjasper = PyReportJasper()
            pyreportjasper.config(
                input_file,
                output_file,
                output_formats=["pdf"],
                db_connection={
                    'driver': 'json',
                    'data_file': bytes_data,
                    'json_query': ''
                },
                resource=ASSET_DIR
            )
            pyreportjasper.process_report()
        
        except Exception as e:
            logging.info(f"Error generating report: {str(e)}")
            return False

        end_time = time.time()

        if os.path.isfile(output_file):
            logging.info('==========================')
            logging.info(f'Report for {id_mem} generated successfully!')
            logging.info(f'Output file name: {output_filename}')
            logging.info(f'Time taken: {end_time - start_time} seconds')
            logging.info('==========================')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # try:
            #     # deleting old report and inserting new report
            #     dsc = f'Bond Member Entitlement PDF - {p_since}, {id_mem}'
            #     filename = output_file.replace(".pdf", ".zip")
            #     delete_report(p_since, id_mem, dsc, conn)
            #     insert_report(id_mem, p_since, os.path.basename(filename), dsc, conn)
            # except Exception as e:
            #     logging.info(f"Error inserting/deleting report in database: {str(e)}")
            #     return False

            return True  # Report generated success
        else:
            logging.info(f"Failed to generate report for {id_mem}.")
            return False  # Report generation faile
        
    except FileNotFoundError as fnf_error:
        logging.info(f"File error: {fnf_error}")
    except json.JSONDecodeError as json_error:
        logging.info(f"JSON error: {json_error}")
    except Exception as e:
        logging.info(f"DB conn error in generate report or initialization failure: {str(e)}")
    finally:
        # Ensure that the connection is properly closed
        if conn:
            try:
                conn.close()
            except Exception as e:
                logging.info(f"Error closing the database connection: {str(e)}")
    
    end_time = time.time()
    logging.info(f"Total time taken for generating report: {end_time - start_time} seconds")

# Multiprocessing from database
def bond_member_entitlement_svc_db_multiprocessing():
    config_log()

    conn = None
    try:
        conn = get_connection_db()

        try:
            libur = fetch_libur_bond(conn)
        except Exception as e:
            logging.info(f"Error fetching holiday data: {str(e)}")
            return

        if libur == 0:
            # Ensure the reports directory exists
            Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

            try:
                # tgl, p_since = fetch_tgl_bond(conn)
                tgl, p_since = ('09-SEP-2024', '20240909')
            except Exception as e:
                logging.info(f"Error fetching tgl or p_since: {str(e)}")
                return

            try:
                start_rs = time.time()
                cf_eff_date = fetch_cf_eff_date(tgl, conn)
                # p_member = fetch_id_mem(tgl, cf_eff_date, conn)
                p_member = ['XL001']
                end_rs = time.time()
                logging.info('=========================================')
                logging.info('Get p_member from Oracle DB successfully!')
                logging.info(f"Total data: {len(p_member)}")
                logging.info(f'It took {end_rs - start_rs} seconds')
                logging.info('=========================================')
            
            except Exception as e:
                logging.info(f"Error fetching cf_eff_date or member data: {str(e)}")
                return
            
            try :
                start_time = time.time()

                num_process = min(len(p_member), multiprocessing.cpu_count())
                logging.info(f'Total CPU: {num_process}')

                # Use multiprocessing to generate reports in parallel
                with multiprocessing.Pool(processes=num_process) as pool:
                    results = pool.starmap(
                        generate_report_db,
                        [(id_mem, tgl, cf_eff_date, p_since) for id_mem in p_member]
                    )

                end_time = time.time()

                # Count the number of reports successfully generated
                jml_report = sum(r for r in results if r is True)
                # id_mem_failed_bmer = fetch_id_mem_failed(tgl, p_since, conn)
                id_mem_failed_bmer = "-"

                logging.info('=========================================')
                logging.info(f'No. of Reports Generated: {jml_report}')
                logging.info(f'Not generated Member BMER Report: {id_mem_failed_bmer}')
                logging.info(f'Total time taken: {end_time - start_time} seconds')
                logging.info('=========================================')

            except Exception as e:
                logging.info(f"Error during report generation: {str(e)}")
                return

        try:
            # Send the email notification
            threading.Thread(
                target=send_email_report_bond_member_entitlement,
                kwargs={
                    'receiver_email': config.RECEIVER_EMAIL,
                    'jml_report': jml_report,
                    'dat_rec': tgl,
                    'id_mem_failed_bmer': id_mem_failed_bmer
                }
            ).start()
        except Exception as e:
            logging.info(f"Error sending email notification: {str(e)}")
    
    except Exception as e:
        logging.info(f"Database connection error or initialization failure: {str(e)}")

    finally:
        # Ensure that the connection is properly closed
        if conn:
            try:
                conn.close()
            except Exception as e:
                logging.info(f"Error closing the database connection: {str(e)}")

#generate from db for test
def generate_report(id_mem, tgl, cf_eff_date, p_since, conn):
    start_time = time.time()

    try:

        input_filename = 'Bond_Member_Entitlement_KSEI_Template.jrxml'
        input_file = os.path.join(RESOURCES_DIR, input_filename)

        logging.info(f'\nStart generate {id_mem} report')
        
        # Create a unique output filename for each member
        output_filename = f'{id_mem}_Bond_Member_Entitlement_KSEI_{p_since}.pdf'
        output_file = os.path.join(REPORTS_DIR, output_filename)
        
        # Prepare the JSON data for this member
        member_data = map_to_json(id_mem, tgl, cf_eff_date, conn)
        json_data = json.dumps(member_data, indent=4)
        bytes_data = json_data.encode('utf-8')

        try:
            # Configure the PyReportJasper instance
            pyreportjasper = PyReportJasper()
            pyreportjasper.config(
                input_file,
                output_file,
                output_formats=["pdf"],
                db_connection={
                    'driver': 'json',
                    'data_file': bytes_data,
                    'json_query': ''
                },
                resource=ASSET_DIR
            )
            pyreportjasper.process_report()
        
        except Exception as e:
            logging.info(f"Error generating report: {str(e)}")
            return False

        end_time = time.time()

        if os.path.isfile(output_file):
            logging.info('==========================')
            logging.info(f'Report for {id_mem} generated successfully!')
            logging.info(f'Output file name: {output_filename}')
            logging.info(f'Time taken: {end_time - start_time} seconds')
            logging.info('==========================')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # try:
            #     # deleting old report and inserting new report
            #     dsc = f'Bond Member Entitlement PDF - {p_since}, {id_mem}'
            #     delete_report(p_since, id_mem, dsc, conn)
            #     insert_report(id_mem, p_since, output_filename, dsc, conn)
            # except Exception as e:
            #     logging.info(f"Error inserting/deleting report in database: {str(e)}")
            #     return False

            return True  # Report generated success
        else:
            logging.info(f"Failed to generate report for {id_mem}.")
            return False  # Report generation faile
        
    except FileNotFoundError as fnf_error:
        logging.info(f"File error: {fnf_error}")
    except json.JSONDecodeError as json_error:
        logging.info(f"JSON error: {json_error}")
    except Exception as e:
        logging.info(f"DB conn error in generate report or initialization failure: {str(e)}")
    finally:
        # Ensure that the connection is properly closed
        if conn:
            try:
                conn.close()
            except Exception as e:
                logging.info(f"Error closing the database connection: {str(e)}")

    
    end_time = time.time()
    logging.info(f"Total time taken for generating report: {end_time - start_time} seconds")
