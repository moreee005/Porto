import json
import os
import time
import threading
from pyreportjasper import PyReportJasper
from pathlib import Path
from repository.invitation_letter.inv_letter_repo import fetch_data
from repository.global_repo.global_repo import fetch_libur, fetch_rs_datas, fetch_tgl, delete_report, insert_report
from config.db import get_connection_db
from utils.email import send_email 
from utils.utils import archive_pdf_to_zip
from config import config
from multiprocessing import Pool, cpu_count, Manager
import logging

RESOURCES_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'report_template', 'inv_letter_report')
ASSET_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'asset')
REPORTS_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'output_report')
LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'log')
    
def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'invitation_letter.log'))  
        ]
    )

def generate_report(data, tgl2, conn):
    try:
        input_file = os.path.join(RESOURCES_DIR, 'Invitation_Letter_KSEI.jrxml')
        output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_{tgl2}_{data.id_ca_capco}_{data.id_mem}")
        
        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

        inv_data = fetch_data(data.id_ca_capco, data.id_mem, conn)
        json_data = json.dumps(inv_data)
        bytes_data = json_data.encode('utf-8')

        pyreportjasper = PyReportJasper()
        pyreportjasper.config(
            input_file,
            output_file,
            output_formats=["pdf"],
            db_connection={
                'driver': 'json',
                'data_file': bytes_data,
                'json_query': ''
            },
            resource=ASSET_DIR
        )
        pyreportjasper.process_report()

        output_file_path = output_file + '.pdf'
        if os.path.isfile(output_file_path):
            logging.info(f"Report generated for {output_file_path} successfully!")
            return output_file_path
        else:
            raise FileNotFoundError(f"Report generation failed for id_mem: {data.id_mem} - File not found: {output_file_path}")
        
    except Exception as e:
        logging.error(f"Unexpected error during report generation for id_mem: {data.id_mem} - Error: {e}")
        raise e 

    
def inv_letter_svc():
    try:
        conn = get_connection_db()
        libur = fetch_libur(conn)

        if libur == 0:
            id_mem_failed_il = []
            jml_report = 0
            tgl, tgl2 = fetch_tgl(conn)
            
            start_rs = time.time()
            rs_data = fetch_rs_datas(tgl="19-AUG-2024", conn=conn)        
            end_rs = time.time()        
            
            logging.info('=========================================')
            logging.info('Get RS Data from Oracle DB successfully!')
            logging.info(f"Total data: {len(rs_data)}")
            logging.info(f'It took {end_rs - start_rs} seconds')
            logging.info('=========================================')
            
            for data in rs_data:
                try:
                    output_file = generate_report(data, tgl2, conn)
                    
                    if os.path.isfile(output_file):
                        logging.info(f'Report generated for {output_file} successfully!')
                        jml_report += 1

                        archive_pdf_to_zip(output_file)
                        os.remove(output_file)
                    else:
                        raise FileNotFoundError(f"Generated file not found for {data.id_mem}")
                
                except FileNotFoundError as fnf_error:
                    logging.error(f"File generation failed for {data.id_mem}: {fnf_error}")
                    id_mem_failed_il.append(data.id_mem)
                except Exception as e:
                    logging.error(f"Failed to generate for {data.id_mem}: {str(e)}")
                    id_mem_failed_il.append(data.id_mem)

            # Send the report email in a separate thread
            threading.Thread(
                target=send_report_email,
                kwargs={
                    'dat_rec': tgl,
                    'jmlReport': jml_report,
                    'id_mem_failed_il': ", ".join(id_mem_failed_il) if id_mem_failed_il else "-"
                }
            ).start()
        else:
            logging.info(f"Reports not generated on {tgl} because the system detected it as a holiday.")

    except ConnectionError as ce:
        logging.error(f"Failed to connect to the database: {ce}")
    except Exception as e:
        logging.error(f"Unexpected error in inv_letter_svc: {e}")
    finally:
        if conn:
            conn.close()
            logging.info("Database connection closed.")

def inv_letter_svc_multiprocessing():
    config_log()
    try:
        conn = get_connection_db()
        libur = fetch_libur(conn)

        if libur == 0:
            tgl, tgl2 = fetch_tgl(conn)
            
            start_rs = time.time()
            rs_data = fetch_rs_datas(tgl="19-AUG-2024", conn=conn)        
            end_rs = time.time()        
            logging.info('Get RS Data from Oracle DB successfully!')
            logging.info(f"Total data: {len(rs_data)}")
            logging.info(f'It took {end_rs - start_rs} seconds')

            input_file = os.path.join(RESOURCES_DIR, 'Invitation_Letter_KSEI.jrxml')

            # Use Manager to handle shared data correctly
            with Manager() as manager:
                id_mem_failed_il = manager.list()
                jml_report = manager.Value('i', 0)
                lock = manager.Lock()
                start_time = time.time()

                # num_process = cpu_count()
                num_process = min(len(rs_data), cpu_count())
                logging.info(num_process)
                
                with Pool(processes=num_process) as pool:
                    pool.starmap(generate_multiprocessing, [(data.__dict__, tgl2, input_file, id_mem_failed_il, jml_report, lock) for data in rs_data])
                            
                end_time = time.time()
                logging.info(f'Total reports generated: {jml_report.value}')
                logging.info(f'It took {end_time - start_time} seconds')

                threading.Thread(
                    target=send_report_email,
                    kwargs={
                        'dat_rec': tgl,
                        'jmlReport': jml_report.value,
                        'id_mem_failed_il': ", ".join(id_mem_failed_il) if id_mem_failed_il else "-"
                    }
                ).start()
                
    except ConnectionError as ce:
        logging.error(f"Failed to connect to the database: {ce}")
    except Exception as e:
        logging.error(f"Error during report generation service: {e}")
    finally:
        if conn:
            conn.close()
            logging.info("Database connection closed.")
    
def send_report_email(dat_rec, jmlReport, id_mem_failed_il):
    subject = f"Generate Invitation Letter Report PDF {dat_rec}"
    
    html_body = f"""
    <html>
    <body>
        <p>PDF Report Creation for Invitation Letter is done</p>
        <p><strong>Record date:</strong> {dat_rec}</p>
        <p><strong>No. of Report Generated:</strong> {jmlReport}</p>
        <p><strong>Not generated Invitation Letter Report:</strong> {id_mem_failed_il}</p>
    </body>
    </html>
    """
    
    receiver_email = config.RECEIVER_EMAIL 

    try:
        send_email(subject, html_body, receiver_email)
        logging.info("Email sent successfully.")
    except Exception as e:
        logging.error(f"Failed to send email: {e}")

def generate_multiprocessing(data, tgl2, input_file, id_mem_failed_il, jml_report, lock):
    conn = get_connection_db()
    
    start_time = time.time() 
    try:
        output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_{tgl2}_{data['id_ca_capco']}_{data['id_mem']}")
        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

        inv_data = fetch_data(data['id_ca_capco'], data['id_mem'], conn)

        json_data = json.dumps(inv_data)

        bytes_data = json_data.encode('utf-8')

        pyreportjasper = PyReportJasper()
        pyreportjasper.config(
            input_file,
            output_file,
            output_formats=["pdf"],
            db_connection={
                'driver': 'json',
                'data_file': bytes_data,
                'json_query': ''
            },
            resource=ASSET_DIR
        )
        pyreportjasper.process_report()

        output_file = output_file + '.pdf'
        if os.path.isfile(output_file):
            with lock:  # Ensure only one process modifies the number at a time
                jml_report.value += 1

            logging.info(f'Report generated for {output_file} successfully!')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # dsc = f"Invitation Letter - {data['id_ca_capco']} {data['insname']} : {data['id_mem']}"
            # filename = output_file.replace(".pdf", ".zip")
            # delete_report(data['id_mem'], tgl2, dsc, conn)
            # insert_report(data['id_mem'], tgl2, os.path.basename(filename), dsc, conn)
        else:
            raise FileNotFoundError("Failed to generate PDF File!")
        
    except FileNotFoundError as e:
        logging.error(f"File not found error: {e}")
        with lock:
            id_mem_failed_il.append(data['id_mem'])
    except Exception as e:
        logging.error(f"General error for {data['id_mem']}: {e}")
        with lock:
            id_mem_failed_il.append(data['id_mem'])

    finally:
        conn.close()

    end_time = time.time()
    logging.info(f'Generate Report processing took {end_time - start_time} seconds')
