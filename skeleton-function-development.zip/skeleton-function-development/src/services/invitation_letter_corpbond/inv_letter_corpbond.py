import json
from multiprocessing import Manager, Pool, cpu_count
import os
import threading
import time
import logging
from pyreportjasper import PyReportJasper
from pathlib import Path
from repository.invitation_letter_corpbond.inv_letter_corpbond_repo import fetch_data
from repository.global_repo.global_repo import fetch_libur, fetch_rs_datas, fetch_tgl, delete_report, insert_report
from config.db import get_connection_db
from config import config
from utils.email import send_email
from utils.utils import archive_pdf_to_zip

RESOURCES_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'report_template', 'inv_letter_corpbond_report')
ASSET_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'asset')
REPORTS_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'output_report')
LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'log')

def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'invitation_letter_corpbond.log'))  
        ]
    )

def generate_report(data, tgl2, conn):
    input_file = os.path.join(RESOURCES_DIR, 'Invitation_Letter_KSEI_KTUR_CorpBond_field.jrxml')
    output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_KTUR_CorpBond_{tgl2}_{data.id_ca_capco}_{data.id_mem}")
    
    Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)
    
    inv_data = fetch_data(data.id_ca_capco, data.id_mem, conn)
    json_data = json.dumps(inv_data)
    bytes_data = json_data.encode('utf-8')
    
    pyreportjasper = PyReportJasper()
    pyreportjasper.config(
        input_file,
        output_file,
        output_formats=["pdf"],
        db_connection={
            'driver': 'json',
            'data_file': bytes_data,
            'json_query': ''
        },
        resource=ASSET_DIR
    )
    pyreportjasper.process_report()
    
    return output_file + '.pdf'

def inv_letter_corpbond_svc():
    conn = get_connection_db()
    libur = fetch_libur(conn)

    if libur == 0:
        list_failed_id_mem = []
        jml_report = 0
        tgl, tgl2 = fetch_tgl(conn)
        
        rs_data = fetch_rs_datas(tgl="19-AUG-2024", typmet="BMET", typsec="2", conn=conn)

        for data in rs_data:
            try:
                output_file = generate_report(data, tgl2, conn)
                
                if os.path.isfile(output_file):
                    logging.info(f'Report generated for {output_file} successfully!')
                    jml_report += 1

                    archive_pdf_to_zip(output_file)
                    os.remove(output_file)
            except Exception as e:
                logging.info(f"Failed to generate for {data.id_mem}: {str(e)}")
                list_failed_id_mem.append(data.id_mem)

        threading.Thread(
            target=send_email_inv_letter_corpbond, 
            kwargs={"tgl" : tgl, 
                "jml_report" : jml_report, 
                "id_mem_failed" : list_failed_id_mem, 
                "receiver_email" : config.RECEIVER_EMAIL
            }
        ).start()
    
    conn.close()


def inv_letter_corp_svc_multiprocessing():
    config_log()

    conn = get_connection_db()
    libur = fetch_libur(conn)

    if libur == 0:
        tgl, tgl2 = fetch_tgl(conn)

        start_rs = time.time()
        rs_data = fetch_rs_datas(tgl="19-AUG-2024", typmet="BMET", typsec="2", conn=conn)
        end_rs = time.time()
        logging.info('=========================================')
        logging.info('Get RS Data from Oracle DB successfully!')
        logging.info(f"Total data: {len(rs_data)}")
        logging.info(f'It took {end_rs - start_rs} seconds')
        logging.info('=========================================')

        input_file = os.path.join(RESOURCES_DIR, 'Invitation_Letter_KSEI_KTUR_CorpBond_field.jrxml')        

        with Manager() as manager:
            list_failed_id_mem = manager.list()
            jml_report = manager.Value('i', 0)
            lock = manager.Lock()
            start_time = time.time()

            # num_process = cpu_count()
            num_process = min(len(rs_data), cpu_count())
            logging.info(num_process)
            
            with Pool(processes=num_process) as pool:
                pool.starmap(generate_multiprocessing, [(data.__dict__, tgl2, input_file, list_failed_id_mem, jml_report, lock) for data in rs_data])

            end_time = time.time()
            logging.info(f'Total reports generated: {jml_report.value}')
            logging.info(f'It took {end_time - start_time} seconds')

            threading.Thread(
                target=send_email_inv_letter_corpbond, 
                kwargs={
                    "tgl" : tgl, 
                    "jml_report" : jml_report.value, 
                    "id_mem_failed" : ", ".join(list_failed_id_mem) if list_failed_id_mem else "-", 
                    "receiver_email" : config.RECEIVER_EMAIL
                }
            ).start()
    
    conn.close()


def generate_multiprocessing(data, tgl2, input_file, list_failed_id_mem, jml_report, lock):    
    conn = get_connection_db()
    start_time = time.time()
    try:             
        output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_KTUR_CorpBond_{tgl2}_{data['id_ca_capco']}_{data['id_mem']}")
        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

        inv_data = fetch_data(data['id_ca_capco'], data['id_mem'], conn)

        json_data = json.dumps(inv_data)

        bytes_data = json_data.encode('utf-8')

        pyreportjasper = PyReportJasper()
        pyreportjasper.config(
            input_file,
            output_file,
            output_formats=["pdf"],
            db_connection={
                'driver': 'json',
                'data_file': bytes_data,
                'json_query': ''
            },
            resource=ASSET_DIR
        )
        pyreportjasper.process_report()

        output_file = output_file + '.pdf'
        if os.path.isfile(output_file):
            with lock:
                jml_report.value += 1
            logging.info('====================================================')
            logging.info(f'Report generated for {output_file} successfully!')
            logging.info('====================================================')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # dsc = f"Invitation Letter Corpbond - {data['id_ca_capco']} {data['insname']} : {data['id_mem']}"
            # filename = output_file.replace(".pdf", ".zip")
            # delete_report(data['id_mem'], tgl2, dsc, conn)
            # insert_report(data['id_mem'], tgl2, os.path.basename(filename), dsc, conn)
        else:
            raise Exception("Failed to generate PDF")

    except Exception as e:        
        logging.info(f"Failed to generate for {data['id_mem']}: {str(e)}")
        with lock:
            list_failed_id_mem.append(data['id_mem'])
    
    finally:
        conn.close()

    end_time = time.time()
    logging.info(f'Generate Report processing took {end_time - start_time} seconds')



def send_email_inv_letter_corpbond(tgl, jml_report, id_mem_failed, receiver_email):
    subject = f"Generate Invitation Letter CorpBond PDF {tgl}"
    html_body = f"""
        <p>PDF Report Creation for Invitation Letter CorpBond is done</p>
        <p><strong>Record date:</strong> {tgl}</p>
        <p><strong>No. of Reports Generated:</strong> {jml_report}</p>
        <p><strong>Not generated Corp Bond Report:</strong> {id_mem_failed}</p>
    """
    send_email(subject, html_body, receiver_email)
    logging.info("email sent..")
