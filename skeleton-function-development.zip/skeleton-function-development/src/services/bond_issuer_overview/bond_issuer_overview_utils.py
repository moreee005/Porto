import json
import os
import logging
from pyreportjasper import PyReportJasper
from utils.email import send_email

RESOURCES_DIR = os.path.join(
    os.path.abspath(os.path.dirname(__file__)),
    "..",
    "..",
    "resources",
    "report_template",
    "bond_issuer_report",
)
ASSET_DIR = os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "..", "..", "resources", "asset"
)
REPORTS_DIR = os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "..", "..", "resources", "output_report"
)
LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'log')

def generate_pdf_report(input_file, output_file, json_data):
    datas = json.dumps(json_data)
    bytes_data = datas.encode("utf-8")

    pyreportjasper = PyReportJasper()
    pyreportjasper.config(
        input_file,
        output_file,
        output_formats=["pdf"],
        db_connection={
            "driver": "json",
            "data_file": bytes_data,
            "json_query": "",
        },
        resource=ASSET_DIR,
    )
    pyreportjasper.process_report()
    return output_file + ".pdf"


# send email
def send_email_report_bond_issuer_overview(
    receiver_email, jml_report, dat_rec, id_mem_failed_bio
):
    # Prepare the email content
    subject = f"Generate Bond Issuer Overview PDF {dat_rec}"
    html_body = f"""
        <p>PDF Report Creation for Bond Issuer Overview is done</p>
        <p><strong>Record date:</strong> {dat_rec}</p>
        <p><strong>No. of Reports Generated:</strong> {jml_report}</p>
        <p><strong>Not generated Bond Issuer Overview Report:</strong> {id_mem_failed_bio}</p>
    """

    # Send the email using the send_email function
    send_email(subject, html_body, receiver_email)
    logging.info("Email sent..")