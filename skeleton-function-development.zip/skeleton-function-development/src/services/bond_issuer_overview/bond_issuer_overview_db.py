import json
import os
import time
import multiprocessing
import traceback
import threading
import oracledb
import logging
from config import config
from config.db import get_connection_db
from repository.bond_issuer_overview.bond_issuer_overview_repo import fetch_bond_issuer, get_json_report_data, get_failed_bio_member
from repository.global_repo.global_repo import fetch_libur_bond, fetch_tgl_bond, delete_report, insert_report
from pyreportjasper import PyReportJasper
from pathlib import Path
from utils.utils import archive_pdf_to_zip, check_json_data
from services.bond_issuer_overview.bond_issuer_overview_utils import *

def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'bond_issuer_overview.log'))  
        ]
    )

def bond_issuer_overview_maker():
    conn = get_connection_db()

    libur = fetch_libur_bond(conn)

    if libur == 0:
        dat_rec, dat_rec2 = fetch_tgl_bond(conn)

        start_rs = time.time()
        rs_mem = fetch_bond_issuer("19-AUG-2024", conn)
        end_rs = time.time()
        logging.info(rs_mem)
        logging.info("=========================================")
        logging.info("Get RsMember from Oracle DB successfully!")
        logging.info(f"Total data: {len(rs_mem)}")
        logging.info(f"It took {end_rs - start_rs} seconds")
        logging.info("=========================================")

        input_file = os.path.join(RESOURCES_DIR, "Bond_Issuer_Overview.jrxml")

        # to be used rs_mem for various fetch queries (if necessary)
        jmlReport = 0
        id_member_failed = []
        start_time = time.time()
        for data in rs_mem:
            filename = (
                f"Bond_Issuer_Overview_KSEI_{data.catype}_{data.sec}_{data.id_mem}"
            )
            dsc = f"Issuer Overview for Bonds -{data.id_mem}, {data.sec}, {data.catype}"
            output_file = os.path.join(REPORTS_DIR, filename)

            Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

            # with open(os.path.join(RESOURCES_DIR, "bio_dummy.json"), "r") as file:
            # json_data = json.load(file)
            try:
                p_ca_id = data.id_ca_capco
                json_data = get_json_report_data(p_ca_id, conn)

                datas = json.dumps(json_data, indent=4)

                # with open(f"result_{p_ca_id}.json", "w") as outfile:
                #     outfile.write(datas)

                bytes_data = datas.encode("utf-8")

                pyreportjasper = PyReportJasper()
                pyreportjasper.config(
                    input_file,
                    output_file,
                    output_formats=["pdf"],
                    db_connection={
                        "driver": "json",
                        "data_file": bytes_data,
                        "json_query": "",
                    },
                    resource=ASSET_DIR,
                )
                pyreportjasper.process_report()
                end_time = time.time()

                output_file = output_file + ".pdf"
                if os.path.isfile(output_file):
                    logging.info("=========================================")
                    logging.info(f"Report {output_file} Generated successfully!")
                    logging.info(f"It took {end_time - start_time} seconds")
                    logging.info("=========================================")
                    jmlReport += 1
                else:
                    raise Exception("PDF file not generated")
            except Exception as e:
                logging.info(f"Failed to generate for {data.id_mem}: {str(e)}")
                logging.info(traceback.format_exc())
            # finally:
            #     delete_report(data.id_mem, dat_rec, dsc, conn)
            #     insert_report(data.id_mem, dat_rec, filename, dsc, conn)

        # id_member_failed = get_failed_bio_member(dat_rec, dat_rec2, conn)
        id_member_failed = []
        end_time = time.time()
        logging.info(f"Total reports generated : {jmlReport}")
        logging.info(f"Total failed reports    : {len(id_member_failed)}")
        logging.info(f"It took {end_time - start_time} seconds")

        # Email Service
        # threading.Thread(
        #     target=send_email_report_bond_issuer_overview,
        #     kwargs={
        #         'receiver_email': config.RECEIVER_EMAIL,
        #         'jml_report': jmlReport,
        #         'dat_rec': dat_rec,
        #         'id_mem_failed_bio': ", ".join(id_member_failed) if id_member_failed else "-"
        #     }
        # ).start()

    conn.close()


def process_data(data, input_file, dat_rec2):
    conn = get_connection_db()

    filename = (
        f"Bond_Issuer_Overview_KSEI_{data['id_ca_capco']}_{data['sec']}_{data['id_mem']}"
    )
    dsc = (
        f"Issuer Overview for Bonds - {data['id_mem']}, {data['sec']}, {data['catype']}"
    )
    output_file = os.path.join(REPORTS_DIR, filename)
    Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

    try:
        p_ca_id = data["id_ca_capco"]
        json_data = get_json_report_data(p_ca_id, conn)

        if check_json_data(json_data) == False:
            logging.info("Data is not Valid")
            return

        output_file = generate_pdf_report(input_file, output_file, json_data)
        if os.path.isfile(output_file):
            logging.info(f"Report {output_file} Generated successfully!")

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # filename = output_file.replace(".pdf", ".zip")
            # delete_report(data['id_mem'], dat_rec2, dsc, conn)
            # delete_report('KSEI1', dat_rec2, dsc, conn)
            # insert_report(data['id_mem'], dat_rec2, os.path.basename(filename), dsc, conn)
            # insert_report('KSEI1', dat_rec2, os.path.basename(filename), dsc, conn)
            # if conn:
            #     conn.close()

            return True
        else:
            raise Exception("PDF file not generated")
    except Exception as e:
        logging.info(f"Failed to generate for {data['id_mem']}: {str(e)}")
        if conn:
            conn.close()
        return False


def bond_issuer_overview_maker_multi_db():
    config_log()

    try:
        conn = get_connection_db()

        libur = fetch_libur_bond(conn)

        if libur == 0:
            dat_rec, dat_rec2 = fetch_tgl_bond(conn)

            start_rs = time.time()
            # rs_mem = fetch_bond_issuer(dat_rec, conn)
            rs_mem = fetch_bond_issuer("19-AUG-2024", conn)
            end_rs = time.time()
            
            logging.info("=========================================")
            logging.info("Get RsMember from Oracle DB successfully!")
            logging.info(f"Total data: {len(rs_mem)}")
            logging.info(f"It took {end_rs - start_rs} seconds")
            logging.info("=========================================")

            input_file = os.path.join(RESOURCES_DIR, "Bond_Issuer_Overview.jrxml")

            jmlReport = 0
            start_time = time.time()

            num_process = min(len(rs_mem), multiprocessing.cpu_count())
            logging.info(f"Total CPU: {num_process}")

            with multiprocessing.Pool(processes=num_process) as pool:
                results = pool.starmap(
                    process_data,
                    [
                        (data.__dict__, input_file, dat_rec2)
                        for data in rs_mem
                    ],
                )

            jmlReport = sum(r for r in results if r is True)
            # id_member_failed = get_failed_bio_member(dat_rec, dat_rec2, conn)
            id_member_failed = []

            end_time = time.time()
            logging.info(f"Total reports generated : {jmlReport}")
            logging.info(f"Total failed reports    : {len(id_member_failed)}")
            logging.info(f"It took {end_time - start_time} seconds")

            # Email Service
            threading.Thread(
                target=send_email_report_bond_issuer_overview,
                kwargs={
                    "receiver_email": config.RECEIVER_EMAIL,
                    "jml_report": jmlReport,
                    "dat_rec": dat_rec,
                    "id_mem_failed_bio": (
                        ", ".join(id_member_failed) if id_member_failed else "-"
                    ),
                },
            ).start()
    except oracledb.Error as e:
        logging.info(f"Unexpected Error Connection to Oracle Database: {str(e)}")
    finally:
        if conn:
            conn.close()
