import json
import os
import time
import multiprocessing
import urllib.request
import urllib.parse
import threading
import logging
from datetime import datetime
import oracledb
from config import config
from config.db import get_connection_db
from repository.global_repo.global_repo import fetch_libur_bond, fetch_tgl_bond, delete_report, insert_report
from repository.bond_issuer_overview.bond_issuer_overview_repo import get_failed_bio_member
from pathlib import Path
from utils.utils import archive_pdf_to_zip, check_json_data
from services.bond_issuer_overview.bond_issuer_overview_utils import *

def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'bond_issuer_overview.log'))  
        ]
    )

def get_data_collector(date):
    start_time = time.time()

    url = f"{config.HOST_DATA_COLLECTOR}/bond-issuer-overview?date={date}"
    api_key = config.API_KEY

    headers = {"API-Key": api_key}

    request = urllib.request.Request(url, headers=headers)
    try:
        response = urllib.request.urlopen(request).read()

        end_time = time.time()

        if response:
            res = json.loads(response.decode("utf-8"))
            logging.info("================================================")
            logging.info("Get data_issuer from datacollector successfully!")
            logging.info(f"Total data: {len(res)}")
            logging.info(f"It took {end_time - start_time} seconds")
            logging.info("================================================")
            return res

    except urllib.error.URLError as e:
        logging.info(f"Failed to get data: {e.reason}")
        return None


def process_data_dc(data, dat_rec2):
    input_file = os.path.join(RESOURCES_DIR, "Bond_Issuer_Overview.jrxml")
    filename = f"Bond_Issuer_Overview_KSEI_{data['ID_CA_CAPCO']}_{data['SEC']}_{data['ID_MEM']}"
    dsc = (
        f"Issuer Overview for Bonds - {data['ID_MEM']}, {data['SEC']}, {data['CATYPE']}"
    )
    output_file = os.path.join(REPORTS_DIR, filename)
    Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

    try:
        output_file = generate_pdf_report(input_file, output_file, data)
        if os.path.isfile(output_file):
            logging.info(f"Report {output_file} Generated successfully!")

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # conn = get_connection_db()
            # filename = output_file.replace(".pdf", ".zip")
            # delete_report(data['ID_MEM'], dat_rec2, dsc, conn)
            # delete_report('KSEI1', dat_rec2, dsc, conn)
            # insert_report(data['ID_MEM'], dat_rec2, os.path.basename(filename), dsc, conn)
            # insert_report('KSEI1', dat_rec2, os.path.basename(filename), dsc, conn)
            # if conn:
            #     conn.close()

            return True
        else:
            raise Exception("PDF file not generated")
    except Exception as e:
        logging.info(f"Failed to generate for {data['ID_MEM']}: {str(e)}")
        return False


def bond_issuer_overview_maker_multi_data_collector():
    config_log()
    
    try:
        conn = get_connection_db()

        libur = fetch_libur_bond(conn)

        if libur == 0:
            # dat_rec, dat_rec2 = fetch_tgl_bond(conn)
            dat_rec, dat_rec2 = ("14-AUG-2024", "20240814")

            start_rs = time.time()

            # Load data from data collector
            try:
                dat_rec_encoded = urllib.parse.quote(
                    datetime.strptime(dat_rec, "%d-%b-%Y").strftime("%d %B %Y")
                )
                json_data = get_data_collector(dat_rec_encoded)
                if check_json_data(json_data) == False:
                    end_time = time.time()
                    logging.info("=========================================")
                    logging.info("No data available to process. Exiting.")
                    logging.info(f"Total time taken: {end_time - start_rs} seconds")
                    logging.info("=========================================")
                    return
            except Exception as e:
                logging.info(f"Error loading data from data collector: {str(e)}")
                return

            jmlReport = 0
            start_time = time.time()

            num_process = min(len(json_data), multiprocessing.cpu_count())
            logging.info(f"Total CPU: {num_process}")

            with multiprocessing.Pool(processes=num_process) as pool:
                results = pool.starmap(
                    process_data_dc,
                    [(data, dat_rec2) for data in json_data],
                )

            jmlReport = sum(r for r in results if r is True)
            # id_member_failed = get_failed_bio_member(dat_rec, dat_rec2, conn)
            id_member_failed = []

            end_time = time.time()
            logging.info(f"Total reports generated : {jmlReport}")
            logging.info(f"Total failed reports    : {len(id_member_failed)}")
            logging.info(f"It took {end_time - start_time} seconds")

            # Email Service
            threading.Thread(
                target=send_email_report_bond_issuer_overview,
                kwargs={
                    "receiver_email": config.RECEIVER_EMAIL,
                    "jml_report": jmlReport,
                    "dat_rec": dat_rec,
                    "id_mem_failed_bio": (
                        ", ".join(id_member_failed) if id_member_failed else "-"
                    ),
                },
            ).start()
    except oracledb.Error as e:
        logging.info(f"Unexpected Error Connection to Oracle Database: {str(e)}")
    finally:
        if conn:
            conn.close()
