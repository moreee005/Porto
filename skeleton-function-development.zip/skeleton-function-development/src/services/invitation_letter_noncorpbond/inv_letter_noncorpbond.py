import json
from multiprocessing import Manager, Pool, cpu_count
import threading
import os
from config.db import get_connection_db
from config import config
import time
from pyreportjasper import PyReportJasper
from pathlib import Path
from utils.email import send_email
from repository.invitation_letter_noncorpbond.inv_letter_noncorpbond_repo import fetch_data
from repository.global_repo.global_repo import fetch_libur, fetch_rs_datas, fetch_tgl, delete_report, insert_report
from utils.utils import archive_pdf_to_zip
import logging


RESOURCES_DIR = os.path.join(
    os.path.abspath(os.path.dirname(__file__)),
    "..",
    "..",
    "resources",
    "report_template",
    "inv_letter_noncorpbond_report",
)
ASSET_DIR = os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "..", '..', "resources", "asset"
)
REPORTS_DIR = os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "..", '..', "resources", "output_report"
)
LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'log')

def config_log():
    Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOG_DIR, 'invitation_letter_noncorpbond.log'))  
        ]
    )

def inv_letter_noncorpbond_svc():
    conn = get_connection_db()

    libur = fetch_libur(conn)

    if libur == 0:
        jml_report = 0
        list_failed_id_mem_ncb = []
        tgl, tgl2 = fetch_tgl(conn)

        start_rs = time.time()
        rs_data = fetch_rs_datas(tgl="18-JUL-2024", typmet="BMET", conn=conn)
        end_rs = time.time()
        logging.info("=========================================")
        logging.info("Get RS Data from Oracle DB successfully!")
        logging.info(f"Total data: {len(rs_data)}")
        logging.info(f"It took {end_rs - start_rs} seconds")
        logging.info("=========================================")

        input_file = os.path.join(
            RESOURCES_DIR, "Invitation_Letter_KSEI_KTUR_NonCorpBond_field.jrxml"
        )

        start_time = time.time()
        for data in rs_data:
            try:
                output_file = os.path.join(
                REPORTS_DIR,
                    f"Invitation_Letter_KSEI_KTUR_NonCorpBond_{tgl2}_{data.id_ca_capco}_{data.id_mem}",
                )
                Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

                inv_data = fetch_data(data.id_ca_capco, data.id_mem, conn)

                json_data = json.dumps(inv_data)

                bytes_data = json_data.encode("utf-8")

                pyreportjasper = PyReportJasper()
                pyreportjasper.config(
                    input_file,
                    output_file,
                    output_formats=["pdf"],
                    db_connection={
                        "driver": "json",
                        "data_file": bytes_data,
                        "json_query": "",
                    },
                    resource=ASSET_DIR,
                )
                pyreportjasper.process_report()

                end_time = time.time()

                output_file = output_file + ".pdf"
                if os.path.isfile(output_file):
                    logging.info("==============================")
                    logging.info(f"Report generated for {output_file} successfully!")
                    logging.info(f"It took {end_time - start_time} seconds")
                    logging.info("==============================")
                    jml_report += 1
                
            except Exception as e:
                logging.info(f"Failed to generate for {data.id_mem}: {str(e)}")
                list_failed_id_mem_ncb.append(data.id_mem)   


        end_time_total = time.time()
        logging.info(f'Total reports generated: {jml_report}')
        logging.info(f'It took {end_time_total - start_time} seconds')
        
        threading.Thread(
            target=send_email_inv_letter_noncorpbond, 
            kwargs={"tgl" : tgl, 
                "jml_report" : jml_report, 
                "id_mem_failed_ncb" : list_failed_id_mem_ncb, 
                "receiver_email" : config.RECEIVER_EMAIL
            }
        ).start()

    conn.close()

def inv_letter_noncorp_svc_multiprocessing():
    config_log()
    try:
        conn = get_connection_db()
        logging.info("Database connection established successfully.")
        libur = fetch_libur(conn)

        if libur == 0:
            tgl, tgl2 = fetch_tgl(conn)

            start_rs = time.time()
            rs_data = fetch_rs_datas(tgl="18-JUL-2024", typmet="BMET", conn=conn)
            end_rs = time.time()
            logging.info('=========================================')
            logging.info('Get RS Data from Oracle DB successfully!')
            logging.info(f"Total data: {len(rs_data)}")
            logging.info(f'It took {end_rs - start_rs} seconds')
            logging.info('=========================================')

            input_file = os.path.join(RESOURCES_DIR, 'Invitation_Letter_KSEI_KTUR_NonCorpBond_field.jrxml')        

            with Manager() as manager:
                list_failed_id_mem_ncb = manager.list()
                jml_report = manager.Value('i', 0)
                lock = manager.Lock()
                start_time = time.time()

                # num_process = cpu_count()
                num_process = min(len(rs_data), cpu_count())
                logging.info(f'Number of Process for multiprocessing: {num_process}')
                
                with Pool(processes=num_process) as pool:
                    pool.starmap(generate_multiprocessing, [(data.__dict__, tgl2, list_failed_id_mem_ncb, jml_report, lock) for data in rs_data])

                end_time = time.time()
                
                logging.info(f'Total reports generated: {jml_report.value}. It took {end_time - start_time} seconds')

                threading.Thread(
                    target=send_email_inv_letter_noncorpbond, 
                    kwargs={
                        "tgl" : tgl, 
                        "jml_report" : jml_report.value, 
                        "id_mem_failed_ncb" : ", ".join(list_failed_id_mem_ncb) if list_failed_id_mem_ncb else "-", 
                        "receiver_email" : config.RECEIVER_EMAIL
                    }
                ).start()
        
    except ConnectionError as ce:
        logging.error(f"Database connection error: {str(ce)}")
    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
    finally:
        if conn:
            conn.close()
            logging.info("Database connection closed.")
            
def generate_report(data, tgl2, conn):
    try:
        input_file = os.path.join(RESOURCES_DIR, 'Invitation_Letter_KSEI_KTUR_NonCorpBond_field.jrxml')
        # output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_KTUR_NonCorpBond_{tgl2}_{data.id_ca_capco}_{data.id_mem}")
        output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_KTUR_NonCorpBond_{tgl2}_{data['id_ca_capco']}_{data['id_mem']}")

        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

        inv_data = fetch_data(data['id_ca_capco'], data['id_mem'], conn)
        # inv_data = fetch_data(data.id_ca_capco, data.id_mem, conn)
        json_data = json.dumps(inv_data)
        bytes_data = json_data.encode('utf-8')

        pyreportjasper = PyReportJasper()
        pyreportjasper.config(
            input_file,
            output_file,
            output_formats=["pdf"],
            db_connection={
                'driver': 'json',
                'data_file': bytes_data,
                'json_query': ''
            },
            resource=ASSET_DIR
        )
        pyreportjasper.process_report()

        output_file = output_file + '.pdf'
        if os.path.isfile(output_file):
            logging.info(f'Report generated successfully for {data["id_mem"]}')
            return output_file
        else:
            raise Exception("Failed to generate PDF")
    except Exception as e:
        logging.error(f"Error generating report for {data['id_mem']}: {e}")
        return None
    
def generate_multiprocessing(data, tgl2, list_failed_id_mem_ncb, jml_report, lock):    
    conn = get_connection_db()
    start_time = time.time()

    try:
        output_file = generate_report(data, tgl2, conn)
        
        if output_file:
            with lock:
                jml_report.value += 1

            logging.info(f'Report generated for {output_file}')

            # archive to zip
            try:
                archive_pdf_to_zip(output_file)
                os.remove(output_file)
            except Exception as e:
                logging.info(f"Error archiving report: {str(e)}")

            # dsc = f"Invitation Letter Noncorpbond - {data['id_ca_capco']} {data['insname']} : {data['id_mem']}"
            # filename = output_file.replace(".pdf", ".zip")
            # delete_report(data['id_mem'], tgl2, dsc, conn)
            # insert_report(data['id_mem'], tgl2, os.path.basename(filename), dsc, conn)
        else:
            raise Exception("Failed to generate PDF")

    except Exception as e:
        logging.error(f"Failed to generate report for {data['id_mem']}: {e}")
        with lock:
            list_failed_id_mem_ncb.append(data['id_mem'])

    finally:
        conn.close()

    end_time = time.time()
    logging.info(f'Generate Report processing took {end_time - start_time} seconds')


def send_email_inv_letter_noncorpbond(
    receiver_email, tgl, jml_report, id_mem_failed_ncb
):
    subject = f"Generate Invitation Letter NonCorpBond PDF {tgl}"
    html_body = f"""
        <p>PDF Report Creation for Invitation Letter NonCorpBond is done</p>
        <p><strong>Record date:</strong> {tgl}</p>
        <p><strong>No. of Reports Generated:</strong> {jml_report}</p>
        <p><strong>Not generated Non Corp Bond Report:</strong> {id_mem_failed_ncb}</p>
    """

    try:
        send_email(subject, html_body, receiver_email)
        logging.info("Email sent successfully.")
    except Exception as e:
        logging.error(f"Failed to send email: {str(e)}")
