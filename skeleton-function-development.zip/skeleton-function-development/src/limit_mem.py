import resource
import platform
import sys
import os
import psutil
from config import config

def memory_limit_exec(percentage: float):
    if platform.system() not in ("Linux", "Darwin"):
        print('This function only works on Linux and macOS!')
        return

    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        total_memory = psutil.virtual_memory().total
        limit = int(total_memory * percentage)
        print(f"soft: {soft}, hard: {hard}")
        print(f"total_memory: {total_memory}")
        print(f"limit_max_memory: {limit}")
        resource.setrlimit(resource.RLIMIT_AS, (limit, hard))
    except Exception as e:
        print(f"Failed to set memory limit: {e}")

def get_memory_usage():
    return psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)  # in MB

def limit_memory(percentage=float(config.MEM_LIMIT)):
    def decorator(function):
        def wrapper(*args, **kwargs):
            memory_limit_exec(percentage)
            try:
                result = function(*args, **kwargs)
                print(f'Peak memory usage: {get_memory_usage():.2f} MB')
                return result
            except MemoryError:
                available_memory = psutil.virtual_memory().available / (1024 * 1024)
                print(f'Available memory: {available_memory:.2f} MB')
                sys.stderr.write('\n\nERROR: Memory Exception\n')
                sys.exit(1)
        return wrapper
    return decorator
