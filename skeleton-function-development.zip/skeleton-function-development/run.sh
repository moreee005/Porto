#!/bin/bash
cd /opt/pyfunction-report
poetry run python ./src/app.py --generate $1
