# pyfunction-report

## Pre-requisite
- Preferred use WSL for Development Environment
- Python 3.12
- Poetry (Used for dependency management), [How to install Poetry](https://python-poetry.org/docs/#installation)
- JDK 11

## How To Install This Project
- Poetry use python3.12
```sh
poetry env use python3.12
```
- Configure Virtual Environment inside project
```sh
poetry config virtualenvs.in-project true
```
- Install Required Dependency
```sh
poetry install
```
- Check Poetry Env Info
```sh
poetry env info
```
- Generate Report
```sh
poetry run python src/app.py --generate <REPORT_NAME>
```
Fill REPORT_NAME with report name to be generated,
Report name available:
- inv_letter_corpbond (Generate only Report Invitation Letter KTUR Corp Bond)
- inv_letter_noncorpbond (Generate only Report Invitation Letter KTUR Non Corp Bond)
- inv_letter (Generate only Report Invitation Letter)
- bond_member_entitlement (Generate only Report Bond Member Entitlement)
- bond_issuer_overview (Generate only Report Bond Issuer Overview)
