import unittest
from unittest.mock import MagicMock, patch
from decimal import Decimal
import zipfile
from services.bond_issuer_overview.bond_issuer_overview_dc import *
from model.bond_issuer_overview.bond_issuer_overview_model import *
from repository.bond_issuer_overview.bond_issuer_overview_repo import *


class TestBioFunctions(unittest.TestCase):
    def test_map_own_account_data(self):
        mock_own_account = MagicMock(spec=OwnAccount)
        mock_own_account.entitlement_clnt_id_own = ("12345",)
        mock_own_account.account_id_own = ("67890",)
        mock_own_account.account_id_disp_own = ("ABC-123",)
        mock_own_account.member_id_own = ("98765",)
        mock_own_account.ata_code_own = ("XYZ",)
        mock_own_account.rblnc_blnc_amt_own = (Decimal("1000.50"),)
        mock_own_account.account_desc_own = ("Savings Account",)
        mock_own_account.ca_id_own = ("CA-54321",)
        mock_own_account.entitlement_ordercol = ("1",)
        mock_own_account.entitlement_ins_sht_nm = ("Short Name",)
        mock_own_account.entitlement_amt_gross_own = (Decimal("500.25"),)
        mock_own_account.entitlement_amt_tax_own = (Decimal("50.03"),)
        mock_own_account.entitlement_amt_net_own = (Decimal("450.22"),)
        mock_own_account.entitlement_frac_nom = Decimal("3")
        mock_own_account.entitlement_frac_denom = Decimal("4")
        mock_own_account.entitlement_dep_acct_own = ("DEP-987",)
        mock_own_account.ip_holding_period_own = (30,)
        mock_own_account.ip_start_date_own = ("2023-01-01",)
        mock_own_account.ip_end_date_own = ("2023-01-31",)
        mock_own_account.ip_holding_balance_own = (Decimal("2000.00"),)
        mock_own_account.ip_proceed_amount_own = (Decimal("1500.75"),)
        mock_own_account.ip_tax_amount_own = (Decimal("150.08"),)
        mock_own_account.ip_net_amount_own = (Decimal("1350.67"),)
        mock_own_account.ip_ca_id = ("CA-13579",)
        mock_own_account.ip_acct_id = ("ACCT-24680",)
        mock_own_account.tax_rate_own = Decimal("11.1")

        expected_data = OwnAccountData(
            OWN_ACCOUNT=("ABC-123",),
            OWN_ACCOUNT_DESC=("Savings Account",),
            RECORD_BALANCE_OWN=(Decimal("1000.50"),),
            TAX_PCT="11.1 %",
            ENTITLEMENT_DEP_ACCT_OWN=("DEP-987",),
            CF_INSTRUMENT_SHORT_OWN=("Short Name",),
            ENTITLEMENT_AMT_GROSS_OWN=(Decimal("500.25"),),
            ENTITLEMENT_AMT_NET_OWN=(Decimal("450.22"),),
            ENTITLEMENT_AMT_TAX=(Decimal("50.03"),),
            CF_ENTITLEMENT_FRAC="3/4",
            HOLDING_PERIOD_OWN1=(30,),
            START_HOLDING_PERIOD_OWN1=("2023-01-01",),
            END_HOLDING_PERIOD_OWN1=("2023-01-31",),
            HOLDING_BALANCE_OWN1=(Decimal("2000.00"),),
            NET_AMOUNT_OWN1=(Decimal("1350.67"),),
            PROCEED_AMOUNT_OWN1=(Decimal("1500.75"),),
            TAX_AMOUNT_OWN1=(Decimal("150.08"),),
        )

        result = map_own_account_data(mock_own_account)
        self.assertEqual(
            result.__dict__.keys(), expected_data.__dataclass_fields__.keys()
        )
        self.assertEqual(result, expected_data)

    def test_map_client_account_data(self):
        client_account = MagicMock(spec=ClientData)
        client_account.client_acct_id = "CLIENT-123"
        client_account.client_mem_id = "MEMBER-456"
        client_account.client_ata_code = "ATA-789"
        client_account.client_blnc_amt = Decimal("5000.00")
        client_account.client_acct_desc = "Checking Account"
        client_account.new_client_ca_id = "NEW-CA-111"
        client_account.dep_amt_gross = Decimal("2000.50")
        client_account.dep_amt_tax = Decimal("200.05")
        client_account.dep_amt_net = Decimal("1800.45")
        client_account.dep_ordercol = "2"
        client_account.dep_ins_sht_nm = "Deposit Short Name"
        client_account.dep_frac_nom = Decimal("1")
        client_account.dep_frac_denom = Decimal("2")
        client_account.dep_account_id_disp = "DISP-ACC-555"
        client_account.ip_holding_period_client = 60
        client_account.ip_start_date_client = "2023-02-15"
        client_account.ip_end_date_client = "2023-04-15"
        client_account.ip_holding_balance_client = Decimal("10000.25")
        client_account.ip_proceed_amount_client = Decimal("8000.20")
        client_account.ip_tax_amount_client = Decimal("800.02")
        client_account.ip_net_amount_client = Decimal("7200.18")
        client_account.ip_ca_id_client = "IP-CA-999"
        client_account.ip_acct_id_client = "IP-ACCT-888"
        client_account.client_tax_rate = Decimal("11.1")

        expected_data = ClientAccountData(
            CLIENT_ACCOUNT="CLIENT-123",
            CLIENT_ACCOUNT_DESC="Checking Account",
            CLIENT_RECORD_BALANCE=Decimal("5000.00"),
            CLIENT_TAX_PCT="11.1 %",
            CLIENT_DEPOSIT_ACCOUNT="DISP-ACC-555",
            DEP_INSTRUMENT="Deposit Short Name",
            DEP_AMT_GROSS=Decimal("2000.50"),
            DEP_FRAC="1/2",
            DEP_AMT_TAX=Decimal("200.05"),
            NET_PROCEED_AMT_CLIENT=Decimal("1800.45"),
            HOLDING_PERIOD_CLIENT=60,
            START_HOLDING_PERIOD_CLIENT="2023-02-15",
            END_HOLDING_PERIOD_CLIENT="2023-04-15",
            HOLDING_BALANCE_CLIENT=Decimal("10000.25"),
            PROCEED_AMOUNT_CLIENT=Decimal("8000.20"),
            TAX_AMOUNT_CLIENT=Decimal("800.02"),
            NET_AMOUNT_CLIENT=Decimal("7200.18"),
        )

        result = map_client_account_data(client_account)
        self.assertEqual(
            result.__dict__.keys(), expected_data.__dataclass_fields__.keys()
        )
        self.assertEqual(result, expected_data)


class TestGeneratePdfReport(unittest.TestCase):
    def setUp(self):
        self.data = MagicMock()
        self.data.id_ca_capco = "CA42069"
        self.data.id_mem = "ISSUER_TEST"
        self.data.sec = "BOND_TEST"
        self.data.catype = "TEST_PAYMENT"
        self.output_file = os.path.join(
            REPORTS_DIR,
            f"Bond_Issuer_Overview_KSEI{self.data.catype}_{self.data.sec}_{self.data.id_mem}",
        )
        self.json_data = {"key": "value"}

    def test_generate_report(self):
        input_file = os.path.join(RESOURCES_DIR, "Bond_Issuer_Overview.jrxml")
        pdf_file = generate_pdf_report(input_file, self.output_file, self.json_data)

        self.assertTrue(os.path.isfile(pdf_file), "Report file was not created")

        file_size = os.path.getsize(pdf_file)
        self.assertGreater(file_size, 0, "Report file size is 0 KB")


class TestArchivePdfToZip(unittest.TestCase):
    @patch("zipfile.ZipFile")
    @patch("os.path.basename")
    def test_successful_archive(self, mock_basename, mock_zipfile):
        pdf_file = "test.pdf"
        zip_file = "test.zip"
        mock_basename.return_value = pdf_file

        with patch("builtins.print") as mock_print:
            archive_pdf_to_zip(pdf_file)

        mock_zipfile.assert_called_once_with(zip_file, "w", zipfile.ZIP_DEFLATED)
        mock_zipfile.return_value.__enter__().write.assert_called_once_with(
            pdf_file, pdf_file
        )
        # mock_print.assert_called_once_with(
        #     f"Archived {pdf_file} to {zip_file} successfully!"
        # )

    @patch("zipfile.ZipFile")
    def test_exception_handling(self, mock_zipfile):
        pdf_file = "test.pdf"
        mock_zipfile.side_effect = Exception("Test exception")

        with patch("builtins.print") as mock_print:
            archive_pdf_to_zip(pdf_file)

        # mock_print.assert_called_once_with(
        #     f"Failed to archive {pdf_file}: Test exception"
        # )

    def test_file_replacement(self):
        pdf_file = "test.pdf"
        expected_zip_file = "test.zip"

        with patch("zipfile.ZipFile") as mock_zipfile, patch(
            "builtins.print"
        ) as mock_print:
            archive_pdf_to_zip(pdf_file)

        mock_zipfile.assert_called_once_with(
            expected_zip_file, "w", zipfile.ZIP_DEFLATED
        )


if __name__ == "__main__":
    unittest.main()
