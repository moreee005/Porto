import unittest
import os
from pathlib import Path
from unittest.mock import MagicMock, patch
from services.bond_member_entitlement.bond_member_entitlement_db import generate_report

# Paths
RESOURCES_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'report_template', 'bond_member_report')
ASSET_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'asset')
REPORTS_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'output_report')

class TestGenerateReportDB(unittest.TestCase):

    def setUp(self):
        self.conn = MagicMock()
        self.id_mem = 'CC121'
        self.tgl = '09-09-2024'
        self.cf_eff_date = '01-09-2024'
        self.p_since = '20240909'
        self.output_file = os.path.join(REPORTS_DIR, f'{self.id_mem}_Bond_Member_Entitlement_KSEI_{self.p_since}.pdf')
        
        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

    @patch('services.bond_member_entitlement.bond_member_entitlement_db.PyReportJasper')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.map_to_json')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.archive_pdf_to_zip')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.delete_report')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.insert_report')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.os.path.isfile')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.os.remove')
    def test_generate_report_db_success(self, mock_remove, mock_isfile, mock_insert_report, mock_delete_report, mock_archive_pdf_to_zip, mock_map_to_json, mock_PyReportJasper):
        mock_map_to_json.return_value = {'data': 'test'}
        mock_PyReportJasper.return_value.process_report = MagicMock()
        mock_isfile.return_value = True
        
        # Call the function
        result = generate_report(self.id_mem, self.tgl, self.cf_eff_date, self.p_since, self.conn)
        
        # Assertions
        self.assertTrue(result)
        mock_PyReportJasper.assert_called_once()
        mock_archive_pdf_to_zip.assert_called_once()
        mock_delete_report.assert_called_once()
        mock_insert_report.assert_called_once()
        mock_remove.assert_called_once()

    @patch('services.bond_member_entitlement.bond_member_entitlement_db.PyReportJasper')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.map_to_json')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.archive_pdf_to_zip')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.delete_report')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.insert_report')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.os.path.isfile')
    @patch('services.bond_member_entitlement.bond_member_entitlement_db.os.remove')
    def test_generate_report_db_failure(self, mock_remove, mock_isfile, mock_insert_report, mock_delete_report, mock_archive_pdf_to_zip, mock_map_to_json, mock_PyReportJasper):
        mock_map_to_json.return_value = {'data': 'test'}
        mock_isfile.return_value = False
        
        # Call the function
        result = generate_report(self.id_mem, self.tgl, self.cf_eff_date, self.p_since, self.conn)
        
        # Assertions
        self.assertFalse(result)
        mock_PyReportJasper.assert_called_once()
        mock_archive_pdf_to_zip.assert_not_called()
        mock_delete_report.assert_not_called()
        mock_insert_report.assert_not_called()
        mock_remove.assert_not_called()

    def tearDown(self):
        # Clean up the generated files
        if os.path.isfile(self.output_file):
            os.remove(self.output_file)
        if Path(REPORTS_DIR).exists():
            Path(REPORTS_DIR).rmdir()

if __name__ == '__main__':
    unittest.main()
