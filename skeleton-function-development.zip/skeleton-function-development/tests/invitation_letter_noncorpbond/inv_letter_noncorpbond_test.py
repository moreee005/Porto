import unittest
import os
from pathlib import Path
from unittest.mock import MagicMock, patch
import os
from services.invitation_letter_noncorpbond.inv_letter_noncorpbond import generate_report

RESOURCES_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'report_template', 'inv_letter_noncorpbond_report')
ASSET_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'asset')
REPORTS_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'output_report')

class TestGenerateReport(unittest.TestCase):

    def setUp(self):
        self.conn = MagicMock()
        self.data = {'id_ca_capco': 'CA123', 'id_mem': 'MEM123'} 
        self.tgl2 = '20240905'
        self.output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_KTUR_NonCorpBond_{self.tgl2}_{self.data['id_ca_capco']}_{self.data['id_mem']}.pdf")

        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

    @patch('services.invitation_letter_noncorpbond.inv_letter_noncorpbond.fetch_data')
    @patch('services.invitation_letter_noncorpbond.inv_letter_noncorpbond.PyReportJasper')
    @patch('services.invitation_letter_noncorpbond.inv_letter_noncorpbond.Path.mkdir')
    @patch('services.invitation_letter_noncorpbond.inv_letter_noncorpbond.os.path.isfile')
    def test_generate_report(self, mock_isfile, mock_mkdir, mock_pyreportjasper, mock_fetch_data):
        mock_isfile.return_value = True  
        mock_fetch_data.return_value = {'field1': 'value1'}
        
       # Set up the PyReportJasper mock to simulate generating a PDF with dummy content
        mock_pyreport = MagicMock()
        mock_pyreport.config = MagicMock()  
        mock_pyreport.process_report = MagicMock()  
        mock_pyreportjasper.return_value = mock_pyreport

        # Act
        output_file = generate_report(self.data, self.tgl2, self.conn)

        # Assert
        self.assertTrue(output_file.endswith('.pdf'))
        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
        mock_fetch_data.assert_called_once_with('CA123', 'MEM123', self.conn) 
        mock_pyreport.config.assert_called_once()
        mock_pyreport.process_report.assert_called_once() 
        mock_isfile.assert_called_once_with(output_file)
        
        with open(output_file, 'w') as f:
            f.write("Test generator report") 

        file_size = os.path.getsize(output_file)
        self.assertGreater(file_size, 0, "Report file size is 0 KB")

    def tearDown(self):
        pdf_file = self.output_file
        if os.path.isfile(pdf_file):
            os.remove(pdf_file)

        if not os.listdir(REPORTS_DIR): 
            Path(REPORTS_DIR).rmdir()
            
if __name__ == '__main__':
    unittest.main()
