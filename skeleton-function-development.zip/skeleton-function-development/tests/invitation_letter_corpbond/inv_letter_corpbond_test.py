import unittest
import os
from pathlib import Path
from unittest.mock import MagicMock
from services.invitation_letter_corpbond.inv_letter_corpbond import generate_report

RESOURCES_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'report_template', 'inv_letter_corpbond_report')
ASSET_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'asset')
REPORTS_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'resources', 'output_report')

print(REPORTS_DIR)

class TestGenerateReport(unittest.TestCase):

    def setUp(self):
        self.conn = MagicMock()
        self.data = MagicMock()
        self.data.id_ca_capco = 'CA123'
        self.data.id_mem = 'MEM123'
        self.tgl2 = '20240905'
        self.output_file = os.path.join(REPORTS_DIR, f"Invitation_Letter_KSEI_KTUR_CorpBond_{self.tgl2}_{self.data.id_ca_capco}_{self.data.id_mem}.pdf")
        
        Path(REPORTS_DIR).mkdir(parents=True, exist_ok=True)

    def test_generate_report(self):
        pdf_file = generate_report(self.data, self.tgl2, self.conn)
        
        self.assertTrue(os.path.isfile(pdf_file), "Report file was not created")
        
        file_size = os.path.getsize(pdf_file)
        self.assertGreater(file_size, 0, "Report file size is 0 KB")

    def tearDown(self):
        if os.path.isfile(self.output_file):
            os.remove(self.output_file)
        Path(REPORTS_DIR).rmdir()

if __name__ == '__main__':
    unittest.main()
